function pathologyNumberChanged() 
{
	var caseForm = window.opener.document.getElementById('caseForm');
	caseForm.action = "/caelmir/CaseAction.do?target=api";
	caseForm.submit();
}
function addSlide(){
	var table = document.getElementById('slideTable');
	var slideDiv = document.getElementById('slideDiv');
	
		
	arrayOfRows = table.rows;
	row = arrayOfRows[0];
	
	row.cells[0].innerHTML =  slideDiv.innerHTML  ;
	
	document.getElementById('slideIdentifier').value="";
	document.getElementById('slideNumber').value="";
	document.getElementById('stain').value="";
	document.getElementById('tissueMicroscopicDescription').value="";
	document.getElementById('tissueDiagnosis').value="";
		
	  for(i = 0; i < document.getElementById('selectedImage').options.length; i++){
		  document.getElementById('selectedImage').options[i]=null;
	  }
}

function deleteSlide(){
	var tissueForm = document.getElementById('tissueForm');
	document.getElementById('slideDeleted').value = "true";
	tissueForm.submit();
}

function addTissue(){
	var caseForm = document.getElementById('caseForm');
	caseForm.action = "/caelmir/AddTissueFromCaseAction.do";
	var submittedFor = document.getElementById('submittedFor').value;
	
	document.getElementById('submittedFor').value = "ForwardTo";
	
	var forwardTo = document.getElementById('forwardTo').value ;
	document.getElementById('forwardTo').value= 'LoadTissueAction';
	caseForm.submit();
}

function addSlideImage(){
	
	var fileBrowseDiv = document.getElementById('fileBrowseDiv');
	var imageCounter = parseInt(document.getElementById('imageCounter').value);
		
	var str = fileBrowseDiv.innerHTML;
	//alert('before'+str);
	str =str.replace("counter",imageCounter+"");
	str =str.replace("counter",imageCounter+"");
	str =str.replace("counter",imageCounter+"");
	//alert('after'+str)
	imageCounter = imageCounter + 1;
	document.getElementById('imageCounter').value = imageCounter;
	
	var table = document.getElementById('imageFileTable');
	arrayOfRows = table.rows;
	row = arrayOfRows[arrayOfRows.length-1];
	row.cells[0].innerHTML =  str;
	(table.insertRow(arrayOfRows.length)).insertCell(0);
}

function callAction(action)
{
	document.forms[0].action = action;
	document.forms[0].submit();
}

function moveOptionsRight(theSelFrom, theSelTo)
{
	var selLength = theSelFrom.length;
	var selectedText = new Array();
	var selectedValues = new Array();
	var selectedCount = 0;	
	var i;	
	// Find the selected Options in reverse order
	// and delete them from the 'from' Select.
	for(i=selLength-1; i>=0; i--)
	{
		if(theSelFrom.options[i].selected)
		{
			selectedText[selectedCount] = theSelFrom.options[i].text;
			selectedValues[selectedCount] = theSelFrom.options[i].value;
			selectedCount++;
		}
	}	
	// Add the selected text/values in reverse order.
	// This will add the Options to the 'to' Select
	// in the same order as they were in the 'from' Select.
	for(i=selectedCount-1; i>=0; i--)
	{
		addOption(theSelTo, selectedText[i], selectedValues[i]);
	}
}

function moveOptionsLeft(theSelFrom, theSelTo)
{
	var selLength = theSelFrom.length;
	var selectedCount = 0;
	var i;
	for(i=selLength-1; i>=0; i--)
	{
		if(theSelFrom.options[i].selected)
		{
	  		deleteOption(theSelFrom, i);
    	}
	}
}

function addOption(theSel, theText, theValue)
{
	var newOpt = new Option(theText, theValue);
	var selLength = theSel.length;
	var exists="false";
	for(var i=0;i<selLength; i++)
	{
		if(theSel.options[i].value==theValue)
		{
			exists="true";
			break;
		}
	}
	if(exists=="false")
		theSel.options[selLength] = newOpt;
}

function deleteOption(theSel, theIndex)
{ 
	var selLength = theSel.length;
	if(selLength>0)
	{
		theSel.options[theIndex] = null;
    }
}
function slideSelected(){
	var tissueForm = document.getElementById('tissueForm');
	tissueForm.submit();
}

function tissueFormLoad(){

	var slideIdentifier = document.getElementById('slideIdentifier');
	if(slideIdentifier != null && slideIdentifier.value != ""){
		var table = document.getElementById('slideTable');
		var slideDiv = document.getElementById('slideDiv');
		arrayOfRows = table.rows;
		row = arrayOfRows[0];
		row.cells[0].innerHTML =  slideDiv.innerHTML  ;
	}
}

function submitClick(){
	document.getElementById('submitType').value = "submit";
	var tissueForm = document.getElementById('tissueForm');
	tissueForm.submit();	

}
	
function backClick(){
	document.getElementById('submitType').value = "back";
}

function submitBackClick(){
	document.getElementById('submitType').value = "submitback";
}



function editTissue(action){
	var caseForm = document.getElementById('caseForm');
	caseForm.action = action;
	caseForm.submit();
}

function addDataSubmit(){
	var addDataForm = document.getElementById('addDataForm');
	var cohortIdentifier = document.getElementById('cohortIdentifier').value;
	addDataForm.action = "/caelmir/ExperimentalDataIntermediateAction.do?cohort=" + cohortIdentifier;
	addDataForm.submit();
}


function dropDownChanged(){
	var addDataForm = document.getElementById('addDataForm');
	addDataForm.submit();
}

function cohortDropDownChanged()
{
var addDataForm = document.getElementById('addDataForm');
var flag = document.getElementById('cohortChanged');
flag.value = 'true';
addDataForm.submit();
}

function studydropDownChanged()
{
var addDataForm = document.getElementById('addDataForm');
var flag = document.getElementById('studyChanged');
flag.value = 'true';
addDataForm.submit();

}

function submitStudyForm() {

var frm = document.getElementById('studyForm');
frm.action = "/caelmir/AddStudyAction.do?operation=add";
frm.submit();
}

function checkTextareaLength(elementName,length){
 var element = document.getElementById(elementName);
 if(element.value.length > length){
 	alert("Max value is " + length +" only.Please enter correct value" );
 	element.focus();
 }
 
}

function defferedPopup(){

	var url = '/caelmir/DefferedAction.do';
   // var properties = "dialogHeight: 200px; dialogWidth: 350px; dialogTop: 300px; dialogLeft: 350px; edge: Sunken; center: Yes; resizable: NO; status: No; help:no"
  // window.showModalDialog(url, window, properties);

   var remote=null;
	var  args="width=330,height=230,left=200,top=150,resizable=no,scrollbars=no,status=0";
	
	remote=window.open(url,'w',args);
	if (remote != null) 
	{
   	  if (remote.opener == null)
   		remote.opener = self;
  	}  	
}

function showPopup(str,textInput,optionSelect,invokeType,page)
{   
	var str=str;

	var studyId ="";
	
	if(page=="experiment")
//this is required for experiment page to get user,userGroup,protocol from study 
		studyId = document.getElementById('studyID').value;
	
	var url='/caelmir/PopupAction.do?object1='+str+'&textInput='+textInput+'&optionSelect='+optionSelect+'&invokeType='+invokeType+'&page='+page+'&id='+studyId;			
	var  args="width=480,height=330,resizable=no,scrollbars=yes,status=0";
	var param=null;
	
	param = window.open(url,'myWindow',args);	
	//param.moveTo(500,250);
}

function showPopupTiles(str,textInput,optionSelect,invokeType)
{   
	var str=str;
	
	var url='/caelmir/PopupActionTiles.do?object1='+str+'&textInput='+textInput+'&optionSelect='+optionSelect+'&invokeType='+invokeType;			
	var  args="width=500,height=350,resizable=no,scrollbars=yes,status=0";
	var param=null;
	
	param = window.open(url,'myWindow',args);	
	//param.moveTo(500,250);
}

function submitProtocolPopUp()
{
	var title = document.getElementById('protocolTitle').value;
	var protocolId=window.opener.document.getElementById('protocolId').value;
	var action='/caelmir/SaveAsProtocolAction.do?entry='+title+'&protocolId='+protocolId;
	//document.forms[0].action=action;
	//document.forms[0].submit();
	return action;
}

function showSaveAsPopUp()
{
	var url='/caelmir/pages/content/protocol/ProtocolSaveAs.jsp';
	var args="width=400,height=150,left=250,top=200,resizable=no,scrollbars=no,status=0";
	var param = window.open(url,'myWindow',args);
}

function handEnroll()
{
	var url='/caelmir/EnrollAnimal.do?operation=add&pageOf=success';
	var param;
	var args="width=540,height=400,resizable=yes,scrollbars=yes,status=0";
	param =  window.open(url,'myWin1',args);
}



function showCloseConfirmation(str,operation) 
{
	var  args='width=330,height=150,left=200,top=150,resizable=no,scrollbars=no,status=0';
	var url = "/caelmir/CloseOperation.do?key=" + str + "&purpose=" + operation+ "";
	window.open(url ,'w', args);
}

function navigateToCloseObject() 
{
	var newStatus = document.getElementById('status').value;
	var status = window.opener.document.getElementById('activityStatus');
	
	var deleteCohortFlag = document.getElementById('deleteCohorts');
	
	var flag = window.opener.document.getElementById('deleteCohortFlag');
	
	if (flag != null && deleteCohortFlag != null &&  deleteCohortFlag.checked == true)
	{
		flag.value = deleteCohortFlag.value;		
	}		
			
	status.value = newStatus;	
	var frm = window.opener.document.forms[0];	
	frm.submit();
	self.close();
}


function checkForExpDataForCohort()
{
	var expDataFlag = document.getElementById('expDataFlag').value;	
	
	if(expDataFlag=="true")//if true then say can't delete cohort
		showCloseConfirmation('delete.cohort.ExpDataFlag.confirmation','donotdelete');
	else
		showCloseConfirmation('delete.cohort.confirmation','delete');
		
}


function checkForExpData()
{
	var expDataFlag = document.getElementById('expDataFlag').value;	
	
	if(expDataFlag=="false")
		showCloseConfirmation('close.experiment.ExpDataFlag.confirmation','close');
	else
		showCloseConfirmation('close.experiment.confirmation','close');
		
}


function checkForStudyDataForModel()
{

var studyDataFlag = document.getElementById('studyDataFlag').value;	
	
	if(studyDataFlag=="true")//if true then say can't delete model
		showCloseConfirmation('delete.model.StudyDataFlag.confirmation','donotdelete');
	else
		showCloseConfirmation('delete.model.confirmation','delete');
		
}

function checkForAnimalDataForGenus()
{
var animalDataFlag = document.getElementById('animalDataFlag').value;	
	
	if(animalDataFlag=="true")//if true then say can't delete genus
		showCloseConfirmation('delete.genus.AnimalDataFlag.confirmation','donotdelete');
	else
		showCloseConfirmation('delete.genus.confirmation','delete');
		
}
function checkForAnimalDataForSpecies()
{
var animalDataFlag = document.getElementById('animalDataFlag').value;	
	
	if(animalDataFlag=="true")//if true then say can't delete species
		showCloseConfirmation('delete.species.AnimalDataFlag.confirmation','donotdelete');
	else
		showCloseConfirmation('delete.species.confirmation','delete');
}

function checkForCohortDataForAnimal()
{
var cohortDataFlag = document.getElementById('cohortDataFlag').value;	
	
	if(cohortDataFlag=="true")//if true then say can't delete animal
		showCloseConfirmation('delete.animal.CohortDataFlag.confirmation','donotdelete');
	else
		showCloseConfirmation('delete.animal.confirmation','delete');

}




function edit(pageOf)
{
	
    var frm = document.forms[0];
	var action="/caelmir/SearchObject.do?pageOf=" +pageOf+ "&operation=search&id="+document.forms[0].systemIdentifier.value;
	frm.action=action;
    frm.submit();
}

function editPage(pageOf,id)
{
 	var frm = document.forms[0];
	 var selectBox= document.getElementById(id);	
	 var destination = selectBox.options[selectBox.selectedIndex].value;	

	var action;
	 if(pageOf == "pageOfTissue")
	 {
	    //var animID = document.getElementById("animalId").value;
	    action="/caelmir/LoadActionTissue.do?pageOf="+pageOf+ "&operation=edit&id="+destination;
	    
	 }
	 else
	 {
//  			    var animID = document.getElementById("animalId").value;
  		action="/caelmir/LoadActionSlide.do?pageOf="+pageOf+ "&operation=edit&id="+destination;
  	  }
	 
// 	 var action="/caelmir/SearchObject.do?pageOf=" +pageOf+ "&operation=search&id="+destination;

//alert('f'+action);

	 frm.action=action;
     frm.submit();
}


function removeCheckedRow(id)
{   
    var table = document.getElementById(id);
    var inputArray = table.getElementsByTagName('input');	
	var len=inputArray.length;
	var i=0;
	for (k = 0; k < len; k++) 
	{
	   var inputArray = table.getElementsByTagName('input');				
	   if (inputArray[i].checked ) 
	   {			  
			   table.deleteRow((i+1));			  				
				k=0;
				i=0;			          
	   }
	   else i++;
	}
}

function checkchkBox(id)
{
    // without checked add into cohort
    //alert("in submit action");
    var table = document.getElementById(id);
    var inputArray = table.getElementsByTagName('input');	
	for (k = 0; k < inputArray.length; k++) 
	{
	   if (inputArray[k].type = "checkbox") 
	   {	
	       inputArray[k].checked = true;
	      // alert("checked");
	   }
    } 
}

function submitAction(id)
{
    // without checked add into cohort
    //alert("in submit action");
    var table = document.getElementById(id);
    var inputArray = table.getElementsByTagName('input');	
	for (k = 0; k < inputArray.length; k++) 
	{
	   if (inputArray[k].type = "checkbox") 
	   {	
	       inputArray[k].checked = true;
	      // alert("checked");
	   }
    } 
    var frm = document.forms[0];    	
    frm.submit();
}


function method(str,textInput,optionSelect,invokeType,act,pageOf,studyId)
{
	//pageOf, studyId is required in experiment page to show user,usergroup,protocol selected for its study
	var obj = document.getElementById(str);
	
	var textInput = document.getElementById(textInput);
     var url;
	if(obj.value == "animalList")
		url='/caelmir/'+act.value+'.do?object1='+obj.value+'&textInput='+textInput.value+'&optionSelect='+optionSelect+'&invokeType='+invokeType.value;					
	else
	    url='/caelmir/PopupAction.do?object1='+obj.value+'&textInput='+textInput.value+'&optionSelect='+optionSelect+'&invokeType='+invokeType.value+'&page='+pageOf.value+'&id='+studyId.value;				
	//alert(obj.value);
    return  url;
 
}

function submitStudy () 
{
	var stopDate = document.getElementById('investigationEndDate');
	if (stopDate != null && stopDate.value != null && replaceAllSpaces(stopDate.value) != "")
	{
		showCloseConfirmation('close.study.confirmation','close');
		return;
	}
	else 
	{
		document.forms[0].submit();
	}

}

function replaceAllSpaces(str)
{
	while(str.indexOf(" ") != -1)
	{
	str = str.replace(/ /,"");
	
	}
	return str;
}

function refreshExperiment() 
{
	var experimentForm = document.getElementById('experimentForm');
	var studySel = document.getElementById('studyOp');
	var studyId = studySel.options[studySel.selectedIndex].value;
	experimentForm.action="/caelmir/Experiment.do?operation=add&pageOf=pageOfExperiment&studyIdentifier="+studyId;
	experimentForm.submit();

}

function refreshAnimal() 
{
	var mouseForm = document.getElementById('mouseForm');
	var genusIdentifier = document.getElementById('genusId').value
	mouseForm.action="/caelmir/EnrollAnimal.do?operation=add&pageOf=PageOfAddAnimal&genusId="+genusIdentifier;
	mouseForm.submit();

}



function submitForAddCohortFromExperimentalData (basicAction) 
{
	var action = basicAction;
	var experimentIdentifier = document.getElementById('experimentIdentifier').value;
	var studyIdentifier = document.getElementById('studyIdentifier').value;
	action = action + "&experimentIdentifier=" + experimentIdentifier + "&studyIdentifier=" + studyIdentifier;

	document.forms[0].action = action;
	document.forms[0].submit();

}

function submitForAddExperimentFromExperimentalData (basicAction) 
{
	var action = basicAction;
	var experimentIdentifier = document.getElementById('studyIdentifier').value;
	var studyIdentifier = document.getElementById('studyIdentifier').value;
	action = action + "&studyIdentifier=" + studyIdentifier;

	document.forms[0].action = action;
	document.forms[0].submit();

}

function animalClicked(ths)
{

	var id = ths.id;
	
	document.getElementById("animNum").value =	ths.innerHTML;

	
	var animalIdentifier = document.getElementById('animalIdentifier');
	
	if (id == animalIdentifier.value)
	{
		animalIdentifier.value = "";
		ths.className = "animalStyle";
	}
	else 
	{
		ths.className = "animalClickedClass";
		var previousAnimal = animalIdentifier.value;
		if (document.getElementById(previousAnimal+""))
		{
			document.getElementById(previousAnimal).className = "animalStyle";
		}
		animalIdentifier.value = id;

		var currentURL=	frames["eventRecordFrame"].location.href;
		//alert(currentURL);
		if(currentURL.indexOf("blank") == -1 ) //if blank not thr
		{
			if(currentURL.indexOf("animalId") != -1 )
			{
				var splitURL=currentURL.split("animalId");	
				//alert('hi: '+splitURL);
				if(splitURL[0] != null) 
				{
					splitURL[0] = splitURL[0] + "animalId="+id;				
					frames["eventRecordFrame"].location.href =splitURL[0];					
					//="http://localhost:8080/caelmir/CaseAction.do?operation=addOrEdit&eventId=1&protocolId=1&entityMapId=2&animalId=21";
				}
			}
			else
				frames["eventRecordFrame"].location.href ="about:blank";
		}
	}
}

function checkEntry()
{
	
	var textContent  = document.getElementById("title").value;

	var action="/caelmir/CheckEntry.do?entry="+textContent;
	document.forms[0].action = action;
	document.forms[0].submit();

}

function cancel()
{
	history.go(-1);
}


function checkForAddNew()
{
	var attr = document.getElementById("submittedFor").value;
//	alert(attr);
	if(attr == "AddNew")
	{
	  	var action="/caelmir/BlockAddNewAction.do?";
		document.forms[0].action = action;
		document.forms[0].submit();
	}
	else
	    cancel();
}


function checkForCancel()
{
	var attr = document.getElementById("addnew").value;
//	alert(attr);
	if(attr == "AddNew")
	{
	  	var action="/caelmir/BlockAddNewAction.do?";
		document.forms[0].action = action;
		document.forms[0].submit();
	}
	else
	    cancel();
}

function checkForSlideAddNew()
{
	var attr = document.getElementById("submittedFor").value;
	var attr1 = document.getElementById("forwardTo").value;
	//alert(attr);// +"f "+ attr1);
	//alert(attr1);
	if(attr == "AddNew" && attr1 != "success")
	{
		  	var action="/caelmir/BlockAddNewAction.do?";
			document.forms[0].action = action;
			document.forms[0].submit();
	
	}
	else
	   history.back();
}

function makeGetMethod()
{
	
//alert(document.forms[0].method);

	//document.forms[0].method ="get";

}

//function makeGet()
//{	
//	alert(document.forms[0].method);

//	document.slideForm.method ="get";

//}

