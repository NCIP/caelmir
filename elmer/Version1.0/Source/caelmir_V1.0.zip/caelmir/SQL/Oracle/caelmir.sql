alter table CAELMIR_TISSUE drop constraint FK2FC4DE532206F20F;
alter table CAELMIR_TISSUE drop constraint FK2FC4DE534BDEEC8A;
alter table CAELMIR_COLLECTION_PROTOCOL drop constraint FK1F32506B2206F20F;
alter table CAELMIR_COLLECTION_PROTOCOL drop constraint FK1F32506BBC7298A9;
alter table CAELMIR_PROTEOMICS drop constraint FKCABEA34BBC7298A9;
alter table CAELMIR_USER_GROUP_REL drop constraint FKAACACA932206F20F;
alter table CAELMIR_USER_GROUP_REL drop constraint FKAACACA93637E40EF;
alter table CAELMIR_PROTOCOL_EVENT drop constraint FK6E1ED58148304401;
alter table CAELMIR_STUDY drop constraint FKD837167B9C0A211;
alter table CAELMIR_STUDY drop constraint FKD837167B2206F20F;
alter table CAELMIR_STUDY drop constraint FKD837167BA45AA914;
alter table CAELMIR_STUDY_USER drop constraint FK140D5B0F2206F20F;
alter table CAELMIR_STUDY_USER drop constraint FK140D5B0F9E810B71;
alter table CAELMIR_EXPERIMENT_PROTOCOL drop constraint FK1721BDEC48304401;
alter table CAELMIR_EXPERIMENT_PROTOCOL drop constraint FK1721BDECCE37489D;
alter table CAELMIR_SPECIES drop constraint FK9F15E16E9B70612C;
alter table CAELMIR_EVENT_RECORDS drop constraint FK22FAC02FE8BFDA3E;
alter table CAELMIR_EVENT_RECORDS drop constraint FK22FAC02F2206F20F;
alter table CAELMIR_EVENT_RECORDS drop constraint FK22FAC02F11B8FADA;
alter table CAELMIR_ANIMAL drop constraint FKF9A9B6AE1AA3B1E;
alter table CAELMIR_ANIMAL drop constraint FKF9A9B6A48A08DA5;
alter table CAELMIR_ANIMAL drop constraint FKF9A9B6A9B70612C;
alter table CAELMIR_COHORT drop constraint FK1311F963CE37489D;
alter table CAELMIR_COHORT drop constraint FK1311F9632206F20F;
alter table CAELMIR_MICROARRAY_ER drop constraint FKDEC80DE9BC7298A9;
alter table CAELMIR_MOUSE drop constraint FKD7E04557BC7298A9;
alter table CAELMIR_EXPERIMENT drop constraint FK296F7A6B9E810B71;
alter table CAELMIR_EXPERIMENT drop constraint FK296F7A6B8519D8DC;
alter table CAELMIR_IMAGE drop constraint FKD7A6B20D5D2FD13C;
alter table CAELMIR_IMAGE drop constraint FKD7A6B20DFEC042B5;
alter table CAELMIR_IMAGE drop constraint FKD7A6B20D808A4B7A;
alter table CAELMIR_IMAGE drop constraint FKD7A6B20DE2CBF289;
alter table CAELMIR_SLIDE drop constraint FKD8334663FEC042B5;
alter table CAELMIR_SLIDE drop constraint FKD83346632206F20F;
alter table CAELMIR_ANIMAL_GENOTYPE drop constraint FK1C0E000EE8BFDA3E;
alter table CAELMIR_ANIMAL_GENOTYPE drop constraint FK1C0E000E5682A041;
alter table CAELMIR_USER drop constraint FK935D80B96CD94566;
alter table CAELMIR_USER drop constraint FK935D80B9808A4B7A;
alter table CAELMIR_USER drop constraint FK935D80B91792AD22;
alter table CAELMIR_STUDY_GROUP drop constraint FK6CD86F9B9E810B71;
alter table CAELMIR_STUDY_GROUP drop constraint FK6CD86F9B637E40EF;
alter table CAELMIR_STUDY_PROTOCOL_REL drop constraint FK2477D19648304401;
alter table CAELMIR_STUDY_PROTOCOL_REL drop constraint FK2477D1969E810B71;
alter table CAELMIR_PATHOLOGY_ER drop constraint FK781DE65BBC7298A9;
alter table CAELMIR_USERPREFERENCE drop constraint FK7BA956542206F20F;
alter table CAELMIR_ENTITY_MAP drop constraint FKD634394E53B01F66;
alter table CAELMIR_EXPERIMENT_GROUP drop constraint FK94D21F8B637E40EF;
alter table CAELMIR_EXPERIMENT_GROUP drop constraint FK94D21F8BCE37489D;
alter table CAELMIR_EXPERIMENT_USER drop constraint FK4F25ED1FCE37489D;
alter table CAELMIR_EXPERIMENT_USER drop constraint FK4F25ED1F2206F20F;
drop table CAELMIR_ADDRESS cascade constraints;
drop table CAELMIR_TISSUE cascade constraints;
drop table CAELMIR_COLLECTION_PROTOCOL cascade constraints;
drop table CAELMIR_PROTEOMICS cascade constraints;
drop table CAELMIR_USER_GROUP_REL cascade constraints;
drop table CAELMIR_ANIMAL_IMPORT cascade constraints;
drop table CAELMIR_IMAGE_TYPE cascade constraints;
drop table CAELMIR_PROTOCOL_EVENT cascade constraints;
drop table CAELMIR_STUDY cascade constraints;
drop table CAELMIR_TGMOUSE cascade constraints;
drop table CAELMIR_STUDY_USER cascade constraints;
drop table CAELMIR_MODEL cascade constraints;
drop table CAELMIR_EXPERIMENT_PROTOCOL cascade constraints;
drop table CAELMIR_SPECIES cascade constraints;
drop table CAELMIR_EVENT_RECORDS cascade constraints;
drop table CAELMIR_ANIMAL cascade constraints;
drop table CAELMIR_COHORT cascade constraints;
drop table CAELMIR_GENOTYPE cascade constraints;
drop table CAELMIR_MICROARRAY_ER cascade constraints;
drop table CAELMIR_MOUSE cascade constraints;
drop table CAELMIR_EXPERIMENT cascade constraints;
drop table CAELMIR_SPECIMEN_PROTOCOL cascade constraints;
drop table CAELMIR_IMAGE cascade constraints;
drop table CAELMIR_SLIDE cascade constraints;
drop table CAELMIR_ANIMAL_GENOTYPE cascade constraints;
drop table CAELMIR_USER_GROUP cascade constraints;
drop table CAELMIR_USER cascade constraints;
drop table CAELMIR_STUDY_GROUP cascade constraints;
drop table CAELMIR_STUDY_PROTOCOL_REL cascade constraints;
drop table CAELMIR_REPORTED_PROBLEM cascade constraints;
drop table CAELMIR_PATHOLOGY_ER cascade constraints;
drop table CAELMIR_USERPREFERENCE cascade constraints;
drop table CAELMIR_ENTITY_MAP cascade constraints;
drop table CAELMIR_EXPERIMENT_GROUP cascade constraints;
drop table CAELMIR_GENUS cascade constraints;
drop table CAELMIR_EXPERIMENT_USER cascade constraints;
drop table CAELMIR_INSTITUTION cascade constraints;
drop sequence CAELMIR_MODEL_SEQ;
drop sequence CAELMIR_ADDRESS_SEQ;
drop sequence CAELMIR_SPECIES_SEQ;
drop sequence CAELMIR_SPECIMEN_PROTOCOL_SEQ;
drop sequence CAELMIR_USER_SEQ;
drop sequence CAELMIR_COHORT_SEQ;
drop sequence CAELMIR_EXPERIMENT_SEQ;
drop sequence CAELMIR_USER_GROUP_SEQ;
drop sequence CAELMIR_ANIMAL_SEQ;
drop sequence CAELMIR_INSTITUTION_SEQ;
drop sequence CAELMIR_GENUS_SEQ;
drop sequence CAELMIR_REPORTED_PROBLEM_SEQ;
drop sequence CAELMIR_TISSUE_SEQ;
drop sequence CAELMIR_EVENT_RECORD_SEQ;
drop sequence CAELMIR_SLIDE_SEQ;
drop sequence CAELMIR_PROTOCOL_EVENT_SEQ;
drop sequence CAELMIR_GENOTYPE_SEQ;
drop sequence CAELMIR_IMAGE_SEQ;
drop sequence CAELMIR_ENTITY_MAP_SEQ;
drop sequence CAELMIR_USERPREFERENCE_SEQ;
drop sequence CAELMIR_IMAGE_TYPE_SEQ;
drop sequence CAELMIR_STUDY_SEQ;
create table CAELMIR_ADDRESS (
   IDENTIFIER number(19,0) not null,
   STREET varchar2(50),
   CITY varchar2(50),
   STATE varchar2(50),
   COUNTRY varchar2(50),
   ZIPCODE varchar2(30),
   primary key (IDENTIFIER)
);
create table CAELMIR_TISSUE (
   IDENTIFIER number(19,0) not null,
   TISSUE_LONG_NAME varchar2(100),
   TISSUE_SHORT_NAME varchar2(50),
   CREATED_DATE date,
   ACTIVITY_STATUS varchar2(50),
   USER_ID number(19,0),
   CASE_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_COLLECTION_PROTOCOL (
   IDENTIFIER number(19,0) not null,
   USER_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_PROTEOMICS (
   IDENTIFIER number(19,0) not null,
   DATA_FILE blob,
   REFERENCE_ID number(19,0),
   DESCRIPTION varchar2(2000),
   CONTENT_TYPE varchar2(30),
   FILE_NAME varchar2(100),
   FILE_SIZE number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_USER_GROUP_REL (
   USER_ID number(19,0) not null,
   USER_GROUP_ID number(19,0) not null,
   primary key (USER_GROUP_ID, USER_ID)
);
create table CAELMIR_ANIMAL_IMPORT (
   ANIMAL_INDEX number(19,0) not null,
   BIRTH_DATE date,
   EAR_CODE varchar2(32),
   GENOTYPE varchar2(16),
   SEX varchar2(32),
   STAIN varchar2(128),
   primary key (ANIMAL_INDEX)
);
create table CAELMIR_IMAGE_TYPE (
   IDENTIFIER number(19,0) not null,
   IMAGE_NAME varchar2(50),
   DESCRIPTION varchar2(200),
   primary key (IDENTIFIER)
);
create table CAELMIR_PROTOCOL_EVENT (
   IDENTIFIER number(19,0) not null,
   STUDY_CALENDAR_EVENT_POINT varchar2(255),
   COLLECTION_PROTOCOL_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_STUDY (
   IDENTIFIER number(19,0) not null,
   MODEL_ID number(19,0),
   CREATED_DATE date,
   NAME varchar2(150),
   HYPOTHESIS varchar2(250),
   DESCRIPTION varchar2(255),
   INVESTIGATION_START_DATE date,
   INVESTIGATION_STOP_DATE date,
   ACTIVITY_STATUS varchar2(10),
   USER_ID number(19,0),
   PRIMARY_INVESTIGATOR_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_TGMOUSE (
   pathnum varchar2(20) not null,
   diagnosis varchar2(254),
   micro varchar2(300),
   primary key (pathnum)
);
create table CAELMIR_STUDY_USER (
   USER_ID number(19,0) not null,
   STUDY_ID number(19,0) not null,
   primary key (STUDY_ID, USER_ID)
);
create table CAELMIR_MODEL (
   IDENTIFIER number(19,0) not null,
   MODEL_REFERENCE_NUMBER number(19,0),
   MODEL_NAME varchar2(100),
   MODEL_DESCRIPTION_URL varchar2(1000),
   ACTIVITY_STATUS varchar2(10),
   primary key (IDENTIFIER)
);
create table CAELMIR_EXPERIMENT_PROTOCOL (
   COLLECTION_PROTOCOL_ID number(19,0) not null,
   EXPERIMENT_ID number(19,0) not null,
   primary key (EXPERIMENT_ID, COLLECTION_PROTOCOL_ID)
);
create table CAELMIR_SPECIES (
   IDENTIFIER number(19,0) not null,
   GENUS_ID number(19,0),
   SPECIES_NAME varchar2(100),
   ACTIVITY_STATUS varchar2(10),
   primary key (IDENTIFIER)
);
create table CAELMIR_EVENT_RECORDS (
   IDENTIFIER number(19,0) not null,
   ENTITY_RECORD_ID number(19,0),
   CREATED_DATE date,
   MODIFIED_DATE date,
   ACTIVITY_STATUS varchar2(10),
   USER_ID number(19,0),
   ANIMAL_ID number(19,0),
   NAME varchar2(100),
   ENTITY_MAP_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_ANIMAL (
   IDENTIFIER number(19,0) not null,
   GENUS_ID number(19,0),
   SPECIES_ID number(19,0),
   ANIMAL_NUMBER varchar2(100),
   BACKGROUND_STRAIN varchar2(100),
   STRAIN varchar2(100),
   BIRTH_DATE date,
   SEX char(1),
   LENGTH double precision,
   WEIGHT double precision,
   ACTIVITY_STATUS varchar2(10),
   COHORT_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_COHORT (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(150),
   EXPERIMENTAL_CONDITION varchar2(255),
   CREATED_DATE date,
   ACTIVITY_STATUS varchar2(10),
   USER_ID number(19,0),
   EXPERIMENT_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_GENOTYPE (
   IDENTIFIER number(19,0) not null,
   GENE_NAME varchar2(150),
   GENOTYPE varchar2(50),
   PROMOTER varchar2(50),
   GENE_IDENTIFIER varchar2(50),
   primary key (IDENTIFIER)
);
create table CAELMIR_MICROARRAY_ER (
   IDENTIFIER number(19,0) not null,
   DATA_FILE blob,
   REFERENCE_ID number(19,0),
   DESCRIPTION varchar2(2000) unique,
   CONTENT_TYPE varchar2(30),
   FILE_NAME varchar2(100),
   FILE_SIZE number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_MOUSE (
   IDENTIFIER number(19,0) not null,
   GENE_OF_INTEREST varchar2(100),
   ANIMAL_COLONY_REFERENCE varchar2(100),
   primary key (IDENTIFIER)
);
create table CAELMIR_EXPERIMENT (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(150),
   HYPOTHESIS varchar2(255),
   STUDY_REQUIREMENTS varchar2(255),
   EXPERIMENT_START_DATE date,
   EXPERIMENT_STOP_DATE date,
   ACTIVITY_STATUS varchar2(10),
   CREATOR_USER_ID number(19,0),
   STUDY_ID number(19,0),
   CREATED_DATE date,
   primary key (IDENTIFIER)
);
create table CAELMIR_SPECIMEN_PROTOCOL (
   IDENTIFIER number(19,0) not null,
   TITLE varchar2(100),
   IRB_IDENTIFIER number(19,0),
   SHORT_TITLE varchar2(20),
   END_DATE date,
   ACTIVITY_STATUS varchar2(10),
   START_DATE date,
   DESCRIPTION_URL varchar2(100),
   primary key (IDENTIFIER)
);
create table CAELMIR_IMAGE (
   IDENTIFIER number(19,0) not null,
   CONTENT_TYPE varchar2(30),
   FILE_NAME varchar2(100),
   FILE_SIZE number(19,0),
   CREATED_DATE date,
   IMAGE blob,
   ACTIVITY_STATUS varchar2(10),
   PARENT_USER_ID number(19,0),
   IMAGE_TYPE_ID number(19,0),
   SLIDE_ID number(19,0),
   TISSUE_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_SLIDE (
   IDENTIFIER number(19,0) not null,
   CREATED_DATE date,
   DIAGNOSIS varchar2(100),
   MICROSCOPIC_DESCRIPTION varchar2(500),
   SLIDE_NUMBER varchar2(5),
   STAIN varchar2(50),
   ACTIVITY_STATUS varchar2(10),
   USER_ID number(19,0),
   TISSUE_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_ANIMAL_GENOTYPE (
   ANIMAL_ID number(19,0) not null,
   GENOTYPE_ID number(19,0) not null,
   primary key (ANIMAL_ID, GENOTYPE_ID)
);
create table CAELMIR_USER_GROUP (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(150),
   DESCRIPTION varchar2(255),
   ACTIVITY_STATUS varchar2(50),
   USER_ROLE_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_USER (
   IDENTIFIER number(19,0) not null,
   FIRST_NAME varchar2(50),
   LAST_NAME varchar2(50),
   INITIALS varchar2(50),
   CSM_USER_ID number(19,0),
   DEPARTMENT varchar2(50),
   EMAIL_ADDRESS varchar2(50),
   LOGIN_NAME varchar2(50) not null unique,
   PASSWORD varchar2(50),
   CREATED_DATE date,
   COMMENTS varchar2(2000),
   FAX_NUMBER varchar2(50),
   PHONE_NUMBER varchar2(50),
   PHONE_POST_HOUR varchar2(50),
   ACTIVITY_STATUS varchar2(10),
   ROLE_ID number(19,0),
   CMS_ID varchar2(20),
   INSTITUTION_ID number(19,0),
   PARENT_USER_ID number(19,0),
   ADDRESS_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_STUDY_GROUP (
   USER_GROUP_ID number(19,0) not null,
   STUDY_ID number(19,0) not null,
   primary key (STUDY_ID, USER_GROUP_ID)
);
create table CAELMIR_STUDY_PROTOCOL_REL (
   COLLECTION_PROTOCOL_ID number(19,0) not null,
   STUDY_ID number(19,0) not null,
   primary key (STUDY_ID, COLLECTION_PROTOCOL_ID)
);
create table CAELMIR_REPORTED_PROBLEM (
   IDENTIFIER number(19,0) not null,
   AFFILIATION varchar2(200) not null,
   NAME_OF_REPORTER varchar2(200) not null,
   REPORTERS_EMAIL_ID varchar2(50) not null,
   MESSAGE_BODY varchar2(200) not null,
   SUBJECT varchar2(100),
   REPORTED_DATE date,
   ACTIVITY_STATUS varchar2(100),
   COMMENTS varchar2(2000),
   primary key (IDENTIFIER)
);
create table CAELMIR_PATHOLOGY_ER (
   IDENTIFIER number(19,0) not null,
   DIAGNOSIS varchar2(3000),
   GROSS varchar2(300),
   MICROSCOPIC_DESCRIPTION varchar2(3000),
   pathnum varchar2(20),
   SUBMITTED_DATE date,
   primary key (IDENTIFIER)
);
create table CAELMIR_USERPREFERENCE (
   IDENTIFIER number(19,0) not null,
   PREFERENCE_Name varchar2(100),
   PREFERENCE_VALUE varchar2(100),
   USER_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_ENTITY_MAP (
   IDENTIFIER number(19,0) not null,
   ENTITY_REFERENCE_ID number(19,0),
   COLLECTION_PROTOCOL_EVENT_ID number(19,0),
   primary key (IDENTIFIER)
);
create table CAELMIR_EXPERIMENT_GROUP (
   USER_GROUP_ID number(19,0) not null,
   EXPERIMENT_ID number(19,0) not null,
   primary key (EXPERIMENT_ID, USER_GROUP_ID)
);
create table CAELMIR_GENUS (
   IDENTIFIER number(19,0) not null,
   GENUS_NAME varchar2(100),
   ACTIVITY_STATUS varchar2(10),
   primary key (IDENTIFIER)
);
create table CAELMIR_EXPERIMENT_USER (
   USER_ID number(19,0) not null,
   EXPERIMENT_ID number(19,0) not null,
   primary key (EXPERIMENT_ID, USER_ID)
);
create table CAELMIR_INSTITUTION (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(150) not null unique,
   INSTITUTION_CODE varchar2(50),
   PHONE_NUMBER varchar2(50),
   WEBSITE_URL varchar2(50),
   ACTIVITY_STATUS varchar2(10),
   primary key (IDENTIFIER)
);
alter table CAELMIR_TISSUE add constraint FK2FC4DE532206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_TISSUE add constraint FK2FC4DE534BDEEC8A foreign key (CASE_ID) references CAELMIR_PATHOLOGY_ER;
alter table CAELMIR_COLLECTION_PROTOCOL add constraint FK1F32506B2206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_COLLECTION_PROTOCOL add constraint FK1F32506BBC7298A9 foreign key (IDENTIFIER) references CAELMIR_SPECIMEN_PROTOCOL;
alter table CAELMIR_PROTEOMICS add constraint FKCABEA34BBC7298A9 foreign key (IDENTIFIER) references CAELMIR_EVENT_RECORDS;
alter table CAELMIR_USER_GROUP_REL add constraint FKAACACA932206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_USER_GROUP_REL add constraint FKAACACA93637E40EF foreign key (USER_GROUP_ID) references CAELMIR_USER_GROUP;
alter table CAELMIR_PROTOCOL_EVENT add constraint FK6E1ED58148304401 foreign key (COLLECTION_PROTOCOL_ID) references CAELMIR_COLLECTION_PROTOCOL;
alter table CAELMIR_STUDY add constraint FKD837167B9C0A211 foreign key (MODEL_ID) references CAELMIR_MODEL;
alter table CAELMIR_STUDY add constraint FKD837167B2206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_STUDY add constraint FKD837167BA45AA914 foreign key (PRIMARY_INVESTIGATOR_ID) references CAELMIR_USER;
alter table CAELMIR_STUDY_USER add constraint FK140D5B0F2206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_STUDY_USER add constraint FK140D5B0F9E810B71 foreign key (STUDY_ID) references CAELMIR_STUDY;
alter table CAELMIR_EXPERIMENT_PROTOCOL add constraint FK1721BDEC48304401 foreign key (COLLECTION_PROTOCOL_ID) references CAELMIR_COLLECTION_PROTOCOL;
alter table CAELMIR_EXPERIMENT_PROTOCOL add constraint FK1721BDECCE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT;
alter table CAELMIR_SPECIES add constraint FK9F15E16E9B70612C foreign key (GENUS_ID) references CAELMIR_GENUS;
alter table CAELMIR_EVENT_RECORDS add constraint FK22FAC02FE8BFDA3E foreign key (ANIMAL_ID) references CAELMIR_ANIMAL;
alter table CAELMIR_EVENT_RECORDS add constraint FK22FAC02F2206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_EVENT_RECORDS add constraint FK22FAC02F11B8FADA foreign key (ENTITY_MAP_ID) references CAELMIR_ENTITY_MAP;
alter table CAELMIR_ANIMAL add constraint FKF9A9B6AE1AA3B1E foreign key (SPECIES_ID) references CAELMIR_SPECIES;
alter table CAELMIR_ANIMAL add constraint FKF9A9B6A48A08DA5 foreign key (COHORT_ID) references CAELMIR_COHORT;
alter table CAELMIR_ANIMAL add constraint FKF9A9B6A9B70612C foreign key (GENUS_ID) references CAELMIR_GENUS;
alter table CAELMIR_COHORT add constraint FK1311F963CE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT;
alter table CAELMIR_COHORT add constraint FK1311F9632206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_MICROARRAY_ER add constraint FKDEC80DE9BC7298A9 foreign key (IDENTIFIER) references CAELMIR_EVENT_RECORDS;
alter table CAELMIR_MOUSE add constraint FKD7E04557BC7298A9 foreign key (IDENTIFIER) references CAELMIR_ANIMAL;
alter table CAELMIR_EXPERIMENT add constraint FK296F7A6B9E810B71 foreign key (STUDY_ID) references CAELMIR_STUDY;
alter table CAELMIR_EXPERIMENT add constraint FK296F7A6B8519D8DC foreign key (CREATOR_USER_ID) references CAELMIR_USER;
alter table CAELMIR_IMAGE add constraint FKD7A6B20D5D2FD13C foreign key (IMAGE_TYPE_ID) references CAELMIR_IMAGE_TYPE;
alter table CAELMIR_IMAGE add constraint FKD7A6B20DFEC042B5 foreign key (TISSUE_ID) references CAELMIR_TISSUE;
alter table CAELMIR_IMAGE add constraint FKD7A6B20D808A4B7A foreign key (PARENT_USER_ID) references CAELMIR_USER;
alter table CAELMIR_IMAGE add constraint FKD7A6B20DE2CBF289 foreign key (SLIDE_ID) references CAELMIR_SLIDE;
alter table CAELMIR_SLIDE add constraint FKD8334663FEC042B5 foreign key (TISSUE_ID) references CAELMIR_TISSUE;
alter table CAELMIR_SLIDE add constraint FKD83346632206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_ANIMAL_GENOTYPE add constraint FK1C0E000EE8BFDA3E foreign key (ANIMAL_ID) references CAELMIR_ANIMAL;
alter table CAELMIR_ANIMAL_GENOTYPE add constraint FK1C0E000E5682A041 foreign key (GENOTYPE_ID) references CAELMIR_GENOTYPE;
alter table CAELMIR_USER add constraint FK935D80B96CD94566 foreign key (ADDRESS_ID) references CAELMIR_ADDRESS;
alter table CAELMIR_USER add constraint FK935D80B9808A4B7A foreign key (PARENT_USER_ID) references CAELMIR_USER;
alter table CAELMIR_USER add constraint FK935D80B91792AD22 foreign key (INSTITUTION_ID) references CAELMIR_INSTITUTION;
alter table CAELMIR_STUDY_GROUP add constraint FK6CD86F9B9E810B71 foreign key (STUDY_ID) references CAELMIR_STUDY;
alter table CAELMIR_STUDY_GROUP add constraint FK6CD86F9B637E40EF foreign key (USER_GROUP_ID) references CAELMIR_USER_GROUP;
alter table CAELMIR_STUDY_PROTOCOL_REL add constraint FK2477D19648304401 foreign key (COLLECTION_PROTOCOL_ID) references CAELMIR_COLLECTION_PROTOCOL;
alter table CAELMIR_STUDY_PROTOCOL_REL add constraint FK2477D1969E810B71 foreign key (STUDY_ID) references CAELMIR_STUDY;
alter table CAELMIR_PATHOLOGY_ER add constraint FK781DE65BBC7298A9 foreign key (IDENTIFIER) references CAELMIR_EVENT_RECORDS;
alter table CAELMIR_USERPREFERENCE add constraint FK7BA956542206F20F foreign key (USER_ID) references CAELMIR_USER;
alter table CAELMIR_ENTITY_MAP add constraint FKD634394E53B01F66 foreign key (COLLECTION_PROTOCOL_EVENT_ID) references CAELMIR_PROTOCOL_EVENT;
alter table CAELMIR_EXPERIMENT_GROUP add constraint FK94D21F8B637E40EF foreign key (USER_GROUP_ID) references CAELMIR_USER_GROUP;
alter table CAELMIR_EXPERIMENT_GROUP add constraint FK94D21F8BCE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT;
alter table CAELMIR_EXPERIMENT_USER add constraint FK4F25ED1FCE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT;
alter table CAELMIR_EXPERIMENT_USER add constraint FK4F25ED1F2206F20F foreign key (USER_ID) references CAELMIR_USER;
create sequence CAELMIR_MODEL_SEQ;
create sequence CAELMIR_ADDRESS_SEQ START WITH 2;
create sequence CAELMIR_SPECIES_SEQ START WITH 11;
create sequence CAELMIR_SPECIMEN_PROTOCOL_SEQ;
create sequence CAELMIR_USER_SEQ;
create sequence CAELMIR_COHORT_SEQ;
create sequence CAELMIR_EXPERIMENT_SEQ;
create sequence CAELMIR_USER_GROUP_SEQ;
create sequence CAELMIR_ANIMAL_SEQ;
create sequence CAELMIR_INSTITUTION_SEQ START WITH 2;
create sequence CAELMIR_GENUS_SEQ START WITH 2;
create sequence CAELMIR_REPORTED_PROBLEM_SEQ;
create sequence CAELMIR_TISSUE_SEQ;
create sequence CAELMIR_EVENT_RECORD_SEQ;
create sequence CAELMIR_SLIDE_SEQ;
create sequence CAELMIR_PROTOCOL_EVENT_SEQ;
create sequence CAELMIR_GENOTYPE_SEQ;
create sequence CAELMIR_IMAGE_SEQ;
create sequence CAELMIR_ENTITY_MAP_SEQ;
create sequence CAELMIR_USERPREFERENCE_SEQ;
create sequence CAELMIR_IMAGE_TYPE_SEQ;
create sequence CAELMIR_STUDY_SEQ;



INSERT INTO CAELMIR_INSTITUTION (
IDENTIFIER,
NAME,
ACTIVITY_STATUS
)
VALUES (
1,
'Caelmir',
'Active'
);

INSERT INTO CAELMIR_ADDRESS (
IDENTIFIER,
STREET,
CITY,
STATE,
COUNTRY,
ZIPCODE
)
VALUES (
1,
'admin street',
'admin city',
'California',
'United States',
12345
);

INSERT INTO CAELMIR_USER (
IDENTIFIER, 
FAX_NUMBER,
EMAIL_ADDRESS,
 PASSWORD ,
FIRST_NAME,
LAST_NAME,
LOGIN_NAME,
INITIALS,
CREATED_DATE ,
ACTIVITY_STATUS,
INSTITUTION_ID,
ADDRESS_ID,
CSM_USER_ID,
COMMENTS,
PARENT_USER_ID,
PHONE_NUMBER,
PHONE_POST_HOUR,
ROLE_ID,
CMS_ID
)

VALUES (
1,
'admin@admin.com',
'admin@admin.com',
'6c416f576765696c6e63316f326d3365',
'admin@admin.com',
'admin@admin.com',
'admin@admin.com',
'a',
TO_DATE('2005-08-30','yyyy-mm-dd'),
'Active',
1,
1,
1,
'cvc',
null,
'123',
'123',
1,
'1'
);




INSERT INTO caelmir_genus VALUES (1, 'Mus', 'Active');


Insert into caelmir_species values (1,1,'musculus','Active');
Insert into caelmir_species values (2,1,'musculus bactrianus','Active');
Insert into caelmir_species values (3,1,'musculus castaneus','Active');
Insert into caelmir_species values (4,1,'musculus gentilulus','Active');
Insert into caelmir_species values (5,1,'musculus homourus','Active');
Insert into caelmir_species values (6,1,'musculus molossinus','Active');
Insert into caelmir_species values (7,1,'musculus musculus','Active');
Insert into caelmir_species values (8,1,'musculus praetextus','Active');
Insert into caelmir_species values (9,1,'musculus wagneri','Active');
Insert into caelmir_species values (10,1,'domesticus','Active');


