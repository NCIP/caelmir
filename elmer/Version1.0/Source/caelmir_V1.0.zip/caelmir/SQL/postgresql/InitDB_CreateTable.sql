drop table CATISSUE_QUERY_TABLE_DATA cascade;

CREATE TABLE CATISSUE_QUERY_TABLE_DATA
(
      TABLE_ID numeric not null, 
      TABLE_NAME varchar(50),
      DISPLAY_NAME varchar(50),
      ALIAS_NAME varchar(50),
      PRIVILEGE_ID numeric(1,0),
      FOR_SQI numeric(1,0),                                                                        
      primary key (TABLE_ID)
);
drop table CATISSUE_INTERFACE_COLUMN_DATA cascade;
CREATE TABLE CATISSUE_INTERFACE_COLUMN_DATA
(
      IDENTIFIER numeric(30) not null,
      TABLE_ID numeric(30) not null,
      COLUMN_NAME varchar(50),
      ATTRIBUTE_TYPE varchar(30),
      primary key (IDENTIFIER)
);

drop TABLE CATISSUE_TABLE_RELATION;
CREATE TABLE CATISSUE_TABLE_RELATION
(
      RELATIONSHIP_ID numeric(30),
      PARENT_TABLE_ID numeric(30),
      CHILD_TABLE_ID numeric(30),
      TABLES_IN_PATH varchar(50),
      primary key (RELATIONSHIP_ID)
);

drop table CATISSUE_SEARCH_DISPLAY_DATA;
CREATE TABLE CATISSUE_SEARCH_DISPLAY_DATA
(
      RELATIONSHIP_ID numeric(30) not null,
      COL_ID numeric(30) not null,
      DISPLAY_NAME varchar(50)
);
ALTER TABLE CATISSUE_SEARCH_DISPLAY_DATA ADD constraint unique_row UNIQUE (RELATIONSHIP_ID,COL_ID,DISPLAY_NAME);
drop table CATISSUE_RELATED_TABLES_MAP;
CREATE TABLE CATISSUE_RELATED_TABLES_MAP
(
      FIRST_TABLE_ID numeric(30),
      SECOND_TABLE_ID numeric(30),
      FIRST_TABLE_JOIN_COLUMN varchar(50),
      SECOND_TABLE_JOIN_COLUMN varchar(50)
);


drop sequence CATISSUE_AUDIT_EVENT_DET_SEQ;
drop sequence CATISSUE_AUDIT_EVENT_PARAM_SEQ;

drop table CATISSUE_CDE cascade;
create table CATISSUE_CDE (
   PUBLIC_ID varchar(30) not null,
   LONG_NAME varchar(200),
   DEFINITION varchar(500),
   VERSION varchar(50),
   LAST_UPDATED date,
   primary key (PUBLIC_ID)
);
drop table CATISSUE_PERMISSIBLE_VALUE cascade;
create table CATISSUE_PERMISSIBLE_VALUE (
   IDENTIFIER numeric(19,0) not null,
   CONCEPT_CODE varchar(40),
   DEFINITION varchar(500),
   PARENT_IDENTIFIER numeric(19,0),
   VALUE varchar(100),
   PUBLIC_ID varchar(30),
   primary key (IDENTIFIER)
);
drop sequence CATISSUE_PERMISSIBLE_VALUE_SEQ;

drop table CATISSUE_AUDIT_EVENT cascade;
create table CATISSUE_AUDIT_EVENT (
   IDENTIFIER numeric(19,0) not null,
   IP_ADDRESS varchar(20),
   EVENT_TIMESTAMP date,
   USER_ID numeric(19,0),
   COMMENTS varchar(3000),
   primary key (IDENTIFIER)
);


drop table CATISSUE_AUDIT_EVENT_LOG cascade;

create table CATISSUE_AUDIT_EVENT_LOG (
   IDENTIFIER numeric(19,0) not null,
   OBJECT_IDENTIFIER numeric(19,0),
   OBJECT_NAME varchar(100),
   EVENT_TYPE varchar(100),
   AUDIT_EVENT_ID numeric(19,0),
   primary key (IDENTIFIER)
);

drop sequence CATISSUE_AUDIT_EVENT_LOG_SEQ;

drop table CATISSUE_AUDIT_EVENT_DETAILS cascade;
create table CATISSUE_AUDIT_EVENT_DETAILS (
   IDENTIFIER numeric(19,0) not null,
   ELEMENT_NAME varchar(3000),
   PREVIOUS_VALUE varchar(3000),
   CURRENT_VALUE varchar(3000),
   AUDIT_EVENT_LOG_ID numeric(19,0),
   primary key (IDENTIFIER)
);

alter table CATISSUE_PERMISSIBLE_VALUE add constraint FK57DDCE153B5435E foreign key (PARENT_IDENTIFIER) references CATISSUE_PERMISSIBLE_VALUE;
alter table CATISSUE_PERMISSIBLE_VALUE add constraint FK57DDCE1FC56C2B1 foreign key (PUBLIC_ID) references CATISSUE_CDE;
alter table CATISSUE_AUDIT_EVENT_LOG add constraint FK8BB672DF77F0B904 foreign key (AUDIT_EVENT_ID) references CATISSUE_AUDIT_EVENT;
alter table CATISSUE_AUDIT_EVENT_DETAILS add constraint FK5C07745D34FFD77F foreign key (AUDIT_EVENT_LOG_ID) references CATISSUE_AUDIT_EVENT_LOG;

create sequence CATISSUE_PERMISSIBLE_VALUE_SEQ;
create sequence CATISSUE_AUDIT_EVENT_LOG_SEQ;
create sequence CATISSUE_AUDIT_EVENT_DET_SEQ;
create sequence CATISSUE_AUDIT_EVENT_PARAM_SEQ;

COMMIT;