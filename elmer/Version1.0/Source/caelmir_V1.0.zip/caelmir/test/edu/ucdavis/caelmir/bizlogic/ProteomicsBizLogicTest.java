/**
 * 
 */
package edu.ucdavis.caelmir.bizlogic;

import com.mockobjects.constraint.Constraint;
import com.mockobjects.constraint.IsAnything;
import com.mockobjects.dynamic.FullConstraintMatcher;
import com.mockobjects.dynamic.Mock;

import edu.ucdavis.caelmir.domain.Experiment;
import edu.ucdavis.caelmir.domain.Proteomics;
import edu.ucdavis.caelmir.domain.Study;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.DAO;
import junit.framework.TestCase;

/**
 * @author ravinder_kankanala
 *
 */
public class ProteomicsBizLogicTest extends TestCase {

	/**
	 * @param arg0
	 */
	public ProteomicsBizLogicTest(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 *@see junit.framework.TestCase#setUp()
	*/
	Mock dao;
	FullConstraintMatcher constraintMatcher;
	FullConstraintMatcher constraintMatcher2;
		
	protected void setUp() throws Exception {
    
			dao = new Mock (DAO.class);
	    	
	    	Constraint []param = new Constraint[4];
	        param[0] = new IsAnything();
	        param[1] = new IsAnything();
	        param[2] = new IsAnything();
	        param[3] = new IsAnything();
	        Constraint []param2 = new Constraint[2];
	        param2[0] = new IsAnything();
	        param2[1] = new IsAnything();
	    	constraintMatcher = new FullConstraintMatcher(param);
	    	constraintMatcher2 = new FullConstraintMatcher(param2);
		    dao.expectAndReturn("insert", constraintMatcher, null);	
      }
    
	protected void tearDown() throws Exception {
	
	  }
	
	
	public void testProteomicsBizLogicForInsertWithExperimentData() {
			DAO daoInterfaceImpl = (DAO) dao.proxy();
			ProteomicsBizLogic proteomicsBizLogic = new ProteomicsBizLogic();
			
 			try {
 				Proteomics proteomics= new Proteomics();  
	  
				Experiment experiment=new Experiment();
				experiment.setName("testExperiment");
				proteomics.setExperiment(experiment);

				Experiment dbERxperiment=new Experiment();
				dbERxperiment.setName("dbtestExperiment");
				dao.expectAndReturn("retrieve",constraintMatcher2,dbERxperiment);
				
				proteomicsBizLogic.insert(proteomics,daoInterfaceImpl, new SessionDataBean());
				proteomics.getExperiment();
				
				assertEquals(proteomics.getExperiment().getName(),"dbtestExperiment");
			    
 				} catch (Exception e) {
				e.printStackTrace();
				fail(".........TestClass:ProteomicsBizLogicTest and TestMethod:testProteomicsBizLogicForInsertWithExperimentData----->Exception occured while processing the request");
						} 
			   }

}
