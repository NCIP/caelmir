package edu.ucdavis.caelmir.bizlogic;

import junit.framework.TestCase;

import com.mockobjects.constraint.Constraint;
import com.mockobjects.constraint.IsAnything;
import com.mockobjects.dynamic.FullConstraintMatcher;
import com.mockobjects.dynamic.Mock;

import edu.ucdavis.caelmir.bizlogic.CaseBizLogic;
import edu.ucdavis.caelmir.domain.Case;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.DAO;

public class CaseBizLogicTest extends TestCase {

		public CaseBizLogicTest(String arg0) {
			super(arg0);
			// TODO Auto-generated constructor stub
		}
	
		/**
	     *@see junit.framework.TestCase#setUp()
	     */
		Mock dao;
		
	    protected void setUp() throws Exception {
	    	dao = new Mock (DAO.class);
	    	Constraint []param = new Constraint[4];
	        param[0] = new IsAnything();
	        param[1] = new IsAnything();
	        param[2] = new IsAnything();
	        param[3] = new IsAnything();
	   
	        FullConstraintMatcher constraintMatcher = new FullConstraintMatcher(param);
	    	dao.expectAndReturn("insert", constraintMatcher,null);
	    }
	    
	    protected void tearDown() throws Exception {
	    	
	    }
	    
	    public void testCaseBizLogicForInsert() {
	    	
	    	DAO daoInterfaceImpl = (DAO) dao.proxy();
	    	
	    	CaseBizLogic caseBizLogic = new CaseBizLogic();
	    	try {
				caseBizLogic.insert(new Case(),daoInterfaceImpl, new SessionDataBean());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				fail("........TestClass: CaseBizLogicTest and TestMethod: testCaseBizLogicForInsert--->Exception occured while processing the request");
				} 
	    	}
}
