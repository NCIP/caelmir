/**
 * 
 */
package edu.ucdavis.caelmir.bizlogic;

import java.util.ArrayList;
import java.util.List;
import com.mockobjects.constraint.Constraint;
import com.mockobjects.constraint.IsAnything;
import com.mockobjects.dynamic.FullConstraintMatcher;
import com.mockobjects.dynamic.Mock;

import edu.ucdavis.caelmir.domain.Cohort;
import edu.ucdavis.caelmir.domain.Experiment;
import edu.ucdavis.caelmir.domain.Microarray;
import edu.ucdavis.caelmir.domain.Protocol;
import edu.ucdavis.caelmir.domain.Study;
import edu.ucdavis.caelmir.domain.User;
import edu.ucdavis.caelmir.domain.UserGroup;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.DAO;
import junit.framework.TestCase;

/**
 * @author ravinder_kankanala  
 *
 */
public class ExperimentBizLogicTest extends TestCase {


	/**
	 * @param arg0
	 */
	public ExperimentBizLogicTest(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 *@see junit.framework.TestCase#setUp()
	*/
	Mock dao;
	FullConstraintMatcher constraintMatcher;
	FullConstraintMatcher constraintMatcher2;
		
	protected void setUp() throws Exception {
    
			dao = new Mock (DAO.class);
	    	
	    	Constraint []param = new Constraint[4];
	        param[0] = new IsAnything();
	        param[1] = new IsAnything();
	        param[2] = new IsAnything();
	        param[3] = new IsAnything();
	        Constraint []param2 = new Constraint[2];
	        param2[0] = new IsAnything();
	        param2[1] = new IsAnything();
	    	constraintMatcher = new FullConstraintMatcher(param);
	    	constraintMatcher2 = new FullConstraintMatcher(param2);
	    	dao.expectAndReturn("insert", constraintMatcher, null);	
      }
    
	protected void tearDown() throws Exception {
	
	  }
	
	public void testExperimentBizLogicForInsertWithExperimnetData() {
			DAO daoInterfaceImpl = (DAO) dao.proxy();
			ExperimentBizLogic experimentBizLogic = new ExperimentBizLogic();
			
 			try {
 				Experiment experiment = new Experiment();	
 				
 				
 				Cohort cohort= new Cohort();
 				cohort.setName("testcohort");
 				
 				Protocol protocol=new Protocol();
 				protocol.setName("testprotocol");
 				
 				UserGroup userGroup = new UserGroup();
 				userGroup.setName("testUserGroup");
 				
 				Study study = new Study();
 				study.setName("testStudy");
				experiment.setStudy(study);
				
				Study dbStudy=new Study();
				dbStudy.setName("dbtestStudy");
				dao.expectAndReturn("retrieve",constraintMatcher2,dbStudy);
				
				
			    List cohortColl= getCohortList(); 
	    		experiment.setCohortCollection(cohortColl);
                dao.expectAndReturn("retrieve",constraintMatcher2,cohortColl.get(0));
		           
               
				List userColl= getUserList(); 
	    		experiment.setUserCollection(userColl);
                dao.expectAndReturn("retrieve",constraintMatcher2,userColl.get(0));
		        
			  
                List userGroupColl= getUserGroupList(); 
	    		experiment.setGroupCollection(userGroupColl);
                dao.expectAndReturn("retrieve",constraintMatcher2,userGroupColl.get(0));
		        
				
                List protocolColl= getProtocolList(); 
	    		experiment.setProtocolCollection(protocolColl);
                dao.expectAndReturn("retrieve",constraintMatcher2,protocolColl.get(0));
               
                dao.expectAndReturn("insert", constraintMatcher, null);    
           	
                experimentBizLogic.insert(experiment,daoInterfaceImpl, new SessionDataBean());
				
                experiment.getStudy();
				cohort.getExperiment();
				experiment.getUserCollection();
				experiment.getGroupCollection(); 
				experiment.getProtocolCollection();
				
				assertEquals(experiment.getUserCollection().size(),userColl.size());
				assertEquals(experiment.getGroupCollection().size(),userGroupColl.size());
				assertEquals(experiment.getProtocolCollection().size(),protocolColl.size());
				assertEquals(experiment.getStudy().getName(),"dbtestStudy");
				assertEquals(cohort.getExperiment().getName(),"testcohort");
				assertEquals(userGroup.getName(),"testUserGroup");
				assertEquals(protocol.getName(),"testprotocol");
				} catch (Exception e) {
				e.printStackTrace();
				fail("........TestClass:ExperimentBizLogicTest and TestMethod: testExperimentBizLogicForInsertWithExperimnetData--->Exception occured while processing the request");
						} 
			   }

	 
	      	   private List getProtocolList() {
					
					Protocol p1=new Protocol();
					p1.setId(new Long(1));
					List protocolList=new ArrayList();
					protocolList.add(p1);
					return protocolList;
				}
				
				private List getUserGroupList() {
					UserGroup ug1= new UserGroup();
					ug1.setId(new Long(1));
					List userGroupList=new ArrayList();
					userGroupList.add(ug1);
					return userGroupList;
				}
				
				private List getUserList() {
					User u1=new User();
					u1.setId(new Long(1));
					List userList=new ArrayList();
					userList.add(u1);
					return userList;
				}
				
				private List getCohortList(){
					Cohort c1= new Cohort();
					c1.setId(new Long(1));
					List cohortList=new ArrayList();
					cohortList.add(c1);
					return cohortList;
				}

}
