/**
 * 
 */
package edu.ucdavis.caelmir.bizlogic;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author ravinder_kankanala
 *
 */
public class AllTests extends TestCase {

		public static Test suite() {
			TestSuite suite = new TestSuite("Test for default package");
			//$JUnit-BEGIN$
			suite.addTestSuite(CaseBizLogicTest.class);
			suite.addTestSuite(CohortBizLogicTest.class);
			suite.addTestSuite(MicroArrayBizLogicTest.class);
			suite.addTestSuite(ProteomicsBizLogicTest.class);
			suite.addTestSuite(StudyBizLogicTest.class);
			suite.addTestSuite(UserGroupBizLogicTest.class);
			//$JUnit-END$
		return suite;
		}

	}
	

