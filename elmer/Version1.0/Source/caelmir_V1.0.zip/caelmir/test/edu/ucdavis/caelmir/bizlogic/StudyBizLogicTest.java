/**
 * 
 */
package edu.ucdavis.caelmir.bizlogic;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.mockobjects.constraint.Constraint;
import com.mockobjects.constraint.IsAnything;
import com.mockobjects.dynamic.FullConstraintMatcher;
import com.mockobjects.dynamic.Mock;

import edu.ucdavis.caelmir.domain.Cohort;
import edu.ucdavis.caelmir.domain.Protocol;
import edu.ucdavis.caelmir.domain.Study;
import edu.ucdavis.caelmir.domain.User;
import edu.ucdavis.caelmir.domain.UserGroup;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.DAO;
import junit.framework.TestCase;

/**
 * @author ravinder_kankanala
 *
 */
public class StudyBizLogicTest extends TestCase {


	/**
	 * @param arg0
	 */
	public StudyBizLogicTest(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
     *@see junit.framework.TestCase#setUp()
     */
		FullConstraintMatcher constraintMatcher;
		FullConstraintMatcher constraintMatcher2;
		Mock dao;
		
    protected void setUp() throws Exception {
    	dao = new Mock (DAO.class);
    	Constraint []param = new Constraint[4];
        param[0] = new IsAnything();
        param[1] = new IsAnything();
        param[2] = new IsAnything();
        param[3] = new IsAnything();
        
        Constraint []param2 = new Constraint[2];
        param2[0] = new IsAnything();
        param2[1] = new IsAnything();
        
        
    	constraintMatcher = new FullConstraintMatcher(param);
    	constraintMatcher2 = new FullConstraintMatcher(param2);
    	dao.expectAndReturn("insert", constraintMatcher,null);
    	
    	}
    
    protected void tearDown() throws Exception {
    	
    	}
    
    public void testStudyBizLogicForInsert() {
    	DAO daoInterfaceImpl = (DAO) dao.proxy();
    	StudyBizLogic studyBizLogic = new StudyBizLogic();
    	
		    	try {
		    		Study study=new Study();
		    		studyBizLogic.insert(study,daoInterfaceImpl, new SessionDataBean());
	 		
		    	} catch (Exception e) {
				e.printStackTrace();
				fail("........TestClass: StudyBizLogicTest and TestMethod: testStudyBizLogicForInsert--->Exception occured while processing the request");
		    	} 
	    	}
    
	public void testStudyBizLogicTestForInsertWithStudyData() {
	    	DAO daoInterfaceImpl = (DAO) dao.proxy();
	    	StudyBizLogic studyBizLogic = new StudyBizLogic();
	    		try {
	    			Study study=new Study();
	    			study.setName("testStudy");
	    			study.setActivityStatus("active");
	    			
	    			/*List userColl= getSubPrimaryInvestigatorCollection(); 
	    			study.setSubPrimaryInvestigatorCollection(userColl);
	                dao.expectAndReturn("retrieve",constraintMatcher2,userColl.get(0));
			         */
	                List userGroupColl= getUserGroupCollection(); 
	                study.setUserGroupCollection(userGroupColl);
	                dao.expectAndReturn("retrieve",constraintMatcher2,userGroupColl.get(0));
	                
	                List protocolColl= getProtocolList(); 
	                study.setProtocolCollection(protocolColl);
	                dao.expectAndReturn("retrieve",constraintMatcher2,protocolColl.get(0));
	               
	                studyBizLogic.insert(study,daoInterfaceImpl, new SessionDataBean());
		 		    
	                assertEquals(study.getName(),"testStudy");
	                assertEquals(study.getActivityStatus(),"active");
					
				} catch (Exception e) {
					e.printStackTrace();
					fail("----TestClass: StudyBizLogicTest and TestMethod:testStudyBizLogicTestForInsertWithStudyData------>Exception occured while processing the request");
					} 
		        	
	          }
	
			private List getProtocolList() {
				Protocol p1 = new Protocol();
				p1.setId(new Long(1));
				List protocolColl=new ArrayList();
				protocolColl.add(p1);
				return protocolColl;
				}
	
			private List getUserGroupCollection() {
				UserGroup ug1=new UserGroup();
				ug1.setId(new Long(1));
				List userGroupColl=new ArrayList();
				userGroupColl.add(ug1);
			    return userGroupColl;
				}
	
			/*private List getSubPrimaryInvestigatorCollection() {
				 User u1=new User();
			     u1.setId(new Long(1));
			     List primaryInvestigatioColl=new ArrayList();
			     primaryInvestigatioColl.add(u1);
			     return primaryInvestigatioColl;
		     	 }*/
	
}
