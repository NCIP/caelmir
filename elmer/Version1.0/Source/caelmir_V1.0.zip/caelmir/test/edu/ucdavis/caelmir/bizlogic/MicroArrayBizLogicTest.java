
package edu.ucdavis.caelmir.bizlogic;



import com.mockobjects.constraint.Constraint;
import com.mockobjects.constraint.IsAnything;
import com.mockobjects.dynamic.FullConstraintMatcher;
import com.mockobjects.dynamic.Mock;

import edu.ucdavis.caelmir.domain.Experiment;
import edu.ucdavis.caelmir.domain.Microarray;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.DAO;
import junit.framework.TestCase;

/**
 * @author ravinder_kankanala
 *
 */

public class MicroArrayBizLogicTest extends TestCase {

	
		/**
		 * @param arg0
		*/
		public MicroArrayBizLogicTest(String arg0) {
			super(arg0);
		
		}

		/**
		 *@see junit.framework.TestCase#setUp()
		*/
		Mock dao;
		FullConstraintMatcher constraintMatcher;
		FullConstraintMatcher constraintMatcher2;
			
		protected void setUp() throws Exception {
	    
				dao = new Mock (DAO.class);
		    	
		    	Constraint []param = new Constraint[4];
		        param[0] = new IsAnything();
		        param[1] = new IsAnything();
		        param[2] = new IsAnything();
		        param[3] = new IsAnything();
		        Constraint []param2 = new Constraint[2];
		        param2[0] = new IsAnything();
		        param2[1] = new IsAnything();
		    	constraintMatcher = new FullConstraintMatcher(param);
		    	constraintMatcher2 = new FullConstraintMatcher(param2);
			    dao.expectAndReturn("insert", constraintMatcher, null);	
	      }
	    
		protected void tearDown() throws Exception {
    	
		  }

		public void testMicroArrayBizLogicForInsertWithExperimentData() {
				DAO daoInterfaceImpl = (DAO) dao.proxy();
				MicroArrayBizLogic microArrayBizLogic = new MicroArrayBizLogic();
				
	 			try {
 					Microarray microarray= new Microarray();  
 	  
					Experiment experiment=new Experiment();
					experiment.setName("testExperiment");
					microarray.setExperiment(experiment);

					Experiment dbERxperiment=new Experiment();
					dbERxperiment.setName("dbtestExperiment");
					dao.expectAndReturn("retrieve",constraintMatcher2,dbERxperiment);
					
					microArrayBizLogic.insert(microarray,daoInterfaceImpl, new SessionDataBean());
					experiment = microarray.getExperiment();
					
					assertEquals(microarray.getExperiment().getName(),"dbtestExperiment");
				
	 				} catch (Exception e) {
					e.printStackTrace();
					fail(".....TestClass:MicroArrayBizLogicTest and TestMethod:testMicroArrayBizLogicForInsertWithExperimentData----->Exception occured while processing the request");
							} 
				   }
	
}

 
 

