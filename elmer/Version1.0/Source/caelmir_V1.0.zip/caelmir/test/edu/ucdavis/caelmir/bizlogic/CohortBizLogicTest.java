package edu.ucdavis.caelmir.bizlogic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import junit.framework.TestCase;
import com.mockobjects.constraint.Constraint;
import com.mockobjects.constraint.IsAnything;
import com.mockobjects.dynamic.FullConstraintMatcher;
import com.mockobjects.dynamic.Mock;
import edu.ucdavis.caelmir.bizlogic.CohortBizLogic;
import edu.ucdavis.caelmir.domain.Animal;
import edu.ucdavis.caelmir.domain.Cohort;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.dao.DAO;


public class CohortBizLogicTest extends TestCase {

		/**
		 * @param arg0
		 */
		public CohortBizLogicTest(String arg0) {
			super(arg0);
		}
	
		/**
	     *@see junit.framework.TestCase#setUp()
	     */
			FullConstraintMatcher constraintMatcher;
			FullConstraintMatcher constraintMatcher2;
			Mock dao;
		
	    protected void setUp() throws Exception {
	    	dao = new Mock (DAO.class);
	    	Constraint []param = new Constraint[4];
	        param[0] = new IsAnything();
	        param[1] = new IsAnything();
	        param[2] = new IsAnything();
	        param[3] = new IsAnything();
	        
	        Constraint []param2 = new Constraint[2];
	        param2[0] = new IsAnything();
	        param2[1] = new IsAnything();
	        
	    	constraintMatcher = new FullConstraintMatcher(param);
	    	constraintMatcher2 = new FullConstraintMatcher(param2);
	    	dao.expectAndReturn("insert", constraintMatcher,null);
	    	}
	    
	    protected void tearDown() throws Exception {
	    	
	    	}
	  
	    public void testCohortBizLogicForInsert() {
	    	DAO daoInterfaceImpl = (DAO) dao.proxy();
	    	CohortBizLogic cohortBizLogic = new CohortBizLogic();
	    	
			    	try {
			    		Cohort cohort=new Cohort();
			    		cohortBizLogic.insert(cohort,daoInterfaceImpl, new SessionDataBean());
		 		
			    	} catch (Exception e) {
					e.printStackTrace();
					fail("........TestClass: CohortBizLogicTest and TestMethod: testCohortBizLogicForInsert--->Exception occured while processing the request");
			    	} 
		    	}
	    
	    public void testCohortBizLogicForInsertWithAnimalData() {
	    	DAO daoInterfaceImpl = (DAO) dao.proxy();
	    	CohortBizLogic cohortBizLogic = new CohortBizLogic();
		    		try {
		    		Cohort cohort=new Cohort();
		    		cohort.setName("testCohort");
		    		cohort.setActivityStatus("active");
		    		List animalList= getAnimalList(cohort); 
		    		cohort.setAnimalCollection(animalList);
	                  
		    			for (int i = 0 ; i < animalList.size();i++) {
				            dao.expectAndReturn("retrieve",constraintMatcher2,animalList.get(i));
				            }
			    		    cohortBizLogic.insert(cohort,daoInterfaceImpl, new SessionDataBean());
				 		    cohort.getAnimalCollection();
							
							assertEquals(cohort.getAnimalCollection().size(),animalList.size());
						    assertEquals(cohort.getName(),"testCohort");
						    assertEquals(cohort.getActivityStatus(),"active");
						    
					} catch (Exception e) {
						e.printStackTrace();
						fail("........TestClass: CohortBizLogicTest and TestMethod: testCohortBizLogicForInsertWithAnimalData--->Exception occured while processing the request");
						} 
		        	
	    	}
	    
	 
			private List getAnimalList(Cohort cohort) {
					Animal a1=new Animal();
					a1.setId(new Long(1));
					a1.setCohort(cohort);
					Animal a2=new Animal();
					a2.setId(new Long(2));
					a2.setCohort(cohort);
					List animalList = new ArrayList();
					animalList.add(a1);
					animalList.add(a2);
					return animalList;
				}
			    
}
