/*
 * Created on Oct 4, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.wustl.common.security;

import java.util.Collection;

import net.sf.hibernate.SessionFactory;
import edu.wustl.common.security.dao.AuthorizationDAOImpl;
import gov.nih.nci.security.exceptions.CSException;
import gov.nih.nci.security.system.ApplicationSessionFactory;


/**
 * @author aarti_sharma
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserProvisioningManagerImpl extends
		gov.nih.nci.security.provisioning.UserProvisioningManagerImpl {

    private AuthorizationDAOImpl authorizationDAOImpl = null;
	/**
	 * @param arg0
	 * @throws Exception
	 */
	public UserProvisioningManagerImpl(String arg0) throws Exception {
		super(arg0);
		
	}
	
	/**
	 * @param arg0
	 * @throws Exception
	 */
	public UserProvisioningManagerImpl() throws Exception {
		super(SecurityManager.CATISSUE_CORE_CONTEXT_NAME);
		SessionFactory sf = ApplicationSessionFactory.getSessionFactory(SecurityManager.CATISSUE_CORE_CONTEXT_NAME);
		authorizationDAOImpl = new AuthorizationDAOImpl(sf,"caelmir");
		super.setAuthorizationDAO(authorizationDAOImpl);
	}

	/**
	 * Returns the users present in this group.
	 * @param groupId the group id of the group.
	 * @return the users present in this group.
	 * @throws CSException
	 */
	public Collection getUsers(String groupId) throws CSException
	{
	    return authorizationDAOImpl.getUsers(groupId);
	}
	
	/**
	 * Returns all the groups in the system.
	 * @return all the groups in the system.
	 */
	public Collection getGroups() throws CSException
	{
	    Collection groups = authorizationDAOImpl.getGroups();
	    return groups;
	}
	/**
	 * Returns group id for given role id from CSM_GROUP_ROLE_REL
	 * @param roleID String
	 * @return group id
	 */
	public String getGroupORRoleID(String selectCol,String whereCol,String value) {
		String groupID = authorizationDAOImpl.getGroupORRoleID(selectCol,whereCol,value);
		return groupID;
	}
	

}
