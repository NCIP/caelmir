
package edu.wustl.common.querysuite.category;

/**
 * @version 1.0
 * @created 03-Oct-2006 11:50:04 AM
 */
public interface ICategory
{

}
