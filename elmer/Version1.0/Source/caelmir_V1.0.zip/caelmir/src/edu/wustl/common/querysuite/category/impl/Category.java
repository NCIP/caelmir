
package edu.wustl.common.querysuite.category.impl;

import edu.wustl.common.querysuite.category.ICategory;

/**
 * @author Mandar Shidhore
 * @version 1.0
 * @created 12-Oct-2006 11.27.04 AM
 */

public class Category implements ICategory
{

}
