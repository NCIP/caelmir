/**
 * 
 */
package edu.ucdavis.caelmir.action;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.GenusForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.subject.Genus;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author ravinder_kankanala
 *
 */
public class GenusAction extends BaseAction {


    /**
     * Overrides the execute method of Action class.
     * Sets the various fields in new genus page.
     * */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
    	String pageOf;
    	boolean isAccessPresent = true;
    	GenusForm  genusForm= (GenusForm) form;
    	
    	String operation = request.getParameter(Constants.OPERATION);
        request.setAttribute(Constants.OPERATION, operation);
        
        pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);
       
        if (operation.equalsIgnoreCase(Constants.ADD))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.GENUS_CREATE,
                    Permissions.GENUS_CREATE_ACCESS_DENIED);
        }
        else if (operation.equalsIgnoreCase(Constants.EDIT))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.GENUS_UPDATE,
                    Permissions.GENUS_UPDATE_ACCESS_DENIED);
          
        }
        else if (operation.equalsIgnoreCase(Constants.VIEW))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.GENUS_READ,
                    Permissions.GENUS_READ_ACCESS_DENIED);
        }
        if (!isAccessPresent)
        {
            return mapping
                    .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
        }
  	
        if(!operation.equals(Constants.VIEW))
        {
            if (isAccessPresent(request, Permissions.GENUS_DELETE,
                    Permissions.GENUS_DELETE_ACCESS_DENIED))
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        true));
            }
            else
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        false));
            }
        }
    
        
        
        if (operation.equals(Constants.EDIT)|| operation.equals(Constants.VIEW))
        {
            checkForAnimalData(form,request);  
           // checkForSpeciesData(form,request);
        }
        request.setAttribute(Constants.ACTIVITY_STATUS ,genusForm.getActivityStatus());
        return mapping.findForward(pageOf);
     } 
  

		private void checkForAnimalData(ActionForm form, HttpServletRequest request) throws DAOException
		{
			    GenusForm genusForm = (GenusForm) form;
			    Long systemIdentifier = new Long(genusForm.getId());        
			    DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();        
			    List list = defaultBizLogic.retrieve(Genus.class.getName(),"id",systemIdentifier);
			    Genus genus = null;
			    request.setAttribute(Constants.ANIMAL_DATA_FLAG,new Boolean(false));
			     if (list != null && !list.isEmpty()) 
			     {
			    	 genus = (Genus) list.get(0);
			     }
			     if (genus != null) 
			     {             
			            Collection animalColl= genus.getAnimalCollection();
			            if(animalColl != null && !animalColl.isEmpty())
			             {
			                    request.setAttribute(Constants.ANIMAL_DATA_FLAG,new Boolean(true));
			             }
	              }
	     }
		   
			
		 /**
	     * This method is used to check the given privilege on given object.
	     * @param request To get the session data bean
	     * @param privilege Name of the privilege
	     * @param accessDeniedMessage The message to be displayed if the access is not present.
	     * @return boolean true if the access is present otherwise false.
	     */
	    private boolean isAccessPresent(HttpServletRequest request,
	            String privilege, String accessDeniedMessage)
	    {
	        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
	                Genus.class.getName(), request.getSession(), privilege);
		        if (!isAccessPresent)
		        {
		            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
		                    accessDeniedMessage);
		        }
	        return isAccessPresent;
	    }
    
		    
		    
		    
		    
		    
		/*private void checkForSpeciesData(ActionForm form, HttpServletRequest request) throws DAOException
		{
		    
			    GenusForm genusForm = (GenusForm) form;
			    Long systemIdentifier = new Long(genusForm.getSystemIdentifier());        
			    DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();        
			    List list = defaultBizLogic.retrieve(Genus.class.getName(),"id",systemIdentifier);
			    Genus genus = null;
			    
			     request.setAttribute(Constants.SPECIES_DATA_FLAG,new Boolean(false));
			     
			     if (list != null && !list.isEmpty()) 
			     {
			    	 genus = (Genus) list.get(0);
			     }
			      
			     if (genus != null) 
			     {             
			            Collection speciesColl= genus.getSpeciesCollection();
			            if(speciesColl != null && !speciesColl.isEmpty())
			             {
			                    request.setAttribute(Constants.SPECIES_DATA_FLAG,new Boolean(true));
			             }
	              }
		}*/
}
