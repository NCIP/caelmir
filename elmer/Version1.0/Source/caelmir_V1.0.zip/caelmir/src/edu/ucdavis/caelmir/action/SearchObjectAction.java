/*
 * Created on Sep 3, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.ucdavis.caelmir.action;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.common.dynamicextensions.ui.webui.util.WebUIManagerConstants;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.logger.Logger;


/**
 * @author gautam_shetty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SearchObjectAction extends Action
{
    
    /* (non-Javadoc)
     * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        String id = request.getParameter(Constants.SYSTEM_IDENTIFIER);
        Long identifier = Long.valueOf(id.trim());
        request.setAttribute(Constants.SYSTEM_IDENTIFIER, identifier);
        
        String containerId = request.getParameter(WebUIManagerConstants.CONTAINER_IDENTIFIER);
        request.setAttribute(WebUIManagerConstants.CONATINER_IDENTIFIER_PARAMETER_NAME,containerId);
        request.setAttribute(Constants.ENTITY_RECORD_ID,identifier.toString());
        request.setAttribute("mode","view");
        if((containerId !=null) && !containerId.equals("null")) {
            getInfo(request,identifier,containerId);
        }
        String dynamicPath = request.getParameter(Constants.DYNAMIC_EXTN_URL);
        request.setAttribute(Constants.DYNAMIC_EXTN_URL,dynamicPath);
        
        String pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);
        
        Logger.out.debug("identifier:"+identifier+" PAGEOF:"+pageOf);
       return mapping.findForward(pageOf);
    }

    private void getInfo(HttpServletRequest request,Long recordId,String containerId) {
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        try
        {
            List entityList = defaultBizLogic.retrieve(EntityMap.class.getName(),"entityReferenceId",containerId);
            if (entityList != null && !entityList.isEmpty()) {
	            Iterator iter = entityList.iterator();
	            while (iter.hasNext()) {
	                EntityMap entityMap = (EntityMap) iter.next();
	                List ERList = defaultBizLogic.retrieve(EventRecords.class.getName(),"entityMap",entityMap.getId());
	                if (ERList != null && !ERList.isEmpty()) {
	                    Iterator it = ERList.iterator();
	                    while (it.hasNext()) {
			                EventRecords eventRecord = (EventRecords) it.next();
			                if(eventRecord.getEntityRecordId()!=null) {
			                    if(eventRecord.getEntityRecordId().equals(recordId)) {
			                        request.setAttribute("animalId",eventRecord.getAnimal().getId().toString());
			                        request.setAttribute("experimentId",eventRecord.getAnimal().getCohort().getExperiment().getId().toString());
			                        request.setAttribute("protocolId",entityMap.getCollectionProtocolEvent().getCollectionProtocol().getId().toString());
			                        request.setAttribute("experimentName",eventRecord.getAnimal().getCohort().getExperiment().getName());
			                        request.setAttribute("protocolName",entityMap.getCollectionProtocolEvent().getCollectionProtocol().getTitle());
			                        break;
			                    }
			                }
	                    }
	                }
	            }
            }
            
        }
        catch (DAOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
