package edu.ucdavis.caelmir.util;

import javax.servlet.http.HttpSession;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.util.logger.Logger;

public class PrivilegeUtil {
	
	public static boolean checkPrivilege (Class callingClass, String protectionElement, HttpSession session, String privilegeName) {
		
		SessionDataBean sessionDataBean = (SessionDataBean) session.getAttribute(Constants.SESSION_DATA);
		if (sessionDataBean == null) {
			return true;
		} else {
		String userName = sessionDataBean.getUserName();
		
		boolean isAuthorised = false;
		try {
			isAuthorised = SecurityManager.getInstance(callingClass).isAuthorized(userName,protectionElement,privilegeName);
			
		} catch (Exception e) {
			Logger.out.info("Exception occured inside the isAuthorised");
			e.printStackTrace();
		}
		
		 return isAuthorised;
		}
	}

}
