/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import java.util.Stack;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.AddNewSessionDataBean;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;
import edu.wustl.common.factory.AbstractDomainObjectFactory;
import edu.wustl.common.factory.MasterFactory;
import edu.wustl.common.util.Utility;
import edu.wustl.common.util.global.ApplicationProperties;
//import edu.wustl.common.util.logger.Logger;



public class BlockAction extends BaseAction
{

    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws AssignDataException
    {
        String operation = (String) request.getParameter(Constants.OPERATION);
        request.setAttribute(Constants.OPERATION, operation);
        
        String  pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        String submittedFor = (String) request.getParameter(Constants.SUBMITTED_FOR);
        
        AbstractActionForm abstractForm = (AbstractActionForm) form;
        
        String target=pageOf;
         
        //------------------------------------------------ AddNewAction Starts----------------------------
        //if AddNew action is executing, load FormBean from Session and redirect to Action which initiated AddNew action
        if( (submittedFor !=null)&& (submittedFor.equals("AddNew")) )
        {
                               
            HttpSession session = request.getSession();
            Stack formBeanStack = (Stack)session.getAttribute(Constants.FORM_BEAN_STACK);
            
            
            AbstractDomainObjectFactory abstractDomainObjectFactory = 
                (AbstractDomainObjectFactory) MasterFactory.getFactory(
                        ApplicationProperties.getValue("app.domainObjectFactory"));
            
           
            AbstractDomainObject abstractDomain = null;            
            abstractDomain = abstractDomainObjectFactory.getDomainObject(abstractForm.getFormId(), abstractForm);
            String objectName = abstractDomainObjectFactory.getDomainObjectName(abstractForm.getFormId());
            
            
            if(formBeanStack !=null)
            {
                //Retrieving AddNewSessionDataBean from Stack
                AddNewSessionDataBean addNewSessionDataBean = (AddNewSessionDataBean)formBeanStack.pop();                      
                if(addNewSessionDataBean != null)
                {
                    //Retrieving FormBean stored into AddNewSessionDataBean 
                    AbstractActionForm sessionFormBean = addNewSessionDataBean.getAbstractActionForm();
                    
                    String forwardTo = addNewSessionDataBean.getForwardTo();
                    
                    //Setting Identifier of new object into the FormBean to populate it on the JSP page 
             //       sessionFormBean.setAddNewObjectIdentifier(addNewSessionDataBean.getAddNewFor(), abstractDomain.getSystemIdentifier());
                    
                    sessionFormBean.setMutable(false);
                    
                    //cleaning FORM_BEAN_STACK from Session if no AddNewSessionDataBean available... Storing appropriate value of SUBMITTED_FOR attribute
                    if(formBeanStack.isEmpty())
                    {
                        session.removeAttribute(Constants.FORM_BEAN_STACK);
                        request.setAttribute(Constants.SUBMITTED_FOR, "Default");
                     }
                    else
                    {
                        request.setAttribute(Constants.SUBMITTED_FOR, "AddNew");
                    }
                    
                    //Storing FormBean into Request to populate data on the page being forwarded after AddNew activity, 
                    //FormBean should be stored with the name defined into Struts-Config.xml to populate data properly on JSP page 
                    String formBeanName = Utility.getFormBeanName(sessionFormBean);
                    request.setAttribute(formBeanName, sessionFormBean);                   
                    
                    //Status message key.
                    String statusMessageKey = String.valueOf(abstractForm.getFormId() +
                            "."+String.valueOf(abstractForm.isAddOperation()));
                    request.setAttribute(Constants.STATUS_MESSAGE_KEY,statusMessageKey);
                    
                    //Changing operation attribute in parth specified in ForwardTo mapping, If AddNew activity started from Edit page
                    if(sessionFormBean.getOperation()!=null && (sessionFormBean.getOperation().equals("edit") ) )
                    {
                                                        
                        ActionForward editForward = new ActionForward();
                        
                        String addPath = (mapping.findForward(forwardTo)).getPath();
                        
                        
                        String editPath = addPath.replaceFirst("operation=add","operation=edit");
                        
                        editForward.setPath(editPath);
                        
                        return editForward;
                    }   
                    
                    return (mapping.findForward(forwardTo));
                }
                else
                {
                    target = new String(Constants.FAILURE);
                    
                    ActionErrors errors = new ActionErrors();
                    ActionError error = new ActionError("errors.item.unknown",
                                            AbstractDomainObject.parseClassName(objectName));
                    errors.add(ActionErrors.GLOBAL_ERROR,error);
                    saveErrors(request,errors);
                }
            }
            
        }
        
        return (mapping.findForward(target));
    }
}
