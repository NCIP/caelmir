/**
 * 
 */
package edu.ucdavis.caelmir.domain.research;

import java.util.Collection;
import java.util.HashSet;

import edu.ucdavis.caelmir.actionForm.ModelForm;
import edu.ucdavis.caelmir.actionForm.StudyForm;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;

/**
* 
* @hibernate.class table="CAELMIR_MODEL"
*/

public class Model extends AbstractDomainObject implements java.io.Serializable {

	private static final long serialVersionUID = 1234567890L;

	/** Unique identifier for the model */
	private Long id;

	/** reference number for the model */
	private Long modelReferenceNum;

	/** Name of the model */
	private String modelName;

	/** DescriptionURL of the model */
	private String modelDescriptionURL;
	
	/**Activity status of the model. Specifies whether this model is active or disabled.*/
    private String activityStatus;

    /**Collection of all the studys which are to be carried out in this model*/
    private Collection studyCollection = new HashSet();

    
    
	
	/**
	 * @return
	 * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
	 *               unsaved-value="null" generator-class="native"
	 * @hibernate.generator-param name="sequence" value="CAELMIR_MODEL_SEQ"
	 */
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return Returns the modelReferenceNum.
	 * @hibernate.property name="modelReferenceNum" type="long" column="MODEL_REFERENCE_NUMBER"
	 *                     length="30"
	 */

	public Long getModelReferenceNum() {
		return modelReferenceNum;
	}

	public void setModelReferenceNum(Long modelReferenceNum) {
		this.modelReferenceNum = modelReferenceNum;
	}

	/**
	 * @return Returns the modelName
	 * @hibernate.property name="modelName" type="string" column="MODEL_NAME"
	 *                     length="100"
	 */
	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	/**
	 * @return Returns the modelDescriptionURL
	 * @hibernate.property name="modelDescriptionURL" type="string"
	 *                     column="MODEL_DESCRIPTION_URL" length="1000"
	 */
	public String getModelDescriptionURL() {
		return modelDescriptionURL;
	}

	public void setModelDescriptionURL(String modelDescriptionURL) {
		this.modelDescriptionURL = modelDescriptionURL;
	}
	
	
	 /**
     * @return Returns the activityStatus.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }


	 /**
     * This function Copies the data from an ModelForm object to a model object.
     * @throws AssignDataException 
     */  
    public void setAllValues(AbstractActionForm actionForm)	throws AssignDataException {
		
	    	ModelForm modelForm = (ModelForm) actionForm;
	    	String operation = modelForm.getOperation();
	        String status = modelForm.getActivityStatus();
	          
	        this.modelReferenceNum = modelForm.getModelReferenceNum();
	        this.modelName = modelForm.getModelName();
	       
	        if (modelForm.getOperation().equals(Constants.ADD))
	        {
	            this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
	        }
	        
	        
	        if (operation != null
	                && ((Constants.VIEW).equalsIgnoreCase(operation) || (Constants.EDIT)
	                        .equalsIgnoreCase(operation)))
	        {
	            if (status != null
	                    && (Constants.ACTIVITY_STATUS_DISABLED)
	                            .equalsIgnoreCase(status))
	            {
	                     
	                this.deleteObject(modelForm);
	                modelForm.setActivityStatus(null);
	            }

	        }
	        
	  }

	public boolean equals(Object obj)
	    {
	        boolean eq = false;
	        if (obj instanceof Model)
	        {
	            Model m = (Model) obj;
	            Long thisId = getId();

	            if (thisId != null && thisId.equals(m.getId()))
	            {
	                eq = true;
	            }

	        }
	        return eq;
	    }

	public int hashCode()
	    {
	        int h = 0;

	        if (getId() != null)
	        {
	            h += getId().hashCode();
	        }

	        return h;
	    }
	
	/**
	 * 
	 */
	public Long getSystemIdentifier() {
		return id;
	}

	/**
	 * Sets an systemIdentifier for the model.
	 * 
	 * @param systemIdentifier
	 *            Unique systemIdentifier to be assigned to the model.
	 * @see #getIdentifier()
	 */
	public void setSystemIdentifier(Long systemIdentifier) {
		this.id = systemIdentifier;
	}

	
	 /**
     * @return Returns the studyCollection.
     * @hibernate.set name="studyCollection" table="CAELMIR_STUDY" cascade="none"
     * inverse="true" lazy="false"
     * @hibernate.collection-key column="MODEL_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.research.Study"
     */
	public Collection getStudyCollection() {
		return studyCollection;
	}

	public void setStudyCollection(Collection studyCollection) {
		this.studyCollection = studyCollection;
	}

	public Model(AbstractActionForm form) {
		try {
			setAllValues(form);
		} catch (AssignDataException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Model() {

		// TODO Auto-generated constructor stub
	}

	public void deleteObject(ModelForm actionForm)
    {
        this.activityStatus = Constants.ACTIVITY_STATUS_DISABLED;
       
    }     
}
