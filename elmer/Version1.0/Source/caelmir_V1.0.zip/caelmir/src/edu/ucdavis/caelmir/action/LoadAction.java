/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */

package edu.ucdavis.caelmir.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.CaseForm;
import edu.ucdavis.caelmir.actionForm.SlideForm;
import edu.ucdavis.caelmir.actionForm.TissueForm;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

public class LoadAction extends BaseAction
{

    /**This method is called when user clicks on the "add" link for the experimental data for pathology protocol.
     * <br>The method populates all the required lists and passes the control onto the appropriate page.
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     */

    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)

    {
        String operation = request.getParameter(Constants.OPERATION);
        request.setAttribute(Constants.OPERATION, operation);

        
        String pageOf = (String) request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        String id = (String) request.getParameter(Constants.ID);
        request.setAttribute(Constants.ID, id);

        //String animid = (String) request.getParameter("animId");
       // request.setAttribute(Constants.ID, id);
         
        try
        {
            StorageManager store = new StorageManager();
            if (pageOf.contains("Tissue"))
            {
                CaseForm caseForm = (CaseForm) form;
               // if(animid!=null)
             //   store.setMap("caseForm_"+animid, caseForm);
                store.setMap("caseForm", caseForm);
                //loadTissue(id);
            }
            else if (pageOf.contains("Slide"))
            {
                TissueForm tissueForm = (TissueForm) form;
               // if(animid!=null)
                //store.setMap("tissueForm_"+animid, tissueForm);
                store.setMap("tissueForm", tissueForm);
                //loadSlide(id);
            }

        }
        catch (Exception e)
        {
        }

        return mapping.findForward(pageOf);
    }

    private void loadTissue(String id) throws DAOException

    {
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List tissueObjectList = bizLogic.retrieve(Tissue.class.getName(),
                Constants.ID, new Long(id));
        Tissue tissue =null ;
        TissueForm tissueForm  = new TissueForm();
        if(tissueObjectList!=null && !tissueObjectList.isEmpty())
        {
             tissue = (Tissue) tissueObjectList.get(0);        
             tissueForm.setAllValues(tissue);
        }
        
        
        
    }

    private void loadSlide(String id) throws DAOException

    {
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List slideObjectList = bizLogic.retrieve(Slide.class.getName(),
                Constants.ID, new Long(id));
        Slide slide=null;
        SlideForm slideForm= new SlideForm(); 
        if(slideObjectList!=null && !slideObjectList.isEmpty())
        {
            slide = (Slide) slideObjectList.get(0);
            slideForm.setAllValues(slide);            
        }
        
    }

}
