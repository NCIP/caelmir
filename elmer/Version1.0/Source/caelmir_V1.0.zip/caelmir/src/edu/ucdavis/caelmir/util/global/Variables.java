/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright: </p>
 *@author Aarti Sharma
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.util.global;

import java.util.Vector;

/**
 * @author aarti_sharma
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Variables extends edu.wustl.common.util.global.Variables
{
    public static String caElmirHome=new String();
    public static String Microarray=new String();
    public static String Proteomics=new String();
    public static String Pathology=new String();
    public static Vector databaseDefinitions=new Vector();
    public static String databaseDriver=new String();
    public static String[] databasenames;
}
