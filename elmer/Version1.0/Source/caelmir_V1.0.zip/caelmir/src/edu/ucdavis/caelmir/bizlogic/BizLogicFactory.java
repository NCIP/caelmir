/**
 * <p>Title: BizLogicFactory Class>
 * <p>Description:  BizLogicFactory is a factory for DAO instances of various domain objects.</p>
 * Copyright:    Copyright (c) year
 * Company: Washington University, School of Medicine, St. Louis.
 * @author Gautam Shetty
 * @version 1.00
 */

package edu.ucdavis.caelmir.bizlogic;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.bizlogic.QueryBizLogic;
import edu.wustl.common.bizlogic.SimpleQueryBizLogic;
import edu.wustl.common.util.logger.Logger;

/**
 * BizLogicFactory is a factory for DAO instances of various domain objects.
 * @author gautam_shetty
 * Kapil: test
 */
public class BizLogicFactory
{
    
//  Singleton instace
	private static BizLogicFactory factory = null;
	
	
	static
	{
		factory = new BizLogicFactory();
	}
	
	protected BizLogicFactory()
	{
	}
	
	/**
	 * Setter method in singleton class is to setup mock unit testing.
	 * */
	public static void setBizLogicFactory(BizLogicFactory externalFactory)
	{
		factory = externalFactory;
	}
	
	public static BizLogicFactory getInstance()
	{
		return factory;
	}
	/**
	 * Returns DAO instance according to the form bean type.
	 * @param FORM_TYPE The form bean type.
	 * @return An AbstractDAO object.
	 */
	public static AbstractBizLogic getBizLogic(int FORM_TYPE)
	{
		AbstractBizLogic abstractBizLogic = null;
		
		switch(FORM_TYPE)
		{
		case Constants.FORGOT_PASSWORD_FORM_ID:
		case Constants.USER_FORM_ID:
			abstractBizLogic = new UserBizLogic();
		Logger.out.debug("In Biz Logic Factory..............User Biz Logic");
		break;
		case Constants.APPROVE_USER_FORM_ID:
			abstractBizLogic = new ApproveUserBizLogic();
		Logger.out.debug("In Biz Logic Factory..............APPROVE_USER_FORM_ID");
		break;
		case Constants.REPORTED_PROBLEM_FORM_ID:
			abstractBizLogic = new ReportedProblemBizLogic();
		break;
		case Constants.QUERY_INTERFACE_ID:
			abstractBizLogic = new QueryBizLogic();
		break;
		case Constants.COHORT_CREATE_FORM_ID:
			abstractBizLogic = new CohortBizLogic();
		break;
		
		case Constants.EXP_CREATE_FORM_ID:
			abstractBizLogic = new ExperimentBizLogic();
		break;
		
		case Constants.STUDY_FORM_ID:
            abstractBizLogic = new StudyBizLogic();
        break;
        
         case Constants.MICROARRAY_FORM_ID :
            abstractBizLogic = new MicroArrayBizLogic();
            break; 
            
         case Constants.PROTEOMICS_FORM_ID:
            abstractBizLogic = new ProteomicsBizLogic();
            break; 
		
        case Constants.USER_GROUP_FORM_ID:
            abstractBizLogic = new UserGroupBizLogic();
		break;
        
        case Constants.SIMPLE_QUERY_INTERFACE_ID:
            abstractBizLogic = new QueryBizLogic();
        break;
		
        
        case Constants.ANIMAL_ADD:
            abstractBizLogic = new MouseBizLogic();
        break;
        
        case Constants.CASE_FORM_ID:
            abstractBizLogic = new CaseBizLogic();
        break;
        
        case Constants.COLLECTION_PROTOCOL_ID:
            abstractBizLogic = new CollectionProtocolBizLogic();
        break;
        
        case Constants.MODEL_FORM_ID:
            abstractBizLogic = new ModelBizLogic();
        break;
        
        case Constants.GENUS_FORM_ID:
            abstractBizLogic = new GenusBizLogic();
        break;
        
        case Constants.SPECIES_FORM_ID:
            abstractBizLogic = new SpeciesBizLogic();
        break;
 
        case Constants.TISSUE_FORM_ID:
            abstractBizLogic = new TissueBizLogic();
        break;
         
        case Constants.SLIDE_FORM_ID:
            abstractBizLogic = new SlideBizLogic();
        break;
        
        case Constants.USER_DEFINED_FORM_ID:
        abstractBizLogic = new UserDefinedBizLogic();
        break;
        
		default:
			abstractBizLogic = new DefaultBizLogic();
		break;
		}
		
		return abstractBizLogic;
	}
	
	public static DefaultBizLogic getDefaultBizLogic()
	{
		return new DefaultBizLogic();
	}
	
	/**
	 * Returns DAO instance according to the fully qualified class name.
	 * @param className The name of the class.
	 * @return An AbstractDAO object.
	 */
	public static AbstractBizLogic getBizLogic(String className)
	{
		AbstractBizLogic abstractBizLogic = null;
		
		if(className.equals("edu.ucdavis.caelmir.domain.common.User"))
		{
			abstractBizLogic = new UserBizLogic();
		}
		else if(className.equals("edu.ucdavis.caelmir.domain.common.ReportedProblem"))
		{
			abstractBizLogic = new ReportedProblemBizLogic();
		}
		
		else
		{
			abstractBizLogic = new DefaultBizLogic();
		}
		
		return abstractBizLogic;
	}
	
	
	
}