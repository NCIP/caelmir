

package edu.ucdavis.caelmir.domain.subject;
import java.text.ParseException;
import java.util.Collection;
import java.util.HashSet;

import edu.ucdavis.caelmir.actionForm.MouseForm;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.util.Utility;

 
  /**
   * This object represents mouse animal
   * @hibernate.joined-subclass table="CAELMIR_MOUSE" 
   * @hibernate.joined-subclass-key column="IDENTIFIER" 
   */

public  class Mouse extends Animal implements java.io.Serializable 
{
    
    public Mouse(AbstractActionForm form)
    {
        setAllValues(form);
    }

    public Mouse()
    {
        // TODO Auto-generated constructor stub
    }
    
	private static final long serialVersionUID = 1234567890L;

	
	   /**The gene to be studied*/
	   private java.lang.String geneOfInterest;
       
       /**Unique identifier for animal within colony management system*/
       private java.lang.String animalColonyReference;
       
     
       
       
       /**
        * @return
        * @hibernate.property name="geneOfInterest" column="GENE_OF_INTEREST" type="string" length="100"
        */
	   public  java.lang.String getGeneOfInterest(){
	      return geneOfInterest;
	   }
	   public void setGeneOfInterest( java.lang.String geneOfInterest){
	      this.geneOfInterest = geneOfInterest;
	   }
	
	   
        /**
         * @return
         * @hibernate.property name="animalColonyReference" type="string" column="ANIMAL_COLONY_REFERENCE" length="100"
         */
	   public  java.lang.String getAnimalColonyReference(){
	      return animalColonyReference;
	   }
	   public void setAnimalColonyReference( java.lang.String animalColonyReference){
	      this.animalColonyReference = animalColonyReference;
	   }
	
	   
	   
	 

	/**
         * This function Copies the data from an AnimalForm object to a animal object.
         * @param user An AnimalForm object containing the information about the animal.  
         * */
        public void setAllValues(AbstractActionForm abstractForm)
        {

            MouseForm mform = (MouseForm) abstractForm;
           
            String operation = mform.getOperation();
            String status = mform.getActivityStatus();

            //this.age = aform.getAge();
            try
            {
                this.setBirthDate(Utility.parseDate(mform.getBirthDate(), Utility
                        .datePattern(mform.getBirthDate())));
             //  this.animalColonyReference = mform.getAnimalColonyReference();
               this.setBackgroundStrain(mform.getBackgroundStrain());
               this.geneOfInterest = mform.getGeneOfInterest();
               
               this.setWeight(mform.getWeight());
               this.setLength(mform.getLength());
               this.setSex(mform.getSex());
               this.setStrain( mform.getStrain());
               this.setAnimalNumber(mform.getAnimalNumber());
               
               if (mform.getGenusId() != null && !mform.getGenusId().equals("-1")) {
               	Genus genus = new Genus();
               	genus.setSystemIdentifier(new Long(mform.getGenusId()));
               	this.genus = genus;
               }
               
               if (mform.getSpeciesId() != null) {
                  	Species species = new Species();
                  	species.setSystemIdentifier(new Long(mform.getSpeciesId()));
                  	this.species = species;
                }

               //   this.setGenus(mform.getGenus());
               //   this.setSpecies(mform.getSpecies());

                this.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);

                if (!mform.getOperation().equals(Constants.ADD))
                {
                    this.setId(new Long(mform.getId()));
                }

                Collection genotypeCollection = new HashSet();
                String genotypeId[] = mform.getGenotypeList();
                if (genotypeId != null)
                {
                    for (int i = 0; i <mform.getGenotypeList().length; i++)
                    {
                        String ID = genotypeId[i];
                        Long genotypeID = new Long(ID);
                        Genotype genotype = new Genotype();
                        genotype.setId(genotypeID);
                        genotypeCollection.add(genotype);
                    }
                }
                setGenotypeCollection(genotypeCollection);
            }
            catch (ParseException e)
            {
                e.printStackTrace();
                System.out.println("Unable to parse " );
            }
       
         
       if (operation != null
                    && (Constants.EDIT).equalsIgnoreCase(operation))
            {
                if (status != null
                        && (Constants.ACTIVITY_STATUS_DISABLED)
                                .equalsIgnoreCase(status))
                {
                    this.deleteObject(mform);
                    mform.setActivityStatus(null);
                }
            }
        }

        public void deleteObject(MouseForm actionForm)
        {  
        	this.setActivityStatus(Constants.ACTIVITY_STATUS_DISABLED);
        	
        }  
        
        
		public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Mouse) {
				Mouse c =(Mouse)obj; 			 
				Long thisId = getId();		
				
					if(thisId != null && thisId.equals(c.getId())) {
					   eq = true;
				    }		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			
			if(getId() != null) {
				h += getId().hashCode();
			}
			
			return h;
	}
        
        
	
	
}