/**
 * <p>Title: UserGroupAction Class>
 * <p>Description:	This class initializes the fields in the UserGroup Add/Edit webpage.</p>
 * Copyright: TODO
 * @author Gautam Shetty
 * @version 1.00
 */

package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


import edu.ucdavis.caelmir.actionForm.UserGroupForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.bizlogic.UserGroupBizLogic;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.util.dbManager.DAOException;
import gov.nih.nci.security.authorization.domainobjects.Group;
import gov.nih.nci.security.authorization.domainobjects.User;


/**
 * This class initializes the fields in the UserGroup Add/Edit webpage.
 * @author gautam_shetty
 */
public class UserGroupAction extends BaseAction
{

    /* (non-Javadoc)
     * @see edu.wustl.common.action.BaseAction#executeAction(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    protected ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        boolean isAccessPresent = true;
        
        String operation = (String) request.getAttribute(Constants.OPERATION);
        
        if (operation.equalsIgnoreCase(Constants.ADD))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.USER_GROUP_CREATE,
                    Permissions.USER_GROUP_CREATE_ACCESS_DENIED);
        }
        else if (operation.equalsIgnoreCase(Constants.EDIT))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.USER_GROUP_UPDATE,
                    Permissions.USER_GROUP_UPDATE_ACCESS_DENIED);
          
        }
        else if (operation.equalsIgnoreCase(Constants.VIEW))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.USER_GROUP_READ,
                    Permissions.USER_GROUP_READ_ACCESS_DENIED);
        }
        if (!isAccessPresent)
        {
            return mapping
                    .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
        }
        
        
        
        String forwardTo = ((UserGroupForm) form).getForwardTo();
        if (forwardTo == null || forwardTo.equalsIgnoreCase(Constants.SUCCESS)) {
            ((UserGroupForm) form).setForwardTo(Constants.POST_SAVE_PROCESS);
        }
       

        //Get the role list.
        Collection groupList = new ArrayList();
        Collection groups = SecurityManager.getInstance(UserGroupAction.class).getGroups();
        UserGroupBizLogic bizLogic = (UserGroupBizLogic)BizLogicFactory.getBizLogic(Constants.USER_GROUP_FORM_ID);
        Iterator iterator = groups.iterator();
        while (iterator.hasNext())
        {
            Group group = (Group) iterator.next();
            NameValueBean nameValueBean = new NameValueBean();
            nameValueBean.setName(bizLogic.getUserGroupDisplayName(group.getGroupId().toString()));
            nameValueBean.setValue(group.getGroupId());
            groupList.add(nameValueBean);
        }
        request.setAttribute(Constants.ROLE_LIST, groupList);

        String groupId = Constants.ADMINISTRATOR_GROUP_ID;
        if (form != null)
        {
            UserGroupForm userGroupForm = (UserGroupForm) form;
            if (userGroupForm.getUserRole() != null)
                groupId = userGroupForm.getUserRole();
        }

        // Get the list of users to be grouped.
        Collection userList = SecurityManager.getInstance(UserGroupAction.class).getUsers(groupId);
        Collection users = new ArrayList();
        Iterator userIterator = userList.iterator();
        while (userIterator.hasNext())
        {
            User user = (User) userIterator.next();
            NameValueBean nameValueBean = new NameValueBean();
            nameValueBean.setName(user.getFirstName()+" , "+user.getLastName());
            nameValueBean.setValue(user.getUserId()+"."+nameValueBean.getName());
            users.add(nameValueBean);
        }
        request.setAttribute(Constants.USER_LIST, users);

        
        String activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
        if (form != null) {
            activityStatus = ((UserGroupForm) form).getActivityStatus();
        }
        Collection selectedUsers = new ArrayList();
        if ((operation.equals(Constants.EDIT) || operation.equals(Constants.ADD))&& activityStatus!=null ){//&& activityStatus.equals(Constants.ACTIVITY_STATUS_ACTIVE)) {
            UserGroupForm userGroupForm = (UserGroupForm) form;
            String[] CSMId = userGroupForm.getUserCollection();
            DefaultBizLogic defBizLogic = new DefaultBizLogic();
            if(CSMId != null)
            for (int i=0;i<CSMId.length;i++) {
                StringTokenizer strTokenizer = new StringTokenizer(CSMId[i], ".");
                String csmid = strTokenizer.nextToken();
                List selectedUser = defBizLogic.retrieve(edu.ucdavis.caelmir.domain.common.User.class.getName(),"csmUserId",new Long(csmid));
                edu.ucdavis.caelmir.domain.common.User userObj = (edu.ucdavis.caelmir.domain.common.User) selectedUser.get(0);
                NameValueBean nameValueBean = new NameValueBean();
                nameValueBean.setName(userObj.getFirstName()+" , "+userObj.getLastName());
                nameValueBean.setValue(userObj.getCsmUserId()+"."+nameValueBean.getName());
                selectedUsers.add(nameValueBean);
            }
        }

        request.setAttribute(Constants.SELECTED_USER_LIST, selectedUsers);
        
        if(!operation.equals(Constants.VIEW))
        {
            if (isAccessPresent(request, Permissions.USER_GROUP_DELETE,
                    Permissions.USER_GROUP_DELETE_ACCESS_DENIED))
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        true));
            }
            else
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        false));
            }
        }
        
        if(operation.equals(Constants.VIEW))
           populateViewParameters(request,form);   

        return mapping.findForward(Constants.SUCCESS);
    }
    
    /**
     * Sets request parameters used to display on webpage in "view" operation.
     * @param request To set attributes
     * @param form to get some fields
     * @throws DAOException 
     */
    private void populateViewParameters(HttpServletRequest request, ActionForm form) throws DAOException 
    {
        UserGroupForm userGroupForm = (UserGroupForm) form ;
        Long systemIdentifier = new Long(userGroupForm.getId());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = defaultBizLogic.retrieve(UserGroup.class.getName(),"id",systemIdentifier);
        UserGroup userGroup = null;
        
        if (list != null && !list.isEmpty()) 
        {
            userGroup = (UserGroup) list.get(0);
        }
         
        if (userGroup != null) 
        {             
            
            Collection collection = userGroup.getUserCollection();
            List userGroupList = new ArrayList();
            if (collection != null) 
            {
                Iterator userGroupIterator = collection.iterator();
                while (userGroupIterator.hasNext()) 
                {
                    edu.ucdavis.caelmir.domain.common.User user = (edu.ucdavis.caelmir.domain.common.User) userGroupIterator.next();
                    userGroupList.add(user.getFirstName());
                }
            }
            request.setAttribute(Constants.USER_NAME_LIST, userGroupList);
            
            Collection groupList = new ArrayList();
            UserGroupBizLogic bizLogic = (UserGroupBizLogic)BizLogicFactory.getBizLogic(Constants.USER_GROUP_FORM_ID);
            String userRole = bizLogic.getUserGroupDisplayName(userGroupForm.getUserRole());           
            request.setAttribute(Constants.USER_ROLE,userRole);
        }
        
        //check for edit privelege.
        boolean editPermission = PrivilegeUtil.checkPrivilege(this.getClass(),
                UserGroup.class.getName(), request.getSession(),
                Permissions.USER_GROUP_UPDATE);
        if (!editPermission)
        {
            request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(false));
        }
        else
        {
            request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(true));
        }

        
        
    }
    
    /**
     * This method is used to check the given privilege on given object.
     * @param request To get the session data bean
     * @param privilege Name of the privilege
     * @param accessDeniedMessage The message to be displayed if the access is not present.
     * @return boolean true if the access is present otherwise false.
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                UserGroup.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

    
}