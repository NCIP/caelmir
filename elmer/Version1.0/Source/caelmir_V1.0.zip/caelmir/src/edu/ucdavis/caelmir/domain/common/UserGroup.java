
package edu.ucdavis.caelmir.domain.common;

import java.util.Collection;
import java.util.HashSet;
import java.util.StringTokenizer;

import edu.ucdavis.caelmir.actionForm.UserGroupForm;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;

//import gov.nih.nci.system.applicationservice.*;

/**
 * UserGroup class contains the group of users.
 * @author gautam_shetty
 * @hibernate.class table="CAELMIR_USER_GROUP"
 */
public class UserGroup extends AbstractDomainObject
        implements 
            java.io.Serializable
{

    /**System generated serial id */
    private static final long serialVersionUID = 1234567890L;

    /**identifier of the user group.*/
    private Long id;

    /** Name of the user group*/
    private String name;

    /** Description of the user group*/
    private String description;

    /**Activity Status of the user group*/
    private String activityStatus;

    /**User role that this group represents.*/
    private Long userRole;

    /**Collection of all the users in this user group*/
    private Collection userCollection = new HashSet();

    /**Collection of all the experiments this user group is a part of*/
    private Collection experimentCollection = new HashSet();

    /**Collection of all the studies this user group is part of.*/
    private Collection studyCollection = new HashSet();

    /**
     * Returns the id of the user group.
     * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
     * unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_USER_GROUP_SEQ"
     * @return Returns the id.
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * Returns the name of the user group.
     * @hibernate.property name="name" type="string" column="NAME" length="150"
     * @return Returns the name of the user group.
     */
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Returns the name of the user group.
     * @hibernate.property name="description" type="string" column="DESCRIPTION" length="255"
     * @return Returns the name of the user group.
     */
    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * Returns the status of the user group.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="50"
     * @return Returns the name of the user group.
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @hibernate.property name="userRole" type="long" column="USER_ROLE_ID" length="38"
     * @return Returns the userRole.
     */
    public Long getUserRole()
    {
        return userRole;
    }

    public void setUserRole(Long userRole)
    {
        this.userRole = userRole;
    }

    /**
     * Returns the set of users in this user group.
     * @hibernate.set name="userCollection" table="CAELMIR_USER_GROUP_REL"
     * cascade="none" inverse="false" lazy="false"
     * @hibernate.collection-key column="USER_GROUP_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.common.User" column="USER_ID"
     * @return the set of users in this user group.
     */
    public Collection getUserCollection()
    {
        //			try{
        //			   if(userCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.common.UserGroup thisIdSet = new edu.ucdavis.caelmir.domain.common.UserGroup();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //				 	userCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("UserGroup:getUserCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return userCollection;
    }

    public void setUserCollection(Collection userCollection)
    {
        this.userCollection = userCollection;
    }

    /**
     * @return Returns the experimentCollection. This collection will contain Experiment objects.
     * @hibernate.set name="experimentCollection" table="CAELMIR_EXPERIMENT_GROUP" 
     * cascade="all-delete-orphan" inverse="true" lazy="true"
     * @hibernate.collection-key column="USER_GROUP_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.research.Experiment" column="EXPERIMENT_ID"
     */
    public Collection getExperimentCollection()
    {
        //			try{
        //			   if(experimentCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.common.UserGroup thisIdSet = new edu.ucdavis.caelmir.domain.common.UserGroup();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.research.Experiment", thisIdSet);				 
        //				 	experimentCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("UserGroup:getExperimentCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return experimentCollection;
    }

    public void setExperimentCollection(Collection experimentCollection)
    {
        this.experimentCollection = experimentCollection;
    }

    /**
     * @return Returns the studyCollection. This collection will contain Study objects.
     * @hibernate.set name="studyCollection" table="CAELMIR_STUDY_GROUP" 
     * cascade="all-delete-orphan" inverse="true" lazy="true"
     * @hibernate.collection-key column="USER_GROUP_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.research.Study" column="STUDY_ID"
     */
    public Collection getStudyCollection()
    {
        //			try{
        //			   if(studyCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.common.UserGroup thisIdSet = new edu.ucdavis.caelmir.domain.common.UserGroup();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.research.Study", thisIdSet);				 
        //				 	studyCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("UserGroup:getStudyCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return studyCollection;
    }

    public void setStudyCollection(Collection studyCollection)
    {
        this.studyCollection = studyCollection;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof UserGroup)
        {
            UserGroup c = (UserGroup) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    /**
     * Default Constructor. 
     */
    public UserGroup()
    {
    }

    /**
     * Initializes the UserGroup object from the form bean.
     */
    public UserGroup(AbstractActionForm form)
    {
        setAllValues(form);
    }

    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#setAllValues(edu.wustl.common.actionForm.AbstractActionForm)
     */
    public void setAllValues(AbstractActionForm form)
    {
        UserGroupForm userGroupForm = (UserGroupForm) form;
        this.name = userGroupForm.getName();
        this.description = userGroupForm.getDescription();
        this.userRole = new Long(userGroupForm.getUserRole());

        if (userGroupForm.getPageOf().equals(Constants.PAGEOF_USER_GROUP)
                && userGroupForm.getOperation().equals(Constants.ADD))
        {
            this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
        }
        else
        {
            this.activityStatus = userGroupForm.getActivityStatus();
            userGroupForm.setActivityStatus(null);
        }

        String[] userColl = userGroupForm.getUserCollection();
        Collection userCol = new HashSet();
        for (int i = 0; i < userGroupForm.getUserCollection().length; i++)
        {
            User user = new User();
            StringTokenizer strTokenizer = new StringTokenizer(userColl[i], ".");
            String userId = strTokenizer.nextToken();
            user.setCsmUserId(Long.valueOf(userId));
            userCol.add(user);
        }
        this.userCollection = userCol;
    }

    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#getSystemIdentifier()
     */
    public Long getSystemIdentifier()
    {
        return this.id;
    }

    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#setSystemIdentifier(java.lang.Long)
     */
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;
    }

}