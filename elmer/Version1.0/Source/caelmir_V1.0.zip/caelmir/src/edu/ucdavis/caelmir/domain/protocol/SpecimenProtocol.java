
package edu.ucdavis.caelmir.domain.protocol;

import java.util.Date;


import edu.wustl.common.domain.AbstractDomainObject;



/**
 * <!-- LICENSE_TEXT_START -->
 * <!-- LICENSE_TEXT_END -->
 */

/**
 * A set of procedures that govern the collection and/or distribution of biospecimens 
 * @hibernate.class table="CAELMIR_SPECIMEN_PROTOCOL"
 */

public abstract class SpecimenProtocol extends AbstractDomainObject
        implements
            java.io.Serializable
{

    protected static final long serialVersionUID = 1234567890L;

    /**Unique identifier of the object*/
    protected  Long id;

    /**Title of the protocol*/
    protected  String title;

    /**IRB Identifier of the protocol*/
    protected  Long irbIdentifier;

    /**Short title of the protocol*/
    protected  String shortTitle;

    /**End date of the protocol*/
    protected  Date endDate;

    /**Activity status of the protocol*/
    protected  String activityStatus;

    /**start date of the protocol*/
    protected  Date startDate;

    /**URL that describes @ the protocol*/
    protected  String descriptionURL;

    /**Enrollment number of the protocol.*/
  //  protected  Integer enrollment;

    /**
     * Returns the identifier assigned to Address.
     * 
     * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
     * unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_SPECIMEN_PROTOCOL_SEQ" 
     * @return a unique systemIdentifier assigned to the address.
     */
    public  Long getId()
    {
        return id;
    }

    public void setId( Long id)
    {
        this.id = id;
    }

    /**
     * Returns the title of the protocol.
     * @hibernate.property name="title" type="string" column="TITLE" length="100"
     * @return Street of the address.
     */
    public  String getTitle()
    {
        return title;
    }

    public void setTitle( String title)
    {
        this.title = title;
    }

    /**
     * Returns the identifier assigned to protocol.
     * @hibernate.property name="irbIdentifier" column="IRB_IDENTIFIER" type="long" length="30"
     */
    public  Long getIrbIdentifier()
    {
        return irbIdentifier;
    }

    public void setIrbIdentifier( Long irbIdentifier)
    {
        this.irbIdentifier = irbIdentifier;
    }

    /**
     * Returns the title of the protocol.
     * @hibernate.property name="shortTitle" type="string" column="SHORT_TITLE" length="20"
     * @return Street of the address.
     */
    public  String getShortTitle()
    {
        return shortTitle;
    }

    public void setShortTitle( String shortTitle)
    {
        this.shortTitle = shortTitle;
    }

    /**
     * @hibernate.property name="endDate" type="date" column="END_DATE"
     * @return Returns the end date.
     */
    public  Date getEndDate()
    {
        return endDate;
    }

    public void setEndDate( Date endDate)
    {
        this.endDate = endDate;
    }

    /**
     * Returns the activitystatus of the user.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     * @return Returns the activityStatus.
     */
    public  String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus( String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @hibernate.property name="startDate" type="date" column="START_DATE"
     * @return Returns the end date.
     */
    public  Date getStartDate()
    {
        return startDate;
    }

    public void setStartDate( Date startDate)
    {
        this.startDate = startDate;
    }

    /**
     * Returns the activitystatus of the user.
     * @hibernate.property name="descriptionURL" type="string" column="DESCRIPTION_URL" length="100"
     * @return Returns the activityStatus.
     */
    public  String getDescriptionURL()
    {
        return descriptionURL;
    }

    public void setDescriptionURL( String descriptionURL)
    {
        this.descriptionURL = descriptionURL;
    }

   
  /*  public  Integer getEnrollment()
    {
        return enrollment;
    }

    public void setEnrollment( Integer enrollment)
    {
        this.enrollment = enrollment;
    }*/

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof SpecimenProtocol)
        {
            SpecimenProtocol c = (SpecimenProtocol) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    

    public Long getSystemIdentifier()
    {
        // TODO Auto-generated method stub
        return id;
    }

    public void setSystemIdentifier(Long systemIdentifier)
    {
        id = systemIdentifier;

    }

}