package edu.ucdavis.caelmir.domain.research;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;



import edu.ucdavis.caelmir.actionForm.ExperimentForm;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.Utility;
import edu.wustl.common.util.logger.Logger;


/**
 * A testable assertion defined by a hypothesis
 * @author gautam_shetty
 * @hibernate.class table="CAELMIR_EXPERIMENT"
 */
public  class Experiment extends AbstractDomainObject implements java.io.Serializable 
{
	private static final long serialVersionUID = 1234567890L;
    
    /**Unique identifier of the experiment.*/
    private  Long id;
    
    /**name of an experiment*/
    private  String name;
    
    /**hypothesis of an experiment*/
    private  String hypothesis;
    
    /** studyRequirement of an experiment */
    private  String studyRequirement;
    
    /**StartDate of an experiment*/
    private  Date experimentStartDate;
    
    /**stop Date of an experiment*/
    private  Date experimentStopDate;
    
    /**Defines whether this experiment is active ,closed or disabled*/
    private  String activityStatus;
    
    /**User object associated with this experiment */
    private edu.ucdavis.caelmir.domain.common.User creator;
    
    /**collection of user associated with experiment*/
    private  Collection userCollection = new  HashSet();
   
    /**collection of cohort associated with experiment*/
    private  Collection cohortCollection = new  HashSet();
    
    /**Collection of protocol associated with experiment*/
    private  Collection collectionProtocolCollection = new  HashSet();
    
    /**Study object under which this experiment is carried out */
    private edu.ucdavis.caelmir.domain.research.Study study;
    
    /**collection of userGroup associated with experiment*/
    private  Collection userGroupCollection = new  HashSet();
    
    /**Date on which the experiment was created*/
    private Date createdDate; 

	   
    /**
     * Returns the unique systemIdentifier.
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_EXPERIMENT_SEQ"
     * @return A unique systemIdentifier.
     * @see #setIdentifier(int)
     * */
	   public   Long getId(){
	      return id;
	   }
       
	   public void setId(  Long id){
	      this.id = id;
	   }
	
	   

        /**
         * @return Returns the name.
         * @hibernate.property name="name" type="string" column="NAME" length="150"
         */
	   public   String getName(){
	      return name;
	   }
	   public void setName(  String name){
	      this.name = name;
	   }
	
       /**
         * @return Returns the hypothesis.
         * @hibernate.property name="hypothesis" type="string" column="HYPOTHESIS" length="255"
         */
	   public   String getHypothesis(){
	      return hypothesis;
	   }
	   public void setHypothesis(  String hypothesis){
	      this.hypothesis = hypothesis;
	   }
	


        /**
         * @return
         * @hibernate.property name="studyRequirements" type="string" column="STUDY_REQUIREMENTS" length="255"
         */
	   public   String getStudyRequirement(){
	      return studyRequirement;
	   }
	   public void setStudyRequirement(  String studyRequirement){
	      this.studyRequirement = studyRequirement;
	   }
	

        /**
         * @return
         * @hibernate.property name="experimentStartDate" column="EXPERIMENT_START_DATE" type="date"
         */
	   public   Date getExperimentStartDate(){
	      return experimentStartDate;
	   }
	   public void setExperimentStartDate(  Date experimentStartDate){
	      this.experimentStartDate = experimentStartDate;
	   }
	
        /**
         * @return
         * @hibernate.property name="experimentStopDate" column="EXPERIMENT_STOP_DATE" type="date"
         */
	   public   Date getExperimentStopDate(){
	      return experimentStopDate;
	   }
	   public void setExperimentStopDate(  Date experimentStopDate){
	      this.experimentStopDate = experimentStopDate;
	   }
	
        /**
         * Returns activityStatus of user
         * @hibernate.property name = "activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
         * @return activityStatus of user
         */
	   public   String getActivityStatus(){
	      return activityStatus;
	   }
	   public void setActivityStatus(  String activityStatus){
	      this.activityStatus = activityStatus;
	   }
	

	
	   
	   
	   
	      
			
			
			
        /**
         * @return user object whos is creator of this experiment
         * @hibernate.many-to-one column="CREATOR_USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
         */
			public edu.ucdavis.caelmir.domain.common.User getCreator(){
//			
//			
//			
//			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
//			  edu.ucdavis.caelmir.domain.research.Experiment thisIdSet = new edu.ucdavis.caelmir.domain.research.Experiment();
//			  thisIdSet.setId(this.getId());
//			  
//			  try {
//			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
//		             if (resultList!=null && resultList.size()>0) {
//		                creator = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
//		             }
//		          
//			  } catch(Exception ex) 
//			  { 
//			      	System.out.println("Experiment:getCreator throws exception ... ...");
//			   		ex.printStackTrace(); 
//			  }
			  return creator;	
			 
			 		
           }
		   
	      
	               
	   
	   
	   
	   public void setCreator(edu.ucdavis.caelmir.domain.common.User creator){
		this.creator = creator;
	   }	
	   
        /**
         * @return
         * @hibernate.set name="userCollection" table="CAELMIR_EXPERIMENT_USER"
         * cascade="none" inverse="false" lazy="false"
         * @hibernate.collection-key column="EXPERIMENT_ID"
         * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.common.User" column="USER_ID"
         */
			public  Collection getUserCollection(){
//			try{
//			   if(userCollection.size() == 0) {}
//		           } catch(Exception e) {			     
//			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
//			      try {
//			      
//			      
//			         
//				 	edu.ucdavis.caelmir.domain.research.Experiment thisIdSet = new edu.ucdavis.caelmir.domain.research.Experiment();
//			         	thisIdSet.setId(this.getId());
//			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
//				 	userCollection = resultList;  
//				 	return resultList;
//				 
//			      
//			      }catch(Exception ex) 
//			      {
//			      	System.out.println("Experiment:getUserCollection throws exception ... ...");
//			   		ex.printStackTrace(); 
//			      }
//			   }	
	              return userCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setUserCollection( Collection userCollection){
	   		this.userCollection = userCollection;
	        }	
	   
	   
	
	   
	   
	   
        /**
         * @return
         * @hibernate.set name="cohortCollection" table="CAELMIR_COHORT"
         * cascade="save-update" inverse="true" lazy="false"
         * @hibernate.collection-key column="EXPERIMENT_ID"
         * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.subject.Cohort"
         */
			public  Collection getCohortCollection(){
//			try{
//			   if(cohortCollection.size() == 0) {}
//		           } catch(Exception e) {			     
//			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
//			      try {
//			      
//			      
//			         
//				 	edu.ucdavis.caelmir.domain.research.Experiment thisIdSet = new edu.ucdavis.caelmir.domain.research.Experiment();
//			         	thisIdSet.setId(this.getId());
//			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.subject.Cohort", thisIdSet);				 
//				 	cohortCollection = resultList;  
//				 	return resultList;
//				 
//			      
//			      }catch(Exception ex) 
//			      {
//			      	System.out.println("Experiment:getCohortCollection throws exception ... ...");
//			   		ex.printStackTrace(); 
//			      }
//			   }	
	              return cohortCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setCohortCollection( Collection cohortCollection){
	   		this.cohortCollection = cohortCollection;
	        }	
	   
	   
	
	   
	   
	   
        /**
         * @return Returns the protocolCollection.
         * @hibernate.set name="collectionProtocolCollection" table="CAELMIR_EXPERIMENT_PROTOCOL" 
         * cascade="none" inverse="false" lazy="false"
         * @hibernate.collection-key column="EXPERIMENT_ID"
         * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.protocol.CollectionProtocol" column="COLLECTION_PROTOCOL_ID"
         */
			public  Collection getCollectionProtocolCollection(){
//			try{
//			   if(collectionProtocolCollection.size() == 0) {}
//		           } catch(Exception e) {			     
//			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
//			      try {
//			      
//			      
//			         
//				 	edu.ucdavis.caelmir.domain.research.Experiment thisIdSet = new edu.ucdavis.caelmir.domain.research.Experiment();
//			         	thisIdSet.setId(this.getId());
//			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.protocol.CollectionProtocol", thisIdSet);				 
//				 	collectionProtocolCollection = resultList;  
//				 	return resultList;
//				 
//			      
//			      }catch(Exception ex) 
//			      {
//			      	System.out.println("Experiment:getCollectionProtocolCollection throws exception ... ...");
//			   		ex.printStackTrace(); 
//			      }
//			   }	
	              return collectionProtocolCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setCollectionProtocolCollection( Collection collectionProtocolCollection){
	   		this.collectionProtocolCollection = collectionProtocolCollection;
	        }	
	   
        /**
         * @return study object this experiment is associated with.
         * @hibernate.many-to-one column="STUDY_ID" class="edu.ucdavis.caelmir.domain.research.Study" constrained="true"
         */
			public edu.ucdavis.caelmir.domain.research.Study getStudy(){
//			
//			
//			
//			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
//			  edu.ucdavis.caelmir.domain.research.Experiment thisIdSet = new edu.ucdavis.caelmir.domain.research.Experiment();
//			  thisIdSet.setId(this.getId());
//			  
//			  try {
//			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.research.Study", thisIdSet);				 
//		             if (resultList!=null && resultList.size()>0) {
//		                study = (edu.ucdavis.caelmir.domain.research.Study)resultList.get(0);
//		             }
//		          
//			  } catch(Exception ex) 
//			  { 
//			      	System.out.println("Experiment:getStudy throws exception ... ...");
//			   		ex.printStackTrace(); 
//			  }
			  return study;	
			 
			 		
           }
		   
	      
	               
	   
	   
	   
	   public void setStudy(edu.ucdavis.caelmir.domain.research.Study study){
		this.study = study;
	   }	
	   
	   
	
	   
	   
	   
        /**
         * @return return userGroupCollection
         * @hibernate.set name="userGroupCollection" table="CAELMIR_EXPERIMENT_GROUP"
         * cascade="none" inverse="false" lazy="false"
         * @hibernate.collection-key column="EXPERIMENT_ID"
         * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.common.UserGroup" column="USER_GROUP_ID"
         */
			public  Collection getUserGroupCollection(){
//			try{
//			   if(userGroupCollection.size() == 0) {}
//		           } catch(Exception e) {			     
//			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
//			      try {
//			      
//			      
//			         
//				 	edu.ucdavis.caelmir.domain.research.Experiment thisIdSet = new edu.ucdavis.caelmir.domain.research.Experiment();
//			         	thisIdSet.setId(this.getId());
//			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.UserGroup", thisIdSet);				 
//				 	userGroupCollection = resultList;  
//				 	return resultList;
//				 
//			      
//			      }catch(Exception ex) 
//			      {
//			      	System.out.println("Experiment:getUserGroupCollection throws exception ... ...");
//			   		ex.printStackTrace(); 
//			      }
//			   }	
	              return userGroupCollection;
	          }
			   
			   
			   
			   
			   
	      
	               
	   
	   	public void setUserGroupCollection( Collection userGroupCollection){
	   		this.userGroupCollection = userGroupCollection;
	        }	
	   
	   
	

		public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof Experiment) {
				Experiment c =(Experiment)obj; 			 
				Long thisId = getId();		
				
					if(thisId != null && thisId.equals(c.getId())) {
					   eq = true;
				    }		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			
			if(getId() != null) {
				h += getId().hashCode();
			}
			
			return h;
	}
        
        /**
         * @return Returns the startDate.
         * @hibernate.property name="createdDate" column="CREATED_DATE" type="date"
         */
        public Date getCreatedDate()
        {
            return createdDate;
        }

        /**
         * Sets the created date.
         * @param createdDate date to set
         */
        public void setCreatedDate(Date createdDate)
        {
            this.createdDate = createdDate;
        }

        /**
         * @return identifier of this experiment
         */
        public Long getSystemIdentifier()
        {
            return id;
        }

        /**
         * set the identifier of this experiment
         */
        public void setSystemIdentifier(Long id)
        {
            this.id = id;
        }	

        /**
         * This function Copies the data from an ExperimentForm object to a Experiment object.
         * @param user An ExperimentForm object containing the information about the Experiment.  
         * */

        public void setAllValues(AbstractActionForm abstractForm)
        {

            ExperimentForm eform = (ExperimentForm) abstractForm;
            String operation = eform.getOperation();

            if (!operation.equals(Constants.VIEW))
            {
                try
                {
                    this.hypothesis = eform.getHypothesis();
                    this.name = eform.getName();
                    this.studyRequirement = eform.getStudyRequirements();
                    this.experimentStartDate = Utility.parseDate(eform
                            .getStartDate(), Utility.datePattern(eform
                            .getStartDate()));
                    if (eform.getStopDate() != null
                            && !eform.getStopDate().equalsIgnoreCase("-")
                            && eform.getStopDate().trim().length() != 0)
                    {
                        this.experimentStopDate = Utility.parseDate(eform
                                .getStopDate());
                    }

                    if (eform.getOperation().equals(Constants.ADD))
                    {
                        this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
                    }
                    else
                    {
                        this.activityStatus = eform.getActivityStatus();
                        //eform.setActivityStatus(null);    
                        this.id = new Long(eform.getId());
                    }

                    Set cohortSet = new HashSet();
                    String cohortId[] = eform.getCohort();
                    if (cohortId != null)
                    {
                        for (int i = 0; i < eform.getCohort().length; i++)
                        {
                            String ID = cohortId[i];
                            Long cohortID = new Long(ID);
                            Cohort cohort = new Cohort();
                            cohort.setId(cohortID);
                            cohortSet.add(cohort);
                        }
                    }
                    setCohortCollection(cohortSet);

                    //Set group collection
                    Set groupSet = new HashSet();
                    String groupId[] = eform.getGroups();
                    if (groupId != null)
                    {
                        for (int i = 0; i < groupId.length; i++)
                        {
                            String ID = groupId[i];
                            UserGroup userGroup = new UserGroup();
                            userGroup.setId(Long.valueOf(ID));
                            groupSet.add(userGroup);
                        }
                    }
                    setUserGroupCollection(groupSet);

                    //      Set Experiment Creator
                    Set userSet = new HashSet();
                    String userId[] = eform.getUsers();

                    if (userId != null)
                    {
                        for (int i = 0; i < userId.length; i++)
                        {
                            String ID = userId[i];
                            User user = new User();
                            user.setId(Long.valueOf(ID));
                            userSet.add(user);
                        }
                    }
                    setUserCollection(userSet);

                    //set protocol collection

                    Set protocolSet = new HashSet();
                    String protocolId[] = eform.getProtocol();
                    if (protocolId != null)
                    {
                        for (int i = 0; i < protocolId.length; i++)
                        {
                            String ID = protocolId[i];
                            CollectionProtocol protocol = new CollectionProtocol();
                            protocol.setId(Long.valueOf(ID));
                            protocolSet.add(protocol);
                        }
                    }
                    setCollectionProtocolCollection(protocolSet);
                    if(eform.getOperation().equals(Constants.ADD))
                    {
                        Study study = new Study();
                        study.setSystemIdentifier(new Long(eform.getStudyIdentifier()));
                        setStudy(study);
                    }
                }
                catch (Exception exp)
                {
                    Logger.out.error("Utility.datePattern() errors " + exp);
                }
            }

            if (operation != null
                    && ((Constants.VIEW).equalsIgnoreCase(operation) || (Constants.EDIT)
                            .equalsIgnoreCase(operation)))
            {
                String status = eform.getActivityStatus();
                if (status != null
                        && (Constants.ACTIVITY_STATUS_CLOSED)
                                .equalsIgnoreCase(status))
                {
                    this.closeAllObjects(eform);
                }
                else if (status != null
                        && (Constants.ACTIVITY_STATUS_DISABLED)
                                .equalsIgnoreCase(status))
                {
                    //eform.setActivityStatus(null);            
                    this.deleteObject(eform);
                    eform.setActivityStatus(null);
                }

            }

        }
        
        /**
         * makes the activityStatus as "Closed"
         * @param actionForm the associated formbean 
         */
        public void closeAllObjects(ExperimentForm actionForm)
        {
            this.activityStatus = Constants.ACTIVITY_STATUS_CLOSED;
            Boolean deleteCohortFlag = actionForm.getDeleteCohortFlag();
            Cohort.setCohortStatus(cohortCollection,Constants.ACTIVITY_STATUS_CLOSED, deleteCohortFlag);
            //setExperimentStatus(experi)
        }
        
        /**
         * makes the activityStatus as "Disabled"
         * @param actionForm the associated formbean 
         */
        public void deleteObject(ExperimentForm actionForm)
        {
            this.activityStatus = Constants.ACTIVITY_STATUS_DISABLED;
            Boolean deleteCohortFlag = actionForm.getDeleteCohortFlag();
            Cohort.setCohortStatus(cohortCollection,Constants.ACTIVITY_STATUS_DISABLED, deleteCohortFlag);

        }
        
        
        public Experiment(AbstractActionForm form)
        {
            setAllValues(form);
        }

        public Experiment()
        {
            // TODO Auto-generated constructor stub
        }
        
        /**
         * set the cohort status to newStatus
         * @param newStatus the Status which is to be set
         * @param flag cohortDelete flag (whether cohort is to be deleted or not)
         */
     
        public static void setExperimentStatus(Collection experimentCollection,String status,Boolean deleteCohortFlag )
        {
            if (experimentCollection != null && !experimentCollection.isEmpty()) 
            {
                Iterator experimentIterator = experimentCollection.iterator();
                while (experimentIterator.hasNext()) 
                {
                    Experiment experiment = (Experiment) experimentIterator.next();
                    experiment.setActivityStatus(status);
                    Collection cohortCollection = experiment.getCohortCollection();
                    Cohort.setCohortStatus(cohortCollection,status,deleteCohortFlag);
                }
            }
        }
        


}