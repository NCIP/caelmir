/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.ProteomicsEventRecords;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;



/**
 * @author sandeep_chinta
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class DownloadFileAction extends HttpServlet {
    
    
    /**
     * 
     */
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doPost(req, res);
	}
	
    /**
     * 
     */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
	throws ServletException, IOException {
	    
	    String identifier = req.getParameter("identifier");
	    String object = req.getParameter(Constants.OBJECT);
	    String className = null;
	    if (object.equalsIgnoreCase("proteomics")) {
	        className = ProteomicsEventRecords.class.getName();
	    } else if (object.equalsIgnoreCase("microarray")){
	        className = MicroarrayEventRecords.class.getName();
	    } else if (object.equalsIgnoreCase("slide")) {
	        className = Image.class.getName();
	    } else if (object.equalsIgnoreCase("tissue")) {
	        className = Image.class.getName();
	    } 
	    DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
	    List list = null;
	    try
        {
            list = defaultBizLogic.retrieve(className,Constants.ID,identifier);
        }
        catch (DAOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        byte[] filedata = null;
        String filename = null;
        if (list != null) {
            if (object.equalsIgnoreCase("proteomics")) {
                ProteomicsEventRecords proteomics = (ProteomicsEventRecords) list.get(0);
                filedata = proteomics.getDataFile();
                filename = proteomics.getFileName();
            } else if (object.equalsIgnoreCase("microarray")){
                MicroarrayEventRecords microarray = (MicroarrayEventRecords) list.get(0);
                filedata = microarray.getDataFile();
                filename = microarray.getFileName();
            } else {
                Image image = (Image) list.get(0);
                filename = image.getFileName();
                filedata = image.getImage();
            }
        }
//      set the header information in the response.
		res.setHeader("Content-Disposition", "attachment; filename=" + filename + ";");
		res.setContentType("application/x-unknown");
        ByteArrayInputStream byteStream = new ByteArrayInputStream(filedata); 
        BufferedInputStream bufStream = new BufferedInputStream(byteStream);
        
        ServletOutputStream responseOutputStream = null; 
        responseOutputStream = res.getOutputStream();
        int data;
        while ((data = bufStream.read()) != -1) {
			responseOutputStream.write(data);
		}
        
        bufStream.close();
        responseOutputStream.close();
	}
		

}
