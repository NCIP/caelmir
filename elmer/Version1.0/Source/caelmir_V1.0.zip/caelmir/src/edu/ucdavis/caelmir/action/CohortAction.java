/**
 *<p>Title: CohortAction Class </p>
 *<p>Description: This class initializes the field and redirect to Add/Edit Cohort webpage.</p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.CohortForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.CommonUtility;
import edu.ucdavis.caelmir.util.ParseXML;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * This class initializes the fields in the cohort Add/Edit webpage.
 * @author shital_lawhale
 */
public class CohortAction extends BaseAction
{

    /**
     * Overrides the execute method of Action class.
     * Sets the various fields in Cohort Add/Edit webpage.
     * */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        String pageOf;
        String operation = request.getParameter(Constants.OPERATION);

        boolean isAccessPresent = true;
        if (operation.equalsIgnoreCase(Constants.ADD))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.COHORT_CREATE,
                    Permissions.COHORT_CREATE_ACCESS_DENIED);
        }
        else if (operation.equalsIgnoreCase(Constants.EDIT))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.COHORT_UPDATE,
                    Permissions.COHORT_UPDATE_ACCESS_DENIED);

            if (isAccessPresent)
            {
                String status = ((CohortForm) form).getActivityStatus();
                if (status.equals(Constants.ACTIVITY_STATUS_PUBLISHED)
                        || status.equals(Constants.ACTIVITY_STATUS_CLOSED))
                {
                    request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                            Constants.COHORT_CLOSED);
                    return mapping
                            .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
                }
            }
        }
        else if (operation.equalsIgnoreCase(Constants.VIEW))
        {
            isAccessPresent = isAccessPresent(request, Permissions.COHORT_READ,
                    Permissions.COHORT_READ_ACCESS_DENIED);

            boolean editPermission = PrivilegeUtil.checkPrivilege(this
                    .getClass(), Cohort.class.getName(), request.getSession(),
                    Permissions.COHORT_UPDATE);
            if (!editPermission)
            {
                request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(
                        false));
            }
            else
            {
                request.setAttribute(Constants.EDIT_PRIVILEGE,
                        new Boolean(true));
            }

        }
        if (!isAccessPresent)
        {
            return mapping.findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
        }
        request.setAttribute(Constants.OPERATION, operation);
        pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        List dataList = new ArrayList();
        List idList = new ArrayList();
        List animalList = new ArrayList();
        request.setAttribute(Constants.ANIMAL_LIST, animalList);
        
        if (operation.equalsIgnoreCase(Constants.VIEW))
            populateViewParameters(request, form);

        if (operation.equals(Constants.ADD))
            pageOf = "create";

        if (operation.equals(Constants.EDIT) || operation.equals(Constants.ADD)
                || operation.equals(Constants.VIEW))
        {
            /*   request.setAttribute(Constants.ACTIVITYSTATUSLIST,
             Constants.COHORT_ACTIVITY_STATUS_VALUES);*/

            dataList = getDataList(form, idList);

            if (!operation.equals(Constants.VIEW))
            {
                if (isAccessPresent(request, Permissions.COHORT_DELETE,
                        Permissions.COHORT_DELETE_ACCESS_DENIED))
                {
                    request.setAttribute(Constants.DELETE_PRIVILEGE,
                            new Boolean(true));
                }
                else
                {
                    request.setAttribute(Constants.DELETE_PRIVILEGE,
                            new Boolean(false));
                }
                checkClosePermission(form, request);
                checkForExpData(form, request);
            }

        }

        request.setAttribute(Constants.SEPARATE, new Long(dataList.size()));

        if (operation.equals(Constants.ADD))//for validation
            dataList = getCMSData(form, dataList, idList);

     
        request.setAttribute(Constants.SPREADSHEET_DATA_LIST, dataList);
        request.setAttribute(Constants.ID_LIST, idList);

        List columnList = getColumnList();
        request.setAttribute(Constants.SPREADSHEET_COLUMN_LIST, columnList);

        request.setAttribute(Constants.ACTIVITY_STATUS, ((CohortForm) form)
                .getActivityStatus());

        return mapping.findForward(pageOf);
    }

    /**
     * 
     * @return The List of columns which are used to display on (grid) Cohort webpage 
     * (should be same as that are mentioned in pop-up config.xml under pickupDisplay -> display-field tags)
     */
    private List getColumnList() //used to display on pop-up so should be user friendly
    {
        List columnList = new ArrayList(); //column which are going to be included in parent page
        
        columnList.add("Animal Number");
        columnList.add("Background strain");
        columnList.add("Gene Of Interest");        
        columnList.add("Sex");
        //columnList.add("Base strain");
        //columnList.add("Birth date");

        return columnList;
    }

    /**
     * 
     * @param form CohortForm to get fields
     * @param idList An Empty List
     * @return dataList contains all values need to be shown on grid and 
     * idList which contains the identifiers of selected Animals.  
     * @throws DAOException
     */
    private List getDataList(ActionForm form, List idList) throws DAOException
    {
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        String objectName = Mouse.class.getName();

        /* String[] showNameFields = {"localAnimalNumber",
         "animalColonyReference", "geneOfInterest"};
         */

        ParseXML parsexml = ParseXML.getinstance();
        Map XMLmap = parsexml.parseXml(Constants.ANIMAL_LIST,
                Constants.HIBERNATE);
        List displayField = (List) XMLmap.get(Constants.DISPAY_FIELD);

        //String[] showNameFields = (String[]) XMLmap.get(Constants.DISPAY_FIELD);
        String[] showNameFields = CommonUtility.ConvertToArray(displayField);

        String[] whereColumnName = {"id"};
        String[] whereColumnCondition = {"="};

        CohortForm cform = (CohortForm) form;

        Map map = cform.getValuesMap();
        Set keys = map.keySet();
        Iterator it = keys.iterator();
        List dataList = new ArrayList();
        while (it.hasNext())
        {
            String[] words = it.next().toString().split("_");
            if (!words[0].equals(Constants.API_KEY))
            {
                String[] whereColumnValue = new String[]{words[1]};
                idList.add(words[1]);
                List list = bizLogic.retrieve(objectName, showNameFields,
                        whereColumnName, whereColumnCondition,
                        whereColumnValue, null);
                Object[] objArray = null;

                List temp = new ArrayList();
                if (list != null && !list.isEmpty() && list.size() != 0)
                {
                    objArray = (Object[]) list.get(0);
                    for (int j = 0; j < objArray.length; j++)
                    {
                        if (objArray[j] != null
                                && (!objArray[j].toString().equals("")))
                        {
                            temp.add(objArray[j]);
                        }
                        else
                            temp.add("-");
                    }
                    dataList.add(temp);
                }
            }
        }

        return dataList;
    }

    /**
     *    
     * @param request
     * @param privilege
     * @param accessDeniedMessage
     * @return
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                Study.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

    /**
     * 
     * @param dataList
     * @return List of animal
     */
    private List getCMSData(ActionForm form, List dataList, List idList)
            throws DAOException
    {

        StorageManager cache = new StorageManager();
        List animalList = new ArrayList();

        List list = (List) cache.getMap(Constants.SELECTED_ANIMAL_LIST);

        /*   List animalIdList = (List)  cache.getMap(Constants.ANIMAL_ID_LIST);
         
         if (animalIdList != null && !animalIdList.isEmpty())//for edit operation
         {
         int i = 0;            
         while (i < animalIdList.size())
         {
         Animal anim = new Animal();
         anim = (Animal) list.get(Integer.parseInt((String) animalIdList
         .get(i)));
         
         animalList.add(anim);
         }
         }
         else //for add operation 'in case of validation error 
         {*/
        CohortForm cform = (CohortForm) form;
        Map map = cform.getValuesMap();
        Set keys = map.keySet();
        Iterator it = keys.iterator();

        while (it.hasNext())
        {
            String[] words = it.next().toString().split("_");
            if (words[0].equals(Constants.API_KEY))
            {
                Mouse mouse = new Mouse();
                mouse = (Mouse) list.get(Integer.parseInt((String) words[1]));
                idList.add(words[1]); // for cms data
                animalList.add(mouse);
            }
        }
        // }

        ParseXML parsexml = ParseXML.getinstance();
        Map XMLmap = parsexml.parseXml(Constants.ANIMAL_LIST, Constants.API);
        List displayField = (List) XMLmap.get(Constants.DISPAY_FIELD);

        //dataList=CommonUtility.ConvertToAnimalList(CommonUtility.ConvertToArray(displayField),animalList);
        dataList.addAll(CommonUtility.ConvertToAnimalList(CommonUtility
                .ConvertToArray(displayField), animalList));

        return dataList;
    }

    private void checkForExpData(ActionForm form, HttpServletRequest request)
            throws DAOException
    {

        CohortForm cform = (CohortForm) form;
        Long systemIdentifier = new Long(cform.getId());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = defaultBizLogic.retrieve(Cohort.class.getName(), "id",
                systemIdentifier);
        Cohort cohort = null;

        request.setAttribute(Constants.EXP_DATA_FLAG, new Boolean(false));

        if (list != null && !list.isEmpty())
        {
            cohort = (Cohort) list.get(0);
        }

        if (cohort != null)
        {
            Collection animalColl = cohort.getAnimalCollection();
            if (animalColl != null && !animalColl.isEmpty())
            {
                Iterator animalIterator = animalColl.iterator();
                while (animalIterator.hasNext())
                {
                    Animal animal = (Animal) animalIterator.next();
                    Collection eventColl = animal.getEventRecordsCollection();
                    if (eventColl != null && !eventColl.isEmpty())
                    {
                        request.setAttribute(Constants.EXP_DATA_FLAG,
                                new Boolean(true));
                    }
                }
            }
        }

    }

    private void checkClosePermission(ActionForm form,
            HttpServletRequest request) throws DAOException
    {
        CohortForm cohortForm = (CohortForm) form;
        long id = cohortForm.getId();
        Long currentUserId = (Long) ((SessionDataBean) request.getSession()
                .getAttribute(Constants.SESSION_DATA)).getUserId();
        if (new Long(id) != null)
        {
            DefaultBizLogic defaultBizLogic = BizLogicFactory
                    .getDefaultBizLogic();
            List cohortList = defaultBizLogic.retrieve(Cohort.class.getName(),
                    "id", new Long(id));
            if (cohortList != null && !cohortList.isEmpty())
            {
                Cohort cohort = (Cohort) cohortList.get(0);
                User user = cohort.getCreator();
                if (user != null)
                {
                    long pi = user.getId().longValue();
                    if (new Long(pi).equals(currentUserId))
                    {
                        request.setAttribute(Constants.CLOSE_PRIVILEGE,
                                new Boolean(true));
                    }
                    else
                    {
                        request.setAttribute(Constants.CLOSE_PRIVILEGE,
                                new Boolean(false));
                    }
                }
            }
        }

    }
    
		    private void populateViewParameters(HttpServletRequest request,
		            ActionForm form) throws DAOException
		    {
		    	
		    	 CohortForm  actionForm = (CohortForm) form;
		    	 
		    	 Long systemIdentifier = new Long(actionForm.getId());
		    	 
		    	 DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
		          
		    	 List list = defaultBizLogic.retrieve(Cohort.class.getName(),
		                  Constants.ID, systemIdentifier);
		          Cohort cohort = null;
		          if (list != null && !list.isEmpty())
		          {
		        	  cohort = (Cohort) list.get(0);
		          }
		
		          if (cohort != null)
		          {   // get experiment
		              Experiment experiment = cohort.getExperiment();
		              if (experiment != null )
		              {
		              request.setAttribute("Experiment", experiment.getName());
		              request.setAttribute("experimentId", experiment.getId().toString());
		              		              
		              }
		              
		              // get animallist 
		              
		              List animalList = new ArrayList();

		              Collection animalColl = cohort.getAnimalCollection();
		              if (animalColl != null && !animalColl.isEmpty())
		              {
		                  Iterator animalIterator = animalColl.iterator();
		                  while (animalIterator.hasNext())
		                  {
		                      Animal animal = (Animal) animalIterator.next();
		                      animalList.add(animal.getId().toString());
		                  }
		              }
		              request.setAttribute(Constants.ANIMAL_LIST, animalList);
		          }
		    }

}
