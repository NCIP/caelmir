/*
 * Created on Aug 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.common.dynamicextensions.entitymanager.EntityManagerConstantsInterface;
import edu.common.dynamicextensions.ui.webui.util.WebUIManagerConstants;
import edu.ucdavis.caelmir.util.CMSClient;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.SimpleQueryInterfaceForm;
import edu.wustl.common.dao.DAOFactory;
import edu.wustl.common.dao.JDBCDAO;
import edu.wustl.common.query.Query;
import edu.wustl.common.query.QueryFactory;
import edu.wustl.common.util.logger.Logger;


/**
 * @author gautam_shetty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SpreadsheetViewAction extends Action
{
    
    /* (non-Javadoc)
     * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        List list = (List)request.getAttribute(Constants.SPREADSHEET_DATA_LIST);
        List columnNames = (List)request.getAttribute(Constants.SPREADSHEET_COLUMN_LIST);
        String pageOf = (String)request.getAttribute(Constants.PAGEOF);
        Logger.out.debug("Pageof in spreadsheetviewaction.........:"+pageOf);
        HttpSession session = request.getSession();

        if (Constants.PAGEOF_SIMPLE_QUERY_INTERFACE.equals(pageOf) || 
        						(Constants.PAGEOF_QUERY_RESULTS.equals(pageOf)))
        {
            //Putting the results view column names and data in session.
            //Required for Export functionality in simple query interface and Advanced Search.
            session.setAttribute(Constants.SPREADSHEET_COLUMN_LIST,columnNames);
            session.setAttribute(Constants.SPREADSHEET_DATA_LIST,list);
        }
        else
        {
            //In case of edit functionality putting it in request.
            request.setAttribute(Constants.SPREADSHEET_COLUMN_LIST,columnNames);
            request.setAttribute(Constants.SPREADSHEET_DATA_LIST,list);
        }
        
        ////////////////
        SimpleQueryInterfaceForm simpleQueryInterfaceForm = (SimpleQueryInterfaceForm) form;
        Map map = simpleQueryInterfaceForm.getValuesMap();
        
        //If map from session is null get the map values from form.
        if (map.size() == 0) 
            map = (Map) session.getAttribute(Constants.SIMPLE_QUERY_MAP);        
        
        String viewAliasName = (String) map
        .get("SimpleConditionsNode:1_Condition_DataElement_table");
        
        
        String pageOf1=null;
        
        if(pageOf.equals(Constants.PAGEOF_SIMPLE_QUERY_INTERFACE))
        {
            if (viewAliasName.startsWith(EntityManagerConstantsInterface.TABLE_NAME_PREFIX)) {
                JDBCDAO dao = (JDBCDAO) DAOFactory.getInstance().getDAO(edu.wustl.common.util.global.Constants.JDBC_DAO);
                String query = "SELECT CONTAINER_ID FROM CAELMIR_CONTAINER_MAP WHERE TABLE_NAME='" + viewAliasName +"'";
                dao.openSession(null);
                List cList = dao.executeQuery(query,null,false,false,null);
                String containerId = (String)((List) cList.get(0)).get(0);
                request.setAttribute(WebUIManagerConstants.CONTAINER_IDENTIFIER,containerId);
                request.setAttribute(Constants.PAGEOF, "pageOfDynamicExtensions");
                CMSClient cms = new CMSClient();
                String dynamicPath = cms.getDynamicExtensionsLoadURL();
                request.setAttribute(Constants.DYNAMIC_EXTN_URL,dynamicPath);
            } else {
                pageOf1 = "pageOf"+  viewAliasName+"ViewMode";       
                request.setAttribute(Constants.PAGEOF, pageOf1);
            }
        }
        else
            request.setAttribute(Constants.PAGEOF, pageOf);
        
        Vector tableAliasNames = new Vector();
        tableAliasNames.add(viewAliasName);
        Query query = QueryFactory.getInstance().newQuery(Query.SIMPLE_QUERY, viewAliasName);
   
        Map tableMap = query.getIdentifierColumnIds(tableAliasNames);
        List rowList = new ArrayList();
        List idList = new ArrayList();
   
        if (tableMap != null)
        {
            
            int id=0;
            if(columnNames.contains(" "+Constants.POPUP_ID) )
                id = columnNames.indexOf(" "+Constants.POPUP_ID);
            else if(columnNames.contains(Constants.Identifier+" : "+ viewAliasName))
                id = columnNames.indexOf(Constants.Identifier+" : "+ viewAliasName);
                    
           
            Iterator dataListIterator = list.iterator();
            while (dataListIterator.hasNext())
            {
                    rowList = (List)dataListIterator.next();
                    idList.add((String)rowList.get(id));
            }
           
            request.setAttribute(Constants.SEARCH_IDENTIFIER_LIST, idList);
            
        }        
        
        //////////////////////
        
        return mapping.findForward(pageOf);
    }

}
