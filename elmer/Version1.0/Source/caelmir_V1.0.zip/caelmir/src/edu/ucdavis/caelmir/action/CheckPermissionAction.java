package edu.ucdavis.caelmir.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.Institution;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.protocol.SpecimenProtocol;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;


/**Description: This class is used as an action class for checking permissions on the given object before moving 
 * ahead to access that object.
 * Title:TODO
 * Copyright:TODO
 * @see  org.apache.struts.action.Action
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class CheckPermissionAction extends Action {
	
    
    /**This method is called when user clicks on the "edit" link for any object. This method checks the privilege
     * for the user to access that object The method populates all 
     * the required lists and passes the control onto the appropriate page.
     * 
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     */

	public ActionForward execute(ActionMapping mapping, ActionForm form,HttpServletRequest request,HttpServletResponse response) {
		
		String permission = request.getParameter(Constants.PERMISSION);
		String object = request.getParameter(Constants.TABLE_ALIAS_NAME);
		String nextAction = request.getParameter(Constants.NEXT_ACTIOM);
		String pageOf = request.getParameter(Constants.PAGEOF);
		String className = getObjectName(object);
		String menuSelected = request.getParameter(Constants.MENU_SELECTED);
		
		boolean isAccessPresent = true;
		
		isAccessPresent = isAccessPresent(request,permission,permission.concat(Constants.UNDERSCORE_ACCESS_DENIED),className);
		 
		if (!isAccessPresent) {
			if (object.equalsIgnoreCase(Constants.USER_ALIAS) || object.equalsIgnoreCase(Constants.INSTITUTE_ALIAS)) {
				return mapping.findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
			}
			return mapping.findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
		} else {
			ActionForward actionForward = new ActionForward ();
			String path = "/"+ nextAction + "?" + Constants.PAGEOF + "=" + pageOf + "&" + Constants.TABLE_ALIAS_NAME + "=" +object;
			if (menuSelected != null) {
				path = path + "&" + Constants.MENU_SELECTED + "=" + menuSelected;
			}
			actionForward.setPath(path);
			return actionForward;
		}
		
		
		
	}

    /**
     * The method returns the fully qualified name given the alias of the object.
     * @param object Object for which the privilege is to be checked.
     * @return String The fully qualified class name of that object.
     */
	private String getObjectName(String object) {
		if (object == null) {
			return null;
		} else if (object.equalsIgnoreCase(Constants.STUDY_ALIAS)){
			return Study.class.getName();
		} else if (object.equalsIgnoreCase(Constants.EXPERIMENT_ALIAS)) {
			return Experiment.class.getName();
		} else if (object.equalsIgnoreCase(Constants.COHORT_ALIAS)) {
			return Cohort.class.getName();
		} else if (object.equalsIgnoreCase(Constants.INSTITUTE_ALIAS)) {
			return Institution.class.getName();
		} else if (object.equalsIgnoreCase(Constants.USER_ALIAS)) {
			return User.class.getName();
		}
		else if (object.equalsIgnoreCase(Constants.ANIMAL_ALIAS)) {
		    return Animal.class.getName();
		}
        else if (object.equalsIgnoreCase(Constants.PROTOCOL_ALIAS)) {
            return SpecimenProtocol.class.getName();
        }
		return null;
	}
	
    /**
     * The method checkes the given privilege on the given object and if that access is not present then 
     * sets the given message in the request .
     * @param request Request to set the message in
     * @param privilege Privilege that is to be checked.
     * @param accessDeniedMessage The message that is to be displayed if the access is not present.
     * @param objectName The object on which the given privilege is to be checked.
     * @return
     */
	private boolean isAccessPresent(HttpServletRequest request, String privilege, String accessDeniedMessage , String objectName) {
		boolean isAccessPresent= PrivilegeUtil.checkPrivilege(this.getClass(),objectName,request.getSession(),privilege);
		if (!isAccessPresent) {
			request.setAttribute(Constants.STATUS_MESSAGE_KEY,accessDeniedMessage);
		}
		return isAccessPresent;
	}

	

}
