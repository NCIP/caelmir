/**
 * <p>Title: InstitutionForm Class>
 * <p>Description:  This Class is used to encapsulate all the request parameters passed 
 * from Institute.jsp page. </p>
 * Copyright:    Copyright (c) year
 * Company: Washington University, School of Medicine, St. Louis.
 * @author Gautam Shetty
 * @version 1.00
 * Created on Mar 3, 2005
 */

package edu.ucdavis.caelmir.actionForm;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.Institution;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;
import edu.wustl.common.util.logger.Logger;

/**
 * This Class is used to encapsulate all the request parameters passed from Institute.jsp page.
 * @author kapil_kaveeshwar
 * */
public class InstitutionForm extends AbstractActionForm
{
   
    /**
     * Activity Status of  Institution, it could be  ACTIVE, DISABLED(DELETED).
     */
   //   private String activityStatus;
      
    /**
     * A string containing the name of the institute.
     */
    private String name = "";  
    
    private String instiPhoneNumber ="";
    
    private String institutionCode ="";
    
    private String websiteURL="";

    /**
     * @return Returns the insitutionCode.
     */
    public String getInstitutionCode()
    {
        return institutionCode;
    }
    /**
     * @param insitutionCode The insitutionCode to set.
     */
    public void setInstitutionCode(String insitutionCode)
    {
        this.institutionCode = insitutionCode;
    }
    /**
     * @return Returns the websiteURL.
     */
    public String getWebsiteURL()
    {
        return websiteURL;
    }
    /**
     * @param websiteURL The websiteURL to set.
     */
    public void setWebsiteURL(String websiteURL)
    {
        this.websiteURL = websiteURL;
    }
    /**
     * No argument constructor for InstitutionForm class 
     */
    public InstitutionForm()
    {
        reset();
    }

    /**
     * This function Copies the data from an institute object to a InstitutionForm object.
     * @param institute An Institute object containing the information about the institute.  
     */
    public void setAllValues(AbstractDomainObject abstractDomain)
    {
        Institution institute = (Institution) abstractDomain;
        this.id = institute.getId().longValue();
        this.name = institute.getName();
        this.instiPhoneNumber = institute.getInstiPhoneNumber();
        this.websiteURL = institute.getWebsiteURL();
        this.institutionCode = institute.getInstitutionCode();
        this.activityStatus = institute.getActivityStatus();
    }

    public void setAllVal(Object obj)
    {
//        edu.wustl.catissuecore.domainobject.Institution institute=(edu.wustl.catissuecore.domainobject.Institution) obj;
//        this.systemIdentifier = institute.getId().longValue();
//        this.name = institute.getName();
    }
    
    
    /**
     * Returns the login name of the institute.
     * @return String representing the login name of the institute
     * @see #setLoginName(String)
     */
    public String getName()
    {
        return (this.name);
    }

    /**
     * Sets the login name of this institute
     * @param loginName login name of the institute.
     * @see #getLoginName()
     */
    public void setName(String name)
    {
        this.name = name;
    }

    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
    /**
     * Returns the id assigned to form bean
     */
    public int getFormId()
    {
        return Constants.INSTITUTION_FORM_ID;
    }
    
 
    /**
     * Resets the values of all the fields.
     * Is called by the overridden reset method defined in ActionForm.  
     * */
    protected void reset()
    {
      //  this.name = null;
    }

    /**
    * Overrides the validate method of ActionForm.
    * */
    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) 
    {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        try
        {
        	if (validator.isEmpty(name))
            {
            	errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("errors.item.required",ApplicationProperties.getValue("institution.name")));
            }
        	
        	 if (validator.isEmpty(institutionCode))
             {
                 errors
                         .add(
                                 ActionErrors.GLOBAL_ERROR,
                                 new ActionError(
                                         "errors.item.required",
                                         ApplicationProperties
                                                 .getValue("institution.institutionCode")));
             }
        }
        catch(Exception excp)
        {
            Logger.out.error(excp.getMessage(),excp);
        }
        return errors;
     }

    
       
    /**
     * @return Returns the phoneNumber.
     */
    public String getInstiPhoneNumber()
    {
        return instiPhoneNumber;
    }
    /**
     * @param phoneNumber The phoneNumber to set.
     */
    public void setInstiPhoneNumber(String phoneNumber)
    {
        this.instiPhoneNumber = phoneNumber;
    }
}