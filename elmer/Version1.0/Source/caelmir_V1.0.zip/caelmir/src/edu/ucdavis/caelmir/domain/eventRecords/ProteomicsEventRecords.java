

package edu.ucdavis.caelmir.domain.eventRecords;

import java.io.FileNotFoundException;
import java.io.IOException;

import edu.ucdavis.caelmir.actionForm.ProteomicsForm;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.exception.AssignDataException;

/**
 * <!-- LICENSE_TEXT_START -->
 * <!-- LICENSE_TEXT_END -->
 */
 
  /**
   * A set of attributes that defines Proteomics
   * @hibernate.joined-subclass table="CAELMIR_PROTEOMICS"
   * @hibernate.joined-subclass-key column="IDENTIFIER"
   */

public  class ProteomicsEventRecords extends EventRecords implements java.io.Serializable 
{
	private static final long serialVersionUID = 1234567890L;

    /**Byte array representation of the data file*/
    private byte[] dataFile;
    
    /**Reference to the appropriate object*/
    private  Long referenceId;
    
    /**Description of the data*/
    private String description;
	   
    /**
     * 
     */
    private String contentType;
    /**
     * 
     */
    
    private String fileName;
    /**
     * 
     */
    
    private Long fileSize;
    
	   
    public ProteomicsEventRecords()
    {
        this.setName(Variables.Proteomics);
      
    }
    /**
     * @hibernate.property name="dataFile" type="edu.ucdavis.caelmir.domain.common.BinaryBlobType" column="DATA_FILE"  
     * @return Returns the dataFile.
     */
	   public byte[] getDataFile(){
	      return dataFile;
	   }
	   public void setDataFile(byte[] dataFile){
	      this.dataFile = dataFile;
	   }
	
       
        /**
         * @return Returns the roleId of the user.
         * @hibernate.property name="referenceId" type="long" column="REFERENCE_ID" length="38"
         */
	   public   Long getReferenceId(){
	      return referenceId;
	   }
	   public void setReferenceId(  Long referenceId){
	      this.referenceId = referenceId;
	   }
	
       
       /**
         * @return Returns the description.
         * @hibernate.property name="description" type="string" length="2000" column="DESCRIPTION"
         */
	   public String getDescription(){
	      return description;
	   }
	   public void setDescription(String description){
	      this.description = description;
	   }
	

	

		public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof ProteomicsEventRecords) {
				ProteomicsEventRecords c =(ProteomicsEventRecords)obj; 			 
				Long thisId = getId();		
				
					if(thisId != null && thisId.equals(c.getId())) {
					   eq = true;
				    }		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			
			if(getId() != null) {
				h += getId().hashCode();
			}
			
			return h;
	}

       public ProteomicsEventRecords(AbstractActionForm form) throws AssignDataException
        {
            setAllValues(form);
            // TODO Auto-generated constructor stub
        }
       
       public void setAllValues(AbstractActionForm actionForm) 
       {
           ProteomicsForm pform = (ProteomicsForm)actionForm;
           if (pform.getAnimalId() != null) 
           {
           Long animalId = Long.valueOf(pform.getAnimalId());
           Animal animal = new Mouse();
           animal.setId(animalId);
           this.setAnimal(animal);
           }
           
           this.setName(Variables.Proteomics);
           EntityMap entityMap = new  EntityMap();
           entityMap.setId(new Long(pform.getEntityMapId()));
           /* Collection collection = new HashSet();
           collection.add(collectionProtocolEvent);
           setCollectionProtocolEventCollection(collection);*/
           //getEntityMap().setCollectionProtocolEvent(collectionProtocolEvent);
           setEntityMap(entityMap);
           
           if(pform.getOperation().equalsIgnoreCase(Constants.ADD))
               this.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
           else
               this.setActivityStatus(pform.getActivityStatus());
           
           String status = pform.getActivityStatus();
           if (status != null
                   && (Constants.ACTIVITY_STATUS_DISABLED)
                           .equalsIgnoreCase(status))
           {
               //eform.setActivityStatus(null);            
              // this.deleteObject(pform);
               pform.setActivityStatus(null);
           }
                  
           
           this.description = pform.getDescription();
           this.referenceId = pform.getReferenceId();
           try
           {
               if (pform.getDataFile() != null) {
	               this.dataFile = pform.getDataFile().getFileData();
	               this.fileName = pform.getDataFile().getFileName();
	               this.contentType = pform.getDataFile().getContentType();
	               this.fileSize = new Long(pform.getDataFile().getFileSize());
               }
               
               //this.dataFile = pform.getDataFile();
           }
           catch (FileNotFoundException e)
           {
            // TODO Auto-generated catch block
               e.printStackTrace();
           }
           catch (IOException e)
           {
            // TODO Auto-generated catch block
               e.printStackTrace();
           }
           
           
       }
       public void deleteObject(ProteomicsForm actionForm)
       {
       //    this.setActivityStatus (Constants.ACTIVITY_STATUS_ACTIVE);
           this.description="";
           this.referenceId=null;        

       }       
	
    /**
     * @return Returns the contentType.
     * @hibernate.property name="contentType" type="string" length="30" column="CONTENT_TYPE"
     */
    public String getContentType()
    {
        return contentType;
    }
    /**
     * @param contentType The contentType to set.
     */
    public void setContentType(String contentType)
    {
        this.contentType = contentType;
    }
    /**
     * @return Returns the fileName.
     * @hibernate.property name="fileName" type="string" length="100" column="FILE_NAME"
     */
    public String getFileName()
    {
        return fileName;
    }
    /**
     * @param fileName The fileName to set.
     */
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }
    /**
     * @return Returns the fileSize.
     * @hibernate.property name="fileSize" type="long" length="30" column="FILE_SIZE"
     */
    public Long getFileSize()
    {
        return fileSize;
    }
    /**
     * @param fileSize The fileSize to set.
     */
    public void setFileSize(Long fileSize)
    {
        this.fileSize = fileSize;
    }
}