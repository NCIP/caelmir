
package edu.ucdavis.caelmir.domain.common;

import edu.ucdavis.caelmir.actionForm.ImageTypeForm;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;

/**
 * @author sujay_narkar
 * @hibernate.class table="CAELMIR_IMAGE_TYPE"
 */
public class ImageType extends AbstractDomainObject implements java.io.Serializable
{

    /**System generated serialId for the file.*/
    private static final long serialVersionUID = 1234567890L;

    /**System generated unique systemIdentifier.*/
    private java.lang.Long id;
    /**
     * Image Type name
     */
    private java.lang.String name;

    /***Name of the mimeType of the image.*/
    private String description;

    /**
     * 
     * @param form
     */

    public ImageType(AbstractActionForm form)
    {
        setAllValues(form);
    }

    public ImageType()
    {
        // TODO Auto-generated constructor stub
    }

    /**
     * 
     */
    public void setAllValues(AbstractActionForm actionForm)
    {
        ImageTypeForm imageForm = (ImageTypeForm) actionForm; 
        this.description = imageForm.getDescription();
        this.name = imageForm.getName();
      //  this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
    }

    public Long getSystemIdentifier()
    {
        return id;
    }

    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;
    }

    /**
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_IMAGE_TYPE_SEQ"
     * @return Returns the systemIdentifier.
     */
    public java.lang.Long getId()
    {
        return id;
    }

    public void setId(java.lang.Long id)
    {
        this.id = id;
    }

    /**
     * @return Returns the imageType.
     * @hibernate.property name="name" type="string" length="50" column="IMAGE_NAME" 
     */
    public java.lang.String getName()
    {
        return name;
    }

    public void setName(java.lang.String name)
    {
        this.name = name;
    }

    /**
     * @return Returns the imageType.
     * @hibernate.property name="description" type="string" length="200" column="DESCRIPTION" 
     */
    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof ImageType)
        {
            ImageType c = (ImageType) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

}