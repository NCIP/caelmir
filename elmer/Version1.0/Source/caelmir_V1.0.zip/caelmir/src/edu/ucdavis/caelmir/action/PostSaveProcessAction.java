/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.StudyForm;
import edu.ucdavis.caelmir.util.PreferenceManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;



public class PostSaveProcessAction extends Action
{

    
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        StudyForm studyForm = (StudyForm) form;
        Long systemIdentifier =new Long (studyForm.getId());
        String activityStatus = (String) request.getAttribute(Constants.ACTIVITY_STATUS);
        String objectName = (String) request.getAttribute("objectName");
        String operation = (String) request.getAttribute(Constants.OPERATION);
        String message = getDisplayMessage(activityStatus, objectName, operation);
        if (message != null) {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY, message);
            request.setAttribute("keyFlag",new Boolean(false));
        }
        if (AbstractDomainObject.parseClassName(objectName) != null && AbstractDomainObject.parseClassName(objectName).equalsIgnoreCase(Constants.STUDY_ALIAS)) {
        PreferenceManager.setUserPreference(request,Constants.LAST_USED_STUDY_PREFERENCE,systemIdentifier.toString());
        }
        return mapping.findForward(Constants.SUCCESS);
    }

    private String getDisplayMessage(String activityStatus, String objectName, String operation)
    {
        //
        objectName = AbstractDomainObject.parseClassName(objectName);
        if (operation != null && !operation.equalsIgnoreCase(Constants.ADD) && activityStatus != null && !activityStatus.equalsIgnoreCase(Constants.ACTIVITY_STATUS_ACTIVE)) {
            
            String msg = ApplicationProperties.getValue("object.status.message");
            msg = msg.replaceAll("\\{0\\}", objectName);
            msg = msg.replaceAll("\\{1\\}", activityStatus);
            return msg;
        }
        return null;
    }

}
