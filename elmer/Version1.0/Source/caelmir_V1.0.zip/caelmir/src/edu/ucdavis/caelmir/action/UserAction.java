/**
 * <p>Title: UserAction Class>
 * <p>Description:	This class initializes the fields in the User Add/Edit webpage.</p>
 * Copyright:TODO
 * @author Gautam Shetty
 * @version 1.00
 * Created on Mar 22, 2005
 */

package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.InstitutionForm;
import edu.ucdavis.caelmir.actionForm.UserForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.bizlogic.UserBizLogic;
import edu.ucdavis.caelmir.domain.common.Institution;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.cde.CDEManager;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.security.exceptions.SMException;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.logger.Logger;
import gov.nih.nci.security.UserProvisioningManager;
import gov.nih.nci.security.authorization.domainobjects.Role;
import gov.nih.nci.security.exceptions.CSObjectNotFoundException;

/**
 * This class initializes the fields in the User Add/Edit webpage.
 * @author gautam_shetty
 */
public class UserAction extends BaseAction
{

    /**
     * Overrides the execute method of Action class.
     * Sets the various fields in User Add/Edit webpage.
     * 
     */
    protected ActionForward executeAction(ActionMapping mapping,
            ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception
    {

        //Gets the value of the operation parameter.
        String operation = request.getParameter(Constants.OPERATION);
        String pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        boolean isAccessPresent = true;
        if (operation.equalsIgnoreCase(Constants.ADD))
        {
            isAccessPresent = isAccessPresent(request, Permissions.USER_CREATE,
                    Permissions.USER_CREATE_ACCESS_DENIED);
        }
        else if (operation.equalsIgnoreCase(Constants.EDIT)
                && !pageOf.equalsIgnoreCase(Constants.PAGEOF_USER_PROFILE))
        {
            isAccessPresent = isAccessPresent(request, Permissions.USER_UPDATE,
                    Permissions.USER_UPDATE_ACCESS_DENIED);
        }
        else if (operation.equalsIgnoreCase(Constants.VIEW))
        {
            isAccessPresent = isAccessPresent(request, Permissions.USER_READ,
                    Permissions.USER_READ_ACCESS_DENIED);
            if(isAccessPresent)
            {
                boolean editPermission = PrivilegeUtil.checkPrivilege(this.getClass(),
                        User.class.getName(), request.getSession(),
                        Permissions.USER_UPDATE);
                if (!editPermission)
                {
                    request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(false));
                }
                else
                {
                    request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(true));
                }
            }
        }
        if (!isAccessPresent)
        {
            return mapping
                    .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
        }

        //Sets the operation attribute to be used in the Add/Edit User Page.
        request.setAttribute(Constants.OPERATION, operation);
        String forwardTo = ((UserForm) form).getForwardTo();
        if (forwardTo == null || forwardTo.equalsIgnoreCase(Constants.SUCCESS))
        {
            ((UserForm) form).setForwardTo(Constants.POST_SAVE_PROCESS);
        }
        //Sets the countryList attribute to be used in the Add/Edit User Page.
        List countryList = CDEManager.getCDEManager().getPermissibleValueList(
                Constants.CDE_NAME_COUNTRY_LIST, null);
        request.setAttribute(Constants.COUNTRYLIST, countryList);

        //Sets the stateList attribute to be used in the Add/Edit User Page.
        List stateList = CDEManager.getCDEManager().getPermissibleValueList(
                Constants.CDE_NAME_STATE_LIST, null);
        request.setAttribute(Constants.STATELIST, stateList);

        //Sets the pageOf attribute (for Add,Edit or Query Interface).

        String target = pageOf;

        AbstractBizLogic bizLogic = BizLogicFactory
                .getBizLogic(Constants.USER_FORM_ID);

        //Sets the instituteList attribute to be used in the Add/Edit User Page.
        String sourceObjectName = Institution.class.getName();
        String[] displayNameFields = {Constants.NAME};
        String valueField = "id";

        List instituteList = bizLogic.getList(sourceObjectName,
                displayNameFields, valueField, false);
        request.setAttribute(Constants.INSTITUTIONLIST, instituteList);

        //Populate the activity status dropdown if the operation is edit
        //and the user page is of administrative tab.
        if (operation.equalsIgnoreCase(Constants.ADD)
                || operation.equalsIgnoreCase(Constants.EDIT))
        {

            String objectName = User.class.getName();
            String[] showNameFields = {"lastName", "firstName"};
            String[] whereColumnName = {"roleId"};
            String[] whereColumnCondition = {"="};
            String[] whereColumnValue = {"4"};
            List primartInvestigatorList = bizLogic.getList(objectName,
                    showNameFields, "id", whereColumnName,
                    whereColumnCondition, whereColumnValue, null, ",", false);
            request.setAttribute("primatyInvestigatorList",
                    primartInvestigatorList);
        }

        if (operation.equals(Constants.EDIT))
        {

            SessionDataBean sessionDataBean = getSessionData(request);
            Long userId = new Long(((UserForm) form).getId());
            String showDelete = "false";
            Long sessionUserId = sessionDataBean.getUserId();
            if (sessionUserId != null && !sessionUserId.equals(userId))
            {
                boolean isDelete = PrivilegeUtil.checkPrivilege(
                        this.getClass(), User.class.getName(), request
                                .getSession(), Permissions.USER_DELETE);
                if (isDelete)
                    showDelete = "true";
            }

            request.setAttribute(Constants.SHOW_USER_DELETE, showDelete);
        }
        if (operation.equals(Constants.EDIT)
                && pageOf.equals(Constants.PAGEOF_USER_ADMIN))
        {
            request.setAttribute(Constants.ACTIVITYSTATUSLIST,
                    Constants.USER_ACTIVITY_STATUS_VALUES);
        }

        //Populate the role dropdown if the page is of approve user or (Add/Edit) user page of adminitraive tab.
        if (pageOf.equals(Constants.PAGEOF_APPROVE_USER)
                || pageOf.equals(Constants.PAGEOF_USER_ADMIN))
        {
            List roleNameValueBeanList = getRoles();

            request.setAttribute(Constants.ROLELIST, roleNameValueBeanList);
        }

        //Populate the status dropdown for approve user page.(Approve,Reject,Pending)
        if (pageOf.equals(Constants.PAGEOF_APPROVE_USER))
        {
            request.setAttribute(Constants.APPROVE_USER_STATUS_LIST,
                    Constants.APPROVE_USER_STATUS_VALUES);
        }

        Logger.out.debug("pageOf :---------- " + pageOf);

        // ------------- add new
        String reqPath = request.getParameter(Constants.REQ_PATH);

        request.setAttribute(Constants.REQ_PATH, reqPath);

        AbstractActionForm aForm = (AbstractActionForm) form;
        if (reqPath != null && aForm != null)
            aForm.setRedirectTo(reqPath);

        if (operation.equals(Constants.VIEW))
            populateViewParameters(request, form);

        return mapping.findForward(target);
    }

    /**
     * Sets request parameters used to display on webpage in "view" operation.
     * @param request To set attributes
     * @param form to get some fields
     * @throws DAOException 
     */
    private void populateViewParameters(HttpServletRequest request,
            ActionForm form) throws DAOException, CSObjectNotFoundException,
            SMException
    {
        UserForm userForm = (UserForm) form;
        request.setAttribute(Constants.STATE, userForm.getState());
        request.setAttribute(Constants.COUNTRY, userForm.getCountry());

        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        String instiId = String.valueOf(userForm.getInstitutionId());
        List list = defaultBizLogic.retrieve(Institution.class.getName(), "id",
                instiId);
        Institution institution = null;
        if (list != null && !list.isEmpty())
        {
            institution = (Institution) list.get(0);
        }

        if (institution != null)
        {
            request.setAttribute(Constants.INSTITUTION, institution.getName());
        }
        if (userForm.getRole() != null)
        {
            Role role = SecurityManager.getInstance(UserBizLogic.class)
                    .getUserRole(new Long(userForm.getRole()).longValue());
            request.setAttribute(Constants.ROLE_NAME, role.getName());
        }

        User user = new User();
        String PIId = String.valueOf(userForm.getPrimaryInvestigator());
        if (PIId != null && !PIId.equals("null"))
        {
            List PIlist = defaultBizLogic.retrieve(User.class.getName(), "id",
                    PIId);
            if (PIlist != null && !PIlist.isEmpty())
                user = (User) PIlist.get(0);
        }
        request.setAttribute(Constants.PRIMARY_INVESTIGATOR, user
                .getFirstName());

        //  request.setAttribute(Constants.INSTITUTION,userForm.getin());

    }

    /**
     * Returns a list of all roles that can be assigned to a user.
     * @return a list of all roles that can be assigned to a user.
     * @throws SMException
     */
    private List getRoles() throws SMException
    {
        //Sets the roleList attribute to be used in the Add/Edit User Page.
        Vector roleList = SecurityManager.getInstance(this.getClass())
                .getRoles();

        ListIterator iterator = roleList.listIterator();

        List roleNameValueBeanList = new ArrayList();
        NameValueBean nameValueBean = new NameValueBean();
        nameValueBean.setName(Constants.SELECT_OPTION);
        nameValueBean.setValue(String.valueOf(Constants.SELECT_OPTION_VALUE));
        roleNameValueBeanList.add(nameValueBean);

        while (iterator.hasNext())
        {
            Role role = (Role) iterator.next();
            nameValueBean = new NameValueBean();
            nameValueBean.setName(role.getName());
            nameValueBean.setValue(String.valueOf(role.getId()));
            roleNameValueBeanList.add(nameValueBean);
        }
        return roleNameValueBeanList;
    }

    /* (non-Javadoc)
     * @see edu.wustl.catissuecore.action.BaseAction#getSessionData(javax.servlet.http.HttpServletRequest)
     */
    protected SessionDataBean getSessionData(HttpServletRequest request)
    {
        String pageOf = request.getParameter(Constants.PAGEOF);
        if (pageOf.equals(Constants.PAGEOF_USER_ADMIN)
                || pageOf.equals(Constants.PAGEOF_USER_PROFILE))
        {
            return super.getSessionData(request);
        }
        return new SessionDataBean();
    }

    /**
     * 
     * @param request HttpServletRequest
     * @param privilege String
     * @param accessDeniedMessage String
     * @return boolean value
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                Study.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }
}