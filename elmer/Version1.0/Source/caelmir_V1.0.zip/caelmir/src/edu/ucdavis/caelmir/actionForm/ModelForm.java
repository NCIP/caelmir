/**
 * 
 */
package edu.ucdavis.caelmir.actionForm;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;

/**
 * @author ravinder_kankanala
 *
 */
public class ModelForm extends AbstractActionForm {

	/**
     * Model Reference Number
     */
	 private Long modelReferenceNum;
	
	/**
     * Model Name
     */
    private String modelName;
  

	public Long getModelReferenceNum() {
		return modelReferenceNum;
	}

	public void setModelReferenceNum(Long modelReferenceNum) {
		this.modelReferenceNum = modelReferenceNum;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	
	 /**
     * Returns the id assigned to form bean.
     * @return the id assigned to form bean.
     */
    public int getFormId() {
        return Constants.MODEL_FORM_ID;
    }
	

	/** 
	 * 
	 */
	public void setAllValues(AbstractDomainObject abstractDomain) {
	
		Model model = (Model) abstractDomain;
		this.activityStatus = model.getActivityStatus();
		this.modelReferenceNum=model.getModelReferenceNum();
		this.modelName = model.getModelName().toString();
		this.id = model.getSystemIdentifier().longValue();
		
	}

	
	/**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
	
	/**
     * Overrides the validate method of ActionForm.
     * */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        
        if (validator.isEmpty(String.valueOf(modelReferenceNum))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("model.num")));
        }
        
        if (validator.isEmpty(String.valueOf(modelName))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("model.name")));
        }
        
       
        return errors;
    }
	
	
    /**
     * 
     */
	protected void reset() {

	}

}
