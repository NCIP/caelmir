/**
 * <p>Title: UserGroupForm Class>
 * <p>Description:  UserGroupForm class represents the form bean for user group. </p>
 * Copyright:    Copyright (c) year
 * Company: University of California, Davis.
 * @author Gautam Shetty
 * @version 1.00
 */

package edu.ucdavis.caelmir.actionForm;

import java.util.Collection;
import java.util.Iterator;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;

/**
 * UserGroupForm class represents the form bean for user group.
 * @author gautam_shetty
 */
public class UserGroupForm extends AbstractActionForm
{
    /**
     * Activity Status of UserGroup, it could be  ACTIVE, DISABLED(DELETED).
     */
      private String activityStatus;
      
    
    /**
     * identifier of the user group.
     */
   // String id;

    /**
     * Name of the user group.
     */
    String name;

    /**
     * Description of the user group.
     */
    String description;



    /**
     * Collection of users in the group.
     */
    String[] userCollection;

    String[] selectUserCollection;

    /**
     * Role of the users to be selected.
     */
    String userRole;

   

    /**
     * Returns the name of the user group.
     * @return Returns the name of the user group.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Sets the name of the user group.
     * @param name the name of the user group.
     */
    public void setName(String name)
    {
        this.name = name;
    }



    /**
     * Returns the description of the user group.
     * @return Returns the description of the user group.
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * Sets the description of the user group.
     * @param description the description of the user group.
     */
    public void setDescription(String description)
    {
        this.description = description;
    }


    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }

    /**
     * @return Returns the userCollection.
     */
    public String[] getUserCollection()
    {
        return userCollection;
    }

    /**
     * @param userCollection The userCollection to set.
     */
    public void setUserCollection(String[] userCollection)
    {
        this.userCollection = userCollection;
    }

    /**
     * @return Returns the selectUserCollection.
     */
    public String[] getSelectUserCollection()
    {
        return selectUserCollection;
    }

    /**
     * @param selectUserCollection The selectUserCollection to set.
     */
    public void setSelectUserCollection(String[] selectUserCollection)
    {
        this.selectUserCollection = selectUserCollection;
    }

    /**
     * @return Returns the userRole.
     */
    public String getUserRole()
    {
        return userRole;
    }

    /**
     * @param userRole The userRole to set.
     */
    public void setUserRole(String userRole)
    {
        this.userRole = userRole;
    }

    /* (non-Javadoc)
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public ActionErrors validate(ActionMapping mapping, HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
       // String activityStatus = (String) request.getAttribute(Constants.ACTIVITY_STATUS);
        //if (activityStatus.equals(Constants.ACTIVITY_STATUS_ACTIVE)) {
	        if (validator.isEmpty(name))
	        {
	            errors.add(ActionErrors.GLOBAL_ERROR,
	                        new ActionError("errors.item.required",
	                           ApplicationProperties.getValue("userGroup.name")));
	        }
	
	        if (validator.isEmpty(description))
	        {
	            errors.add(ActionErrors.GLOBAL_ERROR,
	                        new ActionError("errors.item.required",
	                           ApplicationProperties.getValue("userGroup.description")));
	        }
	
	        if (userCollection == null)
	        {
	            errors.add(ActionErrors.GLOBAL_ERROR,
	                    new ActionError("errors.item.required",
	                       ApplicationProperties.getValue("userGroup.users")));
	        }
        //}
        return errors;
    }

    /* (non-Javadoc)
     * @see edu.wustl.common.actionForm.AbstractActionForm#setAllValues(edu.wustl.common.domain.AbstractDomainObject)
     */
    public void setAllValues(AbstractDomainObject abstractDomain)
    {
        UserGroup userGroup = (UserGroup) abstractDomain;
        this.id = userGroup.getId().longValue();
      //  this.systemIdentifier = userGroup.getSystemIdentifier().longValue();
        this.description = userGroup.getDescription();
        this.name = userGroup.getName();
        this.activityStatus = userGroup.getActivityStatus();
        this.userRole = userGroup.getUserRole().toString();
        Collection userCol = userGroup.getUserCollection();
        Iterator iter = userCol.iterator();
        int i=0;
        String [] userList = new String[userCol.size()];
        while(iter.hasNext()) {
            User user = (User) iter.next();
            if (user!=null) {
               String csmID = user.getCsmUserId().toString();
                StringTokenizer strTokenizer = new StringTokenizer(csmID,".");
                String userId = strTokenizer.nextToken();
                userList[i++] = userId;
            }
        }
        setUserCollection(userList);


    }


    public void setAllVal(Object abstractDomain)
    {
        UserGroup userGroup = (UserGroup) abstractDomain;
        this.id = userGroup.getId().longValue();
        this.description = userGroup.getDescription();
        this.name = userGroup.getName();

    }
    /* (non-Javadoc)
     * @see edu.wustl.common.actionForm.AbstractActionForm#reset()
     */
    protected void reset()
    {
        // TODO Auto-generated method stub
    }

    /* (non-Javadoc)
     * @see edu.wustl.common.actionForm.AbstractActionForm#getFormId()
     */
    public int getFormId()
    {
        return Constants.USER_GROUP_FORM_ID;
    }
    
    
    public String getActivityStatus()
    {
        return activityStatus;
    }

    
    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }
       
    
}