/**
 * <p>Title: InstitutionAction Class>
 * <p>Description:	This class initializes the fields in the Institution.jsp Page</p>
 * Copyright:    Copyright (c) year
 * Company: Washington University, School of Medicine, St. Louis.
 * @author Mandar Deshmukh
 * @version 1.00
 * Created on Mar 22, 2005
 */

package edu.ucdavis.caelmir.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.ExperimentForm;
import edu.ucdavis.caelmir.actionForm.InstitutionForm;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;

public class InstitutionAction extends BaseAction
{
    /**
     * Overrides the execute method of Action class.
     * Initializes the various drop down fields in Institution.jsp Page.
     * */
    protected ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        //Gets the value of the operation parameter.
        String operation = request.getParameter(Constants.OPERATION);
        if (operation.equalsIgnoreCase(Constants.ADD)) {
        	if(!PrivilegeUtil.checkPrivilege(this.getClass(),User.class.getName(),request.getSession(),"CREATE")) {
        		request.setAttribute(Constants.STATUS_MESSAGE_KEY,Permissions.INSTITUTION_CREATE_ACCESS_DENIED);
        		return mapping.findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
        	}
        } else {
        	if(!PrivilegeUtil.checkPrivilege(this.getClass(),User.class.getName(),request.getSession(),"UPDATE")) {
        		request.setAttribute(Constants.STATUS_MESSAGE_KEY,Permissions.INSTITUTION_UPDATE_ACCESS_DENIED);
        		return mapping.findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
        	}
        }
        String forwardTo = ((InstitutionForm) form).getForwardTo();
        if (forwardTo == null || forwardTo.equalsIgnoreCase(Constants.SUCCESS)) {
            ((InstitutionForm) form).setForwardTo(Constants.POST_SAVE_PROCESS);
        }
        //Sets the operation attribute to be used in the Add/Edit Institution Page. 
        request.setAttribute(Constants.OPERATION, operation);
        
        return mapping.findForward((String)request.getParameter(Constants.PAGEOF));
    }
}