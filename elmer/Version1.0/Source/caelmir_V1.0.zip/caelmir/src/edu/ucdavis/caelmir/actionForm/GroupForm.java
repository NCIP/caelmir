package edu.ucdavis.caelmir.actionForm;

public class GroupForm
{

	protected String groupName;
	protected String [] AllUsers;
	 protected Long id;
	
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String[] getAllUsers() 
	{
		return AllUsers;
	}
	public void setAllUsers(String[] allUsers)
	{
		AllUsers = allUsers;
	}
	public String getGroupName()
	{
		return groupName;
	}
	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}
	
	
	
	
}
