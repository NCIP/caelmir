
package edu.ucdavis.caelmir.actionForm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.Utility;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;

/**
 * @author sujay_narkar
 */
public class CaseForm extends AbstractActionForm {
    
    String target ; 
	/**
	 * Animal Identification Number
	 */
	String ain;
	/**
	 * Pathology Number
	 */
	String pathologyNumber;
	/**
	 * Date submitted
	 */
	String dateSubmitted;
	/**
	 * Gross
	 */
	String gross;
	/**
	 * Microscopic Description
	 */
	String microscopicDescription;
	/**
	 * Diagnosis
	 */
	String diagnosis;
	/**
	 * Case identifier
	 */
	String caseIdentifier;
	/**
	 * Edit tissue number
	 */
	String editTissueNumber;
	/**
	 * 
	 */
	String experimentIdentifier;
	
	/***/
	String cohortId;
	
	/***/
	Long animalId;
    
     /***/
    private String eventId;
    /***/
    private String protocolId;
    
   private String sourceLocal;  
    

    private String[] tissueArr;
    
    public String getEventId()
    {
        return eventId;
    }

    
    public void setEventId(String eventId)
    {
        this.eventId = eventId;
    }

    private String entityMapId;
    
    public String getEntityMapId()
    {
        return entityMapId;
    }


    
    public void setEntityMapId(String entityMapId)
    {
        this.entityMapId = entityMapId;
    }

    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }

    public String getProtocolId()
    {
        return protocolId;
    }

    
    public void setProtocolId(String protocolId)
    {
        this.protocolId = protocolId;
    }
	
	public String getCohortId() {
		return cohortId;
	}

	public void setCohortId(String cohortId) {
		this.cohortId = cohortId;
	}
	
	

	/**
	 * 
	 */
	public void reset() {
		
	}
	
	/**
	 * Returns the id assigned to form bean.
	 * @return the id assigned to form bean.
	 */
	public int getFormId() {
		return Constants.CASE_FORM_ID;
	}
    
    
    public void setAddNewObjectIdentifier(String addNewFor, Long addObjectIdentifier)
    {
        
        if(addNewFor.equals("tissue"))
        {
            Long ID=new Long(addObjectIdentifier.longValue());              
            String str= ID.toString();            
            List list = new ArrayList();            
            int len= 1;
            if (tissueArr != null)
            {
                for(int i=0;i<tissueArr.length;i++)
                    list.add(tissueArr[i]);
                len=tissueArr.length + 1;
            }                           
            list.add(str);
            String [] tissueArr = new String[len];   
                            
            for(int i=0;i<len;i++)
                tissueArr[i]=(String)list.get(i);              
            setTissueArr(tissueArr);
        }
         
    }
    
    
    
	/**
	 * 
	 */
	public void setAllValues(AbstractDomainObject abstractDomain)   {
        PathologyEventRecords caseObject = (PathologyEventRecords)abstractDomain;
	/*	if (caseObject.getAnimal() != null) {
        this.ain = String.valueOf(caseObject.getAnimal().getId());
        }
	*/	
        if (caseObject.getAnimal() != null) {
            this.animalId  = caseObject.getAnimal().getId();
            }
        
        this.pathologyNumber = caseObject.getPathologyNumber();
		if (caseObject.getSubmittedDate() != null) {
        this.dateSubmitted = Utility.parseDateToString(caseObject.getSubmittedDate(),Utility.datePattern(caseObject.getSubmittedDate().toString()));
        }
		this.gross = caseObject.getGross();
		this.microscopicDescription = caseObject.getMicroscopicDescription();
		this.diagnosis = caseObject.getDiagnosis();
        this.id = caseObject.getId().longValue();
        
        Collection Coll= caseObject.getTissueCollection();
        if(Coll != null && Coll.size() != 0 )
        {
            String [] tissueArr = new String[Coll.size()];
            Iterator iterate= Coll.iterator();           
            int i=0;                  
            while(iterate.hasNext())
            {
                Tissue tissue = (Tissue) iterate.next();                  
                  tissueArr[i++]=tissue.getId().toString();
            }
            setTissueArr(tissueArr);
        }
		
	}
	
	/**
	 * @return Returns the ain.
	 */
	public String getAin() {
		return ain;
	}
	/**
	 * @param ain The ain to set.
	 */
	public void setAin(String ain) {
		this.ain = ain;
	}
	/**
	 * @return Returns the dateSubmitted.
	 */
	public String getDateSubmitted() {
		return dateSubmitted;
	}
	/**
	 * @param dateSubmitted The dateSubmitted to set.
	 */
	public void setDateSubmitted(String dateSubmitted) {
		this.dateSubmitted = dateSubmitted;
	}
	/**
	 * @return Returns the diagnosis.
	 */
	public String getDiagnosis() {
		return diagnosis;
	}
	/**
	 * @param diagnosis The diagnosis to set.
	 */
	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
	/**
	 * @return Returns the gross.
	 */
	public String getGross() {
		return gross;
	}
	/**
	 * @param gross The gross to set.
	 */
	public void setGross(String gross) {
		this.gross = gross;
	}
	/**
	 * @return Returns the microscopicDescription.
	 */
	public String getMicroscopicDescription() {
		return microscopicDescription;
	}
	/**
	 * @param microscopicDescription The microscopicDescription to set.
	 */
	public void setMicroscopicDescription(String microscopicDescription) {
		this.microscopicDescription = microscopicDescription;
	}
	/**
	 * @return Returns the pathologyNumber.
	 */
	public String getPathologyNumber() {
		return pathologyNumber;
	}
	/**
	 * @param pathologyNumber The pathologyNumber to set.
	 */
	public void setPathologyNumber(String pathologyNumber) {
		this.pathologyNumber = pathologyNumber;
	}
	/**
	 * @return Returns the caseIdentifier.
	 */
	public String getCaseIdentifier() {
		return caseIdentifier;
	}
	/**
	 * @param caseIdentifier The caseIdentifier to set.
	 */
	public void setCaseIdentifier(String caseIdentifier) {
		this.caseIdentifier = caseIdentifier;
	}
	
	/**
	 * @return Returns the editTissueNumber.
	 */
	public String getEditTissueNumber() {
		return editTissueNumber;
	}
	/**
	 * @param editTissueNumber The editTissueNumber to set.
	 */
	public void setEditTissueNumber(String editTissueNumber) {
		this.editTissueNumber = editTissueNumber;
	}
	/**
	 * @return Returns the experimentIdentifier.
	 */
	public String getExperimentIdentifier() {
		return experimentIdentifier;
	}
	/**
	 * @param experimentIdentifier The experimentIdentifier to set.
	 */
	public void setExperimentIdentifier(String experimentIdentifier) {
		this.experimentIdentifier = experimentIdentifier;
	}
	
	/**
	 * Overrides the validate method of ActionForm.
	 * */
	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request) {
		ActionErrors errors = new ActionErrors();
		Validator validator = new Validator();
		
		if (dateSubmitted == null || dateSubmitted.equals("") ||  !validator.checkDate(String.valueOf(dateSubmitted))) {
			errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
					"errors.date.invalid", ApplicationProperties
					.getValue("case.date.submitted")));
		}
        
         if (validator.isEmpty(pathologyNumber))
         {
             errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                     "errors.item.required", ApplicationProperties
                             .getValue("case.pathology.number")));
         }
        
		return errors;
	}

	public Long getAnimalId() {
		return animalId;
	}

	public void setAnimalId(Long animalId) {
		this.animalId = animalId;
	}

    
    public String getTarget()
    {
        return target;
    }

    
    public void setTarget(String target)
    {
        this.target = target;
    }


    
    public String getSourceLocal()
    {
        return sourceLocal;
    }


    
    public void setSourceLocal(String sourceLocal)
    {
        this.sourceLocal = sourceLocal;
    }


    
   
    
    public String[] getTissueArr()
    {
        return tissueArr;
    }


    
    public void setTissueArr(String[] tissueArr)
    {
        this.tissueArr = tissueArr;
    }

}
