/**
 * <p>Title: UserGroup Class>
 * <p>Description:  UserGroupBizLogic is used to add user group information into the database using Hibernate </p>
 * Copyright:TODO
 * @author Gautam Shetty
 * @version 1.00
 */
package edu.ucdavis.caelmir.bizlogic;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.dao.DAOFactory;
import edu.wustl.common.dao.JDBCDAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;


/**
 * @author gautam_shetty
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserGroupBizLogic extends DefaultBizLogic
{

    /* (non-Javadoc)
     * @see edu.wustl.common.bizlogic.DefaultBizLogic#insert(java.lang.Object, edu.wustl.common.dao.DAO, edu.wustl.common.beans.SessionDataBean)
     */
    protected void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {
        UserGroup userGroup = (UserGroup) obj;
        Set userSet = new HashSet();
        Iterator iterator = userGroup.getUserCollection().iterator();
        while (iterator.hasNext())
        {
            User user = (User) iterator.next();
            List list = dao.retrieve(User.class.getName(), "csmUserId", user.getCsmUserId());
            if (list != null && list.isEmpty() == false)
            {
                user = (User)list.get(0);
                userSet.add(user);
            }
        }

        userGroup.setUserCollection(userSet);
        dao.insert(userGroup, sessionDataBean,false,false);
    }

    /**
     * Returns the display name of the csm user group for the passed group id.
     * @param groupId The group id whose display name is required.
     * @return the display name of the csm user group for the passed group id.
     * @throws DAOException
     */
    public String getUserGroupDisplayName(String groupId) throws DAOException
    {
        JDBCDAO jdbcdao = (JDBCDAO)DAOFactory.getInstance().getDAO(Constants.JDBC_DAO);
        jdbcdao.openSession(null);
        String [] selectColumnNames = {"DISPLAY_NAME"};
        String [] whereColumnNames = {"GROUP_ID"};
        String [] whereColumnCondition = {"="};
        String [] whereColumnValues = {groupId};
        List list = jdbcdao.retrieve("csm_user_group_display_name", selectColumnNames,
                                    whereColumnNames, whereColumnCondition,
                                    whereColumnValues, Constants.AND_JOIN_CONDITION);
        jdbcdao.closeSession();
        String userGroupDisplayName = new String();
        if (list != null && list.isEmpty() == false)
        {
            List row = (List) list.get(0);
            userGroupDisplayName = (String) row.get(0);
        }

        return userGroupDisplayName;
    }


    /**
     * Updates an objects into the database.
     * @param obj The object to be updated into the database.
     * @throws DAOException
     */
    protected void update(DAO dao, Object obj, Object oldObj, SessionDataBean sessionDataBean) throws DAOException, UserNotAuthorizedException
    {
        UserGroup newUserGroup = (UserGroup) obj;
        Collection oldUserCol = newUserGroup.getUserCollection();

        Iterator iter = oldUserCol.iterator();
     //   List UG = dao.retrieve(UserGroup.class.getName(),"id",newUserGroup.getId());
   //     UserGroup latestUG = (UserGroup) UG.get(0);
        Collection tempSet = new HashSet();
        while (iter.hasNext()) {
            User oldUser = (User) iter.next();
            List selectedUser = dao.retrieve(User.class.getName(),"csmUserId",oldUser.getCsmUserId());
            User userObj = (User) selectedUser.get(0);
            tempSet.add(userObj);
        }
        newUserGroup.setUserCollection(null);
        newUserGroup.setUserCollection(tempSet);

       /* latestUG.setName(newUserGroup.getName());
        latestUG.setDescription(newUserGroup.getDescription());
        latestUG.setUserRole(newUserGroup.getUserRole());
        
        latestUG.setActivityStatus(newUserGroup.getActivityStatus());*/

        dao.update(newUserGroup, null, false, false, false);
    }

}
