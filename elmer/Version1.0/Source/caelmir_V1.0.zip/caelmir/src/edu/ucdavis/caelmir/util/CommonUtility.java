/**
 *<p>Title:CommonUtility </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.util;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;

import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;

import edu.ucdavis.caelmir.domain.protocol.SpecimenProtocol;
import edu.ucdavis.caelmir.domain.subject.Mouse;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Utility;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.global.ApplicationProperties;

public class CommonUtility
{

    /**
     * Fields from selectColumnName will be populated from animal object   
     * @param selectColumnName String Array
     * @param animalList list of Animal object
     * @return List 
     */
    public static List ConvertToAnimalList(String[] selectColumnName,
            List animalList)
    {
        List dataList = new ArrayList();

        if (animalList != null && !animalList.isEmpty())
        {
            int i = 0;
            while (i < animalList.size())
            {
                Mouse mouse = (Mouse) animalList.get(i);
                List list = new ArrayList();

                if (selectColumnName != null && selectColumnName.length != 0)
                {
                    for (int j = 0; j < selectColumnName.length; j++)
                    {
                        if (selectColumnName[j].equals("backgroundStrain"))
                        {
                            if (mouse.getBackgroundStrain() != null
                                    && !mouse.getBackgroundStrain().equals(""))
                                list.add(mouse.getBackgroundStrain());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j]
                                .equals("animalColonyReference"))
                        {
                            if (mouse.getAnimalColonyReference() != null
                                    && !mouse.getAnimalColonyReference()
                                            .equals(""))
                                list.add(mouse.getAnimalColonyReference());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("animalNumber"))
                        {
                            if (mouse.getAnimalNumber() != null
                                    && !mouse.getAnimalNumber().equals(""))
                                list.add(mouse.getAnimalNumber());
                            else
                                list.add("-");
                        }

                        else if (selectColumnName[j].equals("genus"))
                        {
                            if (mouse.getGenus() != null
                                    && !mouse.getGenus().equals(""))
                                list.add(mouse.getGenus());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("strain"))
                        {
                            if (mouse.getStrain() != null
                                    && !mouse.getStrain().equals(""))
                                list.add(mouse.getStrain());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("birthDate"))
                        {
                            if (Utility.parseDateToString(mouse.getBirthDate(),
                                    Constants.DATE_PATTERN_MM_DD_YYYY) != null
                                    && !Utility.parseDateToString(
                                            mouse.getBirthDate(),
                                            Constants.DATE_PATTERN_MM_DD_YYYY)
                                            .equals(""))

                                list.add(Utility.parseDateToString(mouse
                                        .getBirthDate(),
                                        Constants.DATE_PATTERN_MM_DD_YYYY));
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("geneOfInterest"))
                        {
                            if (mouse.getGeneOfInterest() != null
                                    && !mouse.getGeneOfInterest().equals(""))
                                list.add(mouse.getGeneOfInterest());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("species"))
                        {
                            if (mouse.getSpecies() != null
                                    && !mouse.getSpecies().equals(""))
                                list.add(mouse.getSpecies());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("sex"))
                        {
                            if (mouse.getSex() != null
                                    && !mouse.getSex().equals(""))
                                list.add(mouse.getSex());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("length"))
                        {
                            if (mouse.getLength() != null
                                    && !mouse.getLength().equals(""))
                                list.add(mouse.getLength());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("weight"))
                        {
                            if (mouse.getWeight() != null
                                    && !mouse.getWeight().equals(""))
                                list.add(mouse.getWeight());
                            else
                                list.add("-");
                        }

                    }
                    dataList.add(list);
                }

                i++;
            }
        }
        return dataList;
    }

    public static List ConvertToTgMouseList(String[] selectColumnName,
            List pathologyList)
    {
        List dataList = new ArrayList();
        if (pathologyList != null && !pathologyList.isEmpty())
        {
            int i = 0;
            while (i < pathologyList.size())
            {
                PathologyEventRecords tgMouse = (PathologyEventRecords) pathologyList
                        .get(i);
                List list = new ArrayList();

                if (selectColumnName != null && selectColumnName.length != 0)
                {
                    for (int j = 0; j < selectColumnName.length; j++)
                    {
                        if (selectColumnName[j].equals("pathologyNumber"))
                        {
                            if (tgMouse.getPathologyNumber() != null
                                    && !tgMouse.getPathologyNumber().equals(""))
                                list.add(tgMouse.getPathologyNumber());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j]
                                .equals("microscopicDescription"))
                        {
                            if (tgMouse.getMicroscopicDescription() != null
                                    && !tgMouse.getMicroscopicDescription()
                                            .equals(""))
                                list.add(tgMouse.getMicroscopicDescription());
                            else
                                list.add("-");
                        }
                        else if (selectColumnName[j].equals("diagnosis"))
                        {
                            if (tgMouse.getDiagnosis() != null
                                    && !tgMouse.getDiagnosis().equals(""))
                                list.add(tgMouse.getDiagnosis());
                            else
                                list.add("-");
                        }

                        else if (selectColumnName[j].equals("submittedDate"))
                        {
                            if (tgMouse.getSubmittedDate() != null
                                    && !tgMouse.getSubmittedDate().equals(""))
                                list.add(tgMouse.getSubmittedDate());
                            else
                                list.add("-");
                        }

                    }
                    dataList.add(list);
                }

                i++;
            }
        }
        return dataList;
    }

    /**
     * convert the object array to string array
     * @param ObjArray
     * @return string array
     */
    public static String[] convertToStringArray(Object[] ObjArray)
    {
        String[] strArray;
        List list = new ArrayList();
        if (ObjArray != null && ObjArray.length != 0)
        {
            //strArray = new String[ObjArray.length];
            for (int i = 0; i < ObjArray.length; i++)
            {
                // strArray[i] = ObjArray[i].toString();
                if (ObjArray[i] != null
                        && !ObjArray[i].toString().equalsIgnoreCase(""))
                    list.add(ObjArray[i].toString());
            }
        }
        // else
        //   strArray = null;
        strArray = ConvertToArray(list);
        return strArray;

    }

    /**
     * Add the object contents to list to form one row and then add this list to another list.   
     * @param dataList contains object list 
     * @return list of list 
     */
    public static List convertToList(List dataList)
    {
        List rlist = new ArrayList();
        Object[] objArray = null;
        if (dataList != null)
        {
            for (int i = 0; i < dataList.size(); i++)
            {
                objArray = (Object[]) dataList.get(i);
                if (objArray != null)
                {
                    List list = new ArrayList();
                    for (int j = 0; j < objArray.length; j++)
                    {
                        if (objArray[j] != null
                                && (!objArray[j].toString().equals("")))
                        {
                            list.add(objArray[j]);
                        }
                        else
                            list.add("-");
                    }
                    rlist.add(list);
                }

            }
        }
        return rlist;
    }

    /**
     * set the array filed to null if it is empty
     * @param columnArray string array
     * @return string array intialised with null
     */
    public static List assignToNull(String[] columnArray)
    {
        List list = new ArrayList();
        if (columnArray != null)
        {

            //  String returnArr[];
            for (int i = 0; i < columnArray.length; i++)
            {
                if (!columnArray[i].equals(""))
                    list.add(columnArray[i].toString());
            }
        }
        return list;
    }

    /**
     * increase the size of array by one add re-intialize it.
     * @param strArray
     * @param searchCol the new value to be added
     * @return the new String array
     */
    public static String[] createArray(String[] strArray, String searchCol)
    {
        int i = 0;
        if (strArray == null)
        {
            if (searchCol != null)
            {
                String[] newArr = new String[1];
                newArr[0] = searchCol;
                return newArr;
            }
        }
        else if (strArray != null)
        {
            String[] newArr = new String[strArray.length + 1];
            for (i = 0; i < strArray.length; i++)
            {
                newArr[i] = strArray[i];
            }

            newArr[i] = searchCol;
            return newArr;
        }

        return null;
    }

    /**
     * increase the size of array by one add re-intialize it .
     * @param objArray : object array
     * @param searchCol the new value to be added
     * @return the new Object array
     */
    public static Object[] createObjArray(Object[] objArray, String searchCol,
            String[] whereColumnCondition)
    {
        int i = 0;
        int k = 0;
        Object[] newArr = null;
        if (objArray.length +1 == whereColumnCondition.length)
        {
             newArr = new Object[objArray.length + 1];
            for (i = 0; i < objArray.length; i++)         //animal
            {
                //if(!objArray[i].toString().equals(""))
                newArr[k++] = objArray[i].toString();
            }
        }
        else if(objArray.length == whereColumnCondition.length )
        {
            newArr = new Object[objArray.length ];            
            for (i = 0; i < objArray.length; i++)        //genotype
            {
                if(!objArray[i].toString().equals(""))
                newArr[k++] = objArray[i].toString();
            }
        }
        
        newArr[k] = searchCol;
        return newArr;
    }

    /**
     * Convert the list to String array
     * @param list 
     * @return String array
     */
    public static String[] ConvertToArray(List list)
    {
        if (list != null && !list.isEmpty())
        {
            String[] showNameFields = new String[list.size()];
            int i = 0;
            while (i < list.size())
            {
                showNameFields[i] = (String) list.get(i);
                i++;
            }
            return showNameFields;
        }
        return null;

    }
    
    public static boolean checkDuplicate(String textContent) throws DAOException
    {
        if (textContent != null && !textContent.equalsIgnoreCase(""))
        {
          DefaultBizLogic bizLogic = new DefaultBizLogic();
          List list = bizLogic.retrieve(SpecimenProtocol.class.getName(),
                        "title", textContent.trim());
          if (list != null && !list.isEmpty())
          {
                return true;
            }
       }
        return false;
   }

    public static List AddToList(String[] strArr)
    {
        List list = new ArrayList();
        if (strArr != null)
            for (int i = 0; i < strArr.length; i++)
            {
                list.add(strArr[i].toString());
            }

        return list;
    }

}
