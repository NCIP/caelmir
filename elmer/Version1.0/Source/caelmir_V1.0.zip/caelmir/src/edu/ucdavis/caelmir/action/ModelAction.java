/**
 * 
 */
package edu.ucdavis.caelmir.action;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.ModelForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author ravinder_kankanala
 *
 */
public class ModelAction extends BaseAction {


    /**
     * Overrides the execute method of Action class.
     * Sets the various fields in new model page.
     * */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
    	  String pageOf;
    	  boolean isAccessPresent = true;
    	  
    	  ModelForm  modelForm= (ModelForm) form;
    	  String operation = request.getParameter(Constants.OPERATION);
    	  request.setAttribute(Constants.OPERATION, operation);
        
    	  pageOf = request.getParameter(Constants.PAGEOF);
    	  request.setAttribute(Constants.PAGEOF, pageOf);
    	  
    	
    	  if (operation.equalsIgnoreCase(Constants.ADD))
          {
              isAccessPresent = isAccessPresent(request,
                      Permissions.MODEL_CREATE,
                      Permissions.MODEL_CREATE_ACCESS_DENIED);
          }
          else if (operation.equalsIgnoreCase(Constants.EDIT))
          {
              isAccessPresent = isAccessPresent(request,
                      Permissions.MODEL_UPDATE,
                      Permissions.MODEL_UPDATE_ACCESS_DENIED);
            
          }
          else if (operation.equalsIgnoreCase(Constants.VIEW))
          {
              isAccessPresent = isAccessPresent(request,
                      Permissions.MODEL_READ,
                      Permissions.MODEL_READ_ACCESS_DENIED);
          }
          if (!isAccessPresent)
          {
              return mapping
                      .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
          }
    	
          if(!operation.equals(Constants.VIEW))
          {
              if (isAccessPresent(request, Permissions.MODEL_DELETE,
                      Permissions.MODEL_DELETE_ACCESS_DENIED))
              {
                  request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                          true));
              }
              else
              {
                  request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                          false));
              }
          }
          
          //check for edit privelege.
	        if(operation.equals(Constants.VIEW))
	         {
	            boolean editPermission = PrivilegeUtil.checkPrivilege(this.getClass(),
	                    Model.class.getName(), request.getSession(),
	                    Permissions.MODEL_UPDATE);
	            if (!editPermission)
	            {
	                request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(false));
	            }
	            else
	            {
	                request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(true));
	            }

	         }
	        
          
          
          
          
        
        if (operation.equals(Constants.EDIT)|| operation.equals(Constants.VIEW))
        {
        	
            checkForStudyData(form,request);  
        }
                
        request.setAttribute(Constants.ACTIVITY_STATUS ,modelForm.getActivityStatus());
        return mapping.findForward(pageOf);
 
      }


	     
      private void checkForStudyData(ActionForm form, HttpServletRequest request) throws DAOException
      {
          
          ModelForm modelForm = (ModelForm) form;
          Long systemIdentifier = new Long(modelForm.getId());        
          DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();        
          List list = defaultBizLogic.retrieve(Model.class.getName(),"id",systemIdentifier);
          Model model = null;
          
           request.setAttribute(Constants.STUDY_DATA_FLAG,new Boolean(false));
           
           if (list != null && !list.isEmpty()) 
           {
               model = (Model) list.get(0);
           }
            
           if (model != null) 
           {             
                  Collection studyColl= model.getStudyCollection();
                  if(studyColl != null && !studyColl.isEmpty())
                   {
                          request.setAttribute(Constants.STUDY_DATA_FLAG,new Boolean(true));
                    }
            }
         }
              
			          
			/**
			 * This method is used to check the given privilege on given object.
			 * @param request To get the session data bean
			 * @param privilege Name of the privilege
			 * @param accessDeniedMessage The message to be displayed if the access is not present.
			 * @return boolean true if the access is present otherwise false.
			 */
			private boolean isAccessPresent(HttpServletRequest request,
			        String privilege, String accessDeniedMessage)
			{
			    boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
			            Model.class.getName(), request.getSession(), privilege);
			    if (!isAccessPresent)
			    {
			        request.setAttribute(Constants.STATUS_MESSAGE_KEY,
			                accessDeniedMessage);
			    }
			    return isAccessPresent;
			}
			
			
}  			