
package edu.ucdavis.caelmir.action;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import edu.ucdavis.caelmir.actionForm.TissueForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.exception.BizLogicException;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.logger.Logger;

/**Title:ApplyTissueAction
 * Description:This class is responsible to handle all the requests related to the tissue object. The class populates all the 
 * required request parameters which are needed on the page.
 * @author Vishvesh Mulay
 * @version 1.0
 *
 */
public class ApplyTissueAction extends BaseAction
{
    
    /**This method is called when user clicks on the "add" link for the tissue object . The method populates all 
     * the required lists and passes the control onto the appropriate page.
     * 
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
    {

        TissueForm tissueForm = (TissueForm) form;

        request.setAttribute(Constants.CASE_IDENTIFIER, tissueForm
                .getCaseIdentifier());

        if (tissueForm.getSubmitType() != null
                && tissueForm.getSubmitType().equals(Constants.BACK))
        {
            return mapping.findForward(Constants.PAGE_OF_CASE);
        }

        if (tissueForm.getSubmitType() != null
                && tissueForm.getSubmitType().equals(Constants.SUBMIT))
        {
          //  tissueForm.setSelectedSlide("");
        }

        DefaultBizLogic bizLogic = (DefaultBizLogic) BizLogicFactory
                .getBizLogic(tissueForm.getFormId());

        List caseObjectList = null;
        PathologyEventRecords caseObject = null;
        try
        {
            caseObjectList = bizLogic.retrieve(PathologyEventRecords.class.getName(),
                    Constants.ID, new Long(tissueForm.getCaseIdentifier()));
            caseObject = (PathologyEventRecords) caseObjectList.get(0);
            populateTissue(tissueForm, caseObject);
            bizLogic.update(caseObject, caseObject, Constants.HIBERNATE_DAO,
                    getSessionData(request));
           // setTissueIdentifier(caseObject, tissueForm, request);

        }
        catch (BizLogicException excp)
        {
            ActionErrors errors = new ActionErrors();
            ActionError error = new ActionError(Constants.ERRRORS_ITEM, excp
                    .getMessage());
            errors.add(ActionErrors.GLOBAL_ERROR, error);
            saveErrors(request, errors);
            Logger.out.error(excp.getMessage(), excp);
            return mapping.findForward(Constants.FAILURE);
        }
        catch (UserNotAuthorizedException excp)
        {

            ActionErrors errors = new ActionErrors();
            SessionDataBean sessionDataBean = getSessionData(request);
            String userName;
            if (sessionDataBean == null)
            {
                userName = "";
            }
            else
            {
                userName = sessionDataBean.getUserName();
            }
            ActionError error = new ActionError(
                    Constants.ACCESS_ADDEDIT_OBJECT_DENIED, userName,
                    caseObject.getClass().getName());
            errors.add(ActionErrors.GLOBAL_ERROR, error);
            saveErrors(request, errors);
            Logger.out.error(excp.getMessage(), excp);
            return mapping.findForward(Constants.FAILURE);

        }
        catch (DAOException daoException)
        {
            return mapping.findForward(new String(Constants.FAILURE));

        }

        if (tissueForm.getSubmitType() != null
                && tissueForm.getSubmitType().equals(Constants.SUBMIT_BACK))
        {
            return mapping.findForward(Constants.PAGE_OF_CASE);
        }

        return mapping.findForward(Constants.PAGE_OF_TISSUE);
    }

    /**
     * This method is used to set the identifier of the selected tissue in the request.
     * @param caseObject Parent Case object. 
     * @param tissueForm Tissue form from which the identifier is to be matched.
     * @param request Request to set the attribute in.
     */
    public void setTissueIdentifier(PathologyEventRecords caseObject, TissueForm tissueForm,
            HttpServletRequest request)
    {
        Collection tissueCollection = caseObject.getTissueCollection();
        Iterator tissueIterator = tissueCollection.iterator();
        Tissue tissue = null;
        while (tissueIterator.hasNext())
        {
            tissue = (Tissue) tissueIterator.next();
     /*       if (tissue.getTissue().toString().equals(
                    tissueForm.getTissueNumberHidden()))
            {
                request.setAttribute(Constants.TISSUE_IDENTIFIER, tissue
                        .getId().toString());
            }*/
        }
    }

    /**
     * This method is used to populate the request parameters to load the page.
     * @param tissueForm Tissue related form.
     * @param caseObject the object from which to populate the arguments. 
     */
    public void populateTissue(TissueForm tissueForm, PathologyEventRecords caseObject)
            throws DAOException
    {

        Tissue tissue = null;

        boolean newTissue = false;

        if (tissueForm.getTissueIdentifier() != null
                && !tissueForm.getTissueIdentifier().equals(""))
        {
            newTissue = false;
            tissue = getTissue(caseObject, tissueForm.getTissueIdentifier());
        }
        else
        {
            newTissue = true;
            tissue = new Tissue();
        }
       // tissue.setTissue(new Long(tissueForm.getTissueNumberHidden()));

        Slide slide;
        if (tissueForm.getSlideDeleted() != null
                && tissueForm.getSlideDeleted().equals(Constants.TRUE))
        {
            slide = getSlide(tissue, tissueForm.getSlideIdentifier());
            tissue.getSlideCollection().remove(slide);
            slide.setTissue(null);
        }
        else
        {
            if (tissueForm.getSlideIdentifier() != null
                    && !tissueForm.getSlideIdentifier().equals(""))
            {
                slide = getSlide(tissue, tissueForm.getSlideIdentifier());
              //  populateSlide(tissueForm, slide);
                slide.setImageCollection(getPathologyImages(tissueForm, slide));
            }
            else
            {
            /*    if (tissueForm.getSlideNumber() != null
                        && !tissueForm.getSlideNumber().equals(""))
                {
                    slide = new Slide();
                    populateSlide(tissueForm, slide);
                    slide.setImageCollection(getPathologyImages(tissueForm,
                            slide));

                    tissue.getSlideCollection().add(slide);
                    slide.setTissue(tissue);
                }*/
            }
        }

        if (newTissue)
        {
            caseObject.getTissueCollection().add(tissue);
            tissue.setPathologyEventRecords(caseObject);
        }
    }

    /**
     * This method is used to populate the case object from the tissue action form.
     * @param tissueForm Tissue form
     * @param slide Slide object
     
    public void populateSlide(TissueForm tissueForm, Slide slide)
    {

        String slideNumber = tissueForm.getSlideNumber();
        String stain = tissueForm.getStain();
        String microscopicDescription = tissueForm
                .getTissueMicroscopicDescription();
        String diagnosis = tissueForm.getTissueDiagnosis();
        slide.setSlideNumber(slideNumber);
        slide.setStain(stain);
        slide.setMicroscopicDescription(microscopicDescription);
        slide.setDiagnosis(diagnosis);
    }
*/
    /**
     * This method is used to get the pathology images from the slide object.  
     * @param slide Slide object.
     * @param tissueForm Tissue action form. 
     * @return Collection of "PathologyImage" objects.
     */
    public Collection getPathologyImages(TissueForm tissueForm, Slide slide)
            throws DAOException
    {

        DefaultBizLogic bizLogic = (DefaultBizLogic) BizLogicFactory
                .getBizLogic(tissueForm.getFormId());

        int imageCounter = Integer.parseInt(tissueForm.getImageCounter());
        Set pathologyImageSet = new HashSet();

        FormFile formFile;
        List imageTypeList;

        String imageIdentifier;
        for (int i = 1; i < imageCounter; i++)
        {
            formFile = (FormFile) tissueForm
                    .getValue(Constants.SLIDE_IMAGES_UNDERSCORE + i);
            imageIdentifier = (String) tissueForm
                    .getValue(Constants.IMAGE_TYPES_UNDERSCORE + i);
            Image pathologyImage = new Image();
            ImageType imageType = new ImageType();
            imageType.setName(formFile.getFileName());
            
            pathologyImage.setImageType(imageType);
            //pathologyImage.setFileName(formFile.getFileName());
            //pathologyImage.setFileSize(new Long(formFile.getFileSize()));
            if (imageIdentifier != null && !imageIdentifier.equals(""))
            {
                imageTypeList = (List) bizLogic.retrieve(ImageType.class
                        .getName(), Constants.ID, new Long(imageIdentifier));
                if (imageTypeList.size() > 0)
                {
                    pathologyImage.setImageType((ImageType) imageTypeList
                            .get(0));
                }
                else
                {
                    pathologyImage.setImageType(null);
                }

            }
            try
            {
                byte[] a = formFile.getFileData();
                pathologyImage.setImage(a);
            }
            catch (Exception e)
            {

                e.printStackTrace();
            }
            pathologyImageSet.add(pathologyImage);

            slide.setImageCollection(pathologyImageSet);
           // pathologyImage.setSlide(slide);
        }
        return pathologyImageSet;

    }

    /**
     * This method is used to get the session data bean from the session passing the request to the method.
     * @param request HTTPRequest to get the session from.
     * @return SessionDataBean session data bean.
     */
    protected SessionDataBean getSessionData(HttpServletRequest request)
    {
        Object obj = request.getSession().getAttribute(Constants.SESSION_DATA);
        if (obj != null)
        {
            SessionDataBean sessionData = (SessionDataBean) obj;
            return sessionData;
        }
        return null;

    }

    /**
     * this method is used to get the tissue object as per the selected tissue identifier. 
     * @param caseObject Case object to get the tissue object from.
     * @param tissueIdentifier Selected tissue on the page.
     * @return Tissue Selected tissue object.
     */
    public Tissue getTissue(PathologyEventRecords caseObject, String tissueIdentifier)
    {
        Collection tissueCollection = caseObject.getTissueCollection();
        Iterator tissueIterator = tissueCollection.iterator();
        Tissue tissue;
        while (tissueIterator.hasNext())
        {
            tissue = (Tissue) tissueIterator.next();
            if (tissue.getId().toString().equals(tissueIdentifier))
            {
                return tissue;
            }
        }
        return null;
    }

    /**
     * this method is used to get the Slide object as per the selected slide identifier. 
     * @param tissue Tissue  object to get the slide object from.
     * @param slideIdentifier Selected slide on the page.
     * @return Tissue Selected tissue object.
     */
    public Slide getSlide(Tissue tissue, String slideIdentifier)
    {
        Collection slideCollection = tissue.getSlideCollection();
        Iterator slideIterator = slideCollection.iterator();
        Slide slide;
        while (slideIterator.hasNext())
        {
            slide = (Slide) slideIterator.next();
            if (slide.getId().toString().equals(slideIdentifier))
            {
                return slide;
            }
        }
        return null;
    }

}
