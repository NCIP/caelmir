/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.actionForm;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;



public class ProtocolEventActionForm extends AbstractActionForm
{

    String events [];
    
    String protocols [];
    
    
    
    public String[] getEvents()
    {
        return events;
    }

    
    public void setEvents(String[] events)
    {
        this.events = events;
    }

    
    public String[] getProtocols()
    {
        return protocols;
    }

    
    public void setProtocols(String[] protocols)
    {
        this.protocols = protocols;
    }

   
    public int getFormId()
    {
        
        return 0;
    }

  
    public void setAllValues(AbstractDomainObject abstractDomain)
    {
       

    }

    protected void reset()
    {
        // TODO Auto-generated method stub

    }

}
