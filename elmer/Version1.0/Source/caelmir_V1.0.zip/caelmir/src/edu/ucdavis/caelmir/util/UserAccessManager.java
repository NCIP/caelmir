package edu.ucdavis.caelmir.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.research.Study;



public class UserAccessManager {
	
	
	
	public static boolean isUserPresentForStudy(Study study,Long userId) {
		boolean userPresent = false;
		Collection studyUserList = study.getUserCollection();
		List userList = new ArrayList();
		if (studyUserList != null && !studyUserList.isEmpty()) {
			Iterator studyUserListIterator = studyUserList.iterator();
			while (studyUserListIterator.hasNext()) {
                User user = (User) studyUserListIterator.next();
				
				if (user.getId().equals(userId)) {
					userPresent = true;
					return userPresent;
				}
			}
			
		}
		Collection userGroup = study.getUserGroupCollection();
		if (userGroup != null && !userGroup.isEmpty()) {
			Iterator userGroupIterator = userGroup.iterator();
			while (userGroupIterator.hasNext()) {
				UserGroup group = (UserGroup) userGroupIterator.next();
				if (group != null) {
					Collection userInUserGroup = group.getUserCollection();
					if (userInUserGroup != null && !userInUserGroup.isEmpty()) {
						Iterator userInUserGroupIterator = userInUserGroup.iterator();
						while (userInUserGroupIterator.hasNext()) {
							User userInGroup = (User) userInUserGroupIterator.next();
							if (userInGroup.getId().equals(userId)) {
							userPresent = true;
							return userPresent;
							}
						}
					}
				}
			}
		}
		return userPresent;
	}
	
	public static boolean isUserPresentForExperiment(Experiment experiment, Long userId) {
		boolean userPresent = false;
		Collection userCollection = experiment.getUserCollection();
		List userList = new ArrayList();
		if (userCollection != null && !userCollection.isEmpty()) {
			Iterator userCollectionIterator = userCollection.iterator();
			while (userCollectionIterator.hasNext()) {
				User user = (User) userCollectionIterator.next();
				if (user.getId().equals(userId)) {
					return true;
				}
			}
		}
		Collection userGroup = experiment.getUserGroupCollection();
		if (userGroup != null && !userGroup.isEmpty()) {
			Iterator userGroupIterator = userGroup.iterator();
			while (userGroupIterator.hasNext()) {
				UserGroup group = (UserGroup) userGroupIterator.next();
				if (group != null) {
					Collection userInUserGroup = group.getUserCollection();
					if (userInUserGroup != null && !userInUserGroup.isEmpty()) {
						Iterator userInUserGroupIterator = userInUserGroup.iterator();
						while (userInUserGroupIterator.hasNext()) {
							User userInGroup = (User) userInUserGroupIterator.next();
							if (userInGroup.getId().equals(userId)) {
								return true;
							}
						}
					}
				}
			}
		}
		return userPresent;
	}

}
