/**
 * <p>Title: DomainObjectFactory Class>
 * <p>Description:	DomainObjectFactory is a factory for instances of various domain objects.</p>
 * Copyright:    Copyright (c) year
 * Company: Washington University, School of Medicine, St. Louis.
 * @author Gautam Shetty
 * @version 1.00
 * Created on Apr 21, 2005
 * */

package edu.ucdavis.caelmir.domain;



import edu.ucdavis.caelmir.actionForm.ReportedProblemForm;
import edu.ucdavis.caelmir.actionForm.UserForm;
import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.ucdavis.caelmir.domain.common.Institution;
import edu.ucdavis.caelmir.domain.common.ReportedProblem;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.ProteomicsEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.domain.subject.Genotype;
import edu.ucdavis.caelmir.domain.subject.Genus;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.domain.subject.Species;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;
import edu.wustl.common.factory.AbstractDomainObjectFactory;
import edu.wustl.common.util.logger.Logger;



/**
 * DomainObjectFactory is a factory for instances of various domain objects.
 * @author gautam_shetty
 */
public class DomainObjectFactory extends AbstractDomainObjectFactory
{
	
    /**
     * Returns the fully qualified name of the class according to the form bean type.
     * @param FORM_TYPE Form bean Id.
     * @return the fully qualified name of the class according to the form bean type.
     */
    public  String getDomainObjectName(int FORM_TYPE)
    {
        String className = null;
        switch(FORM_TYPE)
        {
      
            case Constants.INSTITUTION_FORM_ID:
                className = Institution.class.getName();
            	break;
            case Constants.REPORTED_PROBLEM_FORM_ID:
                className = ReportedProblem.class.getName();
            	break;
            case Constants.USER_FORM_ID:
                className = User.class.getName();
            	break;
            case Constants.USER_GROUP_FORM_ID:
                className = UserGroup.class.getName();
            	break;
//            case Constants.SIGNUP_FORM_ID:
//                className = SignUpUser.class.getName();
//            	break;	
            case Constants.APPROVE_USER_FORM_ID:
                className = User.class.getName();
        		break;
        		
        	case Constants.STUDY_FORM_ID :
                className = Study.class.getName();
                break;
            case Constants.CASE_FORM_ID :
                className = PathologyEventRecords.class.getName();
                break;
        		
            case Constants.EXP_CREATE_FORM_ID:
            	 className = Experiment.class.getName();
            	break;
            	
            case Constants.MICROARRAY_FORM_ID:
           	 className = MicroarrayEventRecords.class.getName();
           	 break;
           	 
            case Constants.PROTEOMICS_FORM_ID:
           	 className = ProteomicsEventRecords.class.getName();
           	break;
            
            case Constants.ANIMAL_ADD:
           	 	className = Mouse.class.getName();
           	 	break;
            	
            case Constants.COHORT_CREATE_FORM_ID:
           	 className = Cohort.class.getName();
           	break;
            
            
            case Constants.GENOTYPE_ADD_ID:
             className = Genotype.class.getName();
            break;
            
            case Constants.COLLECTION_PROTOCOL_ID:
                className = CollectionProtocol.class.getName();
               break;
             
            case Constants.MODEL_FORM_ID:
           	 	className = Model.class.getName();
           	 	break;
              
            case Constants.GENUS_FORM_ID:
           	 	className = Genus.class.getName();
           	 	break; 	
           	 	
            case Constants.SPECIES_FORM_ID:
           	 	className = Species.class.getName();
           	 	break;
                
            case Constants.TISSUE_FORM_ID:
                className = Tissue.class.getName();
                break;  
     
            case Constants.SLIDE_FORM_ID:
                className = Slide.class.getName();
                break; 
                
            case Constants.IMAGE_TYPE_FORM_ID:
                className = ImageType.class.getName();
                break; 
          
        }
        return className;
    }
	
    /**
     * Returns an AbstractDomain object copy of the form bean object. 
     * @param FORM_TYPE Form bean Id.
     * @param form Form bean object.
     * @return an AbstractDomain object copy of the form bean object.
     */
    public  AbstractDomainObject getDomainObject(int FORM_TYPE,AbstractActionForm form) throws AssignDataException
    {
        AbstractDomainObject abstractDomain = null;
        switch(FORM_TYPE)
        {
            case Constants.USER_FORM_ID:
            case Constants.APPROVE_USER_FORM_ID:
                UserForm userForm = (UserForm)form;
            	abstractDomain = new User(userForm);
            	break;
       
            case Constants.REPORTED_PROBLEM_FORM_ID:
                ReportedProblemForm reportedProblemForm = (ReportedProblemForm)form;
            	abstractDomain = new ReportedProblem(reportedProblemForm);
            	break;
            case Constants.INSTITUTION_FORM_ID:
            	abstractDomain = new Institution(form);
            	break;
            case Constants.EXP_CREATE_FORM_ID:
            	abstractDomain = new Experiment(form);
            	break;
            case Constants.COHORT_CREATE_FORM_ID:
            	abstractDomain = new Cohort(form);
            	break;	
           	case Constants.STUDY_FORM_ID :
                abstractDomain = new Study(form);
                break;
            case Constants.USER_GROUP_FORM_ID:
                abstractDomain = new UserGroup(form);
            	break;
                
            case Constants.CASE_FORM_ID :
                abstractDomain = new PathologyEventRecords(form);
                break; 
          
            case Constants.ANIMAL_ADD :
                abstractDomain = new Mouse(form);
                break; 
                
	       case Constants.MICROARRAY_FORM_ID :
                abstractDomain = new MicroarrayEventRecords(form);
                break; 
                
            case Constants.PROTEOMICS_FORM_ID:
                abstractDomain = new ProteomicsEventRecords(form);
                break; 
                
            case Constants.GENOTYPE_ADD_ID:
                abstractDomain = new Genotype(form);
                break; 
            case Constants.COLLECTION_PROTOCOL_ID:
                abstractDomain = new CollectionProtocol(form);
                break; 
                
            case Constants.MODEL_FORM_ID:
                abstractDomain = new Model(form);
                break;     
        
            case Constants.GENUS_FORM_ID:
                abstractDomain = new Genus(form);
                break;    
                
            case Constants.SPECIES_FORM_ID:
                abstractDomain = new Species(form);
                break;
                
            case Constants.TISSUE_FORM_ID:
                abstractDomain = new Tissue(form);
                break;    
                
            case Constants.SLIDE_FORM_ID:
                abstractDomain = new Slide(form);
                break;    
 
            case Constants.IMAGE_TYPE_FORM_ID:
                abstractDomain = new ImageType(form);
            	break;
          	default:
            		abstractDomain = null;
            		Logger.out.error("Incompatible object ID");
            		break;
        }
        return abstractDomain;
    }
}