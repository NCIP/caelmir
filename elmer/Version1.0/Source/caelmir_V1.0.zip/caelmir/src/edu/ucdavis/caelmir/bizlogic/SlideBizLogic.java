/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.bizlogic;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;



public class SlideBizLogic extends DefaultBizLogic
{
 
    protected void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
    throws DAOException, UserNotAuthorizedException
    {
        
        Slide slide =(Slide) obj;
        
        Collection images = slide.getImageCollection();
        Iterator iter = images.iterator();
        while (iter.hasNext()) {
            Image image= (Image) iter.next();
            ImageType imageType = image.getImageType();
            if (imageType != null) {
	            List imageTypeList = dao.retrieve(ImageType.class.getName(),"id",imageType.getId());
	            if (imageTypeList != null && imageTypeList.size() > 0) {
	                image.setImageType((ImageType)imageTypeList.get(0));
	            }
            }
        }
        
        slide.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
        User creator = (User) dao.retrieve(User.class.getName(),
                sessionDataBean.getUserId());
        slide.setCreator(creator);
        
        dao.insert(slide,null,true,false);

    }
    
    public void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {
        Slide slide =(Slide) obj;
        Slide slideOld =(Slide) oldObj;


        Collection imagesCol = slide.getImageCollection();
        Iterator iter = imagesCol.iterator();
        while (iter.hasNext()) {
            Image image= (Image) iter.next();
            ImageType imageType = image.getImageType();
            List imageTypeList = dao.retrieve(ImageType.class.getName(),"id",imageType.getId());
            if (imageTypeList != null && imageTypeList.size() > 0) {
                image.setImageType((ImageType)imageTypeList.get(0));
            }
        }
        
        String[] images = slide.getImages();
        if (images != null) {
	        for(int i=0;i<images.length;i++) {
	            String id = (String) images[i];
	            Image image = (Image) dao.retrieve(Image.class.getName(),new Long(id));
	            slide.getImageCollection().add(image);
	        }
        }
        
        
        
        dao.update(slide,null,true,false,false);

    }
    

}
