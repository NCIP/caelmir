package edu.ucdavis.caelmir.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;

/**
 * @author ravinder_kankanala
 *
 * This class is used to entered as a public user in to caELmir application.
 */
public class PublicQueryAction extends Action{

	/**
     * Overrides the execute method of Action class.
     * */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException
    {
		SessionDataBean bean=new SessionDataBean();
		bean.setCsmUserId("1");
		bean.setFirstName("guest");
		bean.setUserId(new Long(1));
		bean.setLastName("guest");
		bean.setUserName("admin@admin.com");
	
		HttpSession session = request.getSession();
		session.setAttribute(Constants.SESSION_DATA,bean);
		
		String status=(String)request.getParameter("activityStatus");
		if(status != null)
			session.setAttribute(Constants.PUBLIC_ACTIVITY_STATUS_PUBLISHED,status);
		
		String isPublicSearch=(String)request.getParameter("isPublicSearch");
		if(isPublicSearch != null)
			session.setAttribute(Constants.IS_PUBLIC_SEARCH, isPublicSearch);
		
		return (mapping.findForward(Constants.SUCCESS));
    	
		
    }

}