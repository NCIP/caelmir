/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.util.CommonUtility;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.global.ApplicationProperties;


/**
 * @author sandeep_chinta
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class SaveAsProtocolAction extends BaseAction
{

    /* (non-Javadoc)
     * @see edu.wustl.common.action.BaseAction#executeAction(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        String title = request.getParameter("entry");
        
        boolean flag =  CommonUtility.checkDuplicate(title);
        
        if(flag) {
            ActionErrors errors = new ActionErrors();
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError( "errors.item", ApplicationProperties
                    .getValue("duplicate.msg")));
            saveErrors(request, errors);
            
            return mapping.findForward(Constants.FAILURE);
        } else {
            String id = request.getParameter("protocolId");
            DefaultBizLogic bizLogic = new DefaultBizLogic();
            List list = bizLogic.retrieve(CollectionProtocol.class.getName(),"id", id);
            
            if (list != null && !list.isEmpty())
            {
                CollectionProtocol colProtocol = (CollectionProtocol) list.get(0);
                CollectionProtocol newProtocol = new CollectionProtocol();
                newProtocol.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
                newProtocol.setCreator(colProtocol.getCreator());
                newProtocol.setDescriptionURL(colProtocol.getDescriptionURL());
                newProtocol.setExperimentCollection(null);
                newProtocol.setIrbIdentifier(colProtocol.getIrbIdentifier());
                newProtocol.setShortTitle(colProtocol.getShortTitle());
                newProtocol.setStartDate(colProtocol.getStartDate());
                newProtocol.setStudyCollection(null);
                newProtocol.setTitle(title);
                
                Collection eventCollection = colProtocol.getCollectionProtocolEventCollection();
                Iterator eventIterator = eventCollection.iterator();

                Collection collOfProtocolEvent = new LinkedHashSet();
                while (eventIterator.hasNext())
                {
                    CollectionProtocolEvent collectionProtocolEvent = (CollectionProtocolEvent) eventIterator.next();
                    CollectionProtocolEvent newCollectionProtocolEvent = new CollectionProtocolEvent();
                    newCollectionProtocolEvent.setCollectionProtocol(newProtocol);
                    newCollectionProtocolEvent.setStudyCalendarEventPoint(collectionProtocolEvent.getStudyCalendarEventPoint());
                    Collection entityMapCollection = collectionProtocolEvent.getEntityMapCollection();
            
                    Iterator entityMapIterator = entityMapCollection.iterator();
                    Collection collOfEventRecord = new LinkedHashSet();
                    while (entityMapIterator.hasNext())
                    {
                        EntityMap entityMap = (EntityMap) entityMapIterator.next();
                        EntityMap newEntityMap = new EntityMap();
                        newEntityMap.setCollectionProtocolEvent(newCollectionProtocolEvent);
                        newEntityMap.setEntityReferenceId(entityMap.getEntityReferenceId());
                      
                        collOfEventRecord.add(newEntityMap);
                    }
                    newCollectionProtocolEvent.setEntityMapCollection(collOfEventRecord);
                    collOfProtocolEvent.add(newCollectionProtocolEvent);
                }
                newProtocol.setCollectionProtocolEventCollection(collOfProtocolEvent);
                bizLogic.insert(newProtocol,null,Constants.HIBERNATE_DAO);
            }
        
            request.setAttribute("message","Protocol Saved As " +title + " Successfully");
            return mapping.findForward(Constants.SUCCESS);
        }
        
        
    }
    
}
