
package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.CollectionProtocolForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.protocol.SpecimenProtocol;
import edu.ucdavis.caelmir.util.CMSClient;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author sujay_narkar
 */
public class AddCollectionProtocolAction extends BaseAction
{

    /**This class is responsible to handle all the requests related to the study object. It handles all the scenarios 
     * viz. "add" "edit" "view" mode for the study object. It populates all the required parameters that are needed 
     * to successfully access the study object. 
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     * 
     * */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)

    {
        String pageOf;
        CollectionProtocolForm collectionProtocolForm = (CollectionProtocolForm) form;
        String operation = (String) request.getParameter(Constants.OPERATION);
        try
        {
            if (operation != null)
            {
                request.setAttribute(Constants.OPERATION, operation);
            }
            else
            {
                operation = Constants.ADD;
            }
            boolean isAccessPresent = true;
            if (operation.equalsIgnoreCase(Constants.ADD))
            {
                isAccessPresent = isAccessPresent(request,
                        Permissions.PROTOCOL_CREATE,
                        Permissions.PROTOCOL_CREATE_ACCESS_DENIED);
            }
            else if (operation.equalsIgnoreCase(Constants.EDIT))
            {
                isAccessPresent = isAccessPresent(request,
                        Permissions.PROTOCOL_UPDATE,
                        Permissions.PROTOCOL_UPDATE_ACCESS_DENIED);
            }
            else if (operation.equalsIgnoreCase(Constants.VIEW))
            {
                isAccessPresent = isAccessPresent(request,
                        Permissions.PROTOCOL_READ,
                        Permissions.PROTOCOL_READ_ACCESS_DENIED);

            }

            if (!isAccessPresent)
            {
                return mapping
                        .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
            }

            pageOf = request.getParameter(Constants.PAGEOF);
            request.setAttribute(Constants.PAGEOF, pageOf);

            /*       if (operation.equals(Constants.ADD)
             || operation.equals(Constants.EDIT))
             {*/

            collectionProtocolForm.setForwardTo(Constants.POST_SAVE_PROCESS);

            getEventRecords(form, request);

            getParameters(form, request);

            /*     if (operation.equals(Constants.VIEW)
             || operation.equals(Constants.EDIT))
             getFieldsValue(request, form);
             else
             populateAddParameters(request,form);*/
            //}

        }
        catch (DAOException daoException)
        {
            return mapping.findForward(new String(Constants.FAILURE));

        }

        return mapping.findForward(pageOf);
    }
    
    /**
     * This method is used to check the given privilege on given object.
     * @param request To get the session data bean
     * @param privilege Name of the privilege
     * @param accessDeniedMessage The message to be displayed if the access is not present.
     * @return boolean true if the access is present otherwise false.
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                SpecimenProtocol.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

    
    private List getEventRecords(ActionForm form, HttpServletRequest request)
            throws DAOException
    {
        List list = new ArrayList();

        list.add(new NameValueBean(Variables.Microarray,
                Constants.MICROARRAY_ID));
        list.add(new NameValueBean(Variables.Pathology,
                Constants.PATHOLOGY_ID));
        list.add(new NameValueBean(Variables.Proteomics,
                Constants.PROTEOMICS_ID));
            CMSClient cms = new CMSClient();
         List dynamic = cms.getDynamicExtnEventRecords();
         list.addAll(dynamic);
        /*   
         StorageManager storage =  new StorageManager();
         storage.setMap(Constants.EVENT_RECORDS_LIST,list);
         */
        request.setAttribute(Constants.EVENT_RECORDS_LIST, list);
        return list;

    }

    /**This method is used to get the list of objects of given type Action form is used to get the 
     * appropriate biz logic factory.
     * Returns tg mouse list
     * @param form action form 
     * @return List of NameValueBean objects 
     * @throws DAOException
     */
    public List getObjectList(ActionForm form, String objectName)
            throws DAOException
    {

        AbstractActionForm abstractForm = (AbstractActionForm) form;
        AbstractBizLogic bizLogic = BizLogicFactory.getBizLogic(abstractForm
                .getFormId());

        String sourceObjectName = objectName;
        String[] displayNameFields = new String[1];
        displayNameFields[0] = Constants.NAME;
        String valueField = Constants.ID;
        boolean isToExcludeDisabled = false;

        List objectList = bizLogic.getList(sourceObjectName, displayNameFields,
                valueField, isToExcludeDisabled);
        if (objectList != null && objectList.size() > 0)
        {
            objectList.remove(0);
        }
        return objectList;

    }

    /*
     private String getRecordId(String recName)
     {
     String str="";
     if(recName.equalsIgnoreCase("MicroArray Event Record"))
     str="1";
     else if(recName.equalsIgnoreCase("Pathology Event Record"))
     str="2";
     else if(recName.equalsIgnoreCase("Proteomics Event Record"))
     str="3";
     return str;
     }
     */
    private String getRecordName(String recId, HttpServletRequest request)
    {
        String str = "";

        List list = (List) request.getAttribute(Constants.EVENT_RECORDS_LIST);

        if (list != null && !list.isEmpty())
        {
            Iterator listIterator = list.iterator();
            while (listIterator.hasNext())
            {
                NameValueBean bean = (NameValueBean) listIterator.next();
                if (bean.getValue().equals(recId))
                {
                    str = bean.getName();
                    break;
                }
            }

        }

        /* if(recId.equalsIgnoreCase("1"))
         str="MicroArray Event Record";
         else if(recId.equalsIgnoreCase("2"))
         str="Pathology Event Record";
         else if(recId.equalsIgnoreCase("3"))
         str="Proteomics Event Record";*/
        return str;
    }

    private void getParameters(ActionForm form, HttpServletRequest request)
            throws DAOException
    {

        CollectionProtocolForm cform = (CollectionProtocolForm) form;
        boolean firstTime = true;

        List eventPoints = new ArrayList();
        List eventRecordsList = new ArrayList();

        int count = 0;

        if (new Long(cform.getId()) != null
                && cform.getId() > 0) //for edit operation
        {
            firstTime = false;

            Long systemIdentifier = new Long(cform.getId());
            DefaultBizLogic defaultBizLogic = BizLogicFactory
                    .getDefaultBizLogic();
            List list = defaultBizLogic.retrieve(CollectionProtocol.class
                    .getName(), "id", systemIdentifier);
            CollectionProtocol collProtocol = null;

            if (list != null && !list.isEmpty())
            {
                collProtocol = (CollectionProtocol) list.get(0);
            }

            int row = 0;
            if (collProtocol != null)
            {
                Collection collProtocolEvent = collProtocol
                        .getCollectionProtocolEventCollection();
                count = collProtocolEvent.size();
                Map map = cform.getValueMap();
                // this.collectionProtocolEventCollection = new HashSet();
                if (map.size() == count)
                {//that means no more row of event points is added in edit operation
                    Iterator itOfProtocolEvent = collProtocolEvent.iterator();

                    while (itOfProtocolEvent.hasNext())
                    {
                        CollectionProtocolEvent collectionProtocolEvent = (CollectionProtocolEvent) itOfProtocolEvent
                                .next();

                        List eventPointsContents = new ArrayList();
                        eventPointsContents.add(new Long(row).toString());
                        eventPointsContents
                                .add(collectionProtocolEvent.getId());
                        eventPointsContents.add(collectionProtocolEvent
                                .getStudyCalendarEventPoint());
                        eventPoints.add(eventPointsContents);

                        Collection entityMapCollection = collectionProtocolEvent
                                .getEntityMapCollection();

                        Iterator itEventRecord = entityMapCollection.iterator();
                        while (itEventRecord.hasNext())
                        {
                            EntityMap entityMap = (EntityMap) itEventRecord
                                    .next();

                            List entityMapContents = new ArrayList();
                            entityMapContents.add(new Integer(row).toString());
                            entityMapContents.add(entityMap
                                    .getEntityReferenceId().toString());
                            entityMapContents.add(entityMap.getId());
                            entityMapContents
                                    .add(getRecordName(entityMap
                                            .getEntityReferenceId().toString(),
                                            request));
                            eventRecordsList.add(entityMapContents);
                        }
                        row++;
                    }
                }
            }
        }
        if (cform.getValueMap() != null && !cform.getValueMap().isEmpty())
        { //edit + add row operation OR  add operation and if any validation fails
            firstTime = false;
            Map map = cform.getValueMap();
            // this.collectionProtocolEventCollection = new HashSet();
            if (map.size() > count)
            {
                Set keys = map.keySet();
                Iterator it = keys.iterator();

                Collection valcoll = map.values();
                Iterator valIterator = valcoll.iterator();

                count = count + cform.getValueMap().size();
                while (it.hasNext())
                {
                    String[] eventPointSplit = it.next().toString().split("_");

                    List eventPointsContents = new ArrayList();

                    /*if( eventPointSplit.length>1)
                     eventPointsContents.add(eventPointSplit[1]);*/
                    for (int j = 0; j < eventPointSplit.length; j++)
                        eventPointsContents.add(eventPointSplit[j]);

                    eventPointsContents.add(valIterator.next().toString());
                    eventPoints.add(eventPointsContents);

                    //now save eventRecords
                    if (cform.getEventRecords() != null
                            && cform.getEventRecords().length != 0)
                    {

                        for (int i = 0; i < cform.getEventRecords().length; i++)
                        {
                            String event_rec = cform.getEventRecords()[i];
                            String eventRecSplit[] = event_rec.split("_");
                            if (eventRecSplit[0].equals(eventPointSplit[0]))
                            {
                                List eventRecordsContents = new ArrayList();
                                for (int j = 0; j < eventRecSplit.length; j++)
                                    eventRecordsContents.add(eventRecSplit[j]);
                                //get last ele will be its name . that one should be shown as selected  
                                eventRecordsContents.add(getRecordName(
                                        eventRecSplit[1], request));
                                eventRecordsList.add(eventRecordsContents);
                            }
                        }
                    }
                }
            }

        }

        if (firstTime) //first time creation
        {
            request.setAttribute(Constants.FIRST_TIME_CREATION, "true");
            count = 1;

            //add one row into it.
            List eventPointsContents = new ArrayList();
            eventPointsContents.add("0");
            eventPointsContents.add("1");
            eventPoints.add(eventPointsContents);

            //getrecords from db.

            List evntRec = getEventRecords(form, request);
            for (int i = 0; i < evntRec.size(); i++)
            {
                List eventRecordsContents = new ArrayList();
                NameValueBean bean = (NameValueBean) evntRec.get(i);
                eventRecordsContents.add(new Integer(0));
                eventRecordsContents.add(bean.getValue());
                eventRecordsContents.add(bean.getName());
                eventRecordsList.add(eventRecordsContents);
            }

        }
        else
            request.setAttribute(Constants.FIRST_TIME_CREATION, "false");

        cform.setCounter(new Integer(count).toString());
        request.setAttribute(Constants.EVENT_PARAMETERS_LIST, eventPoints);
        request.setAttribute(Constants.EVENT_RECORDS, eventRecordsList);

    }

}
