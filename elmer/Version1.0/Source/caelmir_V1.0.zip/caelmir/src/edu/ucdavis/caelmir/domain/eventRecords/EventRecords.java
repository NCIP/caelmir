
package edu.ucdavis.caelmir.domain.eventRecords;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;


/**
 * Experimental data for the protocol
 * @hibernate.class table="CAELMIR_EVENT_RECORDS"
 */

public class EventRecords extends AbstractDomainObject implements java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**Date of creation for the data record*/
    private  Date createdDate;

    /**Modification date for the data */
    private  Date modifiedDate;

    /**Unique identifier for the data*/
    private  Long id;

    /**Activity status for the data This represents the activity status of the associated study or experiment*/
    private  String activityStatus;

    /** Creator user of this data*/
    private edu.ucdavis.caelmir.domain.common.User creator;
    
    /** Creator user of this data*/
    private String name;

    /**Animal for whom this data was recorded*/
    private edu.ucdavis.caelmir.domain.subject.Animal animal;
    
    private edu.ucdavis.caelmir.domain.common.EntityMap entityMap;
    
    private Long entityRecordId;

    /**
     * @return Returns the entityRecordId.
     * @hibernate.property name="entityRecordId" type="long" length="30" column="ENTITY_RECORD_ID"
     */
    public Long getEntityRecordId()
    {
        return entityRecordId;
    }
    /**
     * @param entityDefinitionId The entityDefinitionId to set.
     */
    public void setEntityRecordId(Long entityRecordId)
    {
        this.entityRecordId = entityRecordId;
    }
    /**Collection of all the events on which the data is to be recorded.*/
//    private  Collection collectionProtocolEventCollection = new  HashSet();

    /**
     * Returns the date when the user is added to the system.
     * @hibernate.property name="createdDate" type="date" column="CREATED_DATE"
     * @return Returns the dateAdded.
     */
    public  Date getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate( Date createdDate)
    {
        this.createdDate = createdDate;
    }

    /**
     * Returns the date when the user is added to the system.
     * @hibernate.property name="modifiedDate" type="date" column="MODIFIED_DATE"
     * @return Returns the dateAdded.
     */
    public  Date getModifiedDate()
    {
        return modifiedDate;
    }

    public void setModifiedDate( Date modifiedDate)
    {
        this.modifiedDate = modifiedDate;
    }

    /**
     * Returns the systemIdentifier assigned to user.
     * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
     * unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_EVENT_RECORD_SEQ"
     * @return Returns the systemIdentifier.
     */
    public  Long getId()
    {
        return id;
    }

    public void setId( Long id)
    {
        this.id = id;
    }

    /**
     * Returns the activitystatus of the user.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     * @return Returns the activityStatus.
     */
    public  String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus( String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @return the user object
     * @hibernate.many-to-one column="USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.User getCreator()
    {
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.dataElements.DataElements thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.DataElements();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                creator = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("DataElements:getCreator throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return creator;

    }

    public void setCreator(edu.ucdavis.caelmir.domain.common.User creator)
    {
        this.creator = creator;
    }

    /**
     * @return
     * @hibernate.many-to-one column="ANIMAL_ID" class="edu.ucdavis.caelmir.domain.subject.Animal"
     * constrained="true"
     */
    public edu.ucdavis.caelmir.domain.subject.Animal getAnimal()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.dataElements.DataElements thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.DataElements();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.subject.Animal", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                animal = (edu.ucdavis.caelmir.domain.subject.Animal)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("DataElements:getAnimal throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return animal;

    }

    public void setAnimal(edu.ucdavis.caelmir.domain.subject.Animal animal)
    {
        this.animal = animal;
    }


    /*
     * @return Returns the userGroupCollection.
     * @hibernate.set name="collectionProtocolEventCollection" table="CAELMIR_ER_EVENTS" 
     * cascade="save-update" inverse="true" lazy="false"
     * @hibernate.collection-key column="EVENT_RECORD_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent" column="COLLECTION_PROTOCOL_EVENT_ID"
     */
    /*public  Collection getCollectionProtocolEventCollection()
    {
        //			try{
        //			   if(collectionProtocolEventCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.dataElements.DataElements thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.DataElements();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent", thisIdSet);				 
        //				 	collectionProtocolEventCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("DataElements:getCollectionProtocolEventCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return collectionProtocolEventCollection;
    }

    public void setCollectionProtocolEventCollection(
             Collection collectionProtocolEventCollection)
    {
        this.collectionProtocolEventCollection = collectionProtocolEventCollection;
    }
*/
    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof EventRecords)
        {
            EventRecords c = (EventRecords) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    /***/
    public void setAllValues(AbstractActionForm abstractForm) throws AssignDataException
    {
        // TODO Auto-generated method stub
          
        
    }

    /***/
    public Long getSystemIdentifier()
    {
        // TODO Auto-generated method stub
        return id;
    }

   /***/
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;
        
    }


    /**
     * Returns the activitystatus of the user.
     * @hibernate.property name="name" type="string" column="NAME" length="100"
     * @return Returns the activityStatus.
     */
    public String getName()
    {
        return name;
    }


    public void setName(String name)
    {
        this.name = name;
    }

   public static void setEventRecordStatus(Collection eventRecordsColl , String status)
    {
        if(eventRecordsColl != null && !eventRecordsColl.isEmpty())
        {
            Iterator eventRecordIterator = eventRecordsColl.iterator();
            while(eventRecordIterator.hasNext())
            {
                EventRecords eventRecords = (EventRecords) eventRecordIterator.next();
                eventRecords.setActivityStatus(status);
            }
        }
    }
    /**
     * @return Returns the serialVersionUID.
     */
    public static long getSerialVersionUID()
    {
        return serialVersionUID;
    }
    /**
     * @return Returns the entityMap.
     * @hibernate.many-to-one name="entityMap" column="ENTITY_MAP_ID" class="edu.ucdavis.caelmir.domain.common.EntityMap" cascade="none"
     */
    public edu.ucdavis.caelmir.domain.common.EntityMap getEntityMap()
    {
        return entityMap;
    }
    /**
     * @param entityMap The entityMap to set.
     */
    public void setEntityMap(
            edu.ucdavis.caelmir.domain.common.EntityMap entityMap)
    {
        this.entityMap = entityMap;
    }
}