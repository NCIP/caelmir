
package edu.ucdavis.caelmir.actionForm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;

/**
 * @author sujay_narkar
 */
public class TissueForm extends AbstractActionForm {
    /**
     * 
     */
  
   // protected String tissueNumber="";
    
    /**
     * 
     */
    protected String tissueNumberHidden;
     /**
     * 
     */
    
    protected String[] selectedSlide;
        
    protected String[] remainingFields;
    
    /**
     * 
     */
    protected Map valueMap  = new HashMap();
    /**
     * 
     */
    protected String caseIdentifier;
    
    
    /**Long name for the tissue*/
    private String tissueLongName;

    /**Short Name for the tissue*/
    private String tissueShortName;

    
    
    /**
     * 
     */
    protected String imageCounter;
    /**
     * 
     */
    protected String imagesToBeShown;
    /**
     * Tissue Identifier
     */
    protected String tissueIdentifier;
    /**
     * 
     */
    protected String slideIdentifier;
    /**
     * 
     */
    protected String submitType;
    /**
     * 
     */
    
    /**
     * 
     */
    protected List imageList;
    /**
     * 
     */
    protected String slideDeleted;
    
    protected String[] images;
    /**
     * @return Returns the images.
     */
    public String[] getImages()
    {
        return images;
    }
    
    /**
     * @param images The images to set.
     */
    public void setImages(String[] images)
    {
        this.images = images;
    }
     
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
    protected String submitButton;
 
    /**
     * 
     * @param key
     * @param value
     */
    
    public void setValue(String key, Object value) {
       	valueMap.put(key, value);
    }
    /**
     * 
     * @param key
     * @return
     */
    public Object getValue(String key) {
    	return valueMap.get(key);
    }
    
	/**
	 * @return Returns the valueMap.
	 */
	public Map getValueMap() {
		return valueMap;
	}
    
	/**
	 * @param valueMap The valueMap to set.
	 */
	public void setValueMap(Map valueMap) {
		this.valueMap = valueMap;
	}
    
    /**
     * 
     */
    public void reset() {
        
    }
    
    /**
     * Returns the id assigned to form bean.
     * @return the id assigned to form bean.
     */
    public int getFormId() {
        return Constants.TISSUE_FORM_ID;
    }
    protected Collection imageCollection;
    /**
     * @return Returns the imageCol.
     */
    public Collection getImageCollection()
    {
        return imageCollection;
    }
    /**
     * @param imageCol The imageCol to set.
     */
    public void setImageCollection(Collection imageCol)
    {
        this.imageCollection= imageCol;
    }
    /**
     * 
     */
    public void setAllValues(AbstractDomainObject abstractDomain)   {
        
        
        Tissue tissue =(Tissue) abstractDomain;
        this.tissueLongName =  tissue.getTissueLongName();
        this.tissueShortName = tissue.getTissueShortName();
        this.id = tissue.getSystemIdentifier().longValue();
        
        if (tissue.getPathologyEventRecords() != null)
            this.caseIdentifier = tissue.getPathologyEventRecords().getSystemIdentifier().toString();
        //this.slideNumber = tissue.gets
        
        Collection Coll= tissue.getSlideCollection();
        if(Coll != null && Coll.size() != 0 )
        {
            String [] selectedSlide = new String[Coll.size()];
            Iterator iterate= Coll.iterator();           
            int i=0;                  
            while(iterate.hasNext())
            {
                Slide slide = (Slide) iterate.next();                  
                  selectedSlide[i++]=slide.getId().toString();
            }
            setSelectedSlide(selectedSlide);
        }
        
        this.imageCollection = tissue.getImageCollection();
       	
		if(this.imageCollection != null && this.imageCollection.size() != 0 )
		{
	    	String [] images = new String[this.imageCollection.size()];
			Iterator iterate= this.imageCollection.iterator();			
			int i=0;				  
			while(iterate.hasNext())
			{
			    Image imageObj = (Image) iterate.next();
				images[i++]=imageObj.getId().toString();
			}
			setImages(images);
		}
        
    }
    
    
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        
        if (validator.isEmpty(tissueLongName))
        {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("slide.tissue.longName")));
        }
        
        if (validator.isEmpty(tissueShortName))
        {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("slide.tissue.shortName")));
        }
        
        return errors;
        
    }
    

	/**
	 * @return Returns the selectedSlide.
	 */
/*public String getSelectedSlide() {
		return selectedSlide;
	}
	/**
	 * @param selectedSlide The selectedSlide to set.
	 */
/*	public void setSelectedSlide(String selectedSlide) {
		this.selectedSlide = selectedSlide;
	}
	*/

	/**
	 * @return Returns the tissueNumber.
	 */
/*	public String getTissueNumber() {
		return tissueNumber;
	}
	/**
	 * @param tissueNumber The tissueNumber to set.
	 */
/*	public void setTissueNumber(String tissueNumber) {
		this.tissueNumber = tissueNumber;
	}*/
	/**
	 * @return Returns the tissueNumberHidden.
	 */
	public String getTissueNumberHidden() {
		return tissueNumberHidden;
	}
	/**
	 * @param tissueNumberHidden The tissueNumberHidden to set.
	 */
	public void setTissueNumberHidden(String tissueNumberHidden) {
		this.tissueNumberHidden = tissueNumberHidden;
	}
	/**
	 * @return Returns the caseIdentifier.
	 */
	public String getCaseIdentifier() {
		return caseIdentifier;
	}
	/**
	 * @param caseIdentifier The caseIdentifier to set.
	 */
	public void setCaseIdentifier(String caseIdentifier) {
		this.caseIdentifier = caseIdentifier;
	}
	/**
	 * @return Returns the imageCounter.
	 */
	public String getImageCounter() {
		return imageCounter;
	}
	/**
	 * @param imageCounter The imageCounter to set.
	 */
	public void setImageCounter(String imageCounter) {
		this.imageCounter = imageCounter;
	}
	/**
	 * @return Returns the tissueIdentifier.
	 */
	public String getTissueIdentifier() {
		return tissueIdentifier;
	}
	/**
	 * @param tissueIdentifier The tissueIdentifier to set.
	 */
	public void setTissueIdentifier(String tissueIdentifier) {
		this.tissueIdentifier = tissueIdentifier;
	}
	
	/**
	 * @return Returns the slideIdentifier.
	 */
	public String getSlideIdentifier() {
		return slideIdentifier;
	}
	/**
	 * @param slideIdentifier The slideIdentifier to set.
	 */
	public void setSlideIdentifier(String slideIdentifier) {
		this.slideIdentifier = slideIdentifier;
	}
	/**
	 * @return Returns the submitType.
	 */
	public String getSubmitType() {
		return submitType;
	}
	/**
	 * @param submitType The submitType to set.
	 */
	public void setSubmitType(String submitType) {
		this.submitType = submitType;
	}
	/**
	 * @return Returns the imagesToBeShown.
	 */
	public String getImagesToBeShown() {
		return imagesToBeShown;
	}
	/**
	 * @param imagesToBeShown The imagesToBeShown to set.
	 */
	public void setImagesToBeShown(String imagesToBeShown) {
		this.imagesToBeShown = imagesToBeShown;
	}
	/**
	 * @return Returns the imageList.
	 */
	public List getImageList() {
		return imageList;
	}
	/**
	 * @param imageList The imageList to set.
	 */
	public void setImageList(List imageList) {
		this.imageList = imageList;
	}
	
	/**
	 * @return Returns the slideDeleted.
	 */
	public String getSlideDeleted() {
		return slideDeleted;
	}
	/**
	 * @param slideDeleted The slideDeleted to set.
	 */
	public void setSlideDeleted(String slideDeleted) {
		this.slideDeleted = slideDeleted;
	}
	
	/**
	 * @return Returns the submitButton.
	 */
	public String getSubmitButton() {
		return submitButton;
	}
	/**
	 * @param submitButton The submitButton to set.
	 */
	public void setSubmitButton(String submitButton) {
		this.submitButton = submitButton;
	}
    
    public String getTissueLongName()
    {
        return tissueLongName;
    }
    
    public void setTissueLongName(String tissueLongName)
    {
        this.tissueLongName = tissueLongName;
    }
    
    public String getTissueShortName()
    {
        return tissueShortName;
    }
    
    public void setTissueShortName(String tissueShortName)
    {
        this.tissueShortName = tissueShortName;
    }
    
    public void setSelectedSlide(String[] selectedSlide)
    {
        this.selectedSlide = selectedSlide;
    }
    
    public String[] getSelectedSlide()
    {
        return selectedSlide;
    }
    
    
    public void setAddNewObjectIdentifier(String addNewFor, Long addObjectIdentifier)
    {
            
        if(addNewFor.equals("slide"))
        {
            Long ID=new Long(addObjectIdentifier.longValue());
            String str= ID.toString();              
            List list = new ArrayList();
            
            int len= 1;
            if (selectedSlide != null)
            {
                for(int i=0;i<selectedSlide.length;i++)
                    list.add(selectedSlide[i]);
                len=selectedSlide.length + 1;
            }                           
            list.add(str);
            String [] selectedSlide = new String[len];     
            //cohort =(String[]) list.toArray();                
            for(int i=0;i<len;i++)
                selectedSlide[i]=(String)list.get(i);              
            setSelectedSlide(selectedSlide);
        }
    }

    
    public String[] getRemainingFields()
    {
        return remainingFields;
    }

    
    public void setRemainingFields(String[] remainingFields)
    {
        this.remainingFields = remainingFields;
    }
}
