
package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.SlideForm;
import edu.ucdavis.caelmir.actionForm.TissueForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author sujay_narkar
 */
public class LoadTissueAction extends BaseAction{
    
    
    
    
	public ActionForward executeAction(ActionMapping mapping, ActionForm form,HttpServletRequest request,
			HttpServletResponse response) {
		try{
			populateTissueData( form,request);
		} catch (DAOException daoException) {
			return mapping.findForward(new String(Constants.FAILURE));
			
		}
		
		
		return mapping.findForward(Constants.PAGE_OF_TISSUE);
		
	}   
	/**
	 * 
	 * @param form
	 * @param request
	 * @throws DAOException
	 */
	public void  populateTissueData(ActionForm form,HttpServletRequest request)throws DAOException{
		TissueForm tissueForm = (TissueForm)form;
        
        String caseIdentifier = (String)request.getAttribute(Constants.CASE_IDENTIFIER);
        if(caseIdentifier == null){
            caseIdentifier = tissueForm.getCaseIdentifier();
        }
        request.setAttribute(Constants.CASE_IDENTIFIER,caseIdentifier);
        
      
        
        String tissueIdentifier = tissueForm.getTissueIdentifier();
        if(tissueIdentifier == null ||((tissueIdentifier != null) && (tissueIdentifier.equals(""))  )){
            tissueIdentifier = (String)request.getAttribute(Constants.TISSUE_IDENTIFIER);
        }
		if (tissueIdentifier != null && !tissueIdentifier.equals("")) {
            request.setAttribute(Constants.TISSUE_IDENTIFIER,tissueIdentifier);
			
            
			DefaultBizLogic bizLogic =  (DefaultBizLogic)BizLogicFactory.getBizLogic(tissueForm.getFormId());
			List caseObjectList = bizLogic.retrieve(PathologyEventRecords.class.getName(),Constants.ID,new Long(caseIdentifier));
            PathologyEventRecords caseObject = (PathologyEventRecords) caseObjectList.get(0);
            
			Tissue tissue = getTissue(caseObject,tissueIdentifier);
			tissueForm.setTissueNumberHidden(tissue.getId().toString());
			request.setAttribute(Constants.SLIDE_LIST,getSlideList(tissue));
			
			//request.setAttribute(Constants.IMAGE_LIST,getSelectedImages(form));
            request.setAttribute(Constants.IMAGE_TYPE_LIST,getObjectList(form,Constants.IMAGE_TYPE));
            if(tissueForm.getSelectedSlide() != null && !tissueForm.getSelectedSlide().equals("")){
           // 	populateSlideData(tissue,tissueForm,request);
                
            } else {
            //    resetSlideData(tissueForm);
                request.setAttribute(Constants.SLIDE_IDENTIFIER,"");
                request.setAttribute(Constants.IMAGE_LIST,new ArrayList());
            }
		} else {
			request.setAttribute(Constants.SLIDE_LIST,new ArrayList());
            request.setAttribute(Constants.IMAGE_LIST,new ArrayList());
            request.setAttribute(Constants.IMAGE_TYPE_LIST,getObjectList(form,Constants.IMAGE_TYPE));
                       
		}
		
	}
    /**
     * 
     * @param caseObject
     * @param tissueForm
     
    public void populateSlideData(Tissue tissue,TissueForm tissueForm,HttpServletRequest request){
        if(tissueForm.getSelectedSlide() != null && !tissueForm.getSelectedSlide().equals("")){
        	Slide slide = getSlide(tissue,tissueForm.getSelectedSlide());
            tissueForm.setSlideNumber(slide.getSlideNumber());
            tissueForm.setStain(slide.getStain());
            tissueForm.setTissueMicroscopicDescription(slide.getMicroscopicDescription());
            tissueForm.setTissueDiagnosis(slide.getDiagnosis());
            Collection imageColletion = slide.getImageCollection();
            Iterator imageIterator = imageColletion.iterator();
            Image image;
            List imageList = new ArrayList();
            while(imageIterator.hasNext()){
                image = (Image) imageIterator.next();
                if(image.getImageType() != null){
                	imageList.add(new NameValueBean(image.getImageType().getName()+" "+image.getImageType().getMimeType(),image.getId().toString()));
                } else {
                    imageList.add(new NameValueBean(image.getImageType().getName()+" ",image.getId().toString()));
                }
            }
            
            request.setAttribute(Constants.IMAGE_LIST,imageList);
            request.setAttribute(Constants.SLIDE_IDENTIFIER,slide.getId().toString());
            tissueForm.setImagesToBeShown(Integer.toBinaryString(imageColletion.size()));
        }
        
    }*/
    /**
     * 
     * @param tissueForm
    
    public void resetSlideData(TissueForm tissueForm){
         tissueForm.setSlideNumber("");
         tissueForm.setStain("");
         tissueForm.setTissueMicroscopicDescription("");
         tissueForm.setTissueDiagnosis("");
    } */
    
	/**
	 * 
	 * @param tissue
	 * @return
	 */
	public List getSlideList(Tissue tissue){
		Collection slideCollection = tissue.getSlideCollection();
		Iterator slideIterator = slideCollection.iterator();
		Slide slide;
		NameValueBean nameValueBean;
		List nameValueList = new ArrayList();
		while(slideIterator.hasNext()){
			slide = (Slide)slideIterator.next();
			nameValueBean = new NameValueBean();
			nameValueBean.setName(slide.getSlideNumber());
			nameValueBean.setValue(slide.getId().toString());
			nameValueList.add(nameValueBean);
		}
		return nameValueList;
	}
    
    /**
     * Returns tg mouse list
     * @param form
     * @return
     * @throws DAOException
     */
    public List getObjectList(ActionForm form,String objectName) throws DAOException{
        
        AbstractActionForm abstractForm = (AbstractActionForm) form;
        AbstractBizLogic bizLogic = BizLogicFactory.getBizLogic(abstractForm.getFormId());
        
        String sourceObjectName = objectName;
        String []displayNameFields = new String[1];
        displayNameFields[0] = Constants.IMAGE_TYPE;
        String valueField = Constants.ID;
        boolean isToExcludeDisabled = false;
        
        return  bizLogic.getList(sourceObjectName,displayNameFields,valueField,isToExcludeDisabled);
        
    }
	/**
	 * 
	 * @param caseObject
	 * @param tissueIdentifier
	 * @return
	 */
	public Tissue getTissue(PathologyEventRecords caseObject,String tissueIdentifier){
		Collection tissueCollection = caseObject.getTissueCollection();
		Iterator tissueIterator = tissueCollection.iterator();
		Tissue tissue;
		while(tissueIterator.hasNext()){
			tissue = (Tissue) tissueIterator.next();
			if(tissue.getId().toString().equals(tissueIdentifier)){
				return tissue;
			}
		}
		return null;
	}
    /**
     * 
     * @return
     */
    public Slide getSlide(Tissue tissue,String[] slideIdentifier){
        Collection slideCollection = tissue.getSlideCollection();
        Iterator slideIterator = slideCollection.iterator();
        Slide slide;
        while(slideIterator.hasNext()){
            slide = (Slide) slideIterator.next();
            if(slide.getId().toString().equals(slideIdentifier)){
                return slide;
            }
        }
        return null;
    }
	
	
}
