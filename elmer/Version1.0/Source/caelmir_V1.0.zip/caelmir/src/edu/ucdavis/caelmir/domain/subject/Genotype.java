
package edu.ucdavis.caelmir.domain.subject;

import java.util.Collection;
import java.util.HashSet;

import edu.ucdavis.caelmir.actionForm.GenotypeForm;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;

/**
 * <!-- LICENSE_TEXT_START -->
 * <!-- LICENSE_TEXT_END -->
 */

/**
 * The genotype represents the genetic constitution or the exact genetic makeup (the specific genome) 
 * of an individual ie the particular set of genes possessed by the animal. It refers to the full hereditary 
 * information of an animal. 
 *  @hibernate.class table="CAELMIR_GENOTYPE"
 */

public class Genotype extends AbstractDomainObject implements java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**Unique identifier of the object*/
    private java.lang.Long id;

    /**It stores the name of the gene. This is taken from external datasource like Entrez*/
    private java.lang.String geneName;

    /**It refers to the configuration of the gene in question i.e homozygous,heterozygous,hemizygous.*/
    private java.lang.String genotype;

    /**Name of other gene which promotes the gene*/
    private java.lang.String promoter;

    /**Stores the identifier from the external datasource like Entrez*/
    private String geneIdentifier;
    
    private Collection animalCollection = new HashSet();

    public Genotype(AbstractActionForm form)
    {
        setAllValues(form);
    }

    public Genotype()
    {
        // TODO Auto-generated constructor stub
    }
   

    /**
     * @return identifier of this experiment
     */
    public Long getSystemIdentifier()
    {
        return id;
    }

    /**
     * set the identifier of this experiment
     */
    public void setSystemIdentifier(Long id)
    {
        this.id = id;
    }   

    
    /**
     * @return
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_GENOTYPE_SEQ"
     */
    public java.lang.Long getId()
    {
        return id;
    }

    public void setId(java.lang.Long id)
    {
        this.id = id;
    }

    /**
     * @return name of cohort
     * @hibernate.property name="geneName" column="GENE_NAME" type="string" length="150"
     */
    public java.lang.String getGeneName()
    {
        return geneName;
    }

    public void setGeneName(java.lang.String geneName)
    {
        this.geneName = geneName;
    }

    /**
     * @return name of cohort
     * @hibernate.property name="genotype" column="GENOTYPE" type="string" length="50"
     */
    public java.lang.String getGenotype()
    {
        return genotype;
    }

    public void setGenotype(java.lang.String genotype)
    {
        this.genotype = genotype;
    }

    /**
     * @return name of cohort
     * @hibernate.property name="promoter" column="PROMOTER" type="string" length="50"
     */
    public java.lang.String getPromoter()
    {
        return promoter;
    }

    public void setPromoter(java.lang.String promoter)
    {
        this.promoter = promoter;
    }

    /**
     * @return name of cohort
     * @hibernate.property name="geneIdentifier" column="GENE_IDENTIFIER" type="string" length="50"
     */
    public String getGeneIdentifier()
    {
        return geneIdentifier;
    }

    public void setGeneIdentifier(String geneIdentifier)
    {
        this.geneIdentifier = geneIdentifier;
    }

    
    /**
     * This function Copies the data from an AnimalForm object to a animal object.
     * @param user An AnimalForm object containing the information about the animal.  
     * */
    public void setAllValues(AbstractActionForm abstractForm)
    {

        GenotypeForm gform = (GenotypeForm) abstractForm;

        //this.age = aform.getAge();
       
           this.geneIdentifier= gform.getGeneIdentifier();
           this.geneName=gform.getGeneName();
           this.genotype = gform.getGenotype();
           this.promoter = gform.getPromoter();
           
           if (!gform.getOperation().equals(Constants.ADD))
           {
               this.setId(new Long(gform.getId()));
           }
       
    }
   
    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Genotype)
        {
            Genotype c = (Genotype) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }
    
   
    /**
     * 
     * @return the animalCollection 
     *  @hibernate.set name="animalCollection" table="CAELMIR_ANIMAL_GENOTYPE"
     *  cascade="save-update" inverse="true" lazy="true"
     *  @hibernate.collection-key column ="GENOTYPE_ID"
     *  @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.subject.Animal" column="ANIMAL_ID"
     */
    
    public Collection getAnimalCollection()
    {
        return animalCollection;
    }

    
    public void setAnimalCollection(Collection animalCollection)
    {
        this.animalCollection = animalCollection;
    }

}