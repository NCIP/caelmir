/**
 * <p>Title: ForgotPasswordSearchAction Class>
 * <p>Description:	This Class is used to retrieve the password of the user and mail it to his email address.</p>
 * Copyright:    Copyright (c) year
 * Company: Washington University, School of Medicine, St. Louis.
 * @author Gautam Shetty
 * @version 1.00
 * Created on Apr 19, 2005
 */

package edu.ucdavis.caelmir.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.ForgotPasswordForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.bizlogic.UserBizLogic;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.logger.Logger;

/**
 * This Class is used to retrieve the password of the user and mail it to his email address.
 * @author gautam_shetty
 */
public class ForgotPasswordSearchAction extends Action
{

    /**
     * Overrides the execute method of Action class.
     * Adds the user information in the database.
     * */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException
    {
        String target = null;
        
        try
        {
            ForgotPasswordForm forgotPasswordForm = (ForgotPasswordForm) form;
            UserBizLogic userBizLogic = (UserBizLogic)BizLogicFactory.getBizLogic(forgotPasswordForm.getFormId());
            
            //Retrieves and sends the password to the user whose email address is passed 
            //else returns the error key in case of an error.
            String message = userBizLogic.sendForgotPassword(forgotPasswordForm.getEmailAddress());
            
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,message);
            
	        target = new String(Constants.SUCCESS);
        }
        catch (DAOException excp)
        {
            target = new String(Constants.FAILURE);
            Logger.out.error(excp.getMessage());
        }
        return (mapping.findForward(target));
    }
}