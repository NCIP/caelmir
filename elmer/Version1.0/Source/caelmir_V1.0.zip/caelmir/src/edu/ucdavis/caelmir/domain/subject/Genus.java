/**
 * 
 */
package edu.ucdavis.caelmir.domain.subject;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import edu.ucdavis.caelmir.actionForm.GenusForm;
import edu.ucdavis.caelmir.actionForm.ModelForm;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;

/**
* 
* @hibernate.class table="CAELMIR_GENUS"
*/

public class Genus extends AbstractDomainObject implements java.io.Serializable {

	
	
	private static final long serialVersionUID = 1234567890L;


	/** Unique identifier for the genus */
	private Long id;

	
	/** Name of the genus */
	private String genusName;
	
	/**Activity status of the genus. Specifies whether this genus is active or disabled.*/
    private String activityStatus;

    /**Collection of all the species which are to be carried out in this genus*/
    private Collection speciesCollection = new HashSet();

    /**Collection of all the animals which are to be carried out in this genus*/
    private Collection animalCollection = new HashSet();

    
    /**
	 * @return
	 * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
	 *               unsaved-value="null" generator-class="native"
	 * @hibernate.generator-param name="sequence" value="CAELMIR_GENUS_SEQ"
	 */
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
    
	
	/**
	 * @return Returns the genusName
	 * @hibernate.property name="genusName" type="string" column="GENUS_NAME"
	 *                     length="100"
	 */
	public String getGenusName() {
		return genusName;
	}

	public void setGenusName(String genusName) {
		this.genusName = genusName;
	}

	
	/**
     * @return Returns the activityStatus.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     */
	public String getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}

	 /**
    * @return Returns the speciesCollection.
    * @hibernate.set name="speciesCollection" table="CAELMIR_SPECIES" cascade="none"
    * inverse="true" lazy="false"
    * @hibernate.collection-key column="GENUS_ID"
    * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.subject.Species"
    */
	public Collection getSpeciesCollection() {
		return speciesCollection;
	}

	public void setSpeciesCollection(Collection speciesCollection) {
		this.speciesCollection = speciesCollection;
	}


	 /**
    * @return Returns the animalCollection.
    * @hibernate.set name="animalCollection" table="CAELMIR_ANIMAL" cascade="none"
    * inverse="true" lazy="false"
    * @hibernate.collection-key column="GENUS_ID"
    * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.subject.Animal"
    */
	public Collection getAnimalCollection() {
		return animalCollection;
	}

	public void setAnimalCollection(Collection animalCollection) {
		this.animalCollection = animalCollection;
	}
	
	
	
	
	public void setAllValues(AbstractActionForm actionForm)	
								throws AssignDataException {
		
		GenusForm genusForm = (GenusForm) actionForm;
    	String operation = genusForm.getOperation();
        String status = genusForm.getActivityStatus();
       
        this.genusName = genusForm.getGenusName();
        this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
               
        if (operation != null
                && ((Constants.VIEW).equalsIgnoreCase(operation) || (Constants.EDIT)
                        .equalsIgnoreCase(operation)))
        {
            if (status != null
                    && (Constants.ACTIVITY_STATUS_DISABLED)
                            .equalsIgnoreCase(status))
            {
                     
                this.deleteObject(genusForm);
                genusForm.setActivityStatus(null);
            }

        }
	}

	
	
	
	/**
	 * 
	 */
	public Long getSystemIdentifier() {
		
		return id;
	}

	/**
	 * Sets an systemIdentifier for the genus.
	 * 
	 * @param systemIdentifier
	 *            Unique systemIdentifier to be assigned to the genus.
	 * @see #getIdentifier()
	 */
	public void setSystemIdentifier(Long systemIdentifier) {
		this.id = systemIdentifier;

	}
    
	
	public Genus(AbstractActionForm form) {
		try {
			setAllValues(form);
		} catch (AssignDataException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Genus)
        {
            Genus g = (Genus) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(g.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    /**
	 * 
	 */
	public Genus() {
		
		// TODO Auto-generated constructor stub
	}
	
	public void deleteObject(GenusForm actionForm)
    {
        this.activityStatus = Constants.ACTIVITY_STATUS_DISABLED;
        Species.setSpeciesStatus(speciesCollection,Constants.ACTIVITY_STATUS_DISABLED, new Boolean(true));
    }  
	
	
	public static void setGenusStatus(Collection genusCollection,
            String status, Boolean genusDeleteFlag)
    {
        if (genusCollection != null && !genusCollection.isEmpty())
        {
            Iterator genusIterator = genusCollection.iterator();
	            while (genusIterator.hasNext())
	            {
	                Genus genus = (Genus) genusIterator.next();
	                 if (genusDeleteFlag.booleanValue()) //if genus delete = true 
	                	 genus.setActivityStatus(status);
	                else
	                {
	                	if (genusDeleteFlag.booleanValue()
	                            && status
	                                    .equalsIgnoreCase(Constants.ACTIVITY_STATUS_DISABLED))
	                    	{
	
		                        Collection speciesColl = genus.getSpeciesCollection();
		                        Species.setSpeciesStatus(speciesColl,status,new Boolean(false)); 
	                    	}  
	                }
	            }
	
          }
    }
	
}
