/**
 *<p>Title: CohortAction Class </p>
 *<p>Description: This class initializes the field and redirect to Add/Edit Cohort webpage.</p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.exception.HandlePopupException;
import edu.ucdavis.caelmir.util.CMSClient;
import edu.ucdavis.caelmir.util.CommonUtility;
import edu.ucdavis.caelmir.util.ParseXML;
import edu.ucdavis.caelmir.util.PreferenceManager;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.security.exceptions.SMException;
import edu.wustl.common.util.Utility;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.logger.Logger;
import gov.nih.nci.security.authorization.domainobjects.Role;

/**
 * This class initializes the fields in requied to display Pop-Up
 * @author shital_lawhale
 *
 */
public class PopupAction extends Action
{

    /**
     * Overrides the execute method of Action class.
     * and initializes the fields in requied to display Pop-Up
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)

    throws HandlePopupException,Exception
    {

        String popupObj = (String) request.getParameter(Constants.OBJECT);
        request.setAttribute(Constants.POPUP_OBJECT, popupObj);

        String textInput = (String) request.getParameter(Constants.TEXT_INPUT);
        request.setAttribute(Constants.TEXT_INPUT, textInput);

        String searchCol = (String) request
                .getParameter(Constants.OPTION_SELECT);
        request.setAttribute(Constants.OPTION_SELECT, searchCol);

        String action = (String) request.getParameter(Constants.ACTION);
        HttpSession session = request.getSession();
        if(action == null || action.equals(""))
        {
            action=(String) session.getAttribute(Constants.ACTION);
        }
        else       
          session.setAttribute(Constants.ACTION, action);
        request.setAttribute(Constants.ACTION, action);

        String page = (String) request.getParameter(Constants.PAGE);        
        if(page != null && !page.equalsIgnoreCase(""))
            page = page.trim();
        request.setAttribute(Constants.PAGE, page);

        String invokeType = (String) request
                .getParameter(Constants.INVOKE_TYPE);
        request.setAttribute(Constants.INVOKE_TYPE, invokeType);

        ParseXML parseXML = ParseXML.getinstance();

        Map map = parseXML.parseXml(popupObj, invokeType);
        // String type = (String) map.get(Constants.INVOKE_TYPE);
        String choice = (String) map.get(Constants.CHOICE);
        request.setAttribute(Constants.CHOICE, choice);

        String target = (String) map.get(Constants.TARGET);
        request.setAttribute(Constants.TARGET, target);

        String label = (String) map.get(Constants.OBJECT_LABEL);
        String sourceObjectName = (String) map.get(Constants.SOURCEOBJECTNAME);

        String[] selectColumnName = CommonUtility
                .convertToStringArray((Object[]) map
                        .get(Constants.SELECTCOLUMNNAME));
        List columnList = (List) map.get(Constants.COLUMNLIST);

        String[] whereColumnName = CommonUtility
                .convertToStringArray((Object[]) map
                        .get(Constants.WHERECOLNAME));
        String[] whereColumnCondition = CommonUtility
                .convertToStringArray((Object[]) map
                        .get(Constants.WHERECOLCONDITION));
        Object[] whereColumnValue = (Object[]) map.get(Constants.WHERECOLVALUE);
        String joinCondition = (String) map.get(Constants.JOINCONDITION);
        String ID = (String) map.get(Constants.ID);

        request.setAttribute(Constants.SELECTCOLUMNNAME, selectColumnName); //before chanes in selectColumn
        List displayField = (List) map.get(Constants.DISPAY_FIELD);
        List idList = new ArrayList();

        List linkName = (List) map.get(Constants.LINKNAME);
        List URL = (List) map.get(Constants.URL);

        request.setAttribute(Constants.LINKNAME, linkName);
        request.setAttribute(Constants.URL, URL);

        List dataList = new ArrayList();
        List list = new ArrayList();

        selectColumnName = CommonUtility.ConvertToArray(CommonUtility
                .assignToNull(selectColumnName));
        whereColumnName = CommonUtility.ConvertToArray(CommonUtility
                .assignToNull(whereColumnName));
        whereColumnCondition = CommonUtility.ConvertToArray(CommonUtility
                .assignToNull(whereColumnCondition));

        if (invokeType.equals(Constants.HIBERNATE))
        {
            //	if(searchCol !=null && searchCol.size()!=0)
            if (textInput != null && textInput.length() != 0
                    && !textInput.equals(""))
            {
                whereColumnName = CommonUtility.createArray(whereColumnName,
                        searchCol);

                whereColumnCondition = CommonUtility.createArray(
                        whereColumnCondition, "like");
                String str = "%" + textInput + "%";

                whereColumnValue = CommonUtility.createObjArray(
                        whereColumnValue, str,whereColumnCondition);
            }

            if (page != null && page.equalsIgnoreCase(Constants.EXPERIMENT))
            {
                if (popupObj.equalsIgnoreCase(Constants.USERSLIST)
                        || popupObj.equalsIgnoreCase(Constants.GROUPSLIST)
                        || popupObj.equalsIgnoreCase(Constants.PROTOCOLSLIST))
                {
                    String studyId = (String) request
                            .getParameter(Constants.ID);
                    request.setAttribute(Constants.STUDY_ID, studyId);

                    dataList = getSpecificDataList(studyId, popupObj,
                            selectColumnName);
                    selectColumnName = new String[1];
                    selectColumnName[0] = ID;
                    idList = getSpecificDataList(studyId, popupObj,
                            selectColumnName);
                }
            }
          
            else
            {
                dataList = getDataList(sourceObjectName, selectColumnName,
                        whereColumnName, whereColumnCondition,
                        whereColumnValue, joinCondition);
                selectColumnName = new String[1];
                selectColumnName[0] = ID;
                idList = getDataList(sourceObjectName, selectColumnName,
                        whereColumnName, whereColumnCondition,
                        whereColumnValue, joinCondition);
            }

            list = CommonUtility.convertToList(dataList);

        }
        else if (invokeType.equals(Constants.API))
        {

            String[] whereColumnValues = CommonUtility
                    .convertToStringArray((Object[]) map
                            .get(Constants.WHERECOLVALUE));

            if (textInput != null && textInput.length() != 0
                    && !textInput.equals(""))
            {
                whereColumnName = CommonUtility.createArray(whereColumnName,
                        searchCol);

                whereColumnCondition = CommonUtility.createArray(
                        whereColumnCondition, "like");
                String str = "%" + textInput + "%";

                whereColumnValue = CommonUtility.createObjArray(
                        whereColumnValue, textInput,whereColumnCondition);

                whereColumnValues = CommonUtility
                        .convertToStringArray(whereColumnValue);

            }

            StorageManager storage = new StorageManager();
            List animalList = new ArrayList();

            CMSClient CMSclient = new CMSClient();
            String userId = "";
            boolean flag = false;

            String[] joinConditions = new String[1];
            joinConditions[0] = joinCondition;

            if (popupObj.equals(Constants.ANIMAL_LIST))
            {
                SessionDataBean sessionDataBean = (SessionDataBean) request
                        .getSession().getAttribute(Constants.SESSION_DATA);
                //sessionDataBean.getUserId().toString()
                DefaultBizLogic bizLogic = new DefaultBizLogic();

                if (sessionDataBean != null)
                {
                    List userList = bizLogic.retrieve(User.class.getName(),
                            "id", sessionDataBean.getUserId());
                    if (userList != null && !userList.isEmpty())
                    {
                        User user = (User) userList.get(0);
                        if (user.getCmsId() != null
                                && !user.getCmsId().equals(""))
                            userId = user.getCmsId().toString();
                        else if (user.getUser() != null)
                        {
                            //Else get its PI CMS id
                            if (user.getUser().getCmsId() != null
                                    && !user.getUser().getCmsId().equals(""))
                                userId = user.getUser().getCmsId().toString();
                            else
                                flag = handleError(request,
                                        "errors.incorrectUserId");
                            // ******** else throw exception as cms id is null  
                        }
                        else
                            flag = handleError(request,
                                    "errors.incorrectUserId");
                        //******** else throw exception as cms id is null
                    }
                }

                List whereColumnNames = CommonUtility
                        .AddToList(whereColumnName);
                List whereColValue = CommonUtility.AddToList(whereColumnValues);
                List whereColumnConditions = CommonUtility
                        .AddToList(whereColumnCondition);
                List joinCondn = CommonUtility.AddToList(joinConditions);

                //**** use userId
                if (!flag)
                {
                    animalList = CMSclient.getUnusedAnimals(userId,
                            whereColumnNames, whereColValue,
                            whereColumnConditions, joinCondn);

                    storage.setMap(Constants.SELECTED_ANIMAL_LIST, animalList);

                    //Form Datalist

                    list = CommonUtility.ConvertToAnimalList(selectColumnName,
                            animalList);
                }
            }

            if (popupObj.equals(Constants.PATHOLOGY_LIST))
            {
                             
                if(textInput == null || textInput.equalsIgnoreCase(""))
                {
                    textInput = PreferenceManager.getUserPreferenceValue(request,
                            Constants.LAST_USED_PATHOLOGY_NUMBER);  
                    if(textInput!=null)
                        request.setAttribute(Constants.TEXT_INPUT, textInput);                  
                }
                else
                {
                    PreferenceManager.setUserPreference(request,
                            Constants.LAST_USED_PATHOLOGY_NUMBER, textInput);
                }      
                
                
                List patologyList = new ArrayList();
                // patologyList = 
                List whereColumnNames = CommonUtility
                        .AddToList(whereColumnName);
                List whereColValue = CommonUtility.AddToList(whereColumnValues);
                List whereColumnConditions = CommonUtility
                        .AddToList(whereColumnCondition);
                List joinCondn = new ArrayList();//CommonUtility.AddToList(joinConditions);

                if (whereColumnNames != null && !whereColumnNames.isEmpty())
                {

                    if (page != null)
                    {
                        whereColumnNames.add("animalNumber");
                        whereColValue.add(page);
                        whereColumnConditions.add("like");
                        joinCondn.add("or");
                    }
             
                   patologyList = CMSclient.getTgMouseRecords(null,
                            whereColumnNames, whereColValue,
                            whereColumnConditions, joinCondn);
                    /*
                    for (int i = 0; i < 5; i++)
                    {
                        PathologyEventRecords obj = new PathologyEventRecords();
                        
                        obj.setDiagnosis("d");
                        obj.setMicroscopicDescription("micro");
                        obj.setPathologyNumber("pathnum");
                        obj.setSubmittedDate(Utility.parseDate("01/01/2007"));                 
                        patologyList.add(obj);
                    }
                    */
                    storage.setMap(Constants.PATHOLOGY_LIST, patologyList);
                }

                else
                    request.setAttribute(Constants.MESSAGE,
                            Constants.PATHOLOGY_MESSAGE);

                //Form Datalist
                list = CommonUtility.ConvertToTgMouseList(selectColumnName,
                        patologyList);

            }

            //list = CommonUtility.convertToList(dataList);
            int i = 0;
            while (i < list.size())
            {
                idList.add(new Long(i));
                i++;
            }
            //          =================================================================  
        }
        request.setAttribute(Constants.SPREADSHEET_COLUMN_LIST, columnList);
        request.setAttribute(Constants.SPREADSHEET_DATA_LIST, list);
        request.setAttribute(Constants.ID_LIST, idList);
        request.setAttribute(Constants.DISPAY_FIELD, displayField);

        request.setAttribute(Constants.LABEL, label);
        String pageOf = Constants.SUCCESS;
        return mapping.findForward(pageOf);
    }
    
    
  
    /**
     * Retrieves the records for class name in sourceObjectName according to field values passed .
     * @param sourceObjectName Domain object name
     * @param selectColumnName column names to be displayed
     * @param whereColumnName An array of field names
     * @param whereColumnCondition The comparision condition for the field values
     * @param whereColumnValue An array of field values
     * @param joinCondition The join condition
     * @return records for class name in sourceObjectName according to field values passed.
     * @throws DAOException
     */
    private List getDataList(String sourceObjectName,
            String[] selectColumnName, String[] whereColumnName,
            String[] whereColumnCondition, Object[] whereColumnValue,
            String joinCondition) throws DAOException
    {
        List dataList = new ArrayList();
        sourceObjectName.toLowerCase();

        char[] c = sourceObjectName.toCharArray();
        c[0] = Character.toUpperCase(sourceObjectName.charAt(0));
        String srcObjectName = new String(c);

        if (joinCondition.equals(""))
            joinCondition = null;
        else
            joinCondition = joinCondition.toUpperCase();

        try
        {

            DefaultBizLogic bizLogic = new DefaultBizLogic();
            dataList = bizLogic.retrieve(srcObjectName, selectColumnName,
                    whereColumnName, whereColumnCondition, whereColumnValue,
                    joinCondition);
        }
        catch (Exception ex)
        {
            Logger.out.error(ex.getMessage(), ex);
            throw new DAOException("Error in retrieve " + ex.getMessage(), ex);
        }
        return dataList;
    }

    private boolean handleError(HttpServletRequest request, String errorKey)
    {
        ActionErrors errors = new ActionErrors();
        errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(errorKey));
        //Report any errors we have discovered
        if (!errors.isEmpty())
        {
            saveErrors(request, errors);
            return true;
        }
        return false;
    }

    private List getSpecificDataList(String studyId, String obj,
            String[] selectColumnName) throws DAOException
    {
        List list = new ArrayList();

        DefaultBizLogic bizLogic = new DefaultBizLogic();
        Study study = null;
        List studyList = bizLogic
                .retrieve(Study.class.getName(), "id", studyId);
        if (studyList != null && !studyList.isEmpty())
        {
            study = (Study) studyList.get(0);
        }

        if (study != null)
        {
            Collection coll = new HashSet();
            String srcObjName = "";

            if (obj.equalsIgnoreCase(Constants.USERSLIST))
            {
                srcObjName = User.class.getName();
                coll = study.getUserCollection();
            }
            if (obj.equalsIgnoreCase(Constants.GROUPSLIST))
            {
                srcObjName = UserGroup.class.getName();
                coll = study.getUserGroupCollection();
            }
            if (obj.equalsIgnoreCase(Constants.PROTOCOLSLIST))
            {
                srcObjName = CollectionProtocol.class.getName();
                coll = study.getCollectionProtocolCollection();
            }

            String[] whereColName = new String[coll.size()];
            String[] whereColCondition = new String[coll.size()];
            Object[] whereColValue = new String[coll.size()];

            Iterator iterate = coll.iterator();
            for (int i = 0; i < coll.size(); i++)
            {
                whereColName[i] = Constants.ID;
                whereColCondition[i] = "=";
                if (obj.equalsIgnoreCase(Constants.USERSLIST))
                {
                    User user = (User) iterate.next();
                    whereColValue[i] = user.getId().toString();
                }
                if (obj.equalsIgnoreCase(Constants.GROUPSLIST))
                {
                    UserGroup userGroup = (UserGroup) iterate.next();
                    whereColValue[i] = userGroup.getId().toString();
                }
                if (obj.equalsIgnoreCase(Constants.PROTOCOLSLIST))
                {
                    CollectionProtocol collProtocol = (CollectionProtocol) iterate
                            .next();
                    whereColValue[i] = collProtocol.getId().toString();
                }
            }
            if (coll != null && !coll.isEmpty())
                list = bizLogic.retrieve(srcObjName, selectColumnName,
                        whereColName, whereColCondition, whereColValue,
                        Constants.OR_JOIN_CONDITION);
        }

        return list;

    }

}
