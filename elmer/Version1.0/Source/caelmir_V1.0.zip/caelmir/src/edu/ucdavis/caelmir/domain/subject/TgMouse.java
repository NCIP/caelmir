
package edu.ucdavis.caelmir.domain.subject;

import java.io.Serializable;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;

/**
 * @author sujay_narkar
 * @hibernate.class table="CAELMIR_TGMOUSE"
 */
public class TgMouse extends AbstractDomainObject implements Serializable {
    
    private static final long serialVersionUID = 1234567890L;
  
    protected String pathnum;
    protected String micro;
    protected String diagnosis;
    public TgMouse(){
        
    }
    
    
    public TgMouse(AbstractActionForm form) {
        setAllValues(form);
    }
    
    /**
     * 
     */
    public void setAllValues(AbstractActionForm actionForm) {
     
    }
    
    /**
     * Returns the unique systemIdentifier assigned to institution.
     * 
     * @return A unique systemIdentifier assigned to the institution.
     * @see #setIdentifier(int)
     * */
    public Long getSystemIdentifier() {
        return null;
    }
    
    /**
     * Sets an systemIdentifier for the institution.
     * @param systemIdentifier Unique systemIdentifier to be assigned to the institution.
     * @see #getIdentifier()
     * */
    public void setSystemIdentifier(Long systemIdentifier) {
        
    }

	/**
	 * @return Returns the diagnosis.
     * @hibernate.property name="diagnosis" type="string" column="diagnosis" length="254"
	 */
	public String getDiagnosis() {
		return diagnosis;
	}
	/**
	 * @param diagnosis The diagnosis to set.
	 */
	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
	/**
	 * @return Returns the micro.
     * @hibernate.property name="micro" type="string" column="micro" length="300"
	 */
	public String getMicro() {
		return micro;
	}
	/**
	 * @param micro The micro to set.
	 */
	public void setMicro(String micro) {
		this.micro = micro;
	}
	/**
	 * @return Returns the pathnum.
     * @hibernate.id name="pathnum" column="pathnum" type="string"
     * length="20" unsaved-value="null" generator-class="assigned"
     * 
	 */
	public String getPathnum() {
		return pathnum;
	}
	/**
	 * @param pathnum The pathnum to set.
	 */
	public void setPathnum(String pathnum) {
		this.pathnum = pathnum;
	}


    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#getId()
     */
    public Long getId()
    {
        // TODO Auto-generated method stub
        return null;
    }


    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#setId(java.lang.Long)
     */
    public void setId(Long arg0)
    {
        // TODO Auto-generated method stub
        
    }
}
