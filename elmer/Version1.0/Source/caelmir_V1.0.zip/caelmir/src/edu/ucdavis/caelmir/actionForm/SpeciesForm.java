/**
 * 
 */
package edu.ucdavis.caelmir.actionForm;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Species;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;

/**
 * @author ravinder_kankanala
 *
 */
public class SpeciesForm extends AbstractActionForm {

	/**
     * Species Name
     */
    private String speciesName;
    
    /**
     * Genus name of the species.
     */
    private String genusId;
	
    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
	public String getSpeciesName() {
		return speciesName;
	}

	
	public void setSpeciesName(String speciesName) {
		this.speciesName = speciesName;
	}

	/**
     * Returns the genusId name of the species.
     * @return String representing the genusId of the species. 
     * @see #setgenus(String)
     */
    public String getGenusId()
    {
        return (this.genusId);
    }

    /**
     * Sets the genusId name of the species.
     * @param genusId String representing the genusId of the species.
     * @see #getgenus()
     */
    public void setGenusId(String genusId)
    {
        this.genusId = genusId;
    }

	
	public int getFormId() {
		return Constants.SPECIES_FORM_ID;
		
	}

	/**
	 * 
	 */
	public void setAllValues(AbstractDomainObject abstractDomain) {
		Species species = (Species) abstractDomain;

		this.activityStatus = species.getActivityStatus();
		this.id = species.getSystemIdentifier().longValue();
		this.speciesName = species.getSpeciesName();
		
		if (species.getGenus() != null) {
			this.genusId = species.getGenus().getId().toString();
		}
	
	  }

	

	/**
     * Overrides the validate method of ActionForm.
     * */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        
        if (validator.isEmpty(String.valueOf(speciesName))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("species.name")));
        }
        
       
        return errors;
    }
	
    /**
     * This method sets Identifier of Objects inserted by AddNew activity in Form-Bean which initialized AddNew action
     * @param formBeanId - FormBean ID of the object inserted
     *  @param addObjectIdentifier - Identifier of the Object inserted 
     */
    public void setAddNewObjectIdentifier(String addNewFor, Long addObjectIdentifier)
    {
        if (addNewFor.equals("genus"))
        {
            setGenusId(addObjectIdentifier.toString());
        }
    }
    
	protected void reset() {
		
	}

}
