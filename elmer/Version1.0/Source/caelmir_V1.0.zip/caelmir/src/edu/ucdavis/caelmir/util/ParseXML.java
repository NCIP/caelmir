/**
 *<p>Title: ParseXML Class </p>
 *<p>Description: This class parse the popupConfig.xml initializes the map.</p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.util;

import org.dom4j.Attribute;
import org.dom4j.Element;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.logger.Logger;

/**
 *  This class reads the popupConfig.xml and returns the initialized map
 * @author shital_lawhale
 *
 */
public class ParseXML
{

    public static ParseXML parsexml = null;
   // public static int  variable ;
    public static ParseXML getinstance()
    {
          if(parsexml == null)          
                parsexml =  new ParseXML();

            return parsexml;
        //return null;
    }
    
    /**
     * reads the popupConfig.xml and returns the map
     * @param listName
     * @return map filled with values from pop-up config.xml
     * @throws DAOException
     */
    public final Map parseXml(String listName,String invokeType) throws DAOException
    {
        //variable ++;
        Map moduleMap = new HashMap();
        SAXReader saxReader = new SAXReader();

        String filePath = Variables.caElmirHome
                + System.getProperty("file.separator")
                + edu.ucdavis.caelmir.util.global.Constants.FILE_PATH; //"caelmir-properties"+ "\\" + "popupConfig.xml";   
        File file = new File(filePath);

        Document document = null;
        String string = null;

        try
        {
            document = saxReader.read(file);
            Element root = document.getRootElement();
            Attribute attr;
            Iterator iterator;
            Element element;
            List parametersList = new ArrayList();
            List columnList = new ArrayList();

            Iterator listsIterator = root
                    .elementIterator(Constants.POPUP_OPERATION);
            Element requestProcessor = null;

            while (listsIterator.hasNext())
            {

                requestProcessor = (Element) listsIterator.next();
                attr = requestProcessor.attribute(Constants.LIST);
                String popupList = attr.getText();
                
                attr = requestProcessor.attribute(Constants.INVOKE_TYPE);
                string = attr.getText();
                moduleMap.put(Constants.INVOKE_TYPE, string);
                
                if(popupList != null && invokeType!=null )
                if (popupList.equals(listName) && invokeType.equals(string))
                {
                    attr = requestProcessor.attribute(Constants.LABEL);
                    string = attr.getText();
                    moduleMap.put(Constants.OBJECT_LABEL, string);
                    
                    attr = requestProcessor.attribute(Constants.TARGET);
                    string = attr.getText();
                    moduleMap.put(Constants.TARGET, string);

                    parametersList = new ArrayList();
                    columnList = new ArrayList();
                    element = requestProcessor.element(Constants.CHOICE);
                    string = element.getText();
                    //iterator = element.elementIterator(Constants.COLUMN);
                  //iterateElement(parametersList, columnList, iterator);
                    moduleMap.put(Constants.CHOICE, string);

                    element = requestProcessor
                            .element(Constants.SOURCEOBJECTNAME);
                    string = element.getText();
                    if (string != null && !string.equals(""))
                    {
                        moduleMap.put(Constants.SOURCEOBJECTNAME, string);

                        //now read selectcolumn name 
                        parametersList = new ArrayList();
                        columnList = new ArrayList();
                        element = requestProcessor
                                .element(Constants.SELECTCOLUMNNAME);

                        iterator = element.elementIterator(Constants.COLUMN);
                        iterateElement(parametersList, columnList, iterator);

                        Object[] selectColumnName = (Object[]) parametersList
                                .toArray();
                        moduleMap.put(Constants.SELECTCOLUMNNAME,
                                selectColumnName);
                        moduleMap.put(Constants.COLUMNLIST, columnList);

                        element = requestProcessor
                                .element(Constants.CONDITIONS);
                        iterator = element
                                .elementIterator(Constants.POPUP_CONDITION);
                        String joinCondition;//= null;

                        List whereColumnValue = new ArrayList();
                        parametersList = new ArrayList();
                        columnList = new ArrayList();
                      
                        iterateCondition(parametersList, columnList,
                                whereColumnValue, iterator);
                        joinCondition = element
                                .element(Constants.JOINCONDITION).getText();

                        moduleMap.put(Constants.WHERECOLNAME,
                                (Object[]) parametersList.toArray());
                        moduleMap.put(Constants.WHERECOLCONDITION,
                                (Object[]) columnList.toArray());
                        moduleMap.put(Constants.WHERECOLVALUE,
                                (Object[]) whereColumnValue.toArray());                      
                     
                      
                        moduleMap.put(Constants.JOINCONDITION, joinCondition);

                        element = requestProcessor
                                .element(Constants.PICKUPDISPLAY);
                        moduleMap.put(Constants.ID, element.element("ID")
                                .getText());
                        
                        string = element.element(Constants.DISPAY_FIELD)
                                .getText();

                        List words = new ArrayList();
                        StringTokenizer st = new StringTokenizer(string,Constants.FIELD_SEPERATOR );
                        while (st.hasMoreTokens())
                        {
                            words.add(st.nextToken());
                        }

                        moduleMap.put(Constants.DISPAY_FIELD, words);

                        parametersList = new ArrayList();
                        columnList = new ArrayList();
                        element = requestProcessor
                                .element(Constants.ACTION_LINK);
                        iterator = element.elementIterator(Constants.LINK);
                        iterateElement(parametersList, columnList, iterator);

                        moduleMap.put(Constants.LINKNAME, parametersList);
                        moduleMap.put(Constants.URL, columnList);

                    }

                }
            } //while        

        }
        catch (Exception ex)
        {
            Logger.out.error(ex.getMessage(), ex);
            throw new DAOException("Error in retrieve " + ex.getMessage(), ex);
        }
        return moduleMap;
    }

    /**
     * 
     * @param parametersList Empty List
     * @param columnList  Empty List
     * @param iterator
     * This method sets the parametersList and columnList 
     */
    private void iterateElement(List parametersList, List columnList,
            Iterator iterator)
    {
        Element colName;

        while (iterator.hasNext())
        {
            colName = (Element) iterator.next();
            parametersList.add(colName.attribute(Constants.COL_NAME).getText());
            columnList.add(colName.getText());
        }
    }

    /**
     * 
     * @param parametersList Empty List
     * @param columnList Empty List
     * @param whereColumnValue Empty List
     * @param iterator
     * This method sets the parametersList ,columnList,whereColumnValue List 
     */
    private void iterateCondition(List parametersList, List columnList,
            List whereColumnValue, Iterator iterator)
    {
        Element element;

        while (iterator.hasNext())
        {
            element = (Element) iterator.next();
            parametersList.add(element.element(Constants.WHERECOLNAME)
                    .getText());
            columnList.add(element.element(Constants.WHERECOLCONDITION)
                    .getText());
            whereColumnValue.add(element.element(Constants.WHERECOLVALUE)
                    .getText());
        }

    }

    
   
    
}
