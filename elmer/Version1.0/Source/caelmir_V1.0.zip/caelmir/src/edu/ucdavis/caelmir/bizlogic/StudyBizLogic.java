
package edu.ucdavis.caelmir.bizlogic;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**Description: This class is used to insert the study object in the database or update it. The class also takes
 * care of any pre-processing on the objects before delegating the objects to the database layer.
 * Title:TODO
 * Copyright:TODO
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class StudyBizLogic extends DefaultBizLogic
{

    /**
     * Saves the user object in the database.
     * @param obj The user object to be saved.
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    protected void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {
        Study study = (Study) obj;

        Long parentUserId = sessionDataBean.getUserId();
        User parentUser = getUser(dao, parentUserId);
        study.setCreator(parentUser);
        User primaryInvestigator = parentUser;
        while (parentUser.getUser() != null)
        {
            primaryInvestigator = parentUser.getUser();
        }
        study.setPrimaryInvestigator(primaryInvestigator);

   
        populateUserCollection(study, dao, parentUser, primaryInvestigator);
        populateUserGroupCollection(study, dao);
        populateProtocolCollection(study, dao);
      
       
        /*  added by Ravinder  */
        if (study.getModel() != null) {
            List list = dao.retrieve(Model.class.getName(),"id", study.getModel().getSystemIdentifier());
            Model model = null;
            if (list!=null && list.size() != 0)
            {
                model = (Model) list.get(0);
            }

            study.setModel(model);
        }
        
        study.setCreatedDate(new Date());
        dao.insert(study, sessionDataBean, true, false);
    }
    
    /*  end */
    
    public boolean checkDeleteObject(CollectionProtocol oldProtocol,DAO dao) {
        Collection protocolEventCol = oldProtocol.getCollectionProtocolEventCollection();
        Iterator iter = protocolEventCol.iterator();
        while (iter.hasNext()) {
            CollectionProtocolEvent pEvent = (CollectionProtocolEvent) iter.next();
            Collection entityMapCol = pEvent.getEntityMapCollection();
            Iterator iterMap = entityMapCol.iterator();
            while (iterMap.hasNext()) {
	            EntityMap map = (EntityMap)iterMap.next(); 
	            try
	            {
	                List list = dao.retrieve(EventRecords.class.getName(),"entityMap", map.getId());
	                if(list != null && list.size() > 0) {
	                    return true;
	                }
	            }
	            catch (DAOException e)
	            {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
            }
       }
        return false;
    }
    
    /**
     * Updates an objects into the database.
     * @param obj The object to be updated into the database.
     * @throws DAOException
     */
    protected void update(DAO dao, Object obj, Object oldObj, SessionDataBean sessionDataBean) throws DAOException, UserNotAuthorizedException
    {
        Study study = (Study) obj;
        Study oldStudy = (Study) oldObj;
        Collection userGroupCollection = study.getUserGroupCollection();
        study.setUserGroupCollection(null);
        dao.update(study, null, true, false, false);   
        
        Iterator userGroupIterator = userGroupCollection.iterator();
        UserGroup userGroup = null;
        Collection newUserGroupCollection = new HashSet();
        while (userGroupIterator.hasNext())
        {
            userGroup = (UserGroup) userGroupIterator.next();
            UserGroup newUserGroup = (UserGroup) dao.retrieve(UserGroup.class
                    .getName(), userGroup.getId());
            newUserGroupCollection.add(newUserGroup);
         //   newUserGroup.getStudyCollection().add(study);
        }
        study.setUserGroupCollection(newUserGroupCollection);
        Collection protocolCollection = study.getCollectionProtocolCollection();
        study.setCollectionProtocolCollection(null);
        dao.update(study, null, true, false, false);
        Iterator protocolIterator = protocolCollection.iterator();
        CollectionProtocol protocol = null;
        Collection newProtocolCollection = new HashSet();
        while (protocolIterator.hasNext())
        {
            protocol = (CollectionProtocol) protocolIterator.next();
            CollectionProtocol newProtocol = (CollectionProtocol) dao.retrieve(CollectionProtocol.class
                    .getName(), protocol.getId());
            newProtocolCollection.add(newProtocol);
        }
        
        Collection oldProtocolCol = oldStudy.getCollectionProtocolCollection();
        Iterator iter = oldProtocolCol.iterator();
        while (iter.hasNext()) {
            CollectionProtocol oldProtocol = (CollectionProtocol) iter.next();
            if(!newProtocolCollection.contains(oldProtocol)) {
                if(checkDeleteObject(oldProtocol,dao)) {
                    newProtocolCollection.add(oldProtocol);
                }
            }
        }
        study.setCollectionProtocolCollection(newProtocolCollection);

        Collection user = study.getUserCollection();
        study.setUserCollection(null);
        dao.update(study, null, true, false, false); 
        
        Long parentUserId = sessionDataBean.getUserId();
        User parentUser = getUser(dao, parentUserId);
        study.setCreator(parentUser);
        User primaryInvestigator = parentUser;
        while (parentUser.getUser() != null)
        {
            primaryInvestigator = parentUser.getUser();
        }
        study.setPrimaryInvestigator(primaryInvestigator);
        study.setUserCollection(user);
        populateUserCollection(study, dao, parentUser, primaryInvestigator);
        dao.update(study, null, true, false, false); 
    }

    private User getUser(DAO dao, Long parentUserId) throws DAOException
    {
        User user = (User) dao.retrieve(User.class.getName(), parentUserId);
        return user;
    }

    /*private void populateModelRelatedInformation(Study study, DAO dao) throws FileNotFoundException,IOException
    {
        // TODO Auto-generated method stub
        
        //get url from properties file and then replace id
        Properties prop = new Properties();
        prop.load(new FileInputStream(Variables.caElmirHome
                + System.getProperty(Constants.FILE_SEPARATOR)
                + Constants.PROPERTIES_FILE));
        
        String urlPath = (String) prop.get(Constants.MODEL_URL);
        ///******* assumed that url ends with id=
        urlPath= urlPath + study.getModelDescriptionURL();
        
        study.setModelDescriptionURL(urlPath);

    }*/

    /**
     * 
     * @param study
     */
    private void populateUserCollection(Study study, DAO dao,
           User parentUser, User primaryInvestigator)
            throws DAOException
    {
        Collection studyUserCollection = study.getUserCollection();

        boolean flag = checkForLoginUser(studyUserCollection, parentUser);

        if (parentUser != null && !flag)
            studyUserCollection.add(parentUser);
        
        if (primaryInvestigator != null) 
                if(parentUser.getId() != primaryInvestigator.getId())
            studyUserCollection.add(primaryInvestigator);

        Iterator studyUserCollectionIterator = studyUserCollection.iterator();
        User genUser = null;
        Collection newUserCollection = new HashSet();
        while (studyUserCollectionIterator.hasNext())
        {
            genUser = (User) studyUserCollectionIterator
                    .next();
           
            if(genUser.getUser() != null)
            {
                User userPI = (User) dao.retrieve(User.class.getName(),
                        genUser.getUser().getId());
                
                genUser.setUser(userPI);
                newUserCollection.add(userPI);
                userPI.getStudyCollection().add(study);
            } 
            User user = (User) dao.retrieve(User.class.getName(),
                    genUser.getId());
            newUserCollection.add(user);
            user.getStudyCollection().add(study);
        }
        study.setUserCollection(newUserCollection);
    }

    /**
     * 
     * @param study
     */
    private void populateUserGroupCollection(Study study, DAO dao)
            throws DAOException
    {
        Collection userGroupCollection = study.getUserGroupCollection();
        Iterator userGroupIterator = userGroupCollection.iterator();
        UserGroup userGroup = null;
        Collection newUserGroupCollection = new HashSet();
        while (userGroupIterator.hasNext())
        {
            userGroup = (UserGroup) userGroupIterator.next();
            UserGroup newUserGroup = (UserGroup) dao.retrieve(UserGroup.class
                    .getName(), userGroup.getId());
            newUserGroupCollection.add(newUserGroup);
            newUserGroup.getStudyCollection().add(study);
        }
        study.setUserGroupCollection(newUserGroupCollection);
    }

    /**
     * 
     * @param study
     * @param dao
     * @throws DAOException
     */
    private void populateProtocolCollection(Study study, DAO dao)
            throws DAOException
    {
        Collection protocolCollection = study.getCollectionProtocolCollection();
        Iterator protocolCollectionIterator = protocolCollection.iterator();
        CollectionProtocol protocol = null;
        Collection newProtocolCollection = new HashSet();
        while (protocolCollectionIterator.hasNext())
        {
            protocol = (CollectionProtocol) protocolCollectionIterator.next();
            CollectionProtocol newProtocol = (CollectionProtocol) dao.retrieve(CollectionProtocol.class
                    .getName(), protocol.getId());
            newProtocolCollection.add(newProtocol);
            newProtocol.getStudyCollection().add(study);
        }
        study.setCollectionProtocolCollection(newProtocolCollection);

    }

    private boolean checkForLoginUser(Collection coll, User creator)
    {
        boolean flag = false;

        Iterator iterateData = coll.iterator();
        while (iterateData.hasNext())
        {
            User studyUser = (User) iterateData.next();
            if (studyUser != null && studyUser.getId().equals(creator.getId()))
            {
                flag = true;
                break;
            }

        }
        return flag;
    }

}
