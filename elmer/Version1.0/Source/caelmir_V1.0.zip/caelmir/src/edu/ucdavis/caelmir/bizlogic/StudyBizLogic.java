
package edu.ucdavis.caelmir.bizlogic;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.Vector;
import java.util.Properties;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.common.UserRole;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.security.exceptions.SMException;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;
//import edu.ucdavis.caelmir.util.CommonUtility;
import edu.ucdavis.caelmir.util.global.Constants;
import gov.nih.nci.security.authorization.domainobjects.ProtectionElement;
import gov.nih.nci.security.authorization.domainobjects.ProtectionGroup;
import gov.nih.nci.security.authorization.domainobjects.Role;
import gov.nih.nci.security.exceptions.CSException;
import gov.nih.nci.security.exceptions.CSTransactionException;

/**Description: This class is used to insert the study object in the database or update it. The class also takes
 * care of any pre-processing on the objects before delegating the objects to the database layer.
 * Title:TODO
 * Copyright:TODO
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class StudyBizLogic extends DefaultBizLogic
{

    /**
     * Saves the user object in the database.
     * @param obj The user object to be saved.
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    protected void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {
        Study study = (Study) obj;

        Long parentUserId = sessionDataBean.getUserId();
        User parentUser = getUser(dao, parentUserId);
        study.setCreator(parentUser);
        User primaryInvestigator = parentUser;
        
        User iterateUser=parentUser;
        while (iterateUser != null)
        {
            if(iterateUser.getUser() != null)
                primaryInvestigator = iterateUser.getUser();
            iterateUser=iterateUser.getUser();
        }
        study.setPrimaryInvestigator(primaryInvestigator);

        populateUserCollection(study, dao, parentUser, primaryInvestigator);
        populateUserGroupCollection(study, dao);
        populateProtocolCollection(study, dao);

        /*  added by Ravinder  */
        if (study.getModel() != null)
        {
            List list = dao.retrieve(Model.class.getName(), "id", study
                    .getModel().getSystemIdentifier());
            Model model = null;
            if (list != null && list.size() != 0)
            {
                model = (Model) list.get(0);
            }

            study.setModel(model);
        }
        study.setCreatedDate(new Date());
        dao.insert(study, sessionDataBean, true, false);
        try
        {
            setUserRole(study, dao);//;.getUserRoleCollection();
        }
        catch (CSException e)
        {
        }
        catch (SMException e1)
        {
        }

    }

    private void setUserRole(Study study, DAO dao) throws DAOException,
            SMException, CSException
    {
        Collection userRoleColl = study.getUserRoleCollection();

        Collection newUserRoleColl = new HashSet();
        if (userRoleColl != null && !userRoleColl.isEmpty())
        {
            Iterator it = userRoleColl.iterator();
            while (it.hasNext())
            {
                UserRole userRole = (UserRole) it.next();
                //DefaultBizLogic bizLogic = new DefaultBizLogic();
                List list= dao.retrieve(User.class.getName(),"id",userRole
                        .getUserId());

                if (list != null)
                {
                    User user = (User) list.get(0);
                    if (userRole.getRoleId().toString().equals("-1"))
                        userRole.setRoleId(user.getRoleId());

                    if (!user.getRoleId().equals(userRole.getRoleId()))
                    {
                        //create Pg, role                           
                        Role role = getRoles(userRole.getRoleId().toString());
                        Set roleSet = new HashSet();
                        roleSet.add(role);
                        ProtectionGroup protectionGroup = SecurityManager
                                .getInstance(this.getClass())
                                .getProtectionGroup("STUDY_" + study.getId());
                        /*     
                         Set protectionObjects = new HashSet();
                         protectionObjects.add(study);
                         Set PE= SecurityManager.getInstance(this.getClass()).createProtectionElementsFromProtectionObjects(protectionObjects);
                         
                         Iterator iterator= PE.iterator();
                         ProtectionElement ele = null;
                         while(iterator.hasNext())
                         {
                         ele = (ProtectionElement) iterator.next();
                         }
                         
                         if(ele!=null)
                         SecurityManager.getInstance(this.getClass()).assignProtectionElementToGroup(ele,"STUDY_PROTECTION_GROUP");
                         
                         ProtectionGroup  PG = SecurityManager.getInstance(this.getClass()).getProtectionGroup("STUDY_PROTECTION_GROUP");
                         
                         */
                        SecurityManager.getInstance(this.getClass())
                                .assignUserRoleToProtectionGroup(
                                        user.getCsmUserId(), roleSet,
                                        protectionGroup,
                                        Constants.PRIVILEGE_ASSIGN);
                        newUserRoleColl.add(userRole);
                    }
                }
            }
        }
        study.setUserRoleCollection(null);
        study.setUserRoleCollection(userRoleColl);
    }

    /*  end */

    private Role getRoles(String roleId) throws SMException
    {
        //Sets the roleList attribute to be used in the Add/Edit User Page.
        Vector roleList = SecurityManager.getInstance(this.getClass())
                .getRoles();

        ListIterator iterator = roleList.listIterator();

        List roleNameValueBeanList = new ArrayList();
        NameValueBean nameValueBean = new NameValueBean();
        nameValueBean.setName(Constants.SELECT_OPTION);
        nameValueBean.setValue(String.valueOf(Constants.SELECT_OPTION_VALUE));
        roleNameValueBeanList.add(nameValueBean);

        Role role = null;
        while (iterator.hasNext())
        {
            role = (Role) iterator.next();
            if (role.getId().toString().equals(roleId))
                return role;

        }
        return role;
    }

    public boolean checkDeleteObject(CollectionProtocol oldProtocol, DAO dao)
    {
        Collection protocolEventCol = oldProtocol
                .getCollectionProtocolEventCollection();
        Iterator iter = protocolEventCol.iterator();
        while (iter.hasNext())
        {
            CollectionProtocolEvent pEvent = (CollectionProtocolEvent) iter
                    .next();
            Collection entityMapCol = pEvent.getEntityMapCollection();
            Iterator iterMap = entityMapCol.iterator();
            while (iterMap.hasNext())
            {
                EntityMap map = (EntityMap) iterMap.next();
                try
                {
                    List list = dao.retrieve(EventRecords.class.getName(),
                            "entityMap", map.getId());
                    if (list != null && list.size() > 0)
                    {
                        return true;
                    }
                }
                catch (DAOException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

    /**
     * Updates an objects into the database.
     * @param obj The object to be updated into the database.
     * @throws DAOException
     */
    protected void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {
        Study study = (Study) obj;
        Study oldStudy = (Study) oldObj;
        Collection userGroupCollection = study.getUserGroupCollection();
        study.setUserGroupCollection(null);
        dao.update(study, null, true, false, false);

        Iterator userGroupIterator = userGroupCollection.iterator();
        UserGroup userGroup = null;
        Collection newUserGroupCollection = new HashSet();
        while (userGroupIterator.hasNext())
        {
            userGroup = (UserGroup) userGroupIterator.next();
            UserGroup newUserGroup = (UserGroup) dao.retrieve(UserGroup.class
                    .getName(), userGroup.getId());
            newUserGroupCollection.add(newUserGroup);
            //   newUserGroup.getStudyCollection().add(study);
        }
        study.setUserGroupCollection(newUserGroupCollection);
        Collection protocolCollection = study.getCollectionProtocolCollection();
        study.setCollectionProtocolCollection(null);
        dao.update(study, null, true, false, false);
        Iterator protocolIterator = protocolCollection.iterator();
        CollectionProtocol protocol = null;
        Collection newProtocolCollection = new HashSet();
        while (protocolIterator.hasNext())
        {
            protocol = (CollectionProtocol) protocolIterator.next();
            CollectionProtocol newProtocol = (CollectionProtocol) dao.retrieve(
                    CollectionProtocol.class.getName(), protocol.getId());
            newProtocolCollection.add(newProtocol);
        }

        Collection oldProtocolCol = oldStudy.getCollectionProtocolCollection();
        Iterator iter = oldProtocolCol.iterator();
        while (iter.hasNext())
        {
            CollectionProtocol oldProtocol = (CollectionProtocol) iter.next();
            if (!newProtocolCollection.contains(oldProtocol))
            {
                if (checkDeleteObject(oldProtocol, dao))
                {
                    newProtocolCollection.add(oldProtocol);
                }
            }
        }
        study.setCollectionProtocolCollection(newProtocolCollection);

        Collection user = study.getUserCollection();
        study.setUserCollection(null);
        dao.update(study, null, true, false, false);

        Long parentUserId = sessionDataBean.getUserId();
        User parentUser = getUser(dao, parentUserId);
        study.setCreator(parentUser);
        User primaryInvestigator = parentUser;
        
        User iterateUser=parentUser;
        while (iterateUser != null)
        {
            if(iterateUser.getUser() != null)
                primaryInvestigator = iterateUser.getUser();
            iterateUser=iterateUser.getUser();
        }
        
        study.setPrimaryInvestigator(primaryInvestigator);
        study.setUserCollection(user);
        populateUserCollection(study, dao, parentUser, primaryInvestigator);

        try
        {
            setEditUserRole(study, dao, oldStudy);//;.getUserRoleCollection();
        }
        catch (CSException e)
        {
        }
        catch (SMException e1)
        {
        }

        removeUnusedUserFromPG(study, oldStudy,dao);

        dao.update(study, null, true, false, false);
    }

    private void removeUnusedUserFromPG(Study newstudy, Study oldStudy,DAO dao)
    {
        try
        {
            Collection newUserColl = newstudy.getUserCollection();
            Collection oldUserColl = oldStudy.getUserCollection();

            //List unusedUser = new Aaary
            int check = 1;
            if (oldUserColl != null && !oldUserColl.isEmpty())
            {
                Iterator oldUserIt = oldUserColl.iterator();
                while (oldUserIt.hasNext())
                {
                    User oldUser = (User) oldUserIt.next();
                    check = 1;
                    Iterator newUserIt = newUserColl.iterator();
                    while (newUserIt.hasNext())
                    {
                        User newUser = (User) newUserIt.next();
                        if (newUser.getId().equals(oldUser.getId()))
                            check = 0;
                        //newUser.getRoleId().toString();
                    }

                    if (check == 1)
                    {
                        ProtectionGroup protectionGroup = SecurityManager
                                .getInstance(this.getClass())
                                .getProtectionGroup("STUDY_" + oldStudy.getId());
                        String[] roles = SecurityManager.getInstance(
                                this.getClass()).getuserRoleFromPG(
                                        getCsmUserId(oldUser.getId().toString(),dao), protectionGroup);

                        if (roles != null)
                            SecurityManager.getInstance(this.getClass())
                                    .removeUserRoleFromProtectionGroup(
                                            protectionGroup
                                                    .getProtectionGroupId()
                                                    .toString(),
                                                    getCsmUserId(oldUser.getId().toString(),dao), roles);
                    }
                }
            }
        }
        catch (SMException e)
        {
        }
        catch (CSTransactionException e)
        {
        }
        catch (CSException e)
        {
        }
    }
    
    public   String  getCsmUserId(String id,DAO dao)
    {
        String csmId= null;
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List userList=new ArrayList();
        try
        {
            userList= dao.retrieve(User.class.getName(),"id",id);
            
            if(userList!=null && !userList.isEmpty())
            {
                User user= (User)userList.get(0);
                csmId = user.getCsmUserId().toString();
            }
            
        }
        catch(DAOException e){}
        return csmId;
        
    }

    private void setEditUserRole(Study study, DAO dao, Study oldStudy)
            throws DAOException, SMException, CSException
    {       
        Collection userRoleColl = study.getUserRoleCollection();
//        Collection newUserRoleColl = new HashSet();

        if (userRoleColl != null && !userRoleColl.isEmpty())
        {
            //1:remove all
            //2:then set it new 
            ProtectionGroup protectionGroup = SecurityManager.getInstance(
                    this.getClass()).getProtectionGroup(
                    "STUDY_" + oldStudy.getId());
           // Collection oldUserColl = oldStudy.getUserCollection();

            Iterator userRoleIt = userRoleColl.iterator();
            while (userRoleIt.hasNext())
            {
                UserRole userRole = (UserRole) userRoleIt.next();

                String[] roles = SecurityManager.getInstance(this.getClass())
                        .getuserRoleFromPG(getCsmUserId(userRole.getUserId().toString(),dao),
                                protectionGroup);
                if (roles != null)
                {
                    SecurityManager.getInstance(this.getClass())
                            .removeUserRoleFromProtectionGroup(
                                    protectionGroup.getProtectionGroupId()
                                            .toString(), getCsmUserId(userRole.getUserId().toString(),dao), roles);
                    
                }
                
            }
            setUserRole(study, dao);
        }
        /*       else
         {
         Collection userColl = study.getUserCollection();
         if(userColl!= null && !userColl.isEmpty())
         {
         Iterator userIt = userColl.iterator();
         while(userIt.hasNext())
         {
         User user=(User) userIt.next();                                        
         int access=SecurityManager.getInstance(this.getClass()).checkPrivilegeOnUserRolesForProtectionGroup(user.getId().toString(),protectionGroup,null);
         if(access == 2) //if user Prsent
         {
         
         }
         if(access == 1) //if user not present
         {
         //remove user
         SecurityManager.getInstance(this.getClass()).removeUserRoleFromProtectionGroup(protectionGroup.getProtectionGroupId(),user.getId(),null);
         }                    
         }
         }
         else
         SecurityManager.getInstance(this.getClass()).removeUserRoleFromProtectionGroup(protectionGroup.getProtectionGroupId(),null,null);
         }*/
    }

    private User getUser(DAO dao, Long parentUserId) throws DAOException
    {
        User user = (User) dao.retrieve(User.class.getName(), parentUserId);
        return user;
    }

    /*private void populateModelRelatedInformation(Study study, DAO dao) throws FileNotFoundException,IOException
     {
     // TODO Auto-generated method stub
     
     //get url from properties file and then replace id
     Properties prop = new Properties();
     prop.load(new FileInputStream(Variables.caElmirHome
     + System.getProperty(Constants.FILE_SEPARATOR)
     + Constants.PROPERTIES_FILE));
     
     String urlPath = (String) prop.get(Constants.MODEL_URL);
     ///******* assumed that url ends with id=
     urlPath= urlPath + study.getModelDescriptionURL();
     
     study.setModelDescriptionURL(urlPath);

     }*/

    /**
     * 
     * @param study
     */
    private void populateUserCollection(Study study, DAO dao, User parentUser,
            User primaryInvestigator) throws DAOException
    {
        Collection studyUserCollection = study.getUserCollection();

        boolean flag = checkForLoginUser(studyUserCollection, parentUser);

        if (parentUser != null && !flag)
            studyUserCollection.add(parentUser);

        if (primaryInvestigator != null)
            if (parentUser.getId() != primaryInvestigator.getId())
                studyUserCollection.add(primaryInvestigator);

        Iterator studyUserCollectionIterator = studyUserCollection.iterator();
        User genUser = null;
        Collection newUserCollection = new HashSet();
        while (studyUserCollectionIterator.hasNext())
        {
            genUser = (User) studyUserCollectionIterator.next();

            if (genUser.getUser() != null)
            {
                User userPI = (User) dao.retrieve(User.class.getName(), genUser
                        .getUser().getId());

                genUser.setUser(userPI);
                newUserCollection.add(userPI);
                userPI.getStudyCollection().add(study);
            }
            User user = (User) dao.retrieve(User.class.getName(), genUser
                    .getId());
            newUserCollection.add(user);
            user.getStudyCollection().add(study);
        }
        study.setUserCollection(newUserCollection);
    }

    /**
     * 
     * @param study
     */
    private void populateUserGroupCollection(Study study, DAO dao)
            throws DAOException
    {
        Collection userGroupCollection = study.getUserGroupCollection();
        Iterator userGroupIterator = userGroupCollection.iterator();
        UserGroup userGroup = null;
        Collection newUserGroupCollection = new HashSet();
        while (userGroupIterator.hasNext())
        {
            userGroup = (UserGroup) userGroupIterator.next();
            UserGroup newUserGroup = (UserGroup) dao.retrieve(UserGroup.class
                    .getName(), userGroup.getId());
            newUserGroupCollection.add(newUserGroup);
            newUserGroup.getStudyCollection().add(study);
        }
        study.setUserGroupCollection(newUserGroupCollection);
    }

    /**
     * 
     * @param study
     * @param dao
     * @throws DAOException
     */
    private void populateProtocolCollection(Study study, DAO dao)
            throws DAOException
    {
        Collection protocolCollection = study.getCollectionProtocolCollection();
        Iterator protocolCollectionIterator = protocolCollection.iterator();
        CollectionProtocol protocol = null;
        Collection newProtocolCollection = new HashSet();
        while (protocolCollectionIterator.hasNext())
        {
            protocol = (CollectionProtocol) protocolCollectionIterator.next();
            CollectionProtocol newProtocol = (CollectionProtocol) dao.retrieve(
                    CollectionProtocol.class.getName(), protocol.getId());
            newProtocolCollection.add(newProtocol);
            newProtocol.getStudyCollection().add(study);
        }
        study.setCollectionProtocolCollection(newProtocolCollection);

    }

    private boolean checkForLoginUser(Collection coll, User creator)
    {
        boolean flag = false;

        Iterator iterateData = coll.iterator();
        while (iterateData.hasNext())
        {
            User studyUser = (User) iterateData.next();
            if (studyUser != null && studyUser.getId().equals(creator.getId()))
            {
                flag = true;
                break;
            }
        }
        return flag;
    }

}
