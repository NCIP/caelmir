
package edu.ucdavis.caelmir.domain.common;



import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import edu.ucdavis.caelmir.actionForm.UserForm;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;
import edu.wustl.common.util.logger.Logger;

//import gov.nih.nci.system.applicationservice.ApplicationService;
//import gov.nih.nci.system.applicationservice.ApplicationServiceProvider;

/**
 * A person who interacts with the caTISSUE Core data system
 * and/or participates in the process of biospecimen collection,
 * processing, or utilization.
 * @hibernate.class table="CAELMIR_USER"
 */
public class User extends AbstractDomainObject implements java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**System generated unique systemIdentifier.*/
    private Long id;

    /**A string containing the First Name of the user.*/
    private String firstName;

    /**A string containing the Last Name of the user.*/
    private String lastName;

    /**A String containing initials of the user*/
    private String initials;

    /**Associated csm user id*/
    private Long csmUserId;

    /** Department of the user.*/
    private String department;

    /**EmailAddress of the user.*/
    private String emailAddress;

    /**A string containing the login name of the user.*/
    private String loginName;

    /** Password of the user*/
    private String password;

    /** Date of user registration.*/
    private Date createdDate;

    /** Comments added by the administrator for this user.*/
    private String comments;

    /** Fax number of the user*/
    private String faxNumber;

    /**Phone number of the user.*/
    private String phoneNumber;

    /**Second phone number of the user.*/
    private String phonePostHour;

    /**Activity status of the user.*/
    private String activityStatus;

    /** Role of the user.*/
    private Long roleId;

    /**Colony management system id*/
    private String cmsId;

    /**Institute of the user.*/
    private edu.ucdavis.caelmir.domain.common.Institution institution;

    /** Collection of the experiments */
    private Collection experimentCollection = new HashSet();

    /** Collection of user groups*/
    private Collection userGroupCollection = new HashSet();

    /**Creator user of this user.*/
    private edu.ucdavis.caelmir.domain.common.User user;

    /**Address of the user.*/
    private edu.ucdavis.caelmir.domain.common.Address address;
    
    /**Collection of user's preferences.*/
    private Collection preferenceCollection = new HashSet();
    
    /**Collection of user's preferences.*/
    private Collection studyCollection = new HashSet();
    
    /***TODO*/
    protected String pageOf;

    /**
     * Returns the systemIdentifier assigned to user.
     * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
     * unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_USER_SEQ"
     * @return Returns the systemIdentifier.
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * Returns the firstname assigned to user.
     * @hibernate.property name="firstName" type="string" column="FIRST_NAME" length="50"
     * @return Returns the firstName.
     */
    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    /**
     * Returns the lastname assigned to user.
     * @hibernate.property name="lastName" type="string" column="LAST_NAME" length="50"
     * @return Returns the lastName.
     */
    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    /**
     * Returns the lastname assigned to user.
     * @hibernate.property name="initials" type="string" column="INITIALS" length="50"
     * @return Returns the initials.
     */
    public String getInitials()
    {
        return initials;
    }

    public void setInitials(String initials)
    {
        this.initials = initials;
    }

    /**
     * Returns the id of the csm user.
     * @hibernate.property name="csmUserId" type="long" column="CSM_USER_ID" length="20"
     * @return Returns the password.
     */
    public Long getCsmUserId()
    {
        return csmUserId;
    }

    public void setCsmUserId(Long csmUserId)
    {
        this.csmUserId = csmUserId;
    }

    /**
     * Returns the lastname assigned to user.
     * @hibernate.property name="department" type="string" column="DEPARTMENT" length="50"
     * @return Returns the initials.
     */
    public String getDepartment()
    {
        return department;
    }

    public void setDepartment(String department)
    {
        this.department = department;
    }

    /**
     * Returns the email address of the user.
     * @hibernate.property name="emailAddress" type="string" column="EMAIL_ADDRESS" length="50"
     * @return Returns the password.
     */
    public String getEmailAddress()
    {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress)
    {
        this.emailAddress = emailAddress;
    }

    /**
     * Returns the loginname assigned to user.
     * @hibernate.property name="loginName" type="string" column="LOGIN_NAME" length="50"
     * not-null="true" unique="true"
     * @return Returns the loginName.
     */
    public String getLoginName()
    {
        return loginName;
    }

    public void setLoginName(String loginName)
    {
        this.loginName = loginName;
    }

    /**
     * Returns the password assigned to user.
     * @hibernate.property name="password" type="string" column="PASSWORD" length="50"
     * @return Returns the password.
     */
    public String getPassword()
    {
        return password;
    }

    public void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * Returns the date when the user is added to the system.
     * @hibernate.property name="createdDate" type="date" column="CREATED_DATE"
     * @return Returns the dateAdded.
     */
    public Date getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    /**
     * Returns the comments given by the approver.
     * @hibernate.property name="comments" type="string"
     * column="COMMENTS" length="2000"
     * @return the comments given by the approver.
     * @see #setComments(String)
     */
    public String getComments()
    {
        return comments;
    }

    public void setComments(String comments)
    {
        this.comments = comments;
    }

    /**
     * Returns the fax number of the user.
     * @hibernate.property name="faxNumber" type="string" column="FAX_NUMBER" length="50"
     * @return Returns the password.
     */
    public String getFaxNumber()
    {
        return faxNumber;
    }

    public void setFaxNumber(String faxNumber)
    {
        this.faxNumber = faxNumber;
    }

    /**
     *
     * @hibernate.property name="phoneNumber" type="string"
     * column="PHONE_NUMBER" length="50"
     * @return the phone number of the user
     *
     */
    public String getPhoneNumber()
    {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }

    /**
     * returns the user phone number to be contacted after his office hours
     * @hibernate.property name="phonePostHour" type="string"
     * column="PHONE_POST_HOUR" length="50"
     * @return the phone number of the user
     *
     */
    public String getPhonePostHour()
    {
        return phonePostHour;
    }

    public void setPhonePostHour(String phonePostHour)
    {
        this.phonePostHour = phonePostHour;
    }

    /**
     * Returns the activitystatus of the user.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     * @return Returns the activityStatus.
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @return Returns the roleId of the user.
     * @hibernate.property name="roleId" type="long" column="ROLE_ID" length="38"
     */
    public Long getRoleId()
    {
        return roleId;
    }

    public void setRoleId(Long roleId)
    {
        this.roleId = roleId;
    }

    /**
     * @return Returns the roleId of the user.
     * @hibernate.property name="cmsId" type="string" column="CMS_ID" length="20"
     */
    public String getCmsId()
    {
        return cmsId;
    }

    public void setCmsId(String cmsId)
    {
        this.cmsId = cmsId;
    }

    /**
     * Returns the institution of the user.
     * @hibernate.many-to-one column="INSTITUTION_ID" class="edu.ucdavis.caelmir.domain.common.Institution"
     * constrained="true"
     * @return the institution of the user.
     */
    public edu.ucdavis.caelmir.domain.common.Institution getInstitution()
    {

        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.common.User thisIdSet = new edu.ucdavis.caelmir.domain.common.User();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.Institution", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                institution = (edu.ucdavis.caelmir.domain.common.Institution)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("User:getInstitution throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return institution;
    }

    public void setInstitution(
            edu.ucdavis.caelmir.domain.common.Institution institution)
    {
        this.institution = institution;
    }

    /**
     * @return Returns the userExperimentCollection. This Collections the experiment objects.
     * @hibernate.set name="experimentCollection" table="CAELMIR_EXPERIMENT_USER"
     * cascade="all-delete-orphan" inverse="true" lazy="true"
     * @hibernate.collection-key column="USER_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.research.Experiment" column="EXPERIMENT_ID"
     */
    public Collection getExperimentCollection()
    {
        //			try{
        //			   if(experimentCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.common.User thisIdSet = new edu.ucdavis.caelmir.domain.common.User();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.research.Experiment", thisIdSet);				 
        //				 	experimentCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("User:getExperimentCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return experimentCollection;
    }

    public void setExperimentCollection(Collection experimentCollection)
    {
        this.experimentCollection = experimentCollection;
    }

    /**
     * Returns the userGroupCollection. This Collections the user group objects.
     * @hibernate.set name="userGroupCollection" table="CAELMIR_USER_GROUP_REL"
     * cascade="save-update" inverse="true" lazy="true"
     * @hibernate.collection-key column="USER_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.common.UserGroup" column="USER_GROUP_ID"
     * @return Returns the userGroupCollection.
     */
    public Collection getUserGroupCollection()
    {
        //			try{
        //			   if(userGroupCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.common.User thisIdSet = new edu.ucdavis.caelmir.domain.common.User();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.UserGroup", thisIdSet);				 
        //				 	userGroupCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("User:getUserGroupCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return userGroupCollection;
    }

    public void setUserGroupCollection(Collection userGroupCollection)
    {
        this.userGroupCollection = userGroupCollection;
    }

    /**
     * @return the user object
     * @hibernate.many-to-one column="PARENT_USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.User getUser()
    {
        //			
        //              ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.common.User thisIdSet = new edu.ucdavis.caelmir.domain.common.User();
        //			  thisIdSet.setId(this.getId());
        //			  try {
        //			   List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //			 
        //			  if (resultList!=null && resultList.size()>0) {
        //			     user = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
        //			     }
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("User:getUser throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return user;

    }

    public void setUser(edu.ucdavis.caelmir.domain.common.User user)
    {
        this.user = user;
    }

    /**
     * Returns the address of the user.
     * @hibernate.many-to-one column="ADDRESS_ID" class="edu.ucdavis.caelmir.domain.common.Address"
     * constrained="true"
     * @return the address of the user.
     */
    public edu.ucdavis.caelmir.domain.common.Address getAddress()
    {
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.common.User thisIdSet = new edu.ucdavis.caelmir.domain.common.User();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.Address", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                address = (edu.ucdavis.caelmir.domain.common.Address)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("User:getAddress throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return address;
    }

    public void setAddress(edu.ucdavis.caelmir.domain.common.Address address)
    {
        this.address = address;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof User)
        {
            User c = (User) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    /**
     * Initialize a new User instance.
     * Note: Hibernate invokes this constructor through reflection API.
     */
    public User()
    {
    }

    /**
     * This Constructor Copies the data from an UserForm object to a User object.
     * @param user An UserForm object containing the information about the user.
     * @throws AssignDataException 
     */
    public User(UserForm uform) throws AssignDataException
    {
        this();
        setAllValues(uform);
    }


    public void setAllValues(AbstractActionForm abstractForm) throws AssignDataException
    {
        try
        {
            UserForm uform = (UserForm) abstractForm;
            this.pageOf = uform.getPageOf();

            if (pageOf.equals(Constants.PAGEOF_CHANGE_PASSWORD))
            {
                this.password = uform.getNewPassword();
                
            }
            else
            {
                
                if (!pageOf.equals(Constants.PAGEOF_SIGNUP)
                        && !pageOf.equals(Constants.PAGEOF_USER_PROFILE))
                {
                    this.comments = uform.getComments();
                    this.roleId = new Long(uform.getRole());
                }

                if (uform.getPageOf().equals(Constants.PAGEOF_USER_ADMIN)
                        && uform.getOperation().equals(Constants.ADD))
                {
                    this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
                    this.setCreatedDate(Calendar.getInstance().getTime());
                }
                
                if (Constants.PAGEOF_USER_ADMIN.equals(pageOf))
                {
                    this.csmUserId = uform.getCsmUserId();
                }
                
                this.id = new Long(uform.getId());
                this.setLoginName(uform.getEmailAddress());
                this.setInitials(uform.getInitials());
                this.setDepartment(uform.getDepartment());
                this.setLastName(uform.getLastName());
                this.setFirstName(uform.getFirstName());
                this.setEmailAddress(uform.getEmailAddress());
                this.cmsId = uform.getCmsId();
                User piUser = new User();
                if (uform.getPrimaryInvestigator().intValue() > 0) {
                    piUser.setId(uform.getPrimaryInvestigator());
                    this.setUser(piUser);
                }
                this.setPhoneNumber(uform.getPhoneNumber());
                this.setPhonePostHour(uform.getPhonePostHour());
                this.setFaxNumber(uform.getFaxNumber());
                if (uform.getOperation().equals(Constants.ADD)) {
                    Institution institution = new Institution();
                    institution.setSystemIdentifier(new Long(uform.getInstitutionId()));
                    this.institution = institution;
                    
                    Address address = new Address();
                    address.setStreet(uform.getStreet());
                    address.setCity(uform.getCity());
                    address.setState(uform.getState());
                    address.setCountry(uform.getCountry());
                    address.setZipCode(uform.getZipCode());
                    
                    this.address = address;
                } else if (uform.getOperation().equals(Constants.EDIT)) {
                    this.institution.setSystemIdentifier(new Long(uform.getInstitutionId()));
                    this.address.setStreet(uform.getStreet());
                    this.address.setCity(uform.getCity());
                    this.address.setState(uform.getState());
                    this.address.setCountry(uform.getCountry());
                    this.address.setZipCode(uform.getZipCode());
                }
                
                
              
                
                if (Constants.PAGEOF_USER_PROFILE.equals(pageOf) == false)
                {
                    if (uform.getOperation().equals(Constants.EDIT)) {
                        this.activityStatus = uform.getActivityStatus();
                        uform.setActivityStatus(null);
                    }
                }

                if (pageOf.equals(Constants.PAGEOF_SIGNUP))
                {
                    this.activityStatus = Constants.ACTIVITY_STATUS_NEW;
                    this.setCreatedDate(Calendar.getInstance().getTime());
                }

               

                if (uform.getPageOf().equals(Constants.PAGEOF_APPROVE_USER))
                {
                    if (uform.getStatus().equals(
                            Constants.APPROVE_USER_APPROVE_STATUS))
                    {
                        this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
                    }
                    else if (uform.getStatus().equals(
                            Constants.APPROVE_USER_REJECT_STATUS))
                    {
                        this.activityStatus = Constants.ACTIVITY_STATUS_REJECT;
                    }
                    else
                    {
                        this.activityStatus = Constants.ACTIVITY_STATUS_PENDING;
                    }
                }

               
            }
        }
        catch (Exception excp)
        {
            Logger.out.error(excp.getMessage());
        }
        
    }

    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#getSystemIdentifier()
     */
    public Long getSystemIdentifier()
    {
        return id;
    }

    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#setSystemIdentifier(java.lang.Long)
     */
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
    /**
     * @return Returns the pageOf.
     */
    public String getPageOf()
    {
        return pageOf;
    }

    /**
     * @param pageOf The pageOf to set.
     */
    public void setPageOf(String pageOf)
    {
        this.pageOf = pageOf;
    }
    
    /**
     * @return Returns the experimentCollection.
     * @hibernate.set name="preferenceCollection" table="CAELMIR_USERPREFERENCE" cascade="none"
     * inverse="true" lazy="false"
     * @hibernate.collection-key column="USER_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.common.UserPreference"
     */
    public Collection getPreferenceCollection() {
        return this.preferenceCollection;
    }
    public void setPreferenceCollection(Collection collection) {
        this.preferenceCollection = collection;
    }
 
    
    
    /**
     * @return Returns the userGroupCollection.
     * @hibernate.set name="studyCollection" table="CAELMIR_STUDY_USER" 
     * cascade="all-delete-orphan" inverse="true" lazy="true"
     * @hibernate.collection-key column="USER_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.research.Study" column="STUDY_ID"
     */
    public Collection getStudyCollection()
    {
        return studyCollection;
    }

    
    public void setStudyCollection(Collection studyCollection)
    {
        this.studyCollection = studyCollection;
    }

}