/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author shital lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.bizlogic;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import edu.ucdavis.caelmir.domain.subject.Genotype;
import edu.ucdavis.caelmir.domain.subject.Genus;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.domain.subject.Species;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * MouseBizLogic class is used to add/update Mouse information into database.
 * @author shital_lawhale
 */
public class MouseBizLogic extends DefaultBizLogic
{

    /**
     * Saves the Mouse object in the database.
     * @param obj The Mouse object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    public void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {
        
     
         Mouse mouse = (Mouse) obj;
        
         if(mouse.getGenus()!=null)
         {
         List gList = dao.retrieve(Genus.class.getName(),"id", mouse.getGenus().getSystemIdentifier());
         Genus genus = null;
         if (gList!=null && gList.size() != 0)
         {
         	genus = (Genus) gList.get(0);
         }
         mouse.setGenus(genus);
         }
        
         if(mouse.getSpecies()!=null)
         {
         List sList = dao.retrieve(Species.class.getName(),"id", mouse.getSpecies().getSystemIdentifier());
         Species species = null;
         if (sList!=null && sList.size() != 0)
         {
        	 species = (Species) sList.get(0);
         }
         mouse.setSpecies(species);
         }
         
         
         Collection genotypeColl = mouse.getGenotypeCollection();
         Iterator iterate = genotypeColl.iterator();

         Set tempSet = new HashSet();
         
         while (iterate.hasNext())
         {
             Genotype genotype = (Genotype) iterate.next();
             Genotype genotypefromExp = new Genotype();
             genotypefromExp = (Genotype) dao.retrieve(Genotype.class.getName(), genotype.getId());
             tempSet.add(genotypefromExp);  
             genotypefromExp.getAnimalCollection().add(mouse);
         }      
         
         mouse.setGenotypeCollection(tempSet);
         dao.insert(mouse, null, true, false);
         
    }
    
    
    /**
     * Updates the Mouse object in the database.
     * @param obj The Mouse object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    public void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {
        Mouse mouse = (Mouse) obj;
        Collection genotypeColl = mouse.getGenotypeCollection();
        mouse.setGenotypeCollection(null);
        dao.update(mouse, null, true, false, false);

        Iterator iterateGenotype = genotypeColl.iterator();
        Collection genotypeCollection = new HashSet();
        while (iterateGenotype.hasNext())
        {
            Genotype genotype = (Genotype) iterateGenotype.next();
            Genotype genotypefromTable = (Genotype) dao.retrieve(Genotype.class
                    .getName(), genotype.getId());           
            genotypeCollection.add(genotypefromTable);
        }
        mouse.setGenotypeCollection(genotypeCollection);
        
        dao.update(mouse, null, true, false, false);
    }
}
