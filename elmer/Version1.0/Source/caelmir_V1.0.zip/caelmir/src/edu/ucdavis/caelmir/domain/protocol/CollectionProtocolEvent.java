

package edu.ucdavis.caelmir.domain.protocol;
import java.util.Collection;
import java.util.HashSet;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;



  /**
   * A required specimen collection event associated with a Collection Protocol
   * @hibernate.class table="CAELMIR_PROTOCOL_EVENT"
   */

public  class CollectionProtocolEvent extends AbstractDomainObject implements java.io.Serializable 
{
	private static final long serialVersionUID = 1234567890L;

	
	   /**Unique id of the object.*/
	   private  Long id;
       
       /**Event point on which data is to be recorded*/
       private  String studyCalendarEventPoint;
       
       /**Collection protocol for which data is to be recorded*/
       private edu.ucdavis.caelmir.domain.protocol.CollectionProtocol collectionProtocol;
       
       private Collection entityMapCollection = new HashSet();
       
       /** Collection of all the data elements which are to be captured.*/
    //   private  Collection eventRecordsCollection = new  HashSet();
       
       /**
        * Returns the systemIdentifier assigned to user.
        * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
        * unsaved-value="null" generator-class="native"
        * @hibernate.generator-param name="sequence" value="CAELMIR_PROTOCOL_EVENT_SEQ"
        * @return Returns the systemIdentifier.
        */
	   public   Long getId(){
	      return id;
	   }
	   public void setId(  Long id){
	      this.id = id;
	   }
	
	   

        /**
         * @return
         * @hibernate.property name="studyCalendarEventPoint" column="STUDY_CALENDAR_EVENT_POINT" type="string" length = 20
         */
	   public   String getStudyCalendarEventPoint(){
	      return studyCalendarEventPoint;
	   }
	   public void setStudyCalendarEventPoint(  String studyCalendarEventPoint){
	      this.studyCalendarEventPoint = studyCalendarEventPoint;
	   }
	

	
	   
	   
	   
	      
			
			
			
			
        /**
         * @return
         * @hibernate.many-to-one column="COLLECTION_PROTOCOL_ID" class="edu.ucdavis.caelmir.domain.protocol.CollectionProtocol"
         * constrained="true"
         */
			public edu.ucdavis.caelmir.domain.protocol.CollectionProtocol getCollectionProtocol(){
//			
//			
//			
//			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
//			  edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent thisIdSet = new edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent();
//			  thisIdSet.setId(this.getId());
//			  
//			  try {
//			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.protocol.CollectionProtocol", thisIdSet);				 
//		             if (resultList!=null && resultList.size()>0) {
//		                collectionProtocol = (edu.ucdavis.caelmir.domain.protocol.CollectionProtocol)resultList.get(0);
//		             }
//		          
//			  } catch(Exception ex) 
//			  { 
//			      	System.out.println("CollectionProtocolEvent:getCollectionProtocol throws exception ... ...");
//			   		ex.printStackTrace(); 
//			  }
			  return collectionProtocol;	
			 
			 		
           }
		   
	      
	               
	   
	   
	   
	   public void setCollectionProtocol(edu.ucdavis.caelmir.domain.protocol.CollectionProtocol collectionProtocol){
		this.collectionProtocol = collectionProtocol;
	   }	
	   
	   
	
	   
	   
	   
	      
     /*
         * @return Returns the userGroupCollection.
         * @hibernate.set name="eventRecordsCollection" table="CAELMIR_ER_EVENTS" 
         * cascade="save-update" inverse="false" lazy="false"
         * @hibernate.collection-key column="COLLECTION_PROTOCOL_EVENT_ID"
         * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.eventRecords.EventRecords" column="EVENT_RECORD_ID"
         */
	/*		public  Collection getEventRecordsCollection(){
//			try{
//			   if(dataElementsCollection.size() == 0) {}
//		           } catch(Exception e) {			     
//			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
//			      try {
//			      
//			      
//			         
//				 	edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent thisIdSet = new edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent();
//			         	thisIdSet.setId(this.getId());
//			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.dataElements.DataElements", thisIdSet);				 
//				 	dataElementsCollection = resultList;  
//				 	return resultList;
//				 
//			      
//			      }catch(Exception ex) 
//			      {
//			      	System.out.println("CollectionProtocolEvent:getDataElementsCollection throws exception ... ...");
//			   		ex.printStackTrace(); 
//			      }
//			   }	
	              return eventRecordsCollection;
	          }
			   
		
	   	public void setEventRecordsCollection( Collection eventRecordsCollection){
	   		this.eventRecordsCollection = eventRecordsCollection;
	        }	
	   */
	   
	

		public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof CollectionProtocolEvent) {
				CollectionProtocolEvent c =(CollectionProtocolEvent)obj; 			 
				Long thisId = getId();		
				
					if(thisId != null && thisId.equals(c.getId())) {
					   eq = true;
				    }		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			
			if(getId() != null) {
				h += getId().hashCode();
			}
			
			return h;
	}
        
        public void setAllValues(AbstractActionForm abstractForm) throws AssignDataException
        {
            // TODO Auto-generated method stub
            
        }
       
        public Long getSystemIdentifier()
        {
            // TODO Auto-generated method stub
            return id;
        }
        
        public void setSystemIdentifier(Long systemIdentifier)
        {
            this.id = systemIdentifier;
        }
	
	
    /**
     * @return Returns the entityMapCollection.
     * @hibernate.set name="entityMapCollection" table="CAELMIR_ENTITY_MAP"
     * cascade="save-update" inverse="true" lazy="false"
     * @hibernate.collection-key column="COLLECTION_PROTOCOL_EVENT_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.common.EntityMap"
     */
    public Collection getEntityMapCollection()
    {
        return entityMapCollection;
    }
    /**
     * @param entityMapCollection The entityMapCollection to set.
     */
    public void setEntityMapCollection(Collection entityMapCollection)
    {
        this.entityMapCollection = entityMapCollection;
    }
}