/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */

package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.User;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.NameValueBean;

import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.security.exceptions.SMException;
import edu.wustl.common.util.dbManager.DAOException;
import gov.nih.nci.security.authorization.domainobjects.ProtectionGroup;
import gov.nih.nci.security.authorization.domainobjects.Role;
import gov.nih.nci.security.exceptions.CSException;
import gov.nih.nci.security.exceptions.CSTransactionException;

public class userRoleAction extends BaseAction
{

    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws SMException, DAOException

    {

        String[] userId = request.getParameterValues("userId");

        String studyId = request.getParameter(Constants.Identifier);
        List columnList = new ArrayList();
        columnList.add("User Name");
        columnList.add("Roles");
        if (userId != null)
        {

            List userRoleList = new ArrayList();
            List dataList = getDataList(userId, userRoleList, studyId);
            request.setAttribute(Constants.SPREADSHEET_DATA_LIST, dataList);
            request.setAttribute(Constants.USER_ROLE_LIST, userRoleList);

            List roleNameValueBeanList = getRoles();
            request.setAttribute(Constants.ROLES_LIST, roleNameValueBeanList);
        }
        request.setAttribute(Constants.SPREADSHEET_COLUMN_LIST, columnList);
        return (mapping.findForward(Constants.SUCCESS));
    }

    private List getDataList(String[] userId, List userRoleList, String studyId)
            throws DAOException
    {
        ProtectionGroup protectionGroup = null;
        List userList = new ArrayList();
        try
        {
            if (studyId != null && !studyId.equals("") && !studyId.equals("0"))
                protectionGroup = SecurityManager.getInstance(this.getClass())
                        .getProtectionGroup("STUDY_" + studyId);

            String[] displayNameFields = {"firstName", "lastName"};
            String[] whereColumnName = {"id"};
            String[] whereColumnCondition = {"="};
            DefaultBizLogic bizLogic = new DefaultBizLogic();
            if (userId != null)
                for (int i = 0; i < userId.length; i++)
                {
                    Object[] whereColumnValue = {userId[i]};
                    List list = bizLogic.getList(User.class.getName(),
                            displayNameFields, "id", whereColumnName,
                            whereColumnCondition, whereColumnValue, null, ",",
                            false);
                    List usrList = bizLogic.retrieve(User.class.getName(),
                            "id", userId[i]);
                    if (usrList != null && !usrList.isEmpty())
                    {
                        User user = (User) usrList.get(0);
                        String roles[] = null;
                        if (SecurityManager.getInstance(this.getClass())
                                .getuserRoleFromPG(getCsmUserId(user.getId().toString()),
                                        protectionGroup) != null)
                        {
                            roles = SecurityManager
                                    .getInstance(this.getClass())
                                    .getuserRoleFromPG(getCsmUserId(user.getId().toString()),
                                            protectionGroup);
                        }
                        if (roles != null)
                            userRoleList.add(roles[0]);
                        else
                            userRoleList.add(user.getRoleId().toString());

                        userList.add(list.get(1));
                    }
                }
        }
        catch (SMException e)
        {
        }
        catch (CSTransactionException e)
        {
        }
        catch (CSException e)
        {
        }

        return userList;

    }
    
    
    
    public   String  getCsmUserId(String id)
    {
        String csmId= null;
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List userList=new ArrayList();
        try
        {
            userList= bizLogic.retrieve(User.class.getName(),"id",id);
            
            if(userList!=null && !userList.isEmpty())
            {
                User user= (User)userList.get(0);
                csmId = user.getCsmUserId().toString();
            }
            
        }
        catch(DAOException e){}
        return csmId;
        
    }

    /**
     * Returns a list of all roles that can be assigned to a user.
     * @return a list of all roles that can be assigned to a user.
     * @throws SMException
     */
    private List getRoles() throws SMException
    {
        //Sets the roleList attribute to be used in the Add/Edit User Page.
        Vector roleList = SecurityManager.getInstance(this.getClass())
                .getRoles();

        ListIterator iterator = roleList.listIterator();

        List roleNameValueBeanList = new ArrayList();
        NameValueBean nameValueBean = new NameValueBean();
        nameValueBean.setName(Constants.SELECT_OPTION);
        nameValueBean.setValue(String.valueOf(Constants.SELECT_OPTION_VALUE));
        roleNameValueBeanList.add(nameValueBean);

        while (iterator.hasNext())
        {
            Role role = (Role) iterator.next();
            nameValueBean = new NameValueBean();
            nameValueBean.setName(role.getName());
            nameValueBean.setValue(String.valueOf(role.getId()));
            roleNameValueBeanList.add(nameValueBean);
        }
        return roleNameValueBeanList;
    }

}
