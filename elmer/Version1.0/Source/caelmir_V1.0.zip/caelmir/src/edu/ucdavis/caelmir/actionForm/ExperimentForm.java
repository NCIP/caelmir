
package edu.ucdavis.caelmir.actionForm;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;


import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.util.PreferenceManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Utility;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;
import edu.wustl.common.util.logger.Logger;


/**
 * ExperimentForm Class is used to encapsulate all the request parameters passed 
 * from Experiment Add/Edit webpage.
 * @author shital_lawhale
 * */
public class ExperimentForm extends AbstractActionForm 
{
	   
	/**
     * Activity Status of Experiment, it could be CLOSED, ACTIVE, DISABLED(DELETED).
     */
      private String activityStatus;
	
	/**
	    * Hypothesis for Exeriment
	    */
      protected String hypothesis;
	   
	   /**
	    * Identifier of Experiment
	    */
	  // private Long id;
	   
	   /**
	    * Name of Experiment
	    */
	   private String name;
	   
	   /**
	    * StartDate of Experiment
	    */
	   private String startDate;
	   
	   /**
	    * StopDate of Experiment
	    */	   
	   private String stopDate;
	   
	   /**
	    * StudyRequirements for Experiment
	    */
	   private String studyRequirements;
	   
	   /**
	    * User Selected Cohort Collection for Experiment 
	    */
	   private String [] cohort;
	   
	   /**
	    * User Selected Protocol Collection for Experiment
	    */
	   private String [] protocol;
	   
	   /**
	    * Experiment Creator for Experiment
	    */
	   private String [] users;
	   
	   /**
	    * Data Creator for Experiment
	    */
	   private String [] groups;
	   
	   private String studyIdentifier;
	   
	   Boolean deleteCohortFlag = new Boolean(false);
	  
       String creator;
        
       String createdDate;
       
       public String getCreatedDate()
       {
           return createdDate;
       }

       public void setCreatedDate(String createdDate)
       {
           this.createdDate = createdDate;
       }

        
        public String getCreator()
        {
            return creator;
        }
        
        public void setCreator(String creator)
        {
            this.creator = creator;
        }
	
		public Boolean getDeleteCohortFlag()
	    {
			return deleteCohortFlag;
		}
		public void setDeleteCohortFlag(Boolean deleteCohortFlag) 
		{
			this.deleteCohortFlag = deleteCohortFlag;
		}
	   
	   
	   private Collection cohortCollection = new HashSet();
	   //private Collection experimentCreatorCollection = new HashSet();
//	   private Study study;
	 //  private Collection dataCreatorCollection = new HashSet();
	   private Collection protocolCollection = new HashSet();
	   
	   /**
	    * Returns Hypothesis of an Experiment 
	    * @return hypothesis  
	    * @see #setHypothesis(String)
	    */
	   public  String getHypothesis()
	   {
	      return hypothesis;
	   }
	   
	   /**
	    * sets Hypothesis for experiment 
	    * @param hypothesis
	    * @see #getHypothesis()
	    */  
	   public void setHypothesis(String hypothesis)
	   {
	      this.hypothesis = hypothesis;
	   }
	
	   
	   /**
	    * returns identifier for an experiment
	    * @return identifier for an experiment
	    * @see #setId(Long)
	    */
	   public  long getId()
	   {
	      return id;
	   }
	   
	   /**
	    * sets the identifier for an experiment
	    * @param id
	    * @see #getId()
	    */
	   public void setId( long id)
	   {
	      this.id = id;
	   }
	
	   
	   /**
	    * Returns name of an experiment
	    * @return name of an experiment
	    * @see #setName(String)
	    */
	   public  String getName()
	   {
	      return name;
	   }
	   
	   /**
	    * Sets name of an Experiment
	    * @param name of an Experiment
	    * @see #getName() 
	    */
	   public void setName( String name)
	   {
	      this.name = name;
	   }
	
	   /**
	    * Returns StartDate of an Experiment
	    * @return StartDate of an Experiment
	    * @see #setStartDate(String)
	    */	 
	   public  String getStartDate()
	   {
	      return startDate;
	   }
	   
	   /**
	    * Sets startDate of an Experiment
	    * @param startDate
	    * @see #getStartDate()
	    */
	   public void setStartDate(String startDate)
	   {
	      this.startDate = startDate;
	   }
	
	   
	   /**
	    * Returns stopDate of an experiment
	    * @return stopDate of an experiment
	    * @see #setStartDate(String)
	    */
	   public  String getStopDate()
	   {
	      return stopDate;
	   }
	   
	   /**
	    * Sets stopDate of an Experiment
	    * @param stopDate of an Experiment
	    * @see #getStopDate()
	    */
	   public void setStopDate( String stopDate)
	   {
	      this.stopDate = stopDate;
	   }	   
	  
	   /**
	    * Returns studyRequirements of an Experiment
	    * @return studyRequirements of an Experiment
	    * @see #setStudyRequirements(String)
	    */
	   public String getStudyRequirements()
	   {
	      return studyRequirements;
	   }
	   
	   /**
	    * Sets studyRequirements for an Experiment
	    * @param studyRequirements for an Experiment
	    * @see #getStudyRequirements()
	    */
	   public void setStudyRequirements( String studyRequirements)
	   {
	      this.studyRequirements = studyRequirements;
	   }
	   
	   /**
	    * Returns cohort of an Experiment
	    * @return cohort of an Experiment
	    * @see #setCohort(String[])
	    */
	   public String[] getCohort()
	   {
	      return cohort;
	   }
	  
	   /**
	    * sets cohort for an Experiment
	    * @param cohort for an Experiment
	    * @see #getCohort()
	    */
	   public void setCohort(String [] cohort)
	   {
	      this.cohort=cohort;
	      //System.out.println("SETCOHORT:"+cohort);
	   }
	  
	   /**
	    * 
	    * @return protocol of an Experiment
	    * @see #setProtocol(String[])
	    */
	   public String[] getProtocol()
	   {
	      return protocol;
	   }
	   
	   /**
	    * Sets Protocol for an Experiment
	    * @param protocol for an Experiment
	    * @see #getProtocol()
	    */
	   public void setProtocol(String [] protocol)
	   {
		//  System.out.println("protocol: "+ protocol[0]);
	      this.protocol=protocol;
	   }

	 	
		/**
		 * returns experiment form identifier
		 */
		 public int getFormId()
		 {
			 int formId = Constants.EXP_CREATE_FORM_ID;
			 
			 return formId;
		 }
		
		
		
		 /**
		     * Resets the values of all the fields.
		     * Is called by the overridden reset method defined in ActionForm.  
		     * */
		    protected void reset()
		    {
		  /* 	this.hypothesis = null;
		    	this.name=null;
		    	this.studyRequirements=null;
		    	this.startDate = null;
		    	this.stopDate = null;		    	
		    */	
		    }
		
		
		    /**
		     * Copies the data from an AbstractDomain object to a ExperimentForm object.
		     * @param user An AbstractDomain object.  
		     */
		    public void setAllValues(AbstractDomainObject abstractDomain)
		    {
		    	Experiment experiment = (Experiment) abstractDomain;
		    	
		    	this.hypothesis = experiment.getHypothesis();		    			    	
		    	this.name = experiment.getName();
		    	this.startDate = Utility.parseDateToString(experiment.getExperimentStartDate(),Constants.DATE_PATTERN_MM_DD_YYYY);
		    	//if(Utility.parseDateToString(experiment.getExperimentStopDate(),Constants.DATE_PATTERN_MM_DD_YYYY) == "")
		    //		this.stopDate  =  "-";
		    ///	else
		    		this.stopDate  =  Utility.parseDateToString(experiment.getExperimentStopDate(),Constants.DATE_PATTERN_MM_DD_YYYY);
		    	this.studyRequirements = experiment.getStudyRequirement();
		    	
		    	//required in commonaddeditaction while updation
		    	this.id = experiment.getSystemIdentifier().longValue();
		    	this.activityStatus = experiment.getActivityStatus();		    	
		    	this.studyIdentifier = experiment.getStudy().getId().toString();	    	
		    	
                this.createdDate = Utility.parseDateToString(experiment.getCreatedDate(),Constants.DATE_PATTERN_MM_DD_YYYY);
                if (experiment.getCreator() != null) {
                    this.creator = experiment.getCreator().getLastName() + Constants.COMMA_SEPARATOR + experiment.getCreator().getFirstName();
                }
                
                
                
		    	Iterator iterate;
		    	Collection Coll;		    	
		    	//set user colln
		    	Coll= experiment.getUserCollection();
		    	String xx;
				int i=0;
		    	if(Coll != null && Coll.size() != 0  )
		    	{		
		    		
			    	String [] users = new String[Coll.size()];
					iterate= Coll.iterator();								
					while(iterate.hasNext())
					{
						  User userObj = (User) iterate.next();
						  xx=userObj.getId().toString();
						  users[i++]=xx;
					}
					setUsers(users);
				}
				
				//set group colln
				Coll= experiment.getUserGroupCollection();	
			   if( Coll != null && Coll.size() != 0 )
			   {			    		
			    	String [] groups = new String[Coll.size()];
					iterate= Coll.iterator();			
					i=0;				  
					while(iterate.hasNext())
					{
						  UserGroup userGroupObj = (UserGroup) iterate.next();
						  xx=userGroupObj.getId().toString();
						  groups[i++]=xx;
					}
					setGroups(groups);
				}
				
				//set protocol coll				
				Coll= experiment.getCollectionProtocolCollection();	
				if(Coll != null && Coll.size() != 0 )
				{
			    	String [] protocol = new String[Coll.size()];
					iterate= Coll.iterator();			
					i=0;				  
					while(iterate.hasNext())
					{
                        CollectionProtocol protocolObj = (CollectionProtocol) iterate.next();
						  xx=protocolObj.getId().toString();
						  protocol[i++]=xx;
					}
					setProtocol(protocol);
				}
				
//				set cohort coll				
				Coll= experiment.getCohortCollection();
				if(Coll != null && Coll.size() != 0 )
				{
			    	String [] cohort = new String[Coll.size()];
					iterate= Coll.iterator();			
					i=0;				  
					while(iterate.hasNext())
					{
						Cohort cohortObj = (Cohort) iterate.next();
						  xx=cohortObj.getId().toString();
						  cohort[i++]=xx;
					}
					setCohort(cohort);
				}
				
		}
		
		
		
		public Collection getCohortCollection()
	   {
			 try
			 {
				if(cohortCollection.size() == 0)
			   		{}
		      } 
			  catch(Exception e) 
		      {			     
		//	      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
			      try
			      {
			         
		//	          	Experiment thisIdSet = new Experiment();
			         	//thisIdSet.setId(this.getId());
			         //	Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.Cohort", thisIdSet);				 
				     //	cohortCollection = resultList;  
				 	//return resultList;		 
			      
			      }
			      catch(Exception ex) 
			      {
			      	System.out.println("Experiment:getCohortCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	              return cohortCollection;
	   }
		
	   	public void setCohortCollection(Collection cohortCollection)
	   	{
	   		this.cohortCollection = cohortCollection;
	    }	
	/*   
	    public java.util.Collection getExperimentCreatorCollection()
	    {
			try
			{
			   if(experimentCreatorCollection.size() == 0) 
			   		{}
		    } 
			catch(Exception e)
			{			     
			//     ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
			      try 
			      {
			    	/*    Experiment thisIdSet = new Experiment();
				        thisIdSet.setId(this.getId());
				        Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.User", thisIdSet);				 
					 	experimentCreatorCollection = resultList;  
					 	return resultList;			 
			      */
	/*		      }
			      catch(Exception ex) 
			      {
			      	System.out.println("Experiment:getExperimentCreatorCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			}	
	        return experimentCreatorCollection;
	     }
		
	   	public void setExperimentCreatorCollection(Collection experimentCreatorCollection)
	   	{
	   		this.experimentCreatorCollection = experimentCreatorCollection;
	     }	
	   
			
		 public Collection getDataCreatorCollection()
		 {
			try
			{
			   if(dataCreatorCollection.size() == 0) 
			   {}
		     } 
			 catch(Exception e)
			 {			     
			//      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
			      try
			      {
	/*			 	  Experiment thisIdSet = new Experiment();
			          thisIdSet.setId(this.getId());
			          Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.User", thisIdSet);				 
				 	  dataCreatorCollection = resultList;  
				 	  return resultList;		*/ 
			      
	/*		      }
			      catch(Exception ex) 
			      {
			      	System.out.println("Experiment:getDataCreatorCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
			   }	
	           return dataCreatorCollection;
	      }
			      
	   
	   	public void setDataCreatorCollection(java.util.Collection dataCreatorCollection)
	   	{
	   		this.dataCreatorCollection = dataCreatorCollection;
	    }	
	 /*  
		public Study getStudy()
		{
			
			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
			  Experiment thisIdSet = new Experiment();
			  thisIdSet.setId(this.getId());
			  
			  try 
			  {
				  	List resultList = applicationService.search("edu.ucdavis.caelmir.domain.Study", thisIdSet);				 
		             if (resultList!=null && resultList.size()>0)
		             {
		                study = (Study)resultList.get(0);
		             }
		          
			  } 
			  catch(Exception ex) 
			  { 
			      	System.out.println("Experiment:getStudy throws exception ... ...");
			   		ex.printStackTrace(); 
			  }
			  return study;			 
			 		
		}
		  
	    
	   	
	   public void setStudy(Study study)
	   {
		 this.study = study;
	   }	
	   	*/   
	   public Collection getProtocolCollection()
	   {
			try
			{
			     if(protocolCollection.size() == 0)
			        {}
		    } 
			catch(Exception e) 
			{			     
			 //     ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
			      try 
			      {
			         
				/*	 	Experiment thisIdSet = new Experiment();
				        thisIdSet.setId(this.getId());
				        Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.Protocol", thisIdSet);				 
					 	protocolCollection = resultList;  
					 	return resultList;	*/		 
			      
			      }
			      catch(Exception ex) 
			      {
			      	System.out.println("Experiment:getProtocolCollection throws exception ... ...");
			   		ex.printStackTrace(); 
			      }
		   }	
            return protocolCollection;
        }
	   
	   	public void setProtocolCollection(java.util.Collection protocolCollection)
	   	{
	   		this.protocolCollection = protocolCollection;
	   	}	   	

		public boolean equals(Object obj)
		{
			boolean eq = false;
	/*		if(obj instanceof Experiment)
			{
				Experiment c =(Experiment)obj; 			 
				Long thisId = getId();		
				
					if(thisId != null && thisId.equals(c.getId()))
					{
					   eq = true;
				    }		
				
			}*/
			return eq;
		}
		
		public int hashCode()
		{
			int h = 0;
			
			if(new Long(getId()) != null)
			{
				h += new Long(getId()).hashCode();
			}
			
			return h;
		}
		
		
		public void setAddNewObjectIdentifier(String addNewFor, Long addObjectIdentifier)
	    {
				
	        if(addNewFor.equals("cohort"))
	        {
	        	Long ID=new Long(addObjectIdentifier.longValue());
	        	String str= ID.toString();	        	
	        	List list = new ArrayList();
	        	
	        	int len= 1;
	        	if (cohort != null)
	        	{
	        		for(int i=0;i<cohort.length;i++)
		        		list.add(cohort[i]);
	        		len=cohort.length + 1;
	        	}        		        	
	        	list.add(str);
	        	String [] cohort = new String[len]; 	
	        	//cohort =(String[]) list.toArray();	        	
	        	for(int i=0;i<len;i++)
	        		cohort[i]=(String)list.get(i);	        	
	            setCohort(cohort);
	        }	
	        if (addNewFor.equals("study"))
	        {
	        	Long ID=new Long(addObjectIdentifier.longValue());	        	
	        	String str= ID.toString();		        	       	
	        	setStudyIdentifier(str);	
          
	        }    
	        
	      
	        
	    }	
		
		 public ActionErrors validate(ActionMapping mapping,HttpServletRequest request)
		 {
			 ActionErrors errors = new ActionErrors();
		     Validator validator = new Validator();
		     boolean dateFlag=true;
		     try
		     {
		    	 if (validator.isEmpty(hypothesis))
                 {
                     errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                             "errors.item.required", ApplicationProperties
                                     .getValue("user.experiment.hypothesis")));
                 }
		    	 if (validator.isEmpty(name))
                 {
                     errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                             "errors.item.required", ApplicationProperties
                                     .getValue("user.experiment.name")));
                 }
		    /*	 if (validator.isEmpty(studyRequirements))
                 {
                     errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                             "errors.item.required", ApplicationProperties
                                     .getValue("user.experiment.studyreq")));
                 }
		    	*/ 
		    	 if (validator.isEmpty(startDate))
                 {
		    		 dateFlag=false;
                     errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                             "errors.item.required", ApplicationProperties
                                     .getValue("user.experiment.startdate")));
                 } 	 
		    	 
		    	 else if(!validator.checkDate(startDate))
		    	 {
		    		 dateFlag=false;
		    		 errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(
		    				 "errors.date.format",ApplicationProperties
                             .getValue("user.experiment.startdate")));	
		    		 
		    	 }
		    	 
		    	  if (this.stopDate != null && this.stopDate.trim().length()!=0) {
		 	        if (!validator.compareDates(this.startDate,this.stopDate)) {
		 	        	errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
		 	                    "errors.date.enddate.invalid", ApplicationProperties
		 	                            .getValue("user.experiment.stopdate")));
		 	        }
		         }
		  /*  	 if (validator.isEmpty(stopDate))
                 {
		    		 dateFlag=false;
                     errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                             "errors.item.required", ApplicationProperties
                                     .getValue("user.experiment.stopdate")));
                 }
		    	 else if(!validator.checkDate(stopDate))
		    	 {
		    		 dateFlag=false;
		    		 errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(
		    				 "errors.date.format",ApplicationProperties
                             .getValue("user.experiment.stopdate")));		    				 
		    	 }
		    	 
		    	 if(dateFlag==true && !validator.compareDates(startDate,stopDate))
		    	 {
		    		 errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(
		    				 "errors.item",ApplicationProperties
                             .getValue("user.experiment.date")));		    				 
		    	 }
		    	 
		    	
		  	     if(protocol == null)
		    	 {
		    		  errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(
		    				 "errors.item.select",ApplicationProperties
                             .getValue("user.experiment.protocol")));	
		    	 }
		  	     if(cohort == null)
		    	 {
		    		  errors.add(ActionErrors.GLOBAL_ERROR,new ActionError(
		    				 "errors.item.select",ApplicationProperties
                           .getValue("user.experiment.cohort")));	
		    	 }*/
		  	     if (validator.isValidOption(String.valueOf(studyIdentifier)) == false)
                 {
                   errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                           "errors.item.required", ApplicationProperties
                                   .getValue("user.experiment.study")));
                 }
		     }
		     catch (Exception excp)
		     {
		            Logger.out.error(excp.getMessage(), excp);
		     }
		    return errors;
		 }

		

		public String[] getGroups() 
		{
			return groups;
		}

		public void setGroups(String[] groups)
		{
			this.groups = groups;
			//System.out.println("gropus: "+ groups[0]);
		}

		public String[] getUsers() 
		{
			return users;
		}

		public void setUsers(String[] users) 
		{	
			this.users = users;
		}

		
		public String getActivityStatus()
		{
			return activityStatus;
		}

		
		public void setActivityStatus(String activityStatus)
		{
			this.activityStatus = activityStatus;
		}
        
        public String getStudyIdentifier()
        {
            return studyIdentifier;
        }
        
        public void setStudyIdentifier(String studyIdentifier)
        {
            this.studyIdentifier = studyIdentifier;
        }
		
        
        /**
         * @return Returns the systemIdentifier.
         */
        public long getSystemIdentifier()
        {
            return id;
        }
        /**
         * @param systemIdentifier The systemIdentifier to set.
         */
        public void setSystemIdentifier(long systemIdentifier)
        {
            this.id = systemIdentifier;
        }
	/*	public String[] getCohortList()
		{
			return cohortList;
		}
		
		public void setCohortList(String[] cohortList)
		{
			this.cohortList = cohortList;
		}*/
}
