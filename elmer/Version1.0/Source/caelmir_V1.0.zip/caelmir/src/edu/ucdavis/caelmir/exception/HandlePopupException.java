/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.exception;



public class HandlePopupException extends Exception
{
    public static String  str;
    public HandlePopupException()
    {
         /// throw new 
        
    }
    
    public HandlePopupException(String s)
    {
         /// throw new 
        str=s;
    }
    
}
