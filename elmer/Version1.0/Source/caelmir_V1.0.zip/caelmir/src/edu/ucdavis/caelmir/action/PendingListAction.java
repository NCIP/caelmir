/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */

package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

public class PendingListAction extends BaseAction
{

    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        String pageOf = (String) request.getParameter(Constants.PAGEOF);
        String operation = request.getParameter(Constants.OPERATION);
        request.setAttribute(Constants.OPERATION, operation);
        request.setAttribute(Constants.PAGEOF, pageOf);

        getPendingEventRecords(request);

        return mapping.findForward(pageOf);
    }

    private void getPendingEventRecords(HttpServletRequest req)
            throws DAOException
    {
        List pendingList = new ArrayList();
        SessionDataBean sessionDataBean = (SessionDataBean) req.getSession()
                .getAttribute(Constants.SESSION_DATA);

        //get the experiment for this user 
        DefaultBizLogic bizLogic = new DefaultBizLogic();

        List userList = (List) bizLogic.retrieve(User.class.getName(), "id",
                sessionDataBean.getUserId().toString());

        User user = null;
        if (userList != null && !userList.isEmpty())
        {
            user = (User) userList.get(0);
        }

        List list = new ArrayList();
        if (user != null)
        {

            list = (List) bizLogic.retrieve(Experiment.class.getName(),
                    "creator", user);
            if (list != null && !list.isEmpty())
            {
                Iterator itExp = list.iterator();                
                List dataList= new ArrayList(); 
                dataList = getProtocolInfo(itExp);
                req.setAttribute(Constants.SPREADSHEET_DATA_LIST,dataList);
            }
        }
    }

    private List getProtocolInfo(Iterator itExp) throws DAOException
    {
        
        List outerList = new ArrayList();

        while (itExp.hasNext())
        {
            Experiment exp = (Experiment) itExp.next();
            
            
            
            Collection protocolColl = exp.getCollectionProtocolCollection();
            Iterator protocolIt = protocolColl.iterator();
            while (protocolIt.hasNext())
            {
                CollectionProtocol protocol = (CollectionProtocol) protocolIt
                        .next();
                Collection evntColl = protocol
                        .getCollectionProtocolEventCollection();
                Iterator evntIt = evntColl.iterator();
                while (evntIt.hasNext())
                {
                    CollectionProtocolEvent event = (CollectionProtocolEvent) evntIt
                            .next();
                    Collection entityMapColl = event.getEntityMapCollection();
                    Iterator entityMapIt = entityMapColl.iterator();
                    while (entityMapIt.hasNext())
                    {
                        EntityMap entityMap = (EntityMap) entityMapIt.next();
                        DefaultBizLogic bizLogic = new DefaultBizLogic();

                        String[] whereColumnNames = {"activityStatus",
                                "entityMap"};
                        String[] whereColumnConditions = {"=", "="};
                        Object[] whereColumnValues = {"Pending", entityMap};

                        List result = bizLogic.retrieve(EventRecords.class
                                .getName(), whereColumnNames,
                                whereColumnConditions, whereColumnValues,
                                Constants.AND_JOIN_CONDITION);
                        if (result != null && !result.isEmpty())
                        {
                            List innerList = new ArrayList();
                            NameValueBean bean = new NameValueBean();
                            //then this is pending event record
                            EventRecords evntRec = (EventRecords) result.get(0);
                            bean.setName(evntRec.getName());
                            String str = getURL(evntRec.getName(), entityMap,
                                    protocol, event,evntRec.getAnimal().getId().toString());
                            if (str != null)
                                bean.setValue(str);
                            else
                                bean.setValue("");
                            innerList.add(0,bean);
                            
                            NameValueBean bean1 = new NameValueBean();
                            bean1.setName(exp.getName());
                            bean1.setValue(exp.getId());
                            innerList.add(bean1);                 
                            
                            NameValueBean bean2 = new NameValueBean();
                            bean2.setName(protocol.getTitle());
                            bean2.setValue(protocol.getId());
                            innerList.add(bean2);      
                            
                            outerList.add(innerList);
                        }
                    }
                }
            }
                        
        }
        //protocolColl        
        return outerList;
        
    }

    private String getURL(String eventRecord, EntityMap entityMap,
            CollectionProtocol protocol, CollectionProtocolEvent event,String animalId)
    {
        if (eventRecord == null)
        {
            return "#";
        }
        else
        {
            if (eventRecord.equalsIgnoreCase(Variables.Microarray))
            {
                return "/caelmir/ApproveMicroarrayAction.do?operation=addOrEdit&eventId="
                        + event.getId()
                        +"&animalId="
                        +animalId
                        +"&pageOf=pageOfApproveMicroarray"                        
                        + "&protocolId="
                        + protocol.getId()
                        + "&entityMapId=" + entityMap.getId() + "";
            }
            else if (eventRecord.equalsIgnoreCase(Variables.Pathology))
            {
                return "/caelmir/ApproveCaseAction.do?operation=addOrEdit&eventId="
                        + event.getId()  + "&animalId="
                        +animalId +   "&pageOf=pageOfApproveCase"+   "&protocolId=" + protocol.getId()
                        + "&entityMapId=" + entityMap.getId() + "";
            }
            else if (eventRecord.equalsIgnoreCase(Variables.Proteomics))
            {
                return "/caelmir/ApproveProteomicsAction.do?operation=addOrEdit&eventId="
                        + event.getId()
                        +"&animalId="
                        +animalId
                        +"&pageOf=pageOfApproveProteomics"  
                        + "&protocolId="
                        + protocol.getId()
                        + "&entityMapId=" + entityMap.getId() + "";
            }
        }
        return null;
    }

}
