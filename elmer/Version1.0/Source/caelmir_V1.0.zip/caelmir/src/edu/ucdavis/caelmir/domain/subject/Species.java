/**
 * 
 */
package edu.ucdavis.caelmir.domain.subject;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import edu.ucdavis.caelmir.actionForm.SpeciesForm;
import edu.ucdavis.caelmir.domain.common.Institution;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;

/**
* 
* @hibernate.class table="CAELMIR_SPECIES"
*/

public class Species extends AbstractDomainObject implements Serializable {


	private static final long serialVersionUID = 1234567890L;


	/** Unique identifier for the species */
	private Long id;

	
	/** Name of the species */
	private String speciesName;
	
	/**Activity status of the genus. Specifies whether this species is active or disabled.*/
    private String activityStatus;

    /**Collection of all the animals which are to be carried out in this species*/
    private Collection animalCollection = new HashSet();

    /**Genus object under which this species is carried out */
    private edu.ucdavis.caelmir.domain.subject.Genus genus;
    
    

    /**
     * @return genus object this species is associated with.
     * @hibernate.many-to-one column="GENUS_ID" class="edu.ucdavis.caelmir.domain.subject.Genus" constrained="true"
     */
	public edu.ucdavis.caelmir.domain.subject.Genus getGenus() {
		return genus;
	}

	public void setGenus(edu.ucdavis.caelmir.domain.subject.Genus genus) {
		this.genus = genus;
	}
	
    
	
	
    /**
	 * @return
	 * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
	 *               unsaved-value="null" generator-class="native"
	 * @hibernate.generator-param name="sequence" value="CAELMIR_SPECIES_SEQ"
	 */
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	/**
	 * @return Returns the speciesName
	 * @hibernate.property name="speciesName" type="string" column="SPECIES_NAME"
	 *                     length="100"
	 */
	public String getSpeciesName() {
		return speciesName;
	}

	public void setSpeciesName(String speciesName) {
		this.speciesName = speciesName;
	}
	/**
     * @return Returns the activityStatus.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     */
	public String getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}


	 /**
   * @return Returns the animalCollection.
   * @hibernate.set name="animalCollection" table="CAELMIR_ANIMAL" cascade="none"
   * inverse="true" lazy="false"
   * @hibernate.collection-key column="SPECIES_ID"
   * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.subject.Animal"
   */
	public Collection getAnimalCollection() {
		return animalCollection;
	}

	public void setAnimalCollection(Collection animalCollection) {
		this.animalCollection = animalCollection;
	}


	public void setAllValues(AbstractActionForm actionForm)	throws AssignDataException {

		SpeciesForm speciesForm = (SpeciesForm) actionForm;
		String operation = speciesForm.getOperation();
        String status = speciesForm.getActivityStatus();
        this.speciesName = speciesForm.getSpeciesName();
   
        if (speciesForm.getGenusId() != null) {
        	Genus genus = new Genus();
        	genus.setSystemIdentifier(new Long(speciesForm.getGenusId()));
        	this.genus = genus;
        }
    
        if (speciesForm.getOperation().equals(Constants.ADD))
        {
            this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
        }
        if (operation != null
                && ((Constants.VIEW).equalsIgnoreCase(operation) || (Constants.EDIT)
                        .equalsIgnoreCase(operation)))
        {
            if (status != null
                    && (Constants.ACTIVITY_STATUS_DISABLED)
                            .equalsIgnoreCase(status))
            {
                     
                this.deleteObject(speciesForm);
                speciesForm.setActivityStatus(null);
            }

        }
        
	}

	
	
	public Long getSystemIdentifier() {
		
		return id;
	}

	/**
	 * Sets an systemIdentifier for the species.
	 * 
	 * @param systemIdentifier
	 *            Unique systemIdentifier to be assigned to the species.
	 * @see #getIdentifier()
	 */
	public void setSystemIdentifier(Long systemIdentifier) {
		this.id = systemIdentifier;

	}

	public Species(AbstractActionForm form) {
		try {
			setAllValues(form);
		} catch (AssignDataException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 */
	public Species() {
		
		// TODO Auto-generated constructor stub
	}
	
	public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Species)
        {
        	Species s = (Species) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(s.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }
    
    
    public void deleteObject(SpeciesForm actionForm)
    {
        this.activityStatus = Constants.ACTIVITY_STATUS_DISABLED;
       
    }     

    
    public static void setSpeciesStatus(Collection speciesColl,String status,Boolean setGenus)
    {
        if(speciesColl != null && !speciesColl.isEmpty())
        {
            Iterator speciesIterator = speciesColl.iterator();
            while(speciesIterator.hasNext())
            {
                Species species = (Species) speciesIterator.next();
                if(status.equalsIgnoreCase(Constants.ACTIVITY_STATUS_DISABLED) && setGenus.booleanValue())
                {
                	species.setActivityStatus(Constants.ACTIVITY_STATUS_DISABLED);
                	species.setGenus(null);
                }
            
            }
        }
    }
    
}
