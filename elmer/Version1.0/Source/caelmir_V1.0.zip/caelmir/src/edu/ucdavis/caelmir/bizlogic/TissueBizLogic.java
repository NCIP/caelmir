/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */

package edu.ucdavis.caelmir.bizlogic;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

public class TissueBizLogic extends DefaultBizLogic
{

    protected void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {
        Tissue tissue = (Tissue) obj;
        
        tissue.setCreatedDate(new Date());
        
        User user = (User) ((List) dao.retrieve(User.class.getName(),
                Constants.ID, sessionDataBean.getUserId())).get(0);
        tissue.setCreator(user);

        Collection slideColl = tissue.getSlideCollection();
        Iterator iterate = slideColl.iterator();
        Set tempSet = new HashSet();
        while (iterate.hasNext())
        {
            Slide slide = (Slide) iterate.next();
            Slide slidefromTable = (Slide) dao.retrieve(Slide.class.getName(),
                    slide.getId());
            tempSet.add(slidefromTable);
            slidefromTable.setTissue(tissue);
        }
        tissue.setSlideCollection(tempSet);
        
        dao.insert(tissue,null,true,false);

    }

    public void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {        
        Tissue tissue = (Tissue) obj;
        Tissue tissueOld = (Tissue)oldObj;
        List list = (List) dao.retrieve(Tissue.class.getName(), Constants.ID, tissue.getSystemIdentifier());
        if (list != null && !list.isEmpty()) {
            tissueOld = (Tissue) list.get(0);
        }
        String[] images = tissue.getImages();
        if (images != null) {
	        for(int i=0;i<images.length;i++) {
	            String id = (String) images[i];
	            Image image = (Image) dao.retrieve(Image.class.getName(),new Long(id));
	            tissue.getImageCollection().add(image);
	        }
        }
        
        Collection oldSlideColl = tissueOld.getSlideCollection();

        Collection slideColl = tissue.getSlideCollection();
        
        Set tempSet = new HashSet();
        Iterator itr = oldSlideColl.iterator();
        while (itr.hasNext()) {
            Slide slide = (Slide) itr.next();
            
            if (!slideColl.contains(slide)) {
                slide.setTissue(null);
                slide.setActivityStatus(Constants.ACTIVITY_STATUS_DISABLED);
                tempSet.add((Slide) slide);
            }
        }
        
        Iterator iterate = slideColl.iterator();
        
        while (iterate.hasNext())
        {
            Slide slide = (Slide) iterate.next();
            Slide slidefromTable = (Slide) dao.retrieve(Slide.class.getName(),
                    slide.getId());
            tempSet.add(slidefromTable);
            slidefromTable.setTissue(tissue);
        }
       // tissue.setSlideCollection(null);
        
      //  dao.update(tissue, null, false, false, false);
        tissue.setSlideCollection(tempSet);
        
        tissueOld.setImageCollection(tissue.getImageCollection());
        tissueOld.setSlideCollection(tempSet);
        tissueOld.setTissueLongName(tissue.getTissueLongName());
        tissueOld.setTissueShortName(tissue.getTissueShortName());
        tissueOld.setCreator(tissue.getCreator());
        dao.update(tissueOld, null, true, false, false);
    }

}
