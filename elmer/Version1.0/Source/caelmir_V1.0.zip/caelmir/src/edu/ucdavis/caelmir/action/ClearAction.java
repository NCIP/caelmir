/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.CaseForm;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;



public class ClearAction extends BaseAction
{
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,HttpServletRequest request,
            HttpServletResponse response) {
        
        HttpSession session= request.getSession();
        CaseForm caseForm =(CaseForm) form;
        String str= "_" + formString(caseForm);
        
        if(session.getAttribute(Constants.TISSUE_LIST+str)!=null)
            session.removeAttribute(Constants.TISSUE_LIST+str);
        
        
        return mapping.findForward(Constants.SUCCESS);
    }
    private String formString(CaseForm caseForm)
    {
        String str ="";
        if(caseForm.getEventId() != null && caseForm.getProtocolId() != null && caseForm.getAnimalId() != null )
            str = caseForm.getEventId()+"_"+ caseForm.getProtocolId() +"_" + caseForm.getAnimalId();
        return str;
    }

}
