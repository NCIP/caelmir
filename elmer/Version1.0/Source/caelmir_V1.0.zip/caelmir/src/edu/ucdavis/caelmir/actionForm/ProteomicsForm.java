
package edu.ucdavis.caelmir.actionForm;

import org.apache.struts.upload.FormFile;

import edu.ucdavis.caelmir.domain.eventRecords.ProteomicsEventRecords;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;

/**
 * @author sujay_narkar
 *
 */
public class ProteomicsForm extends AbstractActionForm {
    /**
     * 
     */
    protected String description;
    /**
     * 
     */
    protected FormFile dataFile;
    /**
     * experiment identifier
     */
    protected String experimentIdentifier;
    
    protected String animalId;
    
    /***/
    private String eventId;
    /***/
    private String protocolId;
    
    protected Long referenceId;
    
private String entityMapId;
    
    public String getEntityMapId()
    {
        return entityMapId;
    }


    
    public void setEntityMapId(String entityMapId)
    {
        this.entityMapId = entityMapId;
    }
    
    private String fileName;
    
    /**
     * @return Returns the fileName.
     */
    public String getFileName()
    {
        return fileName;
    }
    /**
     * @param fileName The fileName to set.
     */
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }
    /**
     * @return Returns the referenceId.
     */
    public Long getReferenceId()
    {
        return referenceId;
    }
    /**
     * @param referenceId The referenceId to set.
     */
    public void setReferenceId(Long referenceId)
    {
        this.referenceId = referenceId;
    }
    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
   public String getEventId()
    {
        return eventId;
    }

    
    public void setEventId(String eventId)
    {
        this.eventId = eventId;
    }

    
    public String getProtocolId()
    {
        return protocolId;
    }

    
    public void setProtocolId(String protocolId)
    {
        this.protocolId = protocolId;
    }
    
    public String getAnimalId() {
		return animalId;
	}

	public void setAnimalId(String animalId) {
		this.animalId = animalId;
	}

	public void reset() {
        
    }
    
    /**
     * Returns the id assigned to form bean.
     * @return the id assigned to form bean.
     */
    public int getFormId() {
        return Constants.PROTEOMICS_FORM_ID;
    }
    /**
     * 
     */
    public void setAllValues(AbstractDomainObject abstractDomain)   {
    	
    	ProteomicsEventRecords proteomics = (ProteomicsEventRecords) abstractDomain;
        if (proteomics.getAnimal() != null) {
            this.animalId = String.valueOf(proteomics.getAnimal().getId());
        }
        this.description = proteomics.getDescription();
        this.referenceId = proteomics.getReferenceId();
        this.fileName = proteomics.getFileName();
        this.id = proteomics.getId().longValue();
    }

    /**
     * @return Returns the description.
     */
    public String getDescription() {
        return description;
    }
    /**
     * @param description The description to set.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return Returns the dataFile.
     */
    public FormFile getDataFile() {
        return dataFile;
    }
    /**
     * @param dataFile The dataFile to set.
     */
    public void setDataFile(FormFile dataFile) {
        this.dataFile = dataFile;
    }
    /**
     * @return Returns the experimentIdentifier.
     */
    public String getExperimentIdentifier() {
        return experimentIdentifier;
    }
    /**
     * @param experimentIdentifier The experimentIdentifier to set.
     */
    public void setExperimentIdentifier(String experimentIdentifier) {
        this.experimentIdentifier = experimentIdentifier;
    }
}

