/**
 * 
 */
package edu.ucdavis.caelmir.bizlogic;

import java.util.List;
import edu.ucdavis.caelmir.domain.subject.Genus;
import edu.ucdavis.caelmir.domain.subject.Species;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author ravinder_kankanala
 *
 */
public class SpeciesBizLogic extends DefaultBizLogic {

	 /**
     * Saves the Species object in the database.
     * @param obj The Species object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOEx
     */ 
	public void insert(Object obj, DAO dao, SessionDataBean sessionDataBean) throws DAOException, UserNotAuthorizedException {
		
		Species species = (Species) obj;
	   
		if(species.getGenus()!= null)
		{
        List list = dao.retrieve(Genus.class.getName(),"id", species.getGenus().getSystemIdentifier());
        Genus genus = null;
        if (list!=null && list.size() != 0)
        {
        	genus = (Genus) list.get(0);
        }
        species.setGenus(genus);
		}
       dao.insert(species, null, true, false);
    }
    
  

	 /**
     * Updates an objects into the database.
     * @param obj The object to be updated into the database.
     * @throws DAOException
     */
    protected void update(DAO dao, Object obj, Object oldObj, SessionDataBean sessionDataBean) throws DAOException, UserNotAuthorizedException
    {
    	Species species = (Species) obj;
    	dao.update(species, null, true, false, false);
    }
}
