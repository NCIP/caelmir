/**
 *<p>Title: AnimalAction Class </p>
 *<p>Description: This class initializes the field and redirect to Add/Edit Animal webpage.</p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.action;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.common.dynamicextensions.domaininterface.EntityInterface;
import edu.common.dynamicextensions.domaininterface.userinterface.ContainerInterface;
import edu.common.dynamicextensions.entitymanager.EntityManager;
import edu.common.dynamicextensions.entitymanager.EntityManagerInterface;
import edu.ucdavis.caelmir.actionForm.MouseForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.domain.subject.Genotype;
import edu.ucdavis.caelmir.domain.subject.Genus;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.domain.subject.Species;
import edu.ucdavis.caelmir.util.CMSClient;
import edu.ucdavis.caelmir.util.CommonUtility;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.cde.CDEManager;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * This class initializes the field and redirect to Add/Edit Animal webpage.
 * @author shital_lawhale
 *
 */
public class AnimalAction extends BaseAction
{

    /**
     * Overrides the execute method of Action class.
     * Sets the various fields in Animal Add/Edit webpage.
     * and checks for the Privileges
     * */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        String operation = request.getParameter(Constants.OPERATION);
        boolean isAccessPresent = true;
        if (operation.equalsIgnoreCase(Constants.ADD))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.ANIMAL_CREATE,
                    Permissions.ANIMAL_CREATE_ACCESS_DENIED);
        }
        else if (operation.equalsIgnoreCase(Constants.EDIT))
        {
            Long id = getId(((MouseForm) form).getSystemIdentifier());
            int accessPresent = 1;

            if (id != null)
                accessPresent = CommonUtility.checkForOtherRole(id.longValue(),
                        request, Permissions.ANIMAL_UPDATE);

            if (accessPresent == 2) //no permission
            {
                request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                        Permissions.ANIMAL_UPDATE_ACCESS_DENIED);
                return mapping
                        .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
            }

            if (accessPresent == 1) //user not present so default role
            {

                isAccessPresent = isAccessPresent(request,
                        Permissions.ANIMAL_UPDATE,
                        Permissions.ANIMAL_UPDATE_ACCESS_DENIED);
            }
        }

        else if (operation.equalsIgnoreCase(Constants.VIEW))
        {
            
            Long id = getId(((MouseForm) form).getSystemIdentifier());
            int accessPresent = 1;

            if (id != null)
                accessPresent = CommonUtility.checkForOtherRole(id.longValue(),
                        request, Permissions.ANIMAL_READ);

            if (accessPresent == 2) //no permission
            {
                request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                        Permissions.ANIMAL_READ_ACCESS_DENIED);
                return mapping
                        .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
            }

            if (accessPresent == 1) //user not present so default role
            {
                isAccessPresent = isAccessPresent(request, Permissions.ANIMAL_READ,
                    Permissions.ANIMAL_READ_ACCESS_DENIED);
            }
        }

        if (!isAccessPresent)
        {
            return mapping.findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
        }
        AbstractBizLogic bizLogic = BizLogicFactory
                .getBizLogic(Constants.ANIMAL_ADD);
        List genotypeList = new ArrayList();
        String forwardTo = ((MouseForm) form).getForwardTo();
        if (forwardTo == null || forwardTo.equalsIgnoreCase(Constants.SUCCESS))
        {
            ((MouseForm) form).setForwardTo(Constants.POST_SAVE_PROCESS);
        }
      /* To retrive the strain URL from the property file */
        Properties prop = new Properties();
        prop.load(new FileInputStream(Variables.caElmirHome
			        + System.getProperty(Constants.FILE_SEPARATOR)
			        + Constants.PROPERTIES_FILE));
		
        String strainURL = (String) prop.get(Constants.STRAIN_URL);
        request.setAttribute(Constants.STRAIN_URL,strainURL);
    
        /* end */
        
        
        genotypeList = getGenotype(form);
        List geneOfInterest = getGeneOfinterest();

        if (operation.equals(Constants.ADD) || operation.equals(Constants.EDIT))
        {
            //Sets the genusList attribute to be used in the Add/Edit Animal Page.
            String sourceObjectName = Genus.class.getName();
            String[] displayNameFields = {Constants.GENUS_NAME};
            String valueField = "id";

            List genusList = bizLogic.getList(sourceObjectName,
                    displayNameFields, valueField, true);
            request.setAttribute(Constants.GENUS_LIST, genusList);

        }

        // Sets the speciesList corresponding genus to be used in the Add/Edit Animal Page.
        List speciesList = new ArrayList();
        String genusID = null;
        genusID = (String) request.getParameter(Constants.GENUS_ID);
        if (genusID == null)
        {
            genusID = ((MouseForm) form).getGenusId();
        }
        ((MouseForm) form).setGenusId(genusID);
        speciesList = getSpecies(genusID);

        if (operation.equals(Constants.VIEW))
            populateViewParameters(request, form);

        request.setAttribute(Constants.GENOTYPE_LIST, genotypeList);

        request.setAttribute(Constants.GENEOFINTEREST_LIST, geneOfInterest);

        request.setAttribute(Constants.OPERATION, operation);

        List backgroundStrainList = CDEManager.getCDEManager()
                .getPermissibleValueList(Constants.CDE_NAME_BACKGROUND_STRAIN,
                        null);
        request.setAttribute(Constants.BACKGROUNDSTRAINLIST,
                backgroundStrainList);

        List strainList = CDEManager.getCDEManager().getPermissibleValueList(
                Constants.CDE_NAME_STRAIN, null);
        request.setAttribute(Constants.STRAINLIST, strainList);

        String pageOf = (String) request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        request.setAttribute(Constants.SPECIES_LIST, speciesList);

        request.setAttribute(Constants.ACTIVITY_STATUS, ((MouseForm) form)
                .getActivityStatus());

        if (operation.equalsIgnoreCase(Constants.EDIT)
                || operation.equalsIgnoreCase(Constants.VIEW))
        {
            checkForCohortData(form, request);
        }
        List eventList = null;
        if (operation.equalsIgnoreCase(Constants.VIEW)) {
	        List mouseList = bizLogic.retrieve(Mouse.class.getName(),"id",new Long(((MouseForm) form).getId()));
	        if (mouseList !=null && mouseList.size() > 0) {
	            eventList = bizLogic.retrieve(EventRecords.class.getName(),"animal",((Mouse) mouseList.get(0)));
	        }
        }
        
                request.setAttribute(Constants.EVENT_RECORDS_LIST,eventList);
        Map map = new HashMap();
           if (eventList != null) {
            Iterator iter = eventList.iterator();
            while (iter.hasNext()) {
                EventRecords eventRecord = (EventRecords) iter.next();
                if (eventRecord.getEntityRecordId() != null) {
                    Long containerId = eventRecord.getEntityMap().getEntityReferenceId();
                    EntityManagerInterface entityManagerInterface = EntityManager.getInstance();
                    
                    ContainerInterface container= entityManagerInterface.getContainerByIdentifier(containerId.toString());
                    EntityInterface entity = container.getEntity();
                    map.put(containerId,entity.getName());
                }
            }
        }
           
        
        request.setAttribute("ContainerMap",map);
        CMSClient cms = new CMSClient();
        String dynamicPath = cms.getDynamicExtensionsLoadURL();
        request.setAttribute(Constants.DYNAMIC_EXTN_URL,dynamicPath);
       
        
        if(operation != null && operation.equalsIgnoreCase(Constants.EDIT))
        {
            String status = checkForStatus(form, request);
            if (status != null && isAccessPresent)
            {
                if (status.equals(Constants.ACTIVITY_STATUS_PUBLISHED)
                        || status.equals(Constants.ACTIVITY_STATUS_CLOSED))
                {
                    request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                            Constants.ANIMAL_CLOSED);
                }
                else if (status.equals(Constants.ACTIVITY_STATUS_DISABLED))
                    request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                            Constants.ANIMAL_DELETE);

                if (!status.equals(Constants.ACTIVITY_STATUS_ACTIVE))
                    return mapping
                            .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
            }
        }
         

        return mapping.findForward(pageOf);
    }

    private Long getId(long id)
    {
        Long identifier = null;
        try
        {
            if (new Long(id) != null)
            {
                if (id != 0)// != "")
                {

                    DefaultBizLogic defaultBizLogic = BizLogicFactory
                            .getDefaultBizLogic();

                    List animalList = defaultBizLogic.retrieve(Mouse.class
                            .getName(), "id", new Long(id));
                    if (animalList != null && !animalList.isEmpty())
                    {
                        Mouse mouse = (Mouse) animalList.get(0);
                        if(mouse.getCohort()!= null && mouse.getCohort().getExperiment() != null && mouse.getCohort().getExperiment().getStudy() !=null )
                        identifier = mouse.getCohort().getExperiment()
                                .getStudy().getId();
                    }
                }
            }
        }
        catch (DAOException e)
        {
        }
        return identifier;

    }

    private void checkForCohortData(ActionForm form, HttpServletRequest request)
            throws DAOException
    {
        MouseForm mouseForm = (MouseForm) form;
        Long systemIdentifier = new Long(mouseForm.getSystemIdentifier());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = defaultBizLogic.retrieve(Mouse.class.getName(), "id",
                systemIdentifier);
        Mouse mouse = null;
        request.setAttribute(Constants.COHORT_DATA_FLAG, new Boolean(false));
        if (list != null && !list.isEmpty())
        {
            mouse = (Mouse) list.get(0);
        }
        if (mouse != null)
        {
            Cohort cohort = mouse.getCohort();
            if (cohort != null)
            {
                request.setAttribute(Constants.COHORT_DATA_FLAG, new Boolean(
                        true));
            }
        }
    }

    private String checkForStatus(ActionForm form, HttpServletRequest request)
            throws Exception
    {
        MouseForm mouseForm = (MouseForm) form;
        Long systemIdentifier = new Long(mouseForm.getSystemIdentifier());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = defaultBizLogic.retrieve(Mouse.class.getName(), "id",
                systemIdentifier);

        Mouse mouse = null;
        if (list != null && !list.isEmpty())
        {
            mouse = (Mouse) list.get(0);
        }
        if (mouse != null)
        {
            Cohort cohort = mouse.getCohort();
            if (cohort != null)
            {
                request.setAttribute(Constants.ACTIVITY_STATUS, cohort
                        .getActivityStatus());
                return cohort.getActivityStatus();
            }
        }
        return mouseForm.getActivityStatus();

    }

    private List getGeneOfinterest() throws Exception
    {
        List geneOfinterest = new ArrayList();
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        String[] colName = new String[1];
        colName[0] = "geneOfInterest";

        geneOfinterest = bizLogic.getList(Mouse.class.getName(), colName,
                colName[0], false);
        List newList = new ArrayList();
        if (geneOfinterest != null && !geneOfinterest.isEmpty())
            for (int i = 0; i < geneOfinterest.size(); i++)
            {
                boolean flag = false;
                NameValueBean str = (NameValueBean) geneOfinterest.get(i);
                for (int j = i + 1; j < geneOfinterest.size(); j++)
                {
                    NameValueBean nameValueBean = (NameValueBean) geneOfinterest
                            .get(j);
                    if (nameValueBean.getName().equals(str.getName()))
                    {
                        flag = true;
                        break;
                    }
                }
                if (!flag)
                    newList.add(str);
            }
        return newList;
    }

    private List getGenotype()
    {
        AbstractBizLogic bizLogic = new DefaultBizLogic();
        String objectName = Genotype.class.getName();

        List genotypeList = new ArrayList();
        try
        {
            List list = bizLogic.retrieve(objectName);
            if (list != null && !list.isEmpty())
                for (int i = 0; i < list.size(); i++)
                {
                    NameValueBean namevalue = new NameValueBean();
                    Genotype genotype = (Genotype) list.get(i);
                    namevalue.setName(genotype.getGeneName());
                    namevalue.setValue(genotype.getId());
                    genotypeList.add(namevalue);
                }
        }
        catch (Exception e)
        {
        }
        return genotypeList;
    }

    /**
     * 
     * @param form MouseForm
     * @return List of associated GeneName 
     * @throws Exception
     */
    private List getGenotype(ActionForm form) throws Exception
    {
        List genotypeList = new ArrayList();

        MouseForm mform = (MouseForm) form;
        String[] displayNameFields = {"geneName"};
        String[] whereColumnName = {"id"};
        String[] whereColumnCondition = {"="};
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (mform.getGenotypeList() != null)
            for (int i = 0; i < mform.getGenotypeList().length; i++)
            {
                Object[] whereColumnValue = {mform.getGenotypeList()[i]};
                List list = bizLogic.getList(Genotype.class.getName(),
                        displayNameFields, "id", whereColumnName,
                        whereColumnCondition, whereColumnValue, null, null,
                        false);
                if (list.size() > 1)
                    genotypeList.add(list.get(1));
            }
        return genotypeList;
    }

    /**
     * Sets request parameters used to display on webpage in "view" operation.
     * @param request To set attributes
     * @param form to get some fields
     * @throws DAOException 
     */
    private void populateViewParameters(HttpServletRequest request,
            ActionForm form) throws DAOException
    {
        MouseForm mform = (MouseForm) form;
        Long systemIdentifier = new Long(mform.getId());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = defaultBizLogic.retrieve(Mouse.class.getName(), "id",
                systemIdentifier);
        List genusList = defaultBizLogic.retrieve(Genus.class.getName(), "id",
                mform.getGenusId());
        List speciesList = defaultBizLogic.retrieve(Species.class.getName(),
                "id", mform.getSpeciesId());

        Mouse mouse = null;

        if (list != null && !list.isEmpty())
        {
            mouse = (Mouse) list.get(0);
        }

        if (mouse != null)
        {
            Collection collection = mouse.getGenotypeCollection();
            List genotypeList = new ArrayList();
            if (collection != null)
            {
                Iterator genotypeIterator = collection.iterator();
                while (genotypeIterator.hasNext())
                {
                    Genotype genotype = (Genotype) genotypeIterator.next();
                    genotypeList.add(genotype.getGeneName());
                }
            }
            request.setAttribute(Constants.GENOTYPE_NAME_LIST, genotypeList);

            // get Cohort
            Cohort cohort = mouse.getCohort();
            if (cohort != null)
            {
                request.setAttribute("Cohort", cohort.getName());
                request.setAttribute("cohortId", cohort.getId().toString());
            }
        }

        Genus genus = null;
        if (genusList != null && !genusList.isEmpty())
        {
            genus = (Genus) genusList.get(0);
        }

        if (genus != null)
        {
            request.setAttribute(Constants.GENUS, genus.getGenusName());

        }

        Species species = null;
        if (speciesList != null && !speciesList.isEmpty())
        {
            species = (Species) speciesList.get(0);
        }

        if (species != null)
        {
            request.setAttribute(Constants.SPECIES, species.getSpeciesName());

        }

        boolean editPermission = PrivilegeUtil.checkPrivilege(this.getClass(),
                Animal.class.getName(), request.getSession(),
                Permissions.ANIMAL_UPDATE);
        if (!editPermission)
        {
            request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(false));
        }
        else
        {
            request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(true));
        }
    }

    /**
     * 
     * @param genusID Identifier of the Genus
     * @return the list of the species which are declared in given genus.
     */
    private List getSpecies(String genusID)
    {
        AbstractBizLogic bizLogic = new DefaultBizLogic();
        List genusList = null;
        if (genusID != null)
        {
            try
            {
                genusList = bizLogic.retrieve(Genus.class.getName(), "id",
                        genusID);
            }
            catch (DAOException e1)
            {
                e1.printStackTrace();
            }
        }

        List speciesList = new ArrayList();
        if (genusList != null && genusList.size() != 0)
        {
            Genus genus = (Genus) genusList.get(0);
            Collection speciesColl = genus.getSpeciesCollection();
            Iterator iter = speciesColl.iterator();
            while (iter.hasNext())
            {

                Species specObj = (Species) iter.next();
                try
                {
                    List sList = bizLogic.retrieve(Species.class.getName(),
                            "id", specObj.getId());

                    Species species = null;
                    if (sList != null && sList.size() != 0)
                    {
                        species = (Species) sList.get(0);

                        NameValueBean namevalue = new NameValueBean();
                        namevalue.setName(species.getSpeciesName());
                        namevalue.setValue(species.getId());
                        speciesList.add(namevalue);
                    }
                }
                catch (DAOException e2)
                {
                    e2.printStackTrace();
                }
            }
        }
        return speciesList;

    }

    /**
     * Checks whether access is present to the passed privilege 
     * @param request To get the session
     * @param privilege Contains  
     * @param accessDeniedMessage Contains access denied message
     * @return 
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                Animal.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

}
