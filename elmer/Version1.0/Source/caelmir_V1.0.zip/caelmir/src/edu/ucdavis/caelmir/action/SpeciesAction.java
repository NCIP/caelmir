/**
 * 
 */
package edu.ucdavis.caelmir.action;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.SpeciesForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.domain.subject.Genus;
import edu.ucdavis.caelmir.domain.subject.Species;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author ravinder_kankanala
 *
 */
public class SpeciesAction extends BaseAction {

	 public ActionForward executeAction(ActionMapping mapping, ActionForm form,
	            HttpServletRequest request, HttpServletResponse response)
	            throws Exception
	 {
		    String pageOf;
		    boolean isAccessPresent = true;
		    
	    	SpeciesForm  speciesForm= (SpeciesForm) form;
	    	String operation = request.getParameter(Constants.OPERATION);
	        request.setAttribute(Constants.OPERATION, operation);
	        
	        pageOf = request.getParameter(Constants.PAGEOF);
	        request.setAttribute(Constants.PAGEOF, pageOf);
	        
	        if (operation.equalsIgnoreCase(Constants.ADD))
	        {
	            isAccessPresent = isAccessPresent(request,
	                    Permissions.SPECIES_CREATE,
	                    Permissions.SPECIES_CREATE_ACCESS_DENIED);
	        }
	        else if (operation.equalsIgnoreCase(Constants.EDIT))
	        {
	            isAccessPresent = isAccessPresent(request,
	                    Permissions.SPECIES_UPDATE,
	                    Permissions.SPECIES_UPDATE_ACCESS_DENIED);
	          
	        }
	        else if (operation.equalsIgnoreCase(Constants.VIEW))
	        {
	            isAccessPresent = isAccessPresent(request,
	                    Permissions.SPECIES_READ,
	                    Permissions.SPECIES_READ_ACCESS_DENIED);
	        }
	        if (!isAccessPresent)
	        {
	            return mapping
	                    .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
	        }
	  	
	        if(!operation.equals(Constants.VIEW))
	        {
	            if (isAccessPresent(request, Permissions.SPECIES_DELETE,
	                    Permissions.SPECIES_DELETE_ACCESS_DENIED))
	            {
	                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
	                        true));
	            }
	            else
	            {
	                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
	                        false));
	            }
	        }
	    
	        //check for edit privelege.
	        if(operation.equals(Constants.VIEW))
	         {
	            boolean editPermission = PrivilegeUtil.checkPrivilege(this.getClass(),
	                    Species.class.getName(), request.getSession(),
	                    Permissions.SPECIES_UPDATE);
	            if (!editPermission)
	            {
	                request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(false));
	            }
	            else
	            {
	                request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(true));
	            }

	         }
	        
	        
	        
		        
	        if (operation.equals(Constants.ADD)
                    || operation.equals(Constants.EDIT))
            {
            AbstractBizLogic bizLogic = BizLogicFactory.getBizLogic(Constants.SPECIES_FORM_ID);
            //Sets the genusList attribute to be used in the Add/Edit Species Page.
            String sourceObjectName = Genus.class.getName();
            String[] displayNameFields = {Constants.GENUS_NAME};
            String valueField = "id";

            List genusList = bizLogic.getList(sourceObjectName, displayNameFields, valueField, true);
            request.setAttribute(Constants.GENUS_LIST, genusList);
            }
	        else
	        {
            	if(operation.equals(Constants.VIEW))
                populateViewParameters(request,form);  
	 		}
	        if (operation.equals(Constants.EDIT)|| operation.equals(Constants.VIEW))
	        {
	        	
	        	 checkForAnimalData(form,request); 
	        }
	        request.setAttribute(Constants.ACTIVITY_STATUS ,speciesForm.getActivityStatus());
	        return mapping.findForward(pageOf);
	     } 
	
   
		
		/**
	     * This method is used to populate the request parameters those are needed for view mode page.
	     * @param request Request to set the required parameters.
	     * @param form StudyForm to populate the action form attributes.
	     * @throws DAOException
	     */
	    private void populateViewParameters(HttpServletRequest request,
	            ActionForm form) throws DAOException
	    {
		        SpeciesForm actionForm = (SpeciesForm) form;
		        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
		       
		         String genusId = String.valueOf(actionForm.getGenusId());
		        
		        List genusList = defaultBizLogic.retrieve(Genus.class.getName(),"id",genusId);
		        Genus genus = null;
		        if (genusList != null && !genusList.isEmpty()) 
		        {
		        	genus = (Genus) genusList.get(0);
		        }
		        if (genus != null) 
		        {
		            request.setAttribute(Constants.GENUS,genus.getGenusName());
		        }        
         } 
	    
	    

		private void checkForAnimalData(ActionForm form, HttpServletRequest request) throws DAOException
		{
		    
		    SpeciesForm speciesForm = (SpeciesForm) form;
		    Long systemIdentifier = new Long(speciesForm.getId());        
		    DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();        
		    List list = defaultBizLogic.retrieve(Species.class.getName(),"id",systemIdentifier);
		    Species species = null;
		    
		     request.setAttribute(Constants.ANIMAL_DATA_FLAG,new Boolean(false));
		     
		     if (list != null && !list.isEmpty()) 
		     {
		    	 species = (Species) list.get(0);
		     }
		      
		     if (species != null) 
		     {             
		            Collection animalColl= species.getAnimalCollection();
		            if(animalColl != null && !animalColl.isEmpty())
		             {
		                    request.setAttribute(Constants.ANIMAL_DATA_FLAG,new Boolean(true));
		             }
              }
		}
		
		
		/**
		 * This method is used to check the given privilege on given object.
		 * @param request To get the session data bean
		 * @param privilege Name of the privilege
		 * @param accessDeniedMessage The message to be displayed if the access is not present.
		 * @return boolean true if the access is present otherwise false.
		 */
		private boolean isAccessPresent(HttpServletRequest request,
		        String privilege, String accessDeniedMessage)
		{
		    boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
		            Model.class.getName(), request.getSession(), privilege);
		    if (!isAccessPresent)
		    {
		        request.setAttribute(Constants.STATUS_MESSAGE_KEY,
		                accessDeniedMessage);
		    }
		    return isAccessPresent;
		}
		
		
		
	    
}    
