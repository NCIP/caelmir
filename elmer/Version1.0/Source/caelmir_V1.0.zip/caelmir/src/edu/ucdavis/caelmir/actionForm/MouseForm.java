/**
 *<p>Title:AnimalForm Class </p>
 *<p>Description: This class Class is used to encapsulate all the request parameters passed </p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.actionForm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.subject.Genotype;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Utility;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;
import edu.wustl.common.util.logger.Logger;

/**
 * This class Class is used to encapsulate all the request parameters passed.
 * @author shital_lawhale
 *
 */
public class MouseForm extends AbstractActionForm
{

    /**animal(mouse) identifier**/
   // private Long id;

  

    /**Unique identifier for animal within colony management system **/
    private String animalColonyReference;
    
    /**animal number **/
    private String animalNumber;

    /**baseStrain of animal**/
    private String backgroundStrain;

    /**strain of animal**/
    private String strain;

    /**birth-date of animal**/
    private String birthDate;

    /**geneOfInterest of animal**/
    private String geneOfInterest;

   

    /**sex of animal**/
    private Character sex;

    /**animal length**/
    private Double length;

    /**animal weight **/
    private Double weight;

    /**activityStatus of animal **/
    private String activityStatus;
    
    private String[] genotypeList;

    /**genus name of the Animal **/
    private String genusId;
    
    /**species name of the Animal **/
    private String speciesId;
    
    
    /**
	 * @return Returns the genusId.
	 */
	public String getGenusId() {
		return genusId;
	}

	/**
	 * @param genusId The genusId to set.
	 */
	public void setGenusId(String genusId) {
		this.genusId = genusId;
	}

	 /**
	 * @return Returns the speciesId.
	 */
	public String getSpeciesId() {
		return speciesId;
	}

	/**
	 * @param genusId The speciesId to set.
	 */
	public void setSpeciesId(String speciesId) {
		this.speciesId = speciesId;
	}


	public String[] getGenotypeList()
    {
        return genotypeList;
    }

    
    public void setGenotypeList(String[] genotypeList)
    {
        this.genotypeList = genotypeList;
    }

  
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }

   
    /**     
     * @return strain of animal
     */
    public String getStrain()
    {
        return strain;
    }

    /**
     * set the strain of animal
     * @param strain String representing strain of animal
     */
    public void setStrain(String strain)
    {
        this.strain = strain;
    }

    /**
     * @return sex of animal
     */
    public Character getSex()
    {
        return sex;
    }

    /**     
     * @param sex character representing sex of animal
     */
    public void setSex(Character sex)
    {
        this.sex = sex;
    }

    /**
     * @return activityStatus of animal
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    /**
     * @param activityStatus String representing activityStatus of animal  
     * @see #activityStatus     
     */
    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * Resets the values of all the fields.
     * Is called by the overridden reset method defined in ActionForm.  
     */
    protected void reset()
    {
    }

    /**
     * @return animal form Identifier
     */
    public int getFormId()
    {
        int formId = Constants.ANIMAL_ADD;
        return formId;
    }

    /**
     * @return geneOfInterest of animal
     */
    public String getGeneOfInterest()
    {
        return geneOfInterest;
    }


    /**
     * @return animalColonyReference of animal
     */
    public String getAnimalColonyReference()
    {
        return animalColonyReference;
    }

    /**
     * @param animalColonyReference String representing Unique identifier for animal within colony management system
     */
    public void setAnimalColonyReference(String animalColonyReference)
    {
        this.animalColonyReference = animalColonyReference;
    }

   
    /**
     * @return length of animal
     */
    public Double getLength()
    {
        return length;
    }

    /**
     * @param length String representing length of animal
     */
    public void setLength(Double length)
    {
        this.length = length;
    }

    /**
     * @return weight of animal
     */
    public Double getWeight()
    {
        return weight;
    }

    /**
     * @param weight 
     * @see #getWeight()
     */
    public void setWeight(Double weight)
    {
        this.weight = weight;
    }

    /**
     * @param geneOfInterest String representing geneOfInterest of animal
     */
    public void setGeneOfInterest(String geneOfInterest)
    {
        this.geneOfInterest = geneOfInterest;
    }

   
    /**
     * @param birthDate of animal
     */
    public void setBirthDate(String birthDate)
    {
        this.birthDate = birthDate;
    }

    /**
     * @return birthDate of animal
     */
    public String getBirthDate()
    {
        return birthDate;
    }

    public void setAddNewObjectIdentifier(String addNewFor, Long addObjectIdentifier)
    {
            
        if(addNewFor.equals("genotype"))
        {
            Long ID=new Long(addObjectIdentifier.longValue());
            String str= ID.toString();  
            List list = new ArrayList();
            
            int len= 1;
            if (genotypeList != null)
            {
                for(int i=0;i<genotypeList.length;i++)
                    list.add(genotypeList[i]);
                len=genotypeList.length + 1;
            }                           
            list.add(str);
            String [] genotypeList = new String[len];                           
            for(int i=0;i<len;i++)
                genotypeList[i]=(String)list.get(i);              
            setGenotypeList(genotypeList);
        }   
        
    }
    
    
    /**Overrides the validate method of ActionForm.**/
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();

        try
        {
         /*   if (validator.isEmpty(genus.toString()))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("animal.genus")));
            }*/
          
            if (validator.isEmpty(animalNumber))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("animal.animalNumber")));
            }
            if (validator.isEmpty(backgroundStrain))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("animal.backgroundStrain")));
            }
            if (backgroundStrain.equals("-1"))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("animal.backgroundStrain")));
            }
            /*if (validator.isEmpty(geneOfInterest))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("animal.geneOfInterest")));
            }*/

            if (!validator.checkDate(birthDate))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.date.format", ApplicationProperties
                                .getValue("animal.birthDate")));
            }/*
            if (validator.isEmpty(genotype))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("animal.genotype")));
            }
            if (validator.isEmpty(strain))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("animal.strain")));
            }
            if (!validator.isDouble(length.toString()))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.number", ApplicationProperties
                                .getValue("animal.length")));
            }
            if (!validator.isDouble(weight.toString()))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.number", ApplicationProperties
                                .getValue("animal.weight")));
            }*/

        }
        catch (Exception excp)
        {
            Logger.out.error(excp.getMessage(), excp);
        }
        return errors;
    }

    /**
     * Copies the data from an AbstractDomain object to a AimalForm object.
     * @param abstractDomain An AbstractDomain object of animal.  
     */
    public void setAllValues(AbstractDomainObject abstractDomain)
    {

        Mouse animal = (Mouse) abstractDomain;

        this.activityStatus = animal.getActivityStatus();
        //this.animalColonyReference = animal.getAnimalColonyReference();
        this.backgroundStrain = animal.getBackgroundStrain();
        this.birthDate = Utility.parseDateToString(animal.getBirthDate(),
                Constants.DATE_PATTERN_MM_DD_YYYY);
        this.geneOfInterest = animal.getGeneOfInterest();
      //  this.genotype = animal.getGenotype();
       if( animal.getLength() != null)
        this.length = animal.getLength();
        this.sex = animal.getSex();
        this.strain = animal.getStrain();
        this.animalNumber = animal.getAnimalNumber();
        this.weight = animal.getWeight();
      //  this.id = animal.getId();
        this.id = animal.getId().longValue();
       // this.animalColonyReference =  animal.getAnimalColonyReference();
        
        if (animal.getGenus() != null) {
        this.genusId = animal.getGenus().getId().toString();
        }
        
        if (animal.getSpecies() != null) {
        this.speciesId = animal.getSpecies().getId().toString();        
        } 
        
        Iterator iterate;
        Collection Coll;                
        //set user colln
        Coll= animal.getGenotypeCollection();
        String xx;
        int i=0;
        if(Coll != null && Coll.size() != 0  )
        {       
            
            String [] genotypeList = new String[Coll.size()];
            iterate= Coll.iterator();                               
            while(iterate.hasNext())
            {
                Genotype genotypeObj = (Genotype) iterate.next();
                  xx=genotypeObj.getId().toString();
                  genotypeList[i++]=xx;
            }
            setGenotypeList(genotypeList);
        }    

    }

    /**    
     * @return BackgroundStrain of animal
     */
    public String getBackgroundStrain()
    {
        return backgroundStrain;
    }


    /**
     * set the Background of animal
     * @param Background String representing baseStrain of animal
     */
    
    public void setBackgroundStrain(String backgroundStrain)
    {
        this.backgroundStrain = backgroundStrain;
    }

    
    /**    
     * @return number of animal
     */
	public String getAnimalNumber() {
		return animalNumber;
	}


	public void setAnimalNumber(String animalNumber) {
		this.animalNumber = animalNumber;
	}

   
 
}