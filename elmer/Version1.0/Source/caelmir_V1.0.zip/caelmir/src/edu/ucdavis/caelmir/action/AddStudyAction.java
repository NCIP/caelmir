
package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.ExperimentForm;
import edu.ucdavis.caelmir.actionForm.StudyForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.Institution;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.SpecimenProtocol;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.util.ModelInformationUtility;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PreferenceManager;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Utility;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.cde.CDEManager;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author sujay_narkar
 */
public class AddStudyAction extends BaseAction
{

    /**This class is responsible to handle all the requests related to the study object. It handles all the scenarios 
     * viz. "add" "edit" "view" mode for the study object. It populates all the required parameters that are needed 
     * to successfully access the study object. 
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     * 
     * */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)

    {
        String pageOf;
        StudyForm studyForm = (StudyForm) form;
        String operation = (String) request.getParameter(Constants.OPERATION);
        try
        {
            if (operation != null)
            {
                request.setAttribute(Constants.OPERATION, operation);
            }
            else
            {
                operation = Constants.ADD;
            }
            boolean isAccessPresent = true;
            if (operation.equalsIgnoreCase(Constants.ADD))
            {
                isAccessPresent = isAccessPresent(request,
                        Permissions.STUDY_CREATE,
                        Permissions.STUDY_CREATE_ACCESS_DENIED);
            }
            else if (operation.equalsIgnoreCase(Constants.EDIT))
            {
                isAccessPresent = isAccessPresent(request,
                        Permissions.STUDY_UPDATE,
                        Permissions.STUDY_UPDATE_ACCESS_DENIED);
                if (isAccessPresent)
                {
                    String status = studyForm.getActivityStatus();
                    if (status.equals(Constants.ACTIVITY_STATUS_PUBLISHED)
                            || status.equals(Constants.ACTIVITY_STATUS_CLOSED))
                    {
                        request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                                Constants.STUDY_CLOSED);
                        return mapping
                                .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
                    }
                }

            }
            else if (operation.equalsIgnoreCase(Constants.VIEW))
            {
                isAccessPresent = isAccessPresent(request,
                        Permissions.STUDY_READ,
                        Permissions.STUDY_READ_ACCESS_DENIED);
            }
            if (!isAccessPresent)
            {
                return mapping
                        .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
            }

            pageOf = request.getParameter(Constants.PAGEOF);
            request.setAttribute(Constants.PAGEOF, pageOf);

            List userList = new ArrayList();
            List usergroupList = new ArrayList();

            if (operation.equals(Constants.ADD))
            {
                pageOf = Constants.PAGE_OF_CREATE_STUDY;

            }
            if (operation.equals(Constants.ADD)
                    || operation.equals(Constants.EDIT))
            {
                String path = "postSaveProcess";
                studyForm.setForwardTo(path);

                /* added by Ravinder */

                AbstractBizLogic bizLogic = BizLogicFactory
                        .getBizLogic(Constants.STUDY_FORM_ID);

                //Sets the modelList attribute to be used in the Add/Edit User Page.
                String sourceObjectName = Model.class.getName();
                String[] displayNameFields = {Constants.MODEL_NAME};
                String valueField = "id";

                List modelList = bizLogic.getList(sourceObjectName,
                        displayNameFields, valueField, true);
                request.setAttribute(Constants.MODEL_LIST, modelList);

                /* end */

                /*  request.setAttribute(Constants.GENO_TYPE_LIST, getGenotypeList(
                 form, modelList));
                 List mainStrainList = getMainStrainList(form);
                 request
                 .setAttribute(Constants.MAIN_STRAIN_LIST,
                 mainStrainList);
                 request.setAttribute(Constants.ACTUAL_STRAIN_LIST,
                 getActualStrainList(form, mainStrainList));*/
                checkCloseDeletePrivilege(request, form, Study.class.getName(),
                        Permissions.STUDY_DELETE);

            }

            else
            {
                if (operation.equalsIgnoreCase(Constants.VIEW))
                    populateViewParameters(request, form);
            }

            if (operation != null
                    && (operation.equalsIgnoreCase(Constants.EDIT) || operation
                            .equalsIgnoreCase(Constants.VIEW)))
            {

                Long systemIdentifier = new Long(studyForm
                        .getId());
                DefaultBizLogic defaultBizLogic = BizLogicFactory
                        .getDefaultBizLogic();
                List list = defaultBizLogic.retrieve(Study.class.getName(),
                        Constants.ID, systemIdentifier);
                Study study = null;
                if (list != null && !list.isEmpty())
                {
                    study = (Study) list.get(0);
                }
                User piUser = study.getPrimaryInvestigator();
                if (piUser != null)
                {
                    request
                            .setAttribute(Constants.PRIMARY_INVESTIGATOR,
                                    piUser.getLastName()
                                            + Constants.COMMA_SEPARATOR
                                            + piUser.getFirstName());
                }
                checkForExpData(form, request);

            }
            boolean flag = checkForAddNew(form);
            if (flag || operation.equals(Constants.EDIT)
                    || operation.equals(Constants.ADD))
            {
                userList = getSelectedUsers(form, request);
                usergroupList = getSelectedGroup(form);
                request.setAttribute(Constants.PROTOCOL_LIST,
                        getObjectListForProtocol(form, CollectionProtocol.class
                                .getName()));
            }

            if (operation != null
                    && (operation.equalsIgnoreCase(Constants.EDIT) || operation
                            .equalsIgnoreCase(Constants.ADD)))
            {
                checkCreatePermission(form, request);
            }
            request.setAttribute(Constants.USERLIST, userList);
            request.setAttribute(Constants.USER_GROUP_LIST, usergroupList);

        }
        catch (DAOException daoException)
        {
            return mapping.findForward(new String(Constants.FAILURE));

        }
        request.setAttribute(Constants.ACTIVITY_STATUS, studyForm
                .getActivityStatus());
        return mapping.findForward(pageOf);

    }

    /**
     * This method is used to check whether the logged in user has the close and delete privilege on the object that 
     * is specified as an argument.
     * @param request To get the session data bean
     * @param form  To populate the privilege related parameters.
     * @param objectName Object name of the object that is to be retrieved.
     * @param deletePrivilege Name of the privilege.
     * @throws DAOException Exception that is thrown from the biz logic layer.
     */
    private void checkCloseDeletePrivilege(HttpServletRequest request,
            ActionForm form, String objectName, String deletePrivilege)
            throws DAOException
    {
        StudyForm studyForm = (StudyForm) form;
        long id = studyForm.getId();
        Long currentUserId = (Long) ((SessionDataBean) request.getSession()
                .getAttribute(Constants.SESSION_DATA)).getUserId();
        if (new Long(id) != null)
        {
            DefaultBizLogic defaultBizLogic = BizLogicFactory
                    .getDefaultBizLogic();
            List studyList = defaultBizLogic.retrieve(objectName, Constants.ID,
                    new Long(id));
            if (studyList != null && !studyList.isEmpty())
            {
                Study study = (Study) studyList.get(0);
                User user = study.getPrimaryInvestigator();
                if (user != null)
                {
                    long pi = user.getId().longValue();
                    if (new Long(pi).equals(currentUserId))
                    {
                        request.setAttribute(Constants.CLOSE_PRIVILEGE,
                                new Boolean(true));
                    }
                    else
                    {
                        request.setAttribute(Constants.CLOSE_PRIVILEGE,
                                new Boolean(false));
                    }
                    if (isAccessPresent(request, deletePrivilege,
                            deletePrivilege + "_ACCESS_DENIED"))
                    {
                        request.setAttribute(Constants.DELETE_PRIVILEGE,
                                new Boolean(true));
                    }
                    else
                    {
                        request.setAttribute(Constants.DELETE_PRIVILEGE,
                                new Boolean(false));
                    }
                }
            }

        }

    }

    /**
     * This method is used to check the given privilege on given object.
     * @param request To get the session data bean
     * @param privilege Name of the privilege
     * @param accessDeniedMessage The message to be displayed if the access is not present.
     * @return boolean true if the access is present otherwise false.
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                Study.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

    /**
     * This method is used to populate the request parameters those are needed for view mode page.
     * @param request Request to set the required parameters.
     * @param form StudyForm to populate the action form attributes.
     * @throws DAOException
     */
    private void populateViewParameters(HttpServletRequest request,
            ActionForm form) throws DAOException
    {
        StudyForm actionForm = (StudyForm) form;
        Long userId = ((SessionDataBean) request.getSession().getAttribute(
                Constants.SESSION_DATA)).getUserId();
        Long systemIdentifier = new Long(actionForm.getId());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();

        /* added by Ravinder */
        String modelId = String.valueOf(actionForm.getModelId());

        List modelList = defaultBizLogic.retrieve(Model.class.getName(), "id",
                modelId);
        Model model = null;
        if (modelList != null && !modelList.isEmpty())
        {
            model = (Model) modelList.get(0);
        }

        if (model != null)
        {
            request.setAttribute(Constants.MODEL, model.getModelName());
            request.setAttribute(Constants.MODEL_DESRCIPTION_URL, model
                    .getModelDescriptionURL());
        }

        /* end  */

        List list = defaultBizLogic.retrieve(Study.class.getName(),
                Constants.ID, systemIdentifier);
        Study study = null;
        if (list != null && !list.isEmpty())
        {
            study = (Study) list.get(0);
        }

        if (study != null)
        {
            //            request.setAttribute(Constants.MAIN_STRAIN_VALUE, study
            //                    .getStrain());
            //            request.setAttribute(Constants.ACTUAL_STRAIN_VALUE, study
            //                    .getActualStrain());
            //            request
            //                    .setAttribute(Constants.GENO_TYPE_VALUE, study
            //                            .getGenotype());
            //request.setAttribute("modelId",study.getModelId());
            //            List modelList = getModelList(form);
            //            if (modelList != null && !modelList.isEmpty())
            //            {
            //                for (int i = 0; i < modelList.size(); i++)
            //                {
            //                    NameValueBean nameValueBean = (NameValueBean) modelList
            //                            .get(i);
            //                    if (nameValueBean.getValue().equalsIgnoreCase(
            //                            study.getModelId().toString()))
            //                    {
            //                        request.setAttribute(Constants.MODEL_NAME,
            //                                nameValueBean.getName());
            //                        break;
            //                    }
            //                }
            //            }
            Collection collection = study.getCollectionProtocolCollection();
            List protocolList = new ArrayList();
            if (collection != null)
            {
                Iterator protocolIterator = collection.iterator();
                while (protocolIterator.hasNext())
                {
                    CollectionProtocol protocol = (CollectionProtocol) protocolIterator
                            .next();
                    NameValueBean bean = new NameValueBean();
                    bean.setName(protocol.getTitle());
                    bean.setValue(protocol.getId().toString());
                    protocolList.add(bean);
                    
                }
            }
            request.setAttribute(Constants.PROTOCOL_NAME_LIST, protocolList);

            List userList = new ArrayList();
            Collection studyUserCollection = study.getUserCollection();
            if (studyUserCollection != null)
            {
                Iterator studyUserIterator = studyUserCollection.iterator();
                while (studyUserIterator.hasNext())
                {
                    User user = (User) studyUserIterator.next();
                    String userName = user.getLastName() + ","
                            + user.getFirstName();
                    userList.add(userName);

                }
            }
            request.setAttribute(Constants.USER_NAME_LIST, userList);

            List userGroupList = new ArrayList();
            Collection userGroupCollection = study.getUserGroupCollection();
            if (userGroupCollection != null)
            {
                Iterator userGroupIterator = userGroupCollection.iterator();
                while (userGroupIterator.hasNext())
                {
                    UserGroup userGroup = (UserGroup) userGroupIterator.next();
                    userGroupList.add(userGroup.getName());
                }
            }
            request.setAttribute(Constants.USER_GROUP_NAME_LIST, userGroupList);

            //get experiment name , start,stop date and status.
            List experimentList = new ArrayList();

            Collection experimentColl = study.getExperimentCollection();
            if (experimentColl != null && !experimentColl.isEmpty())
            {
                Iterator expIterator = experimentColl.iterator();
                while (expIterator.hasNext())
                {
                    Experiment exp = (Experiment) expIterator.next();
                    List experimentData = new ArrayList();
                    experimentData.add(exp.getName());
                    experimentData.add(Utility.parseDateToString(study
                            .getInvestigationStartDate(),
                            Constants.DATE_PATTERN_MM_DD_YYYY));
                    experimentData.add(Utility.parseDateToString(study
                            .getInvestigationStopDate(),
                            Constants.DATE_PATTERN_MM_DD_YYYY));
                    experimentData.add(exp.getActivityStatus());
                    experimentData.add(exp.getId().toString());
                    experimentList.add(experimentData);
                }
            }
            request.setAttribute(Constants.EXPERIMENT_LIST, experimentList);
            // request.setAttribute(Constants.MODEL_URL,study.getModelDescriptionURL());
        }

        boolean editPermission = PrivilegeUtil.checkPrivilege(this.getClass(),
                Study.class.getName(), request.getSession(),
                Permissions.STUDY_UPDATE);
        if (!editPermission)
        {
            request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(false));
        }
        else
        {
            request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(true));
        }

        if (study.getActivityStatus().equalsIgnoreCase(
                Constants.ACTIVITY_STATUS_CLOSED)
                && study.getPrimaryInvestigator().getId().equals(userId))
        {
            request
                    .setAttribute(Constants.PUBLISH_PRIVILEGE,
                            new Boolean(true));
        }
        else
        {
            request.setAttribute(Constants.PUBLISH_PRIVILEGE,
                    new Boolean(false));
        }
    }

    /**
     * This method fetches the list of the actual strain values.
     * @param form action form 
     * @param mainStrainList main strain list from which actual strain list is to be built.
     * @return
     */
    private List getActualStrainList(ActionForm form, List mainStrainList)
    {
        return new ModelInformationUtility().getActualStrainNameValuePairs();
    }

    /**
     * This method is used to get the list of main strain values.
     * @param form action form for study.
     * @return list of main strain values.
     */
    private List getMainStrainList(ActionForm form)
    {
        return new ModelInformationUtility().getMainStrainNameValuePairs();
    }

    /**
     * This method is used to get the list of genotype values.
     * @param form action form for study.
     * @return list of genotype values.
     */
    private List getGenotypeList(ActionForm form, List modelList)
    {
        return new ModelInformationUtility().getGenotypeNameValuePairs();
    }

    /**
     * This method is used to get the list of model values.
     * @param form action form for study.
     * @return list of main model values.
     */
    private List getModelList(ActionForm form)
    {
        return new ModelInformationUtility().getModelNameValuePairs();
    }

    /**This method is used to get the list of objects of given type Action form is used to get the 
     * appropriate biz logic factory.
     * Returns tg mouse list
     * @param form action form 
     * @return List of NameValueBean objects 
     * @throws DAOException
     */
    public List getObjectList(ActionForm form, String objectName)
            throws DAOException
    {

        AbstractActionForm abstractForm = (AbstractActionForm) form;
        AbstractBizLogic bizLogic = BizLogicFactory.getBizLogic(abstractForm
                .getFormId());

        String sourceObjectName = objectName;
        String[] displayNameFields = new String[1];
        displayNameFields[0] = Constants.NAME;
        String valueField = Constants.ID;
        boolean isToExcludeDisabled = false;

        List objectList = bizLogic.getList(sourceObjectName, displayNameFields,
                valueField, isToExcludeDisabled);
        if (objectList != null && objectList.size() > 0)
        {
            objectList.remove(0);
        }
        return objectList;

    }

    /**This method is used to get the list of objects of given type Action form is used to get the 
     * appropriate biz logic factory.
     * Returns tg mouse list
     * @param form action form 
     * @return List of NameValueBean objects 
     * @throws DAOException
     */
    public List getObjectListForProtocol(ActionForm form, String objectName)
            throws DAOException
    {

        StudyForm sform = (StudyForm) form;
        DefaultBizLogic bizLogic = new DefaultBizLogic();

        String[] displayNameFields = new String[1];
        displayNameFields[0] = "title";
        String valueField = Constants.ID;
        String[] whereColumnName = {Constants.ID};
        String[] whereColumnCondition = {"="};
        boolean isToExcludeDisabled = false;

        List objectList = new ArrayList();

        if (sform.getProtocols() != null)
            for (int i = 0; i < sform.getProtocols().length; i++)
            {
                Object[] whereColumnValue = {sform.getProtocols()[i]};
                List list = bizLogic.getList(objectName, displayNameFields,
                        valueField, whereColumnName, whereColumnCondition,
                        whereColumnValue, null, null, false);
                objectList.add(list.get(1));
            }
        return objectList;

    }

    /**
     * This method is used to get the list of selected users from the ui.
     * @param form study form 
     * @return List of user objects which are selected by the user.
     */
    private List getSelectedUsers(ActionForm form, HttpServletRequest request) //throws Exception
    {

        List userList = new ArrayList();
        try
        {
            StudyForm sform = (StudyForm) form;
            String[] displayNameFields = {Constants.FIRSTNAME};
            String[] whereColumnName = {Constants.ID};
            String[] whereColumnCondition = {"="};
            DefaultBizLogic bizLogic = new DefaultBizLogic();
            if (sform.getUsers() != null)
                for (int i = 0; i < sform.getUsers().length; i++)
                {
                    Object[] whereColumnValue = {sform.getUsers()[i]};
                    List list = bizLogic.getList(User.class.getName(),
                            displayNameFields, Constants.ID, whereColumnName,
                            whereColumnCondition, whereColumnValue, null, null,
                            false);

                    NameValueBean bean = (NameValueBean) list.get(1);
                    Long currentUserId = (Long) ((SessionDataBean) request
                            .getSession().getAttribute(Constants.SESSION_DATA))
                            .getUserId();
                    if (!bean.getValue().equals(currentUserId.toString()))
                        userList.add(list.get(1));
                }
        }
        catch (Exception e)
        {
        }
        return userList;
    }

    /**
     * This method is used to get the list of usergroup objects that are selected by the user.
     * @param form study form
     * @return List list of "UserGroup" objects.
     * @see edu.ucdavis.caelmir.domain.UserGroup
     */
    private List getSelectedGroup(ActionForm form) //throws Exception
    {
        List groupList = new ArrayList();
        try
        {
            StudyForm sform = (StudyForm) form;
            String[] displayNameFields = {Constants.NAME};
            String[] whereColumnName = {Constants.ID};
            String[] whereColumnCondition = {"="};
            DefaultBizLogic bizLogic = new DefaultBizLogic();
            if (sform.getUserGroups() != null)
                for (int i = 0; i < sform.getUserGroups().length; i++)
                {
                    Object[] whereColumnValue = {sform.getUserGroups()[i]};
                    List list = bizLogic.getList(UserGroup.class.getName(),
                            displayNameFields, Constants.ID, whereColumnName,
                            whereColumnCondition, whereColumnValue, null, null,
                            false);
                    groupList.add(list.get(1));
                }
        }
        catch (Exception e)
        {
        }
        return groupList;

    }

    /**
     * This method checks whether the submitted for action is "addnew" or not.
     * @param form study form
     * @return boolean returns true or false depending on whether the action is "addnew" or not.
     */
    private boolean checkForAddNew(ActionForm form)
    {
        boolean flag = false;
        StudyForm sform = (StudyForm) form;

        if (sform.getSubmittedFor() != null
                && !sform.getSubmittedFor().equals("")
                && sform.getSubmittedFor().equals("AddNew"))
        {
            flag = true;
        }
        return flag;

    }

    /**
     * This method checks whether the logged in user has access to create the user and user group
     * @param form action form 
     * @param request HTTP request to get the session data bean.
     */
    private void checkCreatePermission(ActionForm form,
            HttpServletRequest request)
    {
        boolean userCreatePermission = PrivilegeUtil.checkPrivilege(this
                .getClass(), User.class.getName(), request.getSession(),
                Permissions.USER_CREATE);
        boolean userGroupCreatePermission = PrivilegeUtil.checkPrivilege(this
                .getClass(), UserGroup.class.getName(), request.getSession(),
                Permissions.USER_GROUP_CREATE);
        boolean protocolCreatePermission = PrivilegeUtil.checkPrivilege(this
                .getClass(), SpecimenProtocol.class.getName(), request.getSession(),
                Permissions.PROTOCOL_CREATE);
        
        //boolean studyCreatePermission = PrivilegeUtil.checkPrivilege(this.getClass(),Study.class.getName(),request.getSession(),Permissions.STUDY_CREATE);
        //	StudyForm studyForm = (StudyForm) form;
        //request.setAttribute("studyCreatePermissionFlag",new Boolean(studyCreatePermission));
        request.setAttribute("userCreatePermissionFlag", new Boolean(
                userCreatePermission));
        request.setAttribute("userGroupCreatePermissionFlag", new Boolean(
                userGroupCreatePermission));
        request.setAttribute("protocolCreatePermission", new Boolean(
                protocolCreatePermission));
    }

    private void checkForExpData(ActionForm form, HttpServletRequest request)
            throws DAOException
    {

        StudyForm sform = (StudyForm) form;
        Long systemIdentifier = new Long(sform.getId());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = defaultBizLogic.retrieve(Study.class.getName(), "id",
                systemIdentifier);
        Study study = null;

        request.setAttribute(Constants.EXP_DATA_FLAG, new Boolean(false));

        if (list != null && !list.isEmpty())
        {
            study = (Study) list.get(0);
        }

        if (study != null)
        {
            Collection expColl = study.getExperimentCollection();
            if (expColl != null && !expColl.isEmpty())
            {
                Iterator expIterator = expColl.iterator();
                while (expIterator.hasNext())
                {
                    Experiment experiment = (Experiment) expIterator.next();

                    Collection cohortColl = experiment.getCohortCollection();
                    //get animal collection and check for animal ids with eexp data
                    if (cohortColl != null && !cohortColl.isEmpty())
                    {
                        Iterator cohortIterator = cohortColl.iterator();
                        while (cohortIterator.hasNext())
                        {
                            Cohort cohort = (Cohort) cohortIterator.next();
                            Collection animalColl = cohort
                                    .getAnimalCollection();
                            if (animalColl != null && !animalColl.isEmpty())
                            {
                                Iterator animalIterator = animalColl.iterator();
                                while (animalIterator.hasNext())
                                {
                                    Animal animal = (Animal) animalIterator
                                            .next();
                                    Collection eventColl = animal
                                            .getEventRecordsCollection();
                                    if (eventColl != null
                                            && !eventColl.isEmpty())
                                    {
                                        request.setAttribute(
                                                Constants.EXP_DATA_FLAG,
                                                new Boolean(true));
                                    }
                                }
                            }
                        }
                    }
                }

            }
        }
    }

}
