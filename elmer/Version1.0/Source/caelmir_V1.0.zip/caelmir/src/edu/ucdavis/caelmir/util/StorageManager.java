/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.util;


import java.util.HashMap;
import java.util.Map;

public class StorageManager
{

    private static Map cacheMap = new HashMap();
    
    public void setMap(String keyName, Object value)
    {
        cacheMap.put(keyName,value);
    }
    
    public Object getMap (String keyName)
    {
        return cacheMap.get(keyName);
    }
    
    public void  remove(String keyName)
    {
        cacheMap.remove(keyName);        
    }
    
    
}
