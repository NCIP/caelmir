package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.ProteomicsEventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.dbManager.DAOException;


/**Title:TODO
 * Description: This class is used as an action class for building the experimenatal data matrix for the 
 * given combination of study experiment, protocol and cohort.
 * Copyright:TODO
 * @see  org.apache.struts.action.Action
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class ExperimentalDataSpreadSheetViewAction extends Action {
	
    /**This method is called when user clicks on the "ADD EXPERIMENT DATA" link for any combination of study experiment and 
     * cohort. The class helps to build the experimental data matrix for the given combination. The class populates all
     * the required lists and passes the control onto the appropriate page.
     * 
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     */
	public ActionForward execute(ActionMapping mapping, ActionForm form,HttpServletRequest request,HttpServletResponse response) throws DAOException {
		
		String cohortIdentifier = request.getParameter(Constants.COHORT_IDENTIFIER);
		String source = request.getParameter(Constants.SOURCE);
		if (cohortIdentifier == null && source == null) {
			cohortIdentifier = (String) request.getSession().getAttribute(Constants.COHORT_ID);
			request.getSession().removeAttribute(Constants.COHORT_ID);
		} if (cohortIdentifier != null) {
			request.getSession().setAttribute(Constants.COHORT_ID,cohortIdentifier);
			DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
			List cohortList =  defaultBizLogic.retrieve(Cohort.class.getName(),Constants.ID,new Long(cohortIdentifier));
			if (cohortList != null && !cohortList.isEmpty()) {
				Cohort cohort = (Cohort) cohortList.get(0);
				
				if (cohort != null && cohort.getAnimalCollection() != null) {
					request.setAttribute(Constants.COHORT_NAME,cohort.getName());
					request.setAttribute(Constants.COHORT_URL,getCohortURL(cohortIdentifier));
					request.setAttribute(Constants.EXPERIMENT_NAME,cohort.getExperiment().getName());
					request.setAttribute(Constants.STUDY_NAME,cohort.getExperiment().getStudy().getName());
					Collection animalCollection = cohort.getAnimalCollection();
					Iterator animalCollectionIterator = animalCollection.iterator();
					Experiment experiment = cohort.getExperiment();
					List animalProtocolList = new ArrayList();
					List protocolURLList = new ArrayList();		
					List protocolNameList = new ArrayList();
                    List protocolstyleList = new ArrayList();
					if (experiment != null) {
						Collection protocolCollection = experiment.getCollectionProtocolCollection();
						if (protocolCollection != null && !protocolCollection.isEmpty()) {
							int numberOfProtocols = protocolCollection.size();
							
							Iterator protocolCollectionIterator = protocolCollection.iterator();
							while (protocolCollectionIterator.hasNext()) {
								CollectionProtocol protocol = (CollectionProtocol) protocolCollectionIterator.next();
								if (protocol != null) {
									protocolNameList.add(protocol.getTitle());
									String className = getClassName(protocol);
									List urlList = new ArrayList();
									List list = new ArrayList();
                                    List styleList = new ArrayList();
									Set animalSet = (Set) cohort.getAnimalCollection();
									List animalList = new ArrayList(animalSet);
									for (int i =0; i < animalList.size();i++) {
										Animal animal = (Animal) animalList.get(i);
										Long id = animal.getId();
                                        boolean animalDisabledFlag = false;
                                          if (Constants.ACTIVITY_STATUS_DISABLED.equalsIgnoreCase(animal.getActivityStatus())) {
                                              animalDisabledFlag = true;
                                          }
										String url = "";
										List isanimalPresentlist = defaultBizLogic.retrieve(className,Constants.ANIMAL_ID,id);
                                        //TODO
                                        
                                        if (isanimalPresentlist != null && !isanimalPresentlist.isEmpty()) {
                                            if (!animalDisabledFlag) {
                                                styleList.add("doneEnabled");    
											url = getBasicURL(protocol,id,cohortIdentifier,Constants.EDIT,((AbstractDomainObject)isanimalPresentlist.get(0)).getId());
                                            } else {
                                                styleList.add("doneDisabled");
                                                url = "#";
                                            }
											list.add(Constants.DONE);
										} else {
                                            if (!animalDisabledFlag) {
                                                styleList.add("addDataEnabled");
											url = getBasicURL(protocol,id,cohortIdentifier,Constants.ADD,null);
                                            } else {
                                                styleList.add("addDataDisabled");
                                                url = "#";
                                            }
											list.add(Constants.ADD_DATA);
										}
										urlList.add(url);
									}
									protocolURLList.add(new ArrayList(urlList));
									animalProtocolList.add(new ArrayList(list));
                                    protocolstyleList.add(new ArrayList(styleList));
                                    styleList.clear();
									list.clear();
									urlList.clear();
								}
							}
							
							request.setAttribute(Constants.NUMBER_OF_PROTOCOLS, new Integer(numberOfProtocols));
						}
						protocolNameList.add(0,Constants.ANIMALS);
						request.setAttribute(Constants.PROTOCOL_NAME_LIST,protocolNameList);
						Set animalSet = (Set) cohort.getAnimalCollection();
						List animalList = new ArrayList(animalSet);
						List animalNameList = new ArrayList();
						List animalURLList = new ArrayList();
                        List animalStyleList = new ArrayList();
						if (animalList != null && !animalList.isEmpty()) {
							for (int j =0 ; j < animalList.size(); j++) {
								Animal animal = (Animal) animalList.get(j);
								animalNameList.add(animal.getId().toString());
                                animalStyleList.add("animalStyle");
								animalURLList.add("SearchObject.do?operation=edit&pageOf=pageOfAnimal&id=" + animal.getId() + "&forwardTo=pageOfExperimentlaDataSpreadsheetView");
							}
						}
						protocolURLList.add(0,animalURLList);
						request.setAttribute(Constants.ANIMAL_NAME_LIST,animalNameList);
						animalProtocolList.add(0,animalNameList);
                        protocolstyleList.add(0, new ArrayList(animalStyleList));
						request.setAttribute(Constants.ANIMAL_PROTOCOL_LIST,animalProtocolList);
						request.setAttribute(Constants.PROTOCOL_URL_LIST,protocolURLList);
                        request.setAttribute(Constants.PROTOCOL_STYLE_LIST,protocolstyleList);
					}
				}
			}
		} else {
			return mapping.findForward(Constants.FAILURE);
		}
		return mapping.findForward(Constants.SUCCESS);
	}

    /**
     * The method builds the URL for the cohort object for the given cohort id.
     * @param cohortIdentifier Identifier from which the object can be retrieved.
     * @return String url to load the cohort page.
     */
	private String getCohortURL(String cohortIdentifier) {
		return "/caelmir/SearchObject.do?operation=edit&pageOf=pageOfCohort&id="+ cohortIdentifier + "&systemIdentifier=" + cohortIdentifier + "&forwardTo=pageOfExperimentlaDataSpreadsheetView";
	}
    

    /**
     * The method is used to get the appropriate url of the protocol page.
     * @param protocol Identifies which particular protocol it is 
     * @param id Id of the protocol object
     * @param cohortIdentifier cohort id for which experimental data is to be populated.
     * @param operation Add/Edit mode of operation
     * @param systemIdentifier SystemIdentifier request parameter is required for common code.
     * @return String URL TO load the appropriate protocol's page.
     */
	private String getBasicURL(CollectionProtocol protocol,Long id,String cohortIdentifier,String operation,Long systemIdentifier) {
		String sysId = "";
		if (systemIdentifier != null) {
			sysId = systemIdentifier.toString();
		}
		if (protocol.getTitle().equalsIgnoreCase("pathology")) {
			return "/caelmir/CaseAction.do?operation="+operation+"&animalId="+id.toString() + "&systemIdentifier=" + sysId;
		} else if (protocol.getTitle().equalsIgnoreCase("Microarray")) {
			return "/caelmir/MicroarrayAction.do?operation="+operation+"&animalId="+id.toString() + "&systemIdentifier=" + sysId;
		} else {
			return "/caelmir/ProteomicsAction.do?operation="+operation+"&animalId="+id.toString() + "&systemIdentifier=" + sysId;
		}
	}

    /**
     * This method is used to get the fully qualified class name of the object given the object alias.
     * @param protocol Protocol Alias 
     * @return String  Fully qualified class name of the given protocol
     */
	private String getClassName(CollectionProtocol protocol) {
		if (protocol.getTitle().equalsIgnoreCase(Constants.PATHOLOGY_ALIAS)) {
			return PathologyEventRecords.class.getName();
		} else if (protocol.getTitle().equalsIgnoreCase(Constants.MICROARRAY_ALIAS)) {
			return MicroarrayEventRecords.class.getName();
		} else {
			return ProteomicsEventRecords.class.getName();
		}
	}
}
