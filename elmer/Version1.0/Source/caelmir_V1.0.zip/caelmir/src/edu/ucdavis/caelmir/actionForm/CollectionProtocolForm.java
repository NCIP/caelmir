/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.actionForm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.util.CommonUtility;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Utility;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.Validator;



public class CollectionProtocolForm extends AbstractActionForm
{

    /***/
    private String title;
    /***/
    private String shortTitle;
    /***/
    private String startDate;
    /***/
    private String endDate;
    /***/
    private String descriptionURL;
    /***/
    private String irbIdentifier;
    /***/
 //   private String enrollmentNumber;
    /***/
  //  private String[] events = new String[1];
    
  //  private String[] editEvents ;
    
   
    
    private String counter ; 
    
    public CollectionProtocolForm()
    {
      counter="1";   
    }
    
    /**hashMap defined for checkboxes **/
    private Map valueMap = new LinkedHashMap();

    /**
     * @return hashMap 
     * @see #getValue(String)
     
    public Map getValueMap()
    {
        return valueMap;
    }*/

    /**
     * @param values 
     * @see #setValue(String, Object)
     */
   /* public void setValueMap(Map valueMap)
    {
        this.valueMap = values;
    }
*/
    /**
     * Associates the specified object with the specified key in the map.
     * @param key the key to which the object is mapped.
     * @param value the object which is mapped.
     */
    public void setValue1(String key, Object value)
    {
        valueMap.put(key, value);
    }

    /**
     * Returns the object to which this map maps the specified key.
     * @param key the required key.
     * @return the object to which this map maps the specified key.
     */
    public Object getValue1(String key)
    {
        System.out.println("get key:" + valueMap.get(key));
        return valueMap.get(key);

    }
    
    
    /***/
    private String[] eventRecords ;
    
  /*  public CollectionProtocolForm () {
      //  events [0] = "1";
        eventRecords[0] = "";
    }
    
    */
    public String[] getEventRecords()
    {
        return eventRecords;
    }


    
    public void setEventRecords(String[] eventRecords)
    {
        this.eventRecords = eventRecords;
    }


    public String getDescriptionURL()
    {
        return descriptionURL;
    }

    
    public void setDescriptionURL(String descriptionURL)
    {
        this.descriptionURL = descriptionURL;
    }

    
    public String getEndDate()
    {
        return endDate;
    }

    
    public void setEndDate(String endDate)
    {
        this.endDate = endDate;
    }

    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
   /* public String getEnrollmentNumber()
    {
        return enrollmentNumber;
    }

    
    public void setEnrollmentNumber(String enrollmentNumber)
    {
        this.enrollmentNumber = enrollmentNumber;
    }*/

    
    public String getIrbIdentifier()
    {
        return irbIdentifier;
    }

    
    public void setIrbIdentifier(String irbIdentifier)
    {
        this.irbIdentifier = irbIdentifier;
    }

    
    public String getShortTitle()
    {
        return shortTitle;
    }

    
    public void setShortTitle(String shortTitle)
    {
        this.shortTitle = shortTitle;
    }

    
    public String getStartDate()
    {
        return startDate;
    }

    
    public void setStartDate(String startDate)
    {
        this.startDate = startDate;
    }

    
    public String getTitle()
    {
        return title;
    }

    
    public void setTitle(String title)
    {
        this.title = title;
    }

    public int getFormId()
    {
        // TODO Auto-generated method stub
        return 500;
    }
    
    public void setAllValues(AbstractDomainObject abstractDomain)
    {
        CollectionProtocol collectionProtocol = (CollectionProtocol) abstractDomain;
        this.activityStatus = collectionProtocol.getActivityStatus();
        this.descriptionURL = collectionProtocol.getDescriptionURL();
        if (collectionProtocol.getEndDate() != null) {
        this.endDate = Utility.parseDateToString(collectionProtocol.getEndDate(),Constants.DATE_PATTERN_MM_DD_YYYY);
        }
        if (collectionProtocol.getStartDate() != null) {
            this.startDate = Utility.parseDateToString(collectionProtocol.getStartDate(),Constants.DATE_PATTERN_MM_DD_YYYY);
        }
        /*if(collectionProtocol.getEnrollment() != null)
            this.enrollmentNumber = collectionProtocol.getEnrollment().toString();*/
        if(collectionProtocol.getIrbIdentifier() != null) 
            this.irbIdentifier = collectionProtocol.getIrbIdentifier().toString();
        
        this.id = collectionProtocol.getId().longValue();
        this.shortTitle = collectionProtocol.getShortTitle();
        this.title = collectionProtocol.getTitle();
        
            
        //set its event points
       setEventPoints(collectionProtocol);        
    }
    
    private void  setEventPoints(CollectionProtocol collProtocol)
    {
      if (collProtocol != null)
        {
            Collection collProtocolEvent = collProtocol
                    .getCollectionProtocolEventCollection();
            List eventRec = new ArrayList();
            if(collProtocolEvent != null)
            {
                this.valueMap =  new LinkedHashMap();
                Iterator itOfProtocolEvent= collProtocolEvent.iterator();
                int i=0;
                while(itOfProtocolEvent.hasNext())
                {
                    CollectionProtocolEvent collectionProtocolEvent = (CollectionProtocolEvent) itOfProtocolEvent.next();
                    //eventPoints.add(collectionProtocolEvent.getStudyCalendarEventPoint());
                    this.setValue1(i+"_"+collectionProtocolEvent.getId().toString() ,collectionProtocolEvent.getStudyCalendarEventPoint());
                    Collection entityMapCollection = collectionProtocolEvent.getEntityMapCollection();
                    
                //     int j=0;
                    /*Iterator itEventRecord= entityMapCollection.iterator();
                    while(itEventRecord.hasNext())
                    {
                        EntityMap entityMap = (EntityMap) itEventRecord.next();
                        if (eventRecords.getName() != null) {
	                        String key= i+"_"+getRecordId(eventRecords.getName())+"_"+eventRecords.getId();
	                        eventRec.add(key);
	                      //this.eventRecords[j]=key;
	                        //j++;
                        }
                    } */   
                    i++;
                }
            }
          this.eventRecords=CommonUtility.ConvertToArray(eventRec);
        }        
    }  
 /*   
    private String getRecordId(String recName)
    {
        String str="";
        if(recName.equalsIgnoreCase("MicroArray Event Record"))
          str="1";
        else if(recName.equalsIgnoreCase("Pathology Event Record"))
            str="2";
        else if(recName.equalsIgnoreCase("Proteomics Event Record"))
            str="3";
        return str;
    }
    */
    protected void reset()
    {
        // TODO Auto-generated method stub
        
    }


    /*
    public String[] getEvents()
    {
        return events;
    }


    
    public void setEvents(String[] events)
    {
        this.events = events;
    }
*/
    /**
     * Overrides the validate method of ActionForm.
     * */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        
        if (validator.isEmpty(String.valueOf(title))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", "title"));
        }
        
        if (!validator.checkDate(String.valueOf(startDate))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.date.invalid", "Start date" ));
        }
    
              
        if (this.endDate != null && this.endDate.trim().length()!=0) {
            if (!validator.compareDates(this.startDate,this.endDate)) {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.date.enddate.invalid", "End date"));
            }
        }
        
        if (this.irbIdentifier != null && this.irbIdentifier.trim().length()!= 0) {
            if (!validator.isNumeric(this.irbIdentifier)) {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.IRBIdentifier.NotNumber"));
            }
        }
        
        if (this.valueMap != null && !this.valueMap.isEmpty()) {
            Collection label = this.valueMap.values();
            Iterator iter = label.iterator();
            while (iter.hasNext()) {
                String value = (String) iter.next();
                if (value.trim().length() == 0) {
                    errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.events.empty")); 
                    break;
                }
            }
        }
        
 /*       if (this.enrollmentNumber != null && this.enrollmentNumber.trim().length()!= 0)  {
            if (!validator.isNumeric(this.enrollmentNumber)) {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.enorllment.NotNumber"));
            }
        }
        
       if (this.values != null || this.values.isEmpty()) 
       {          
               errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
               "errors.events.empty"));                
        }
       
   */ 
        
        
        return errors;
    }

    
    public String getCounter()
    {
        return counter;
    }

    
    public void setCounter(String counter)
    {
        this.counter = counter;
    }

    
    public void setValueMap(Map valueMap)
    {
        this.valueMap = valueMap;
    }

    
    public Map getValueMap()
    {
        return valueMap;
    }

}
