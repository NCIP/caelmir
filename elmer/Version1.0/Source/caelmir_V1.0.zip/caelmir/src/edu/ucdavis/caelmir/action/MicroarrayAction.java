
package edu.ucdavis.caelmir.action;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.MicroarrayForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.security.exceptions.SMException;
import edu.wustl.common.util.dbManager.DAOException;
import gov.nih.nci.security.authorization.domainobjects.ProtectionGroup;
import gov.nih.nci.security.exceptions.CSException;
import gov.nih.nci.security.exceptions.CSTransactionException;

/**Title:TODO
 * Description: This class is used as an action class when user clicks on the "add data" or "done" link to add or 
 * modify any micro array related data for any animal.
 * Copyright:TODO
 * @see  org.apache.struts.action.Action
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class MicroarrayAction extends Action
{

    /**This method is called when user clicks on the "Add data" or "Done" link for any microarray data.
     * <br>The method populates all the required lists and passes the control onto the appropriate page.
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws DAOException
    {
        MicroarrayForm actionForm = (MicroarrayForm) form;
        String operation = request.getParameter(Constants.OPERATION);

        String operations = operation;

        String pageOf = (String) request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        if (actionForm.getAnimalId() == null
                || actionForm.getAnimalId().toString().equals("0"))
        {
            String ID = (String) request.getParameter("animalId");
            if (ID != null)
                actionForm.setAnimalId(ID);
        }
        Animal mouse = new Mouse();
        if (operation != null && operation.equalsIgnoreCase("addOrEdit")
                || operation.equalsIgnoreCase(Constants.VIEW))
        {
            if (actionForm.getFileName() != null)
            {
                request.setAttribute("fileName", actionForm.getFileName());
                request.setAttribute("systemIdentifier", new Long(actionForm
                        .getId()));
            }

            if (actionForm.getEventId() != null)
                request.setAttribute("event", setEventName(actionForm
                        .getEventId()));

            DefaultBizLogic defaultBizLogic = BizLogicFactory
                    .getDefaultBizLogic();

            if (actionForm.getAnimalId() != null
                    && actionForm.getAnimalId().length() > 0)
            {
                List animalList = defaultBizLogic.retrieve(Mouse.class
                        .getName(), Constants.ID, Long.valueOf(actionForm
                        .getAnimalId()));

                if (animalList != null)
                {
                    mouse = (Animal) animalList.get(0);
                    request.setAttribute("animal", mouse.getId().toString());
                    request.setAttribute(Constants.ANIMAL_ID, mouse.getId()
                            .toString());
                    request.setAttribute("Experiment", mouse.getCohort()
                            .getExperiment().getName());
                    request.setAttribute("experimentId", mouse.getCohort()
                            .getExperiment().getId().toString());
                    Collection collection = mouse.getCohort().getExperiment()
                            .getCollectionProtocolCollection();
                    if (collection != null && !collection.isEmpty())
                    {
                        Iterator iterator = collection.iterator();
                        while (iterator.hasNext())
                        {
                            CollectionProtocol collectionProtocol = (CollectionProtocol) iterator
                                    .next();
                            if (actionForm.getProtocolId() != null
                                    && collectionProtocol.getId()
                                            .equals(
                                                    new Long(actionForm
                                                            .getProtocolId())))
                            {
                                request.setAttribute("protocol",
                                        collectionProtocol.getTitle());
                            }
                        }
                    }
                }

                if (operation != null
                        && (operation.equalsIgnoreCase(Constants.VIEW)))
                {
                    Long systemIdentifier = new Long(actionForm.getId());

                    List list = defaultBizLogic.retrieve(
                            MicroarrayEventRecords.class.getName(), "id",
                            systemIdentifier);

                    MicroarrayEventRecords microarrayEventRecords = null;

                    if (list != null && !list.isEmpty())
                    {
                        microarrayEventRecords = (MicroarrayEventRecords) list
                                .get(0);
                    }

                    if (microarrayEventRecords != null)
                    {

                        EntityMap entityMap = (EntityMap) microarrayEventRecords
                                .getEntityMap();
                        if (entityMap != null)
                        {
                            if (entityMap.getCollectionProtocolEvent() != null
                                    && entityMap.getCollectionProtocolEvent()
                                            .getCollectionProtocol().getId() != null)
                            {
                                request.setAttribute("protocol", entityMap
                                        .getCollectionProtocolEvent()
                                        .getCollectionProtocol().getTitle());
                                request.setAttribute("protocolId", entityMap
                                        .getCollectionProtocolEvent()
                                        .getCollectionProtocol().getId()
                                        .toString());
                                request.setAttribute("event", entityMap
                                        .getCollectionProtocolEvent()
                                        .getStudyCalendarEventPoint());
                            }
                        }
                    }
                }

                List microList = defaultBizLogic
                        .retrieve(MicroarrayEventRecords.class.getName(),
                                "animal", mouse);
                if (microList != null && !microList.isEmpty())
                {
                    Iterator listIterator = microList.iterator();
                    while (listIterator.hasNext())
                    {
                        EventRecords eventRecord = (EventRecords) listIterator
                                .next();
                        if (eventRecord != null
                                && eventRecord.getActivityStatus() != null
                                && !eventRecord
                                        .getActivityStatus()
                                        .equalsIgnoreCase(
                                                Constants.ACTIVITY_STATUS_DISABLED))
                        {
                            /*  Collection eventCollection = (Collection) eventRecord.getEntityMap().getCollectionProtocolEvent();
                             if (eventCollection != null && !eventCollection.isEmpty()) {
                             Iterator eventCollectionIterator = eventCollection.iterator();
                             while (eventCollectionIterator.hasNext()) {*/
                            EntityMap entityMap = (EntityMap) eventRecord
                                    .getEntityMap();
                            if (entityMap != null
                                    && entityMap.getId() != null
                                    && actionForm.getEntityMapId() != null
                                    && entityMap.getId().equals(
                                            new Long(actionForm
                                                    .getEntityMapId())))
                            {
                                actionForm.setOperation(Constants.EDIT);
                                operation = Constants.EDIT;
                                actionForm.setId(eventRecord.getId()
                                        .longValue());
                                break;
                            }
                            //  }
                            //   }
                        }
                        /*if(eventRecord.getActivityStatus().equalsIgnoreCase(Constants.ACTIVITY_STATUS_DISABLED))
                         {
                         return mapping.findForward(Constants.FAILURE);
                         }*/
                    }
                }
            }
        }

        if (operation != null && operation.equalsIgnoreCase(Constants.EDIT))
        { //check for delete privelege
            if (isAccessPresent(request, Permissions.EXPDATA_DELETE,
                    Permissions.EXPDATA_DELETE_ACCESS_DENIED))
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        true));

                //find the role of the user                    
                boolean role = getRole(request, mouse);
                request.setAttribute(Constants.USER_ROLE, new Boolean(role));
            }
            else
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        false));
            }
        }

        if (actionForm.getAnimalId() != null
                && actionForm.getAnimalId().length() > 0)
        {
            if (operation != null && operation.equalsIgnoreCase("addOrEdit"))
            {
                operation = Constants.ADD;
                actionForm.setOperation(Constants.ADD);
            }

            if (operation != null && operation.equalsIgnoreCase(Constants.EDIT))
            {
                populateMicroarray(request, actionForm);
            }

            /*   if(operations.equalsIgnoreCase(Constants.VIEW))
             operation = operations;
             */
            request.setAttribute(Constants.OPERATION, operation);

            if (pageOf != null
                    && pageOf
                            .equalsIgnoreCase(Constants.PAGE_OF_MICROARRAY_APPROVE))
            {
                request.setAttribute(Constants.ACTIVITYSTATUSLIST,
                        Constants.EXPDATA_ACTIVITY_STATUS_VALUES);
                return mapping
                        .findForward(Constants.PAGE_OF_MICROARRAY_APPROVE);
            }

            if (!operation.equalsIgnoreCase(Constants.VIEW))
                return mapping.findForward(Constants.PAGE_OF_MICROARRAY);
        }
        //actionForm.setForwardTo(Constants.PAGE_OF_EXPERIMENTAL_DATA);
        if (operations.equalsIgnoreCase(Constants.VIEW))
            operation = operations;

        request.setAttribute(Constants.OPERATION, operation);

        if (actionForm.getOperation() != null
                && actionForm.getOperation().equalsIgnoreCase(Constants.VIEW))
            //return mapping.findForward(Constants.PAGE_OF_MICROARRAY_VIEW);
            return mapping.findForward(pageOf);
        else
            return mapping.findForward(Constants.FAILURE);

    }

    private String setEventName(String eventId)
    {
        String eventName = null;

        DefaultBizLogic defaultBizLogic = new DefaultBizLogic();
        try
        {
            List eventList = defaultBizLogic.retrieve(
                    CollectionProtocolEvent.class.getName(), Constants.ID, Long
                            .valueOf(eventId));
            if (eventList != null && !eventList.isEmpty())
            {
                CollectionProtocolEvent event = (CollectionProtocolEvent) eventList
                        .get(0);
                if (event.getStudyCalendarEventPoint() != null)
                    eventName = event.getStudyCalendarEventPoint();
            }
        }
        catch (DAOException e)
        {
        }

        return eventName;
    }

    /**
     * To check whether particular privilege is granted for this class 
     * @param request
     * @param privilege
     * @param accessDeniedMessage
     * @return true if access is present otherwise false
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                EventRecords.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

    private boolean getRole(HttpServletRequest request, Animal mouse)
            throws DAOException
    {
        boolean role = false;

        SessionDataBean sessionDataBean = (SessionDataBean) request
                .getSession().getAttribute(Constants.SESSION_DATA);

        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List creatorlist = (List) bizLogic.retrieve(User.class.getName(),
                Constants.ID, sessionDataBean.getUserId());

        User user = null;
        if (creatorlist != null && !creatorlist.isEmpty())
        {
            user = (User) creatorlist.get(0);
            if (getStudyRole(mouse, user.getId().toString()))
            {
                role = true;
            }
            else if (user.getRoleId().toString().equalsIgnoreCase("3")) //if the loginned user is DC
                role = true;
        }

        return role;
    }

    public boolean getStudyRole(Animal mouse, String id)
    {
        boolean flag = false;
        ProtectionGroup protectionGroup = null;
        if (mouse != null)
        {
            try
            {
                String studyId = null;
                if (mouse.getCohort() != null
                        && mouse.getCohort().getExperiment() != null
                        && mouse.getCohort().getExperiment().getStudy() != null
                        && mouse.getCohort().getExperiment().getStudy().getId() != null)
                {
                    studyId = mouse.getCohort().getExperiment().getStudy()
                            .getId().toString();
                    protectionGroup = SecurityManager.getInstance(
                            this.getClass()).getProtectionGroup(
                            "STUDY_" + studyId);

                    String roles[] = null;
                    userRoleAction act = new userRoleAction();
                    if (SecurityManager.getInstance(this.getClass())
                            .getuserRoleFromPG(act.getCsmUserId(id),
                                    protectionGroup) != null)
                    {
                        roles = SecurityManager.getInstance(this.getClass())
                                .getuserRoleFromPG(act.getCsmUserId(id),
                                        protectionGroup);
                        if (roles != null && roles[0] != null
                                && roles[0].equalsIgnoreCase("3")) //if the loginned user is DC
                            return true;
                    }
                }
            }
            catch (SMException e)
            {
            }
            catch (CSTransactionException e)
            {
            }
            catch (CSException e)
            {
            }

        }
        return flag;
    }

    private void populateMicroarray(HttpServletRequest request,
            MicroarrayForm actionForm) throws DAOException
    {
        Long systemIdentifier = new Long(actionForm.getId());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();

        List list = defaultBizLogic.retrieve(MicroarrayEventRecords.class
                .getName(), Constants.ID, systemIdentifier);
        if (list != null && !list.isEmpty())
        {
            MicroarrayEventRecords microarray = (MicroarrayEventRecords) list
                    .get(0);
            actionForm.setAllValues(microarray);
            request.setAttribute(Constants.FILE_NAME, actionForm.getFileName());
            request.setAttribute("systemIdentifier", new Long(actionForm
                    .getId()));
        }

    }

}
