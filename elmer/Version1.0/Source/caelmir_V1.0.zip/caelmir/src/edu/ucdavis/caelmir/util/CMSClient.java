/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */

package edu.ucdavis.caelmir.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import edu.common.dynamicextensions.ui.webui.util.WebUIManagerConstants;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.exception.HandlePopupException;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.util.Utility;

public class CMSClient
{

    public CMSClient()
    {
        super();
    }

    public static URL url = null;
    private static URLConnection con = null;

    public static URL tgMouseUrl = null;
    private static URLConnection tgMouseCon = null;

    public static URL dynamicUrl = null;
    private static URLConnection dynamicCon = null;

    static
    {
        // Read the properties file.
        Properties prop = new Properties();

        try
        {
            // load the property file
            prop.load(new FileInputStream(Variables.caElmirHome
                    + System.getProperty(Constants.FILE_SEPARATOR)
                    + Constants.PROPERTIES_FILE));
            // get the URL path for CMS Interface Servlet
            String urlPath = (String) prop.get(Constants.SERVLET_URL);
            // connect the CMS interface servlet
            url = new URL(urlPath);

            String tgMousePath = (String) prop.get(Constants.TGMOUSE_URL);
            System.out.println("TGmouse url:** : " + tgMousePath);
            tgMouseUrl = new URL(tgMousePath);


            String dynamicPath = (String) prop.get(Constants.DYNAMIC_EXTN_URL) + WebUIManagerConstants.DYNAMIC_EXTENSIONS_INTERFACE_ACTION_URL;
            
            dynamicUrl = new URL(dynamicPath);
            


            String useProxy = (String) prop.get("use.proxy.server");
            if (useProxy != null && useProxy.equalsIgnoreCase("true"))
            {
                Connection.proxy();
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            //throw new HandlePopupException(e.toString()); 
        }
    }
    

    
    public String getDynamicExtensionsLoadURL() {
        Properties prop = new Properties();
        try
        {
            prop.load(new FileInputStream(Variables.caElmirHome
                    + System.getProperty(Constants.FILE_SEPARATOR)
                    + Constants.PROPERTIES_FILE));
        }
        catch (FileNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String dynamicPath ="";
        dynamicPath = (String) prop.get(Constants.DYNAMIC_EXTN_URL) + WebUIManagerConstants.LOAD_DATA_ENTRY_FORM_ACTION_URL;
    
        return dynamicPath;
    }
    
    
    public String getDynamicExtensionsURL() {
        Properties prop = new Properties();
        try
        {
            prop.load(new FileInputStream(Variables.caElmirHome
                    + System.getProperty(Constants.FILE_SEPARATOR)
                    + Constants.PROPERTIES_FILE));
        }
        catch (FileNotFoundException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String dynamicPath="";
        dynamicPath = (String) prop.get(Constants.DYNAMIC_EXTN_URL) + WebUIManagerConstants.CREATE_CONTAINER_URL;
    
        return dynamicPath;
    }
    
    public List getDynamicExtnEventRecords() {
        List eventRecords = new ArrayList();
        
        try
        {
            dynamicCon = dynamicUrl.openConnection();
            dynamicCon.setDoOutput(true);
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        JSONObject jsonObj = new JSONObject();
        
        jsonObj.put(Constants.OPERATION, WebUIManagerConstants.GET_ALL_CONTAINERS);
        PrintWriter out = null;
        try
        {
            out = new PrintWriter(dynamicCon.getOutputStream());
        }
        catch (IOException e1)
        {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        out.write(jsonObj.toString());
        out.flush();
        out.close();
        
        BufferedReader bufferedReader = null;
        String resultStr = null;
       
        try
        {
            bufferedReader = new BufferedReader(new InputStreamReader(dynamicCon.getInputStream()));
            if (bufferedReader != null) {
                resultStr = (String) bufferedReader.readLine();
            }
        }
        catch (IOException e2)
        {
            // TODO Auto-generated catch block
            e2.printStackTrace();
        }
        
        if (resultStr != null) {
	        JSONArray jsonArray = new JSONArray(resultStr);
	        for (int i = 0; i < jsonArray.length(); i++)
	        {
	            JSONObject jobj = (JSONObject) jsonArray.get(i);
	            String name = jobj.getString(WebUIManagerConstants.CONTAINER_NAME);
	            int identifier = jobj.getInt(WebUIManagerConstants.CONTAINER_IDENTIFIER);
	            eventRecords.add(new NameValueBean(name,new Integer(identifier)));
	        }
        }
 
        return eventRecords;
    }

    public List getUnusedAnimals(String userId, List filterColumns,
            List filterValues, List operators, List conditions)
            throws  HandlePopupException
    {
        List animalList = new ArrayList();
        if (userId == null)
        {
            throw new HandlePopupException("UserId should not be null");
        }
        else
        {
            JSONArray jsonArray = null;
            
            try
            {
                con = url.openConnection();
                //con.
                con.setDoOutput(true);

         

            JSONObject jsonObj = new JSONObject();
            //passing all the parameters in one JSONObject
            jsonObj.put(Constants.OPERATION, Constants.CMS_OPERATION);
            jsonObj.put(Constants.USER_ID, userId);
            jsonObj.put(Constants.FILTER_COL, filterColumns.toString());
            jsonObj.put(Constants.FILTER_VALUES, filterValues.toString());
            jsonObj.put(Constants.OPERATORS, operators.toString());
            jsonObj.put(Constants.CONDITIONS, conditions.toString());

            System.out.println("JSON:" + jsonObj.toString());
            PrintWriter out = new PrintWriter(con.getOutputStream());

            //sending it to the CMS interface
            out.write(jsonObj.toString());
            //jsonObj.write(out);
            out.flush();
            out.close();
            BufferedReader bufferedReader;
           
                // getting back the response from CMS interface
                bufferedReader = new BufferedReader(new InputStreamReader(con
                        .getInputStream()));
            

            String resultStr = null;
            /*         try
             {*/
            resultStr = (String) bufferedReader.readLine();
            checkForNull(resultStr);
            /*           }
             catch (Exception e)
             {
             // TODO Auto-generated catch block
             e.printStackTrace();
             }*/

            jsonArray = new JSONArray(resultStr);
            for (int i = 0; i < jsonArray.length(); i++)
            {
                JSONObject jobj = (JSONObject) jsonArray.get(i);
                Mouse obj = new Mouse();

                //obj.setId(new Long(jobj.getLong("id")));
                //obj.setId(new Long(1111));
               
              /*  obj.setSex(new Character(jobj.getString(Constants.SEX)
                        .charAt(0)));
                obj.setAnimalColonyReference(jobj
                        .getString(Constants.COLONY_NUM));
                obj.setStrain(jobj.getString(Constants.STRAIN));
                obj.setBirthDate(Utility.parseDate(jobj
                        .getString(Constants.DOB)));*/
                
                
                obj.setBackgroundStrain(jobj.getString(Constants.BACK_GROUND_STRAIN));
                obj.setStrain(jobj.getString(Constants.STRAIN));
                obj.setBirthDate(Utility.parseDate(jobj.getString(Constants.BIRTH_DATE)));
                obj.setSex(new Character(jobj.getString(Constants.SEX)
                        .charAt(0)));
                /*obj.setLength(new Double(jobj.getString(Constants.LENGTH)));
                obj.setWeight(new Double(jobj.getString(Constants.WEIGHT)));*/
                obj.setLength(new Double(0));
                obj.setWeight(new Double(0));
                obj.setGeneOfInterest(jobj.getString(Constants.GENE_OF_INTEREST));
                obj.setAnimalColonyReference(jobj.getString(Constants.ANIMAL_COLONY_REFERENCE));
                obj.setAnimalNumber(jobj.getString(Constants.ANIMAL_NUMBER));
              
                animalList.add(obj);

            }

            System.out.println("*/*/***** jsonarray value is .........."
                    + jsonArray);

            }
            catch (Exception ex)
            {
                throw new HandlePopupException("CMS Response failure : "
                        + ex.toString());
                //throw new Exception("CMS connection failure");
            }
            
        }
            return animalList;
        
    }

    public int unmarkAnimals(List animals) throws 
            HandlePopupException
    {

        if (animals == null)
            System.out.println("Animals list is empty");
        else
        {
            JSONArray jsonArray = null;
            try
            {
                con = url.openConnection();
                con.setDoOutput(true);
            
            JSONObject jsonObj = new JSONObject();

            //passing all the parameters in one JSONObject
            jsonObj.put(Constants.OPERATION, Constants.UNMARK_ANIMALS);

            jsonObj.put(Constants.ANIMAL_IDs, animals.toString());

            PrintWriter out = new PrintWriter(con.getOutputStream());
            out.write(jsonObj.toString());
            out.flush();
            out.close();

            //getting back the response from CMS interface

            BufferedReader bufferedReader;
           
                // getting back the response from CMS interface
                bufferedReader = new BufferedReader(new InputStreamReader(con
                        .getInputStream()));
            
            String resultStr = null;
            resultStr = (String) bufferedReader.readLine();
                checkForNull(resultStr);
           
            jsonArray = new JSONArray(resultStr);
            Object obj = jsonArray.get(0);
            JSONObject jObj = new JSONObject(obj.toString());
            if (jObj.getString(Constants.RESULT).equalsIgnoreCase("1"))
                return 1;
            
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block
                // e.printStackTrace();
                throw new HandlePopupException(e.toString());

            }

        }
        

        return 0;
    }

    public int markAnimals(List animals) throws HandlePopupException
    {

        if (animals == null)
            System.out.println("Animals list is empty");
        else
        {
            JSONArray jsonArray = null;

            try
            {
                con = url.openConnection();
                con.setDoOutput(true);
         
            JSONObject jsonObj = new JSONObject();
            jsonObj.put(Constants.OPERATION, Constants.MARK_ANIMALS);
            jsonObj.put(Constants.ANIMAL_IDs, animals.toString());

            PrintWriter out = new PrintWriter(con.getOutputStream());

            //sending it to the CMS interface
            out.write(jsonObj.toString());
            out.flush();
            out.close();

            // getting back the response from CMS interface
            // ObjectInputStream objectInStream = new ObjectInputStream(con.getInputStream());
            BufferedReader bufferedReader;
             // getting back the response from CMS interface
                bufferedReader = new BufferedReader(new InputStreamReader(con
                        .getInputStream()));
           
            String resultStr = null;
            //            try
            //            {
            resultStr = (String) bufferedReader.readLine();
            checkForNull(resultStr);
            /*     }
             catch (Exception e)
             {
             // TODO Auto-generated catch block
             e.printStackTrace();
             }*/
            jsonArray = new JSONArray(resultStr);
            Object object = jsonArray.get(0);
            JSONObject jObj = new JSONObject(object.toString());

            if (jObj.getString(Constants.RESULT).equalsIgnoreCase("1"))
                return 1;
            
            }
            catch (Exception ex)
            {
                throw new HandlePopupException(ex.toString());
                //throw new Exception("CMS connection failure");
            }

        }

        return 0;
    }

    public List getTgMouseRecords(String userId, List filterColumns,
            List filterValues, List operators, List conditions)
            throws HandlePopupException
    {

        List animalList = new ArrayList();
        JSONArray jsonArray = null;
        try
        {
            tgMouseCon = tgMouseUrl.openConnection();
            tgMouseCon.setDoOutput(true);

            JSONObject jsonObj = new JSONObject();
            //passing all the parameters in one JSONObject
            jsonObj.put(Constants.OPERATION, Constants.GET_PATH_RECORDS);
            //  jsonObj.put(Constants.USER_ID, userId);
            jsonObj.put(Constants.FILTER_COL, filterColumns.toString());
            jsonObj.put(Constants.FILTER_VALUES, filterValues.toString());
            jsonObj.put(Constants.OPERATORS, operators.toString());
            jsonObj.put(Constants.CONDITIONS, conditions.toString());

            PrintWriter out = new PrintWriter(tgMouseCon.getOutputStream());

            //sending it to the TGMOUSE interface
            out.write(jsonObj.toString());
            out.flush();
            out.close();
            BufferedReader bufferedReader;

            // getting back the response from TGMOUSE interface
            bufferedReader = new BufferedReader(new InputStreamReader(
                    tgMouseCon.getInputStream()));

            String resultStr = null;
            /*    try
             {*/
            resultStr = (String) bufferedReader.readLine();
            checkForNull(resultStr);
            /*     }
             catch (Exception e)
             {
             // TODO Auto-generated catch block
             e.printStackTrace();
             }
             try
             {*/
            jsonArray = new JSONArray(resultStr);

            for (int i = 0; i < jsonArray.length(); i++)
            {
                JSONObject jobj = (JSONObject) jsonArray.get(i);
                //TgMouse obj= new TgMouse();
                
                if(!jobj.has("result"))
                {
                    PathologyEventRecords obj = new PathologyEventRecords();
    
                    obj.setDiagnosis(jobj.getString(Constants.PATH_DIAGNOSIS));
                    obj.setMicroscopicDescription(jobj.getString(Constants.MICRO));
                    obj.setPathologyNumber(jobj.getString(Constants.PATHNUM));
                    obj.setSubmittedDate(Utility.parseDate(jobj.getString(Constants.PATHOLOGY_SUBMITTED_DATE)));
                  
                    animalList.add(obj);
                }
            }
        }
        catch (Exception ex)
        {
            throw new HandlePopupException(ex.toString());
            // throw new Exception();
        }

        return animalList;

    }

    public int markTgMouseRecords(List pathologyRecords) throws 
            HandlePopupException
    {

        if (pathologyRecords == null)
            System.out.println("Pathology list is empty");
        else
        {
            JSONArray jsonArray = null;

            try
            {
                tgMouseCon = tgMouseUrl.openConnection();
                tgMouseCon.setDoOutput(true);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put(Constants.OPERATION, Constants.MARK_PATHOLOGY);
                jsonObj.put(Constants.PATHNUM, pathologyRecords.toString());

                PrintWriter out = new PrintWriter(tgMouseCon.getOutputStream());

                //sending it to the tgMouse interface
                out.write(jsonObj.toString());
                out.flush();
                out.close();

                // getting back the response from CMS interface
                // ObjectInputStream objectInStream = new ObjectInputStream(con.getInputStream());
                BufferedReader bufferedReader;

                // getting back the response from TGMOUSE interface
                bufferedReader = new BufferedReader(new InputStreamReader(
                        tgMouseCon.getInputStream()));

                String resultStr = null;
                //            try
                //            {
                resultStr = (String) bufferedReader.readLine();
                checkForNull(resultStr);
                /*     }
                 catch (Exception e)
                 {
                 // TODO Auto-generated catch block
                 e.printStackTrace();
                 }*/
                jsonArray = new JSONArray(resultStr);
                Object object = jsonArray.get(0);
                JSONObject jObj = new JSONObject(object.toString());

                if (jObj.getString(Constants.RESULT).equalsIgnoreCase("1"))
                    return 1;

            }
            catch (Exception ex)
            {
                // throw new Pop("TGMouse response failure");
                throw new HandlePopupException(ex.toString());
            }

        }

        return 0;
    }


    public int unmarkTgMouseRecords(List idList) throws 
            HandlePopupException
    {

        if (idList == null)
            System.out.println("Id list is empty");
        else
        {
            JSONArray jsonArray = null;
            try
            {
                tgMouseCon = tgMouseUrl.openConnection();
                tgMouseCon.setDoOutput(true);
            
            JSONObject jsonObj = new JSONObject();

            //passing all the parameters in one JSONObject
            jsonObj.put(Constants.OPERATION, Constants.UNMARK_PATHOLOGY);
            jsonObj.put(Constants.PATHNUM, idList.toString());

            PrintWriter out = new PrintWriter(tgMouseCon.getOutputStream());
            out.write(jsonObj.toString());
            out.flush();
            out.close();

            //getting back the response from CMS interface

            BufferedReader bufferedReader;
           
                // getting back the response from CMS interface
                bufferedReader = new BufferedReader(new InputStreamReader(tgMouseCon
                        .getInputStream()));
            
            String resultStr = null;
            resultStr = (String) bufferedReader.readLine();
                checkForNull(resultStr);
           
            jsonArray = new JSONArray(resultStr);
            Object obj = jsonArray.get(0);
            JSONObject jObj = new JSONObject(obj.toString());
            if (jObj.getString(Constants.RESULT).equalsIgnoreCase("1"))
                return 1;
            
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block
                // e.printStackTrace();
                throw new HandlePopupException(e.toString());

            }

        }
        

        return 0;
    }
    
    
    private void checkForNull(Object obj) throws HandlePopupException
    {
        if (obj == null)
        {
            throw new HandlePopupException("CMS result is null");
        }
    }

}
