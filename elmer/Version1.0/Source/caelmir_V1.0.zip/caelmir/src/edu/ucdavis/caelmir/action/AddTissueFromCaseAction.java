package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.TissueForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author sujay_narkar
 *
 
 */
public class AddTissueFromCaseAction extends BaseAction
{
    
    protected List getSelectedImages(ActionForm form) {
        TissueForm eform = (TissueForm) form;
        List imageList = new ArrayList();
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (eform.getImages() != null)
            for (int i = 0; i < eform.getImages().length; i++)
            {
                Object[] whereColumnValue = {eform.getImages()[i]};
                List list = null;
                try
                {
                    list = bizLogic.retrieve(Image.class.getName(),"id", whereColumnValue);
                }
                catch (DAOException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                if (list!=null && list.size() > 0) {
                    NameValueBean nameValue = new NameValueBean();
                    Image image = (Image) list.get(0);
                    nameValue.setValue(image.getId());
                    String type = "";
                    if (image.getImageType() != null) {
                        type = "[" + image.getImageType().getName() + "]";
                    }
                    nameValue.setName(type + "  " + image.getFileName());
                    imageList.add(nameValue);
                }
            }
        return imageList;
    }
   
	public ActionForward executeAction(ActionMapping mapping, ActionForm form,HttpServletRequest request,
			HttpServletResponse response) {
		TissueForm tissueForm = (TissueForm)form;

        String operation = request.getParameter(Constants.OPERATION);
        request.setAttribute(Constants.OPERATION, operation);

        String pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);
        StorageManager store= new StorageManager();
           if(store.getMap("tissueForm")!=null && tissueForm.getForwardTo()!=null && tissueForm.getForwardTo().equalsIgnoreCase(Constants.SUCCESS) )
           {           
               TissueForm newTissueForm = (TissueForm) store.getMap("tissueForm");
               setFormValues(tissueForm,newTissueForm);                   
               store.remove("tissueForm");
            }
            else
            {        
               if(store.getMap("tissueForm")!=null)
                   store.remove("tissueForm");        
            }
        
            
            
            request.setAttribute(Constants.CASE_IDENTIFIER,tissueForm.getCaseIdentifier());
            DefaultBizLogic bizLogic =  (DefaultBizLogic)BizLogicFactory.getBizLogic(tissueForm.getFormId());
            try
            {
                if(tissueForm.getCaseIdentifier() != null && !tissueForm.getCaseIdentifier().equalsIgnoreCase(""))
                {
                    List caseObjectList =  bizLogic.retrieve(PathologyEventRecords.class.getName(),Constants.ID,new Long(tissueForm.getCaseIdentifier()));
                    if (caseObjectList != null && caseObjectList.size() > 0) 
                    {
                        request.setAttribute(Constants.PATHNUM,((PathologyEventRecords) caseObjectList.get(0)).getPathologyNumber());
                    }
                }
            }
            catch (NumberFormatException e1)
            {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            catch (DAOException e1)
            {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            try
            {
             
            List slideList = new ArrayList();     
          
            slideList=getSelectedSlide(tissueForm);
            
            List imageList = new ArrayList(); 
            //if (operation != null && operation.equals("edit")) {
            imageList = getSelectedImages(form);
            //}                
              
            
           HttpSession session= request.getSession();
           
           if(tissueForm.getForwardTo()!= null && tissueForm.getForwardTo().equals(Constants.SUCCESS))
                   checkContents(slideList,session);           
           session.setAttribute(Constants.SLIDE_LIST, slideList);
           
          request.setAttribute(Constants.SLIDE_LIST, slideList); 
          
          request.setAttribute(Constants.IMAGE_LIST,imageList);
          request.setAttribute(Constants.IMAGE_TYPE_LIST,getImageTypeList());
          
        }
        catch(Exception e){}
          
        return mapping.findForward(pageOf);
	}
	
     private TissueForm setFormValues(TissueForm destn,TissueForm src)
        {
            destn.setActivityStatus(src.getActivityStatus());
            destn.setImageCounter(src.getImageCounter());
            destn.setCaseIdentifier(src.getCaseIdentifier());
            destn.setImageCollection(src.getImageCollection());
            destn.setImageList(src.getImageList());
            destn.setImages(src.getImages());
            destn.setSelectedSlide(src.getSelectedSlide());
            destn.setTissueShortName(src.getTissueShortName());
            destn.setTissueLongName(src.getTissueLongName());
            destn.setSlideIdentifier(src.getSlideIdentifier());
            destn.setValueMap(src.getValueMap());
            destn.setId(src.getId());
            if(destn.getPageOf()!=null)
                destn.setPageOf(src.getPageOf());
          //  destn.setOperation(src.getOperation());
          //  destn.setForwardTo(src.getForwardTo());
         //   destn.setForwardTo("");
           // destn.setSubmittedFor(src.getSubmittedFor());
          //  destn.setSubmittedFor("");
            //destn.set
            return destn;
            
        }
     
     private void  checkContents(List slideList,HttpSession session)
     {
     if(session.getAttribute(Constants.SLIDE_LIST) != null)
     {
         List list = (List) session.getAttribute(Constants.SLIDE_LIST);
         
         Iterator it = list.iterator();         
         while(it.hasNext())
         {
             //Slideit.next();
             NameValueBean bean = (NameValueBean) it.next();
             Iterator slideIt = slideList.iterator();
             boolean flag=false;
             while(slideIt.hasNext())
             {
                 NameValueBean bean1 = (NameValueBean) slideIt.next();
                 if(bean1.getValue().equals(bean.getValue()))
                     flag=true;
             }
             if(!flag)
                 slideList.add(bean);
         }
      }
     }
      
	/**
	 * 
	 * @param request
	 * @return
	 */
	protected SessionDataBean getSessionData(HttpServletRequest request) {
		Object obj = request.getSession().getAttribute(Constants.SESSION_DATA);
		if(obj!=null)
		{
			SessionDataBean sessionData = (SessionDataBean) obj;
			return  sessionData;
		}
		return null;
		
	}
	
	protected List getImageTypeList() {
        List list = new ArrayList();
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List imageTypes = null;
        try
        {
            imageTypes = bizLogic.retrieve(ImageType.class.getName());
        }
        catch (DAOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        if (imageTypes!=null) {
            Iterator iter = imageTypes.iterator();
            while (iter.hasNext()) {
                ImageType imageType = (ImageType) iter.next();
                NameValueBean nameValue = new NameValueBean();
                nameValue.setName(imageType.getName());
                nameValue.setValue(imageType.getId());
                list.add(nameValue);
            }
        }
        
        return list;
    }
    
       /**
     * 
     * @param form to get some fields
     * @return List of namevalue bean pairs of cohort object which are selected in creation of experiment. 
     * @throws Exception
     */
    private List getSelectedSlide(ActionForm form) throws Exception
    {
        List slidelist = new ArrayList();
        TissueForm cform = (TissueForm) form;
        String[] displayNameFields = {"slideNumber"};
        String[] whereColumnName = {"id"};
        String[] whereColumnCondition = {"="};
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (cform.getSelectedSlide() != null)
            for (int i = 0; i < cform.getSelectedSlide().length; i++)
            {
                Object[] whereColumnValue = {cform.getSelectedSlide()[i]};
                List list = bizLogic.getList(Slide.class.getName(),
                        displayNameFields, "id", whereColumnName,
                        whereColumnCondition, whereColumnValue, null, null,
                        false);
                if (list.size() > 1)
                    slidelist.add(list.get(1));
            }
        return slidelist;
    }
    
}
