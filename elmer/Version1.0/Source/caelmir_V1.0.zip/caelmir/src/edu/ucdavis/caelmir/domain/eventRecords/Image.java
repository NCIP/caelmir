
package edu.ucdavis.caelmir.domain.eventRecords;

import java.util.Date;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;

/**
 * A set of attributes that stores the Pathology Image
 * @hibernate.class table="CAELMIR_IMAGE"
 */

public class Image extends AbstractDomainObject implements java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**Unique identifier for the object*/
    private Long id;

    /**Date of creation of the image*/
    private Date createdDate;

    /** Byte array data of actual image*/
    private byte[] image;
    
    private String contentType;
    
    private String fileName;
    private Long fileSize;
    
    /**
     * @return Returns the contentType.
     * @hibernate.property name="contentType" type="string" length="30" column="CONTENT_TYPE"
     */
    public String getContentType()
    {
        return contentType;
    }
    /**
     * @param contentType The contentType to set.
     */
    public void setContentType(String contentType)
    {
        this.contentType = contentType;
    }
    /**
     * @return Returns the fileName.
     * @hibernate.property name="fileName" type="string" length="100" column="FILE_NAME"
     */
    public String getFileName()
    {
        return fileName;
    }
    /**
     * @param fileName The fileName to set.
     */
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }
    /**
     * @return Returns the fileSize.
     * @hibernate.property name="fileSize" type="long" length="30" column="FILE_SIZE"
     */
    public Long getFileSize()
    {
        return fileSize;
    }
    /**
     * @param fileSize The fileSize to set.
     */
    public void setFileSize(Long fileSize)
    {
        this.fileSize = fileSize;
    }
   

    /**Activity Status of the object*/
    private String activityStatus;

    /** Creator user*/
    private edu.ucdavis.caelmir.domain.common.User creator;

    /** Type of image.*/
    private edu.ucdavis.caelmir.domain.common.ImageType imageType;
    
   
    /**
     * @return
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_IMAGE_SEQ"
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * Returns the date when the user is added to the system.
     * @hibernate.property name="createdDate" type="date" column="CREATED_DATE"
     * @return Returns the dateAdded.
     */
    public Date getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    /**
     * @return Returns the image.
     * @hibernate.property name="image" type="edu.ucdavis.caelmir.domain.common.BinaryBlobType" column="IMAGE"  
     */
    public byte[] getImage()
    {
        return image;
    }

    public void setImage(byte[] image)
    {
        this.image = image;
    }

    /**
     * Returns the activitystatus of the user.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     * @return Returns the activityStatus.
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @return the user object
     * @hibernate.many-to-one column="PARENT_USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.User getCreator()
    {

        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.dataElements.Image thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Image();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                creator = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Image:getCreator throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return creator;

    }

    public void setCreator(edu.ucdavis.caelmir.domain.common.User creator)
    {
        this.creator = creator;
    }

    /**
     * @return
     * @hibernate.many-to-one column="IMAGE_TYPE_ID" class="edu.ucdavis.caelmir.domain.common.ImageType"
     * constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.ImageType getImageType()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.dataElements.Image thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Image();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.ImageType", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                imageType = (edu.ucdavis.caelmir.domain.common.ImageType)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Image:getImageType throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return imageType;

    }

    public void setImageType(
            edu.ucdavis.caelmir.domain.common.ImageType imageType)
    {
        this.imageType = imageType;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Image)
        {
            Image c = (Image) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    
    public void setAllValues(AbstractActionForm abstractForm) throws AssignDataException
    {
        // TODO Auto-generated method stub
        
    }

    
    public Long getSystemIdentifier()
    {
        // TODO Auto-generated method stub
        return id;
    }

   
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;
        
    }

}