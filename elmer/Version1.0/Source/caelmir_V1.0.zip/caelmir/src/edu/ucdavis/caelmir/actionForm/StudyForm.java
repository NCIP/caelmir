
package edu.ucdavis.caelmir.actionForm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Utility;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;


/**
 * @author sujay_narkar
 */
public class StudyForm extends AbstractActionForm {
    /**
     * Study Name
     */
    String studyName;
    /**
     * Study Hypothesis
     */
    String studyHypothesis;
    /**
     * Investigation startdate
     */
    String investigationStartDate;
    /**
     * Investigation End Date
     */
    String investigationEndDate;
    /**
     * Created date for the study
     */
    String createdDate;
    /**
     * Study Description
     */
    String studyDescription;
 
    String modelId;
    
    /**
     * protocols
     */
    String []protocols;
    
    String []assignedUser;
    /**
     * users
     */
    String []users;
   /**
    * User groups
    */
    String []userGroups;
    /***/
    String modelName;
    /***/
    String genotype;
    /***/
    String actualStrain;
    /***/
    String mainStrain;
    /***/
    Boolean deleteCohortFlag = new Boolean(false);
    /***/
    String creator;
    
    String [] roles; 
    
  
    public String[] getRoles()
    {
        return roles;
    }

    
    public void setRoles(String[] roles)
    {
        this.roles = roles;
    }
    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }

    public String getCreator()
    {
        return creator;
    }
    
    public void setCreator(String creator)
    {
        this.creator = creator;
    }
    public Boolean getDeleteCohortFlag() 
    {
		return deleteCohortFlag;
	}
	public void setDeleteCohortFlag(Boolean deleteCohortFlag) 
	{
		this.deleteCohortFlag = deleteCohortFlag;
	}
	/**
     * @return Returns the investigationEndDate.
     */
    public String getInvestigationEndDate() {
        return investigationEndDate;
    }
    /**
     * @param investigationEndDate The investigationEndDate to set.
     */
    public void setInvestigationEndDate(String investigationEndDate) {
        this.investigationEndDate = investigationEndDate;
    }
    /**
     * @return Returns the investigationStartDate.
     */
    public String getInvestigationStartDate() {
        return investigationStartDate;
    }
    /**
     * @param investigationStartDate The investigationStartDate to set.
     */
    public void setInvestigationStartDate(String investigationStartDate) {
        this.investigationStartDate = investigationStartDate;
    }
    /**
     * @return Returns the studyDescription.
     */
    public String getStudyDescription() {
        return studyDescription;
    }
    /**
     * @param studyDescription The studyDescription to set.
     */
    public void setStudyDescription(String studyDescription) {
        this.studyDescription = studyDescription;
    }
    /**
     * @return Returns the studyHypothesis.
     */
    public String getStudyHypothesis() {
        return studyHypothesis;
    }
    /**
     * @param studyHypothesis The studyHypothesis to set.
     */
    public void setStudyHypothesis(String studyHypothesis) {
        this.studyHypothesis = studyHypothesis;
    }
    /**
     * @return Returns the studyName.
     */
    public String getStudyName() {
        return studyName;
    }
    /**
     * @param studyName The studyName to set.
     */
    public void setStudyName(String studyName) {
        this.studyName = studyName;
    }
    /**
     * 
     */
    public void reset() {
        
    }
    
    /**
     * Returns the id assigned to form bean.
     * @return the id assigned to form bean.
     */
    public int getFormId() 
    {
        return Constants.STUDY_FORM_ID;
    }
	public void setAddNewObjectIdentifier(String addNewFor, Long addObjectIdentifier)
    {
		 
	    if(addNewFor.equals("user"))
	    {
	    	Long ID=new Long(addObjectIdentifier.longValue());	        	
	    	String str= ID.toString();
	    	
	    	List list = new ArrayList();
	    	
	    	int len= 1;
	    	if (users != null)
	    	{
	    		for(int i=0;i<users.length;i++)
	        		list.add(users[i]);
	    		len=users.length + 1;
	    	}        		        	
	    	list.add(str);
	    	String [] users = new String[len]; 	
	    	        	
	    	for(int i=0;i<len;i++)
	    		users[i]=(String)list.get(i);	        	
	        setUsers(users);
	    }
	    if(addNewFor.equals("userGroup"))
	    {
	    	Long ID=new Long(addObjectIdentifier.longValue());	        	
	    	String str= ID.toString();
	    	
	    	List list = new ArrayList();
	    	
	    	int len= 1;
	    	if (userGroups != null)
	    	{
	    		for(int i=0;i<userGroups.length;i++)
	        		list.add(userGroups[i]);
	    		len=userGroups.length + 1;
	    	}        		        	
	    	list.add(str);
	    	String [] userGroups = new String[len]; 	
	    	//cohort =(String[]) list.toArray();	        	
	    	for(int i=0;i<len;i++)
	    		userGroups[i]=(String)list.get(i);	        	
	        setUserGroups(userGroups);
	    }
        
        if(addNewFor.equals("collectionProtocol"))
        {
            Long ID=new Long(addObjectIdentifier.longValue());              
            String str= ID.toString();            
            List list = new ArrayList();            
            int len= 1;
            if (protocols != null)
            {
                for(int i=0;i<protocols.length;i++)
                    list.add(protocols[i]);
                len=protocols.length + 1;
            }                           
            list.add(str);
            String [] protocols = new String[len];   
                            
            for(int i=0;i<len;i++)
                protocols[i]=(String)list.get(i);              
            setProtocols(protocols);
        }
    }
    
    /**
     * 
     */
    public void setAllValues(AbstractDomainObject abstractDomain)  
    {
    		Study study = (Study) abstractDomain;
    		
//    		this.genotype = study.getGenotype();
//    		this.actualStrain = study.getActualStrain();
//    		this.mainStrain = study.getMainStrain();
    		//this.modelName = study.getModelName().toString();
    		this.activityStatus = study.getActivityStatus();
    		this.id = study.getSystemIdentifier().longValue();
           
    		this.studyDescription = study.getDescription();
    		this.studyHypothesis = study.getHypothesis();
    		if (study.getModel() != null) {
    			this.modelId = study.getModel().getId().toString();
    		}
          //  this.modelDescriptionURL = study.getModelDescriptionURL();
    		this.studyName = study.getName();
	    	this.investigationStartDate = Utility.parseDateToString(study.getInvestigationStartDate(),Constants.DATE_PATTERN_MM_DD_YYYY);
	    	this.investigationEndDate  =  Utility.parseDateToString(study.getInvestigationStopDate(),Constants.DATE_PATTERN_MM_DD_YYYY);
	    	this.createdDate = Utility.parseDateToString(study.getCreatedDate(),Constants.DATE_PATTERN_MM_DD_YYYY);
	    	if (study.getCreator() != null) {
	    	    this.creator = study.getCreator().getLastName() + Constants.COMMA_SEPARATOR + study.getCreator().getFirstName();
            }
            Iterator iterate;
	    	Collection Coll;		    	
	    	//set userGrup colln
	    	Coll= study.getUserGroupCollection();
	    	String xx;
			int i=0;
	    	if(Coll.size() != 0 && Coll != null)
	    	{		    		
		    	String [] userGroups = new String[Coll.size()];
				iterate= Coll.iterator();								
				while(iterate.hasNext())
				{
					  UserGroup userGroupObj = (UserGroup) iterate.next();
					  xx=userGroupObj.getId().toString();
					  userGroups[i++]=xx;
				}
				setUserGroups(userGroups);
			}
	    	
	    	//user colln
	    	Coll= study.getUserCollection();
			i=0;
	    	if(Coll.size() != 0 && Coll != null)
	    	{		    		
		    	String [] users = new String[Coll.size()];
				iterate= Coll.iterator();								
				while(iterate.hasNext())
				{
					  User userObj = (User) iterate.next();
					  
					  if (userObj != null) {
					  xx=userObj.getId().toString();
					  users[i++]=xx;
					  }
				}				
				setUsers(users);
			}	
	    	
	    	Collection protocolCollection = study.getCollectionProtocolCollection();
	    	if (protocolCollection != null && !protocolCollection.isEmpty()) {
	    		int counter = 0;
	    		Iterator protocolIterator = protocolCollection.iterator();
	    		
	    		String [] protocols = new String[protocolCollection.size()];
	    		while(protocolIterator.hasNext()) {
	    			CollectionProtocol protocol = (CollectionProtocol) protocolIterator.next();
	    			protocols[counter++] = protocol.getId().toString();
	    		
	    		}
	    		this.setProtocols(protocols);
	    	}
			
    		
    }
    
    /**
     * Overrides the validate method of ActionForm.
     * */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        
        if (validator.isEmpty(String.valueOf(studyName))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("study.name")));
        }
        
        if (validator.isEmpty(String.valueOf(studyHypothesis))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("study.hypothesis")));
        }
        
        if (!validator.checkDate(String.valueOf(investigationStartDate))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.date.invalid", ApplicationProperties
                            .getValue("study.investigation.startdate")));
        }
        
              
        if (this.investigationEndDate != null && this.investigationEndDate.trim().length()!=0) {
	        if (!validator.compareDates(this.investigationStartDate,this.investigationEndDate)) {
	        	errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
	                    "errors.date.enddate.invalid", ApplicationProperties
	                            .getValue("study.investigation.stopdate")));
	        }
        }
        
      
        
        
        return errors;
    }
	/**
	 * @return Returns the protocols.
	 */
	public String[] getProtocols() {
		return protocols;
	}
	/**
	 * @param protocols The protocols to set.
	 */
	public void setProtocols(String[] protocols) {
		this.protocols = protocols;
	}
	/**
	 * @return Returns the users.
	 */
	public String[] getUsers() {
		return users;
	}
	/**
	 * @param users The users to set.
	 */
	public void setUsers(String[] users) {
		this.users = users;
	}
/**
 * @return Returns the userGroups.
 */
public String[] getUserGroups() {
	return userGroups;
}
/**
 * @param userGroups The userGroups to set.
 */
public void setUserGroups(String[] userGroups) {
	this.userGroups = userGroups;
}
public String getActualStrain() {
	return actualStrain;
}
public void setActualStrain(String actualStrain) {
	this.actualStrain = actualStrain;
}
public String getGenotype() {
	return genotype;
}
public void setGenotype(String genotype) {
	this.genotype = genotype;
}
public String getMainStrain() {
	return mainStrain;
}
public void setMainStrain(String mainStrain) {
	this.mainStrain = mainStrain;
}


public String getCreatedDate()
{
    return createdDate;
}

public void setCreatedDate(String createdDate)
{
    this.createdDate = createdDate;
}






public String getModelId()
{
    return modelId;
}


public void setModelId(String modelId)
{
    this.modelId = modelId;
}



public String[] getAssignedUser()
{
    return assignedUser;
}



public void setAssignedUser(String[] assignedUser)
{
    this.assignedUser = assignedUser;
}



}
