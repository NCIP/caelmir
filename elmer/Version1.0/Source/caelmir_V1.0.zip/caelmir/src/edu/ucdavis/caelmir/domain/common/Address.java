
package edu.ucdavis.caelmir.domain.common;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;


/**
 * A set of attributes that defines the physical location of a User or Site.
 * @hibernate.class table="CAELMIR_ADDRESS"
 * @author Mandar Deshmukh
 */
public class Address extends AbstractDomainObject
        implements
            java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**Identifier for the object - UNIQUE */
    private Long id;
    /**Street name*/
    private String street;
    /**City name*/
    private String city;
    /**state name*/
    private String state;
    /**country name*/
    private String country;
    /**Zipcode details*/
    private String zipCode;

    /**
     * Returns the identifier assigned to Address.
     * 
     * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
     * unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_ADDRESS_SEQ" 
     * @return a unique systemIdentifier assigned to the address.
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * Returns the Street of the address.
     * @hibernate.property name="street" type="string" column="STREET" length="50"
     * @return Street of the address.
     */
    public String getStreet()
    {
        return street;
    }

    public void setStreet(String street)
    {
        this.street = street;
    }

    /**
     * Returns the City of the address.
     * @hibernate.property name="city" type="string" column="CITY" length="50"
     * @return City of the address.
     */
    public String getCity()
    {
        return city;
    }

    public void setCity(String city)
    {
        this.city = city;
    }

    /**
     * Returns the state of the address.
     * @hibernate.property name="state" type="string" column="STATE" length="50"
     * @return state of the address.
     */
    public String getState()
    {
        return state;
    }

    public void setState(String state)
    {
        this.state = state;
    }

    /**
     * Returns the Country of the address.
     * @hibernate.property name="country" type="string" column="COUNTRY" length="50"
     * @return country of the address.
     */
    public String getCountry()
    {
        return country;
    }

    public void setCountry(String country)
    {
        this.country = country;
    }

    /**
     * Returns the zipcode of the address.
     * @hibernate.property name="zipCode" type="string" column="ZIPCODE" length="30"
     * @return zipCode of the address.
     */
    public String getZipCode()
    {
        return zipCode;
    }

    public void setZipCode(String zipCode)
    {
        this.zipCode = zipCode;
    }

    public Long getSystemIdentifier()
    {

        return id;
    }

    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;

    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Address)
        {
            Address c = (Address) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    
    public void setAllValues(AbstractActionForm abstractForm)
            throws AssignDataException
    {
        // TODO Auto-generated method stub

    }

}