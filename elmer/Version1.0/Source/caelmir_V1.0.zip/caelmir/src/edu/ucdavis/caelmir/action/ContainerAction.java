/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.common.dynamicextensions.ui.webui.util.WebUIManagerConstants;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.util.CMSClient;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;


/**
 * @author sandeep_chinta
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class ContainerAction extends BaseAction
{
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,HttpServletRequest request,HttpServletResponse response) throws DAOException {
        CMSClient cms = new CMSClient();
        HttpSession session = request.getSession();
        String dynamicPath = cms.getDynamicExtensionsLoadURL();
        request.setAttribute(Constants.DYNAMIC_EXTN_URL,dynamicPath);
        
        String entityMapId = (String) request.getParameter("entityMapId");
      //  String prevEntity = (String) session.getAttribute("entityMapId");
        
        String eventId = (String) request.getParameter("eventId");
        session.setAttribute("eventId",eventId);
        
        String animalId = (String) request.getParameter("animalId");
        session.setAttribute("animalId",animalId);
        
        String protocolId = (String) request.getParameter("protocolId");
        session.setAttribute("protocolId",protocolId);
        
        String entityRecordId = ""; //(String) request.getParameter("entityRecordId");
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = null;
        try
        {
            List entityList = defaultBizLogic.retrieve(EntityMap.class.getName(),"id",entityMapId);
            EntityMap entityMap = (EntityMap) entityList.get(0);
           list = defaultBizLogic.retrieve(EventRecords.class.getName(),"entityMap",entityMap);
        }
        catch (DAOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        if (list != null && !list.isEmpty()) {
            Iterator iter = list.iterator();
            while (iter.hasNext()) {
	            EventRecords eventRecords = (EventRecords) iter.next();
	            if(animalId != null && animalId.length() > 0) {
	                if(eventRecords.getAnimal() != null && eventRecords.getAnimal().getId().equals(new Long(animalId)))
	                {
	                    if(eventRecords.getEntityRecordId()!=null) {
	                        entityRecordId = eventRecords.getEntityRecordId().toString();
	                    }
	                }
	            }
            }
        }
       
        
        String containerIdentifier = (String) request.getParameter("containerIdentifier");
        session.setAttribute("entityReferenceId",containerIdentifier);
        session.setAttribute("entityMapId",entityMapId);
        session.setAttribute("entityRecordId",entityRecordId);
    	request.setAttribute(Constants.ENTITY_RECORD_ID,entityRecordId);
        request.setAttribute(WebUIManagerConstants.CONATINER_IDENTIFIER_PARAMETER_NAME,containerIdentifier);
       /* String status = request.getParameter(WebUIManagerConstants.OPERATION_STATUS_PARAMETER_NAME);
        if(!status.equals(WebUIManagerConstants.SUCCESS)) {
            return mapping.findForward(Constants.FAILURE);
        }*/
        
        if (animalId != null && animalId.length() > 0) {
            return mapping.findForward(Constants.PAGE_OF_CONTAINER);
        } else 
                return mapping.findForward(Constants.FAILURE);
    }
        

}
