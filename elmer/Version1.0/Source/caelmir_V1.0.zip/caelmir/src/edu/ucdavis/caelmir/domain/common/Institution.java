
package edu.ucdavis.caelmir.domain.common;

import edu.ucdavis.caelmir.actionForm.InstitutionForm;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;



/**
 * An institution to which a user belongs to.
 * @hibernate.class table="CAELMIR_INSTITUTION"
 */
public class Institution  extends AbstractDomainObject implements java.io.Serializable
{

    /**Ssytem generated serial Id for the file.*/
    private static final long serialVersionUID = 1234567890L;

    /**System generated unique systemIdentifier.*/
    private  Long id;
    
    /**Name of the Institution.*/
    private  String name;

    /**Unique code for the institute*/
    private  String institutionCode;
    
    /**Phone number for the institute*/
    private  String instiPhoneNumber;
    
    /**Home URL for the institute*/
    private  String websiteURL;
    
    /**Activity status of the institute.*/
    private  String activityStatus;

    
    
    /**
     * NOTE: Do not delete this constructor. Hibernet uses this by reflection API.
     * */
    public Institution()
    {
        
    }
    
    public Institution(AbstractActionForm form)
    {
        setAllValues(form);
    }
    
    /**
     * Returns the unique systemIdentifier assigned to institution.
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_INSTITUTION_SEQ"
     * @return A unique systemIdentifier assigned to the institution.
     * @see #setIdentifier(int)
     * */
    public  Long getId()
    {
        return id;
    }

    public void setId( Long id)
    {
        this.id = id;
    }

    /**
     * Returns the name of the institution.
     * @hibernate.property name="name" type="string" 
     * column="NAME" length="150" not-null="true" unique="true"
     * @return Returns the name of the institution. 
     * @see #setName(String)
     */
    public  String getName()
    {
        return name;
    }

    public void setName( String name)
    {
        this.name = name;
    }

    
    /**
     * Returns the name of the institution.
     * @hibernate.property name="institutionCode" type="string" 
     * column="INSTITUTION_CODE" length="50" 
     * @return Returns the name of the institution. 
     * @see #setName(String)
     */
    public  String getInstitutionCode()
    {
        return institutionCode;
    }

    public void setInstitutionCode( String institutionCode)
    {
        this.institutionCode = institutionCode;
    }

    /**
     * Returns the name of the institution.
     * @hibernate.property name="instiPhoneNumber" type="string" 
     * column="PHONE_NUMBER" length="50" 
     * @return Returns the name of the institution. 
     * @see #setName(String)
     */
    public  String getInstiPhoneNumber()
    {
        return instiPhoneNumber;
    }

    public void setInstiPhoneNumber( String phoneNumber)
    {
        this.instiPhoneNumber = phoneNumber;
    }

    /**
     * Returns the name of the institution.
     * @hibernate.property name="websiteURL" type="string" 
     * column="WEBSITE_URL" length = "50"
     * @return Returns the name of the institution. 
     * @see #setName(String)
     */
    public  String getWebsiteURL()
    {
        return websiteURL;
    }

    public void setWebsiteURL( String websiteURL)
    {
        this.websiteURL = websiteURL;
    }

    
    /**
     * Returns the name of the institution.
     * @hibernate.property name="activityStatus" type="string" 
     * column="ACTIVITY_STATUS" length="10" 
     * @return Returns the name of the institution. 
     * @see #setName(String)
     */
    public  String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus( String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Institution)
        {
            Institution c = (Institution) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }
    
    /* (non-Javadoc)
     * @see edu.wustl.catissuecore.domain.AbstractDomainObject#setAllValues(edu.wustl.catissuecore.actionForm.AbstractActionForm)
     */
    public void setAllValues(AbstractActionForm abstractForm)
    {
        InstitutionForm instituteForm = (InstitutionForm)abstractForm;
        
        this.name = instituteForm.getName().trim();
        this.instiPhoneNumber = instituteForm.getInstiPhoneNumber();
        this.websiteURL = instituteForm.getWebsiteURL();
        this.institutionCode = instituteForm.getInstitutionCode();
        
        if (instituteForm.getOperation().equals(Constants.ADD))
        {
            this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
        }
        else
        {
            this.activityStatus = instituteForm.getActivityStatus();
            instituteForm.setActivityStatus(null);
        }
    }
    
    
    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#getSystemIdentifier()
     */
    public Long getSystemIdentifier()
    {
        return id;
    }
    
    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#setSystemIdentifier( Long)
     */
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;
    }


}