/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.util;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.UserPreference;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.exception.BizLogicException;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;



public class PreferenceManager
{

    public static String getUserPreferenceValue(HttpServletRequest request, String preferenceName) {
        String preference = "";
        UserPreference userPreference = getUserPreference(request,preferenceName);
        if (userPreference != null) 
        {
            preference = userPreference.getPreferenceValue();
        }
        return preference;
    }
    
    private static UserPreference getUserPreference(HttpServletRequest request, String preferenceName) {
        Collection preferenceCollection = (Collection) request.getSession().getAttribute(Constants.USER_PREFERENE_LIST);
        if (preferenceCollection != null && !preferenceCollection.isEmpty()) {
            Iterator preferenceIterator = preferenceCollection.iterator();
            while (preferenceIterator.hasNext()) {
                UserPreference userPreference = (UserPreference) preferenceIterator.next();
                if (userPreference.getPreferenceName().equalsIgnoreCase(preferenceName)) {
                    return userPreference;
                    
                }
            }
        }
        return null;
    }
    
    
    public static void setUserPreference(HttpServletRequest request, String preferenceName, String preferenceValue) throws BizLogicException, UserNotAuthorizedException, DAOException {
        UserPreference userPreference = getUserPreference(request,preferenceName);
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        if (userPreference != null) {
            if(!preferenceValue.equalsIgnoreCase(userPreference.getPreferenceValue())) {
            userPreference.setPreferenceValue(preferenceValue);
            defaultBizLogic.update(userPreference,Constants.HIBERNATE_DAO);
            }
        } else 
        {
            userPreference = new UserPreference();
            userPreference.setPreferenceName(preferenceName);
            userPreference.setPreferenceValue(preferenceValue);
            userPreference.setUser(getUser(request));
            Collection collection = (Collection) request.getSession().getAttribute(Constants.USER_PREFERENE_LIST);
            if (collection == null) {
                collection = new HashSet();
                collection.add(userPreference);
                request.getSession().setAttribute(Constants.USER_PREFERENE_LIST,collection);
            } else {
                collection.add(userPreference);
            }
            //defaultBizLogic.insert(userPreference,getSessionData(request),Constants.HIBERNATE_DAO);
            defaultBizLogic.insert(userPreference,Constants.HIBERNATE_DAO);
        }
    }
    
    private static User getUser(HttpServletRequest request) throws DAOException 
    {
        Collection preferenceCollection = (Collection) request.getSession().getAttribute(Constants.USER_PREFERENE_LIST);
            if (preferenceCollection != null && !preferenceCollection.isEmpty()) {
                Iterator preferenceIterator = preferenceCollection.iterator();
                    UserPreference userPreference = (UserPreference) preferenceIterator.next();
                    return userPreference.getUser();
            } else 
            {
                SessionDataBean sessionDataBean = getSessionData(request);
                if (sessionDataBean != null) {
                    Long id = sessionDataBean.getUserId();
                    DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
                    List userList = defaultBizLogic.retrieve(User.class.getName(),Constants.ID,id);
                    if (userList != null && !userList.isEmpty()) {
                        return (User) userList.get(0);
                    }
                }
            }
                
            return null;
    }

    protected static SessionDataBean getSessionData(HttpServletRequest request) {
        Object obj = request.getSession().getAttribute(Constants.SESSION_DATA);
        if(obj!=null)
        {
            SessionDataBean sessionData = (SessionDataBean) obj;
            return  sessionData;
        }
        return null;
        //return (String) request.getSession().getAttribute(Constants.SESSION_DATA);
    }
   
}
