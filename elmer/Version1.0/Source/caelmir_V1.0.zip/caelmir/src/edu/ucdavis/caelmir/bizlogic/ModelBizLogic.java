/**
 * 
 */
package edu.ucdavis.caelmir.bizlogic;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author ravinder_kankanala
 *
 */
public class ModelBizLogic extends DefaultBizLogic {


	 /**
     * Saves the Model object in the database.
     * @param obj The Model object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOEx
     */ 
	public void insert(Object obj, DAO dao, SessionDataBean sessionDataBean) throws DAOException, UserNotAuthorizedException {
		
		Model model= (Model) obj;  
		 try
	        {
	            populateModelInformation(model, dao);
	        } 
	        catch(Exception e){}
		
		dao.insert(model,null,true,false);  
		
	}

	 /**
     * Updates an objects into the database.
     * @param obj The object to be updated into the database.
     * @throws DAOException
     */
    protected void update(DAO dao, Object obj, Object oldObj, SessionDataBean sessionDataBean) throws DAOException, UserNotAuthorizedException
    {
        Model model = (Model) obj;
        try
        {
            populateModelInformation(model, dao);
        } 
        catch(Exception e){}
        dao.update(model, null, true, false, false);
    } 
	
	
	// To get the populated Model Ddescription URL 
	private void populateModelInformation(Model model, DAO dao) throws FileNotFoundException,IOException{
	
		 // ******* get url from properties file and then replace id *********/
        Properties prop = new Properties();
        prop.load(new FileInputStream(Variables.caElmirHome
                + System.getProperty(Constants.FILE_SEPARATOR)
                + Constants.PROPERTIES_FILE));
        
        String urlPath = (String) prop.get(Constants.MODEL_URL);
        // /******* assumed that url ends with id= *******/
        urlPath= urlPath + model.getModelReferenceNum();
        
        model.setModelDescriptionURL(urlPath);
	
	}
	
	
	

}
