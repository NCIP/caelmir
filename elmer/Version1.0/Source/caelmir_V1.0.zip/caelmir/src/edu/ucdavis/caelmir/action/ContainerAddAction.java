/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.common.dynamicextensions.ui.webui.util.WebUIManagerConstants;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.IBizLogic;
import edu.wustl.common.exception.BizLogicException;
import edu.wustl.common.factory.AbstractBizLogicFactory;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.global.ApplicationProperties;


/**
 * @author sandeep_chinta
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class ContainerAddAction extends BaseAction
{

    public ActionForward executeAction(ActionMapping mapping, ActionForm form,HttpServletRequest request,HttpServletResponse response) throws DAOException {
        HttpSession session = request.getSession();
        
        String prevEntityRecordId = (String) session.getAttribute("entityRecordId");
        
        if (prevEntityRecordId!=null && prevEntityRecordId.equals("")) {
	        String entityMapId = (String) session.getAttribute("entityMapId");
	        String eventId = (String) session.getAttribute("eventId");
	        String animalId = (String) session.getAttribute("animalId");
	        String protocolId = (String) session.getAttribute("protocolId");
	        
	        IBizLogic bizLogic = null;
	        try
	        {
	            bizLogic = AbstractBizLogicFactory.getBizLogic(
	            		ApplicationProperties.getValue("app.bizLogicFactory"),
	            			"getBizLogic", Constants.USER_DEFINED_FORM_ID);
	        }
	        catch (BizLogicException e1)
	        {
	            // TODO Auto-generated catch block
	            e1.printStackTrace();
	        }
	        List list = bizLogic.retrieve(Mouse.class.getName(),Constants.ID,Long.valueOf(animalId));
	        
	               
	        String entityRecordId = request.getParameter(WebUIManagerConstants.RECORD_IDENTIFIER_PARAMETER_NAME);
	        EventRecords eventRecord = new EventRecords();
	        eventRecord.setEntityRecordId(new Long(entityRecordId));
	      //  session.setAttribute("entityRecordId",entityRecordId);
	        eventRecord.setActivityStatus("Active");
	        eventRecord.setCreatedDate(new Date());
	        if (list != null && !list.isEmpty()) 
	        {
	            Mouse mousefromTable = (Mouse) list.get(0);
	            eventRecord.setAnimal(mousefromTable);
	        }
	        
	        Object obj = request.getSession().getAttribute(Constants.SESSION_DATA);
	        SessionDataBean sessionData = null;
			if(obj!=null)
			{
				sessionData = (SessionDataBean) obj;
			}
	        User user  = (User) ((List) bizLogic.retrieve(User.class.getName(), Constants.ID, sessionData.getUserId())).get(0);
	        eventRecord.setCreator(user);
	        
	        List entityMapList = (List) bizLogic.retrieve(EntityMap.class.getName(),Constants.ID, entityMapId);
	        if (entityMapList != null && !entityMapList.isEmpty()) 
	        {
	            EntityMap entityMapFromTable =(EntityMap) entityMapList.get(0);
	            eventRecord.setEntityMap(entityMapFromTable);
	        }  
	        
	        try
	        {
	            bizLogic.insert(eventRecord,sessionData,Constants.HIBERNATE_DAO);
	        }
	        catch (BizLogicException e)
	        {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        catch (UserNotAuthorizedException e)
	        {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        String status = request.getParameter(WebUIManagerConstants.OPERATION_STATUS_PARAMETER_NAME);
	        if(!status.equals(WebUIManagerConstants.SUCCESS)) {
	            request.setAttribute("message","Unable To Insert Data");
	            return mapping.findForward(Constants.FAILURE);
	        }
	    }
        request.setAttribute("message","Data Inserted Successfully");
        return mapping.findForward(Constants.SUCCESS);
    }
}
