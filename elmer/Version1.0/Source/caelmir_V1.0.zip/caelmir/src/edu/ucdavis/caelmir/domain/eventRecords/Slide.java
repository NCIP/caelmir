
package edu.ucdavis.caelmir.domain.eventRecords;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import org.apache.struts.upload.FormFile;

import edu.ucdavis.caelmir.actionForm.SlideForm;
import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;

/**
 * @author sujay_narkar
 * @hibernate.class table="CAELMIR_SLIDE"
 */

public class Slide extends AbstractDomainObject implements java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**System generated unique systemIdentifier.*/
    private Long id;

    /**Date of creation of the slide*/
    private Date createdDate;

    /**Diagnosis of the slide*/
    private String diagnosis;

    /**Microscopic description of the slide*/
    private String microscopicDescription;

    /**Slide Number*/
    private String slideNumber;

    /** Stain associated with the slide*/
    private String stain;

    /**Activity status of the slide*/
    private String activityStatus;

    /**Creator user of the slide*/
    private edu.ucdavis.caelmir.domain.common.User creator;

    /**Collection of all the images associated with this slide.*/
    private Collection imageCollection = new HashSet();

    /**Tissue associated with the slide.*/
    private edu.ucdavis.caelmir.domain.eventRecords.Tissue tissue;

    /**
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_SLIDE_SEQ"
     * @return Returns the systemIdentifier.
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * Returns the date when the user is added to the system.
     * @hibernate.property name="createdDate" type="date" column="CREATED_DATE"
     * @return Returns the dateAdded.
     */
    public Date getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    /**
     * @return Returns the diagnosis.
     * @hibernate.property name="diagnosis" type="string" length="100" column="DIAGNOSIS" 
     */
    public String getDiagnosis()
    {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis)
    {
        this.diagnosis = diagnosis;
    }

    /**
     * @return Returns the microscopicDescription.
     * @hibernate.property name="microscopicDescription" type="string" length="500" column="MICROSCOPIC_DESCRIPTION"
     */
    public String getMicroscopicDescription()
    {
        return microscopicDescription;
    }

    public void setMicroscopicDescription(String microscopicDescription)
    {
        this.microscopicDescription = microscopicDescription;
    }

    /**
     * @return Returns the slideNumber.
     * @hibernate.property name="slideNumber" type="string" length="5" column="SLIDE_NUMBER"
     */
    public String getSlideNumber()
    {
        return slideNumber;
    }

    public void setSlideNumber(String slideNumber)
    {
        this.slideNumber = slideNumber;
    }

    /**
     * @return Returns the stain.
     * @hibernate.property name="stain" type="string" length="50" column="STAIN"
     */
    public String getStain()
    {
        return stain;
    }

    public void setStain(String stain)
    {
        this.stain = stain;
    }

    /**
     * @return Returns the diagnosis.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length = "10"
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @return the user object
     * @hibernate.many-to-one column="USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.User getCreator()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.dataElements.Slide thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Slide();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                creator = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Slide:getCreator throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return creator;

    }

    public void setCreator(edu.ucdavis.caelmir.domain.common.User creator)
    {
        this.creator = creator;
    }

    /**
     * Returns the set of users in this user group.
     * @hibernate.set name="imageCollection" cascade="save-update" inverse="false" lazy="false"
     * @hibernate.collection-key column="SLIDE_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.eventRecords.Image" 
     * @return the set of users in this user group.
     */
    public Collection getImageCollection()
    {
        //			try{
        //			   if(imageCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.dataElements.Slide thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Slide();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.dataElements.Image", thisIdSet);				 
        //				 	imageCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Slide:getImageCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return imageCollection;
    }

    public void setImageCollection(Collection imageCollection)
    {
        this.imageCollection = imageCollection;
    }

    /**
     * @return Returns the tissue.
     * @hibernate.many-to-one column="TISSUE_ID" 
     * class="edu.ucdavis.caelmir.domain.eventRecords.Tissue" constrained="true" 
     */
    public edu.ucdavis.caelmir.domain.eventRecords.Tissue getTissue()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.dataElements.Slide thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Slide();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.dataElements.Tissue", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                tissue = (edu.ucdavis.caelmir.domain.dataElements.Tissue)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Slide:getTissue throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return tissue;

    }

    public void setTissue(edu.ucdavis.caelmir.domain.eventRecords.Tissue tissue)
    {
        this.tissue = tissue;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Slide)
        {
            Slide c = (Slide) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }
    
    
    public Slide(AbstractActionForm form)
    {
        try
        {
            setAllValues(form);
        }
        catch (AssignDataException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public Slide()
    {
        // TODO Auto-generated constructor stub
    }
    
    
    protected String[] images;
    /**
     * @return Returns the images.
     */
    public String[] getImages()
    {
        return images;
    }
    
    /**
     * @param images The images to set.
     */
    public void setImages(String[] images)
    {
        this.images = images;
    }
    

    public void setAllValues(AbstractActionForm abstractForm)
            throws AssignDataException
    {
        SlideForm tform = (SlideForm) abstractForm;
        this.setSlideNumber(tform.getSlideNumber());
        this.setDiagnosis(tform.getTissueDiagnosis());
        this.setMicroscopicDescription(tform.getTissueMicroscopicDescription());
        this.setStain(tform.getStain());
        
        Collection imageCol = new HashSet();
        FormFile formFile = null;
        String[] imageList = tform.getImages();
        setImages(imageList);
        String imageIdentifier = null;
        int imageCounter = Integer.parseInt(tform.getImageCounter());
        for (int i =1;i<imageCounter;i++) {
            formFile = (FormFile) tform.getValue(Constants.SLIDE_IMAGES_UNDERSCORE + i);
            imageIdentifier = (String) tform.getValue(Constants.IMAGE_TYPES_UNDERSCORE + i);
               if(formFile!=null) {
		            Image image = new Image();
		            try
		            {
		                image.setImage(formFile.getFileData());
		                image.setFileName(formFile.getFileName());
		                image.setFileSize(new Long(formFile.getFileSize()));
		                image.setContentType(formFile.getContentType());
		                
		            }
		            catch (FileNotFoundException e)
		            {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		            catch (IOException e)
		            {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		            if (imageIdentifier != null && !imageIdentifier.equals("-1")) {
		                ImageType imageType = new ImageType();
		                imageType.setId(new Long(imageIdentifier));
		                image.setImageType(imageType);
		            }
		            imageCol.add(image);
		        }
            
        }
        
        this.imageCollection = imageCol;
    }

    public Long getSystemIdentifier()
    {

        return id;
    }

    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;

    }

}