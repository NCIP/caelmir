
package edu.ucdavis.caelmir.domain.subject;


import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;

import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.domain.AbstractDomainObject;


/**
 * A non-human living creature which may serve as the subject of an experimental condition
 * @hibernate.class table="CAELMIR_ANIMAL"
 */

public abstract class Animal extends AbstractDomainObject
        implements
            java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**System generated unique identifier.*/
    private Long id;

    /** baseStrain of animal*/
    private String backgroundStrain;

    /**strain of animal**/
    private String strain;

    /**birthDate of animal**/
    private Date birthDate;

    /**sex of animal **/
    private Character sex;

    /**The anticipated length of a clinical trial measured as a unit of time. **/
    private Double length;

    /**weight of animal*/
    private Double weight;

    /**activityStatus of animal**/
    private String activityStatus;
    
    private String animalNumber;

    /**Cohort this animal is part of.*/
    private edu.ucdavis.caelmir.domain.subject.Cohort cohort;

    /**Collection of all the genotypes this animal is associated with.*/
    private Collection genotypeCollection = new HashSet();

    /**Collection of all the data records collected for this animal*/
    private Collection eventRecordsCollection = new HashSet();


    /**Genus object under which this animal is carried out */
   edu.ucdavis.caelmir.domain.subject.Genus genus;
    

    /**Species object under which this animal is carried out */
   edu.ucdavis.caelmir.domain.subject.Species species;
    
                                
   
  
    /**
     * @return genus object this animal is associated with.
     * @hibernate.many-to-one column="GENUS_ID" class="edu.ucdavis.caelmir.domain.subject.Genus" constrained="true"
     */
	public edu.ucdavis.caelmir.domain.subject.Genus getGenus() {
		return genus;
	}

	
	public void setGenus(edu.ucdavis.caelmir.domain.subject.Genus genus) {
		this.genus = genus;
	}

	 /**
     * @return species object this animal is associated with.
     * @hibernate.many-to-one column="SPECIES_ID" class="edu.ucdavis.caelmir.domain.subject.Species" constrained="true"
     */
	public edu.ucdavis.caelmir.domain.subject.Species getSpecies() {
		return species;
	}

	public void setSpecies(edu.ucdavis.caelmir.domain.subject.Species species) {
		this.species = species;
	}

	
	  /**
     * @return
     * @hibernate.property name="animalNumber" type="string" column="ANIMAL_NUMBER" length="100"
     */
	    public java.lang.String getAnimalNumber() {
			return animalNumber;
		}
	
		public void setAnimalNumber(java.lang.String animalNumber) {
			this.animalNumber = animalNumber;
		}
	
	
	/**
     * @return
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_ANIMAL_SEQ"
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * @return
     * @hibernate.property name="backgroundStrain" type="string" column="BACKGROUND_STRAIN" length="100"
     */
    public String getBackgroundStrain()
    {
        return backgroundStrain;
    }

    public void setBackgroundStrain(String backgroundStrain)
    {
        this.backgroundStrain = backgroundStrain;
    }

    /**
     * @return
     * @hibernate.property name="strain" column="STRAIN" type="string" length="100"
     */
    public String getStrain()
    {
        return strain;
    }

    public void setStrain(String strain)
    {
        this.strain = strain;
    }

    /**
     * @return Returns the startDate.
     * @hibernate.property name="birthDate" column="BIRTH_DATE" type="date"
     */
    public Date getBirthDate()
    {
        return birthDate;
    }

    public void setBirthDate(Date birthDate)
    {
        this.birthDate = birthDate;
    }

    /**
     * @return
     * @hibernate.property name="sex" column="SEX" type="character" length="10"
     */
    public Character getSex()
    {
        return sex;
    }

    public void setSex(Character sex)
    {
        this.sex = sex;
    }

    /**
     * @return
     * @hibernate.property name="length" column="LENGTH" type="double"
     */
    public Double getLength()
    {
        return length;
    }

    public void setLength(Double length)
    {
        this.length = length;
    }

    /**
     * @return
     * @hibernate.property name="weight" column="WEIGHT" type="double"
     */
    public Double getWeight()
    {
        return weight;
    }

    public void setWeight(Double weight)
    {
        this.weight = weight;
    }

    /**
     * @return Returns the activityStatus.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

   

    /**
     * @return
     * @hibernate.many-to-one column="COHORT_ID" class="edu.ucdavis.caelmir.domain.subject.Cohort" cascade="none"
     * constrained="true"
     */

    public edu.ucdavis.caelmir.domain.subject.Cohort getCohort()
    {

        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.subject.Animal thisIdSet = new edu.ucdavis.caelmir.domain.subject.Animal();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.subject.Cohort", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                cohort = (edu.ucdavis.caelmir.domain.subject.Cohort)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Animal:getCohort throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return cohort;

    }

    public void setCohort(edu.ucdavis.caelmir.domain.subject.Cohort cohort)
    {
        this.cohort = cohort;
    }
    
    
    /**
     * @return
     * @hibernate.set name="genotypeCollection" table="CAELMIR_ANIMAL_GENOTYPE"
     * cascade="none" inverse="false" lazy="false"
     * @hibernate.collection-key column="ANIMAL_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.subject.Genotype" column="GENOTYPE_ID"
     */

    public Collection getGenotypeCollection()
    {
        //			try{
        //			   if(genotypeCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.subject.Animal thisIdSet = new edu.ucdavis.caelmir.domain.subject.Animal();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.subject.Genotype", thisIdSet);				 
        //				 	genotypeCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Animal:getGenotypeCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return genotypeCollection;
    }

    public void setGenotypeCollection(Collection genotypeCollection)
    {
        this.genotypeCollection = genotypeCollection;
    }



    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Animal)
        {
            Animal c = (Animal) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

   
    /**
     * @return identifier of animal
     */
    public Long getSystemIdentifier()
    {
        return id;
    }

    /**
     * @param systemIdentifier unique identifier of animal
     */
    public void setSystemIdentifier(Long systemIdentifier)
    {
        id = systemIdentifier;

    }
    /**
     * @return Returns the eventRecordsCollection.
     *    
     * @hibernate.set name="eventRecordsCollection" table="CAELMIR_EVENT_RECORDS"
     * cascade="save-update" inverse="true" lazy="false"
     * @hibernate.collection-key column="ANIMAL_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.eventRecords.EventRecords"
     */
    public Collection getEventRecordsCollection()
    {
        return eventRecordsCollection;
    }
    /**
     * @param eventRecordsCollection The eventRecordsCollection to set.
     */
    public void setEventRecordsCollection(Collection eventRecordsCollection)
    {
        this.eventRecordsCollection = eventRecordsCollection;
    }
    
    public static void setAnimalStatus(Collection animalColl,String status,Boolean setCohort)
    {
        if(animalColl != null && !animalColl.isEmpty())
        {
            Iterator animalIterator = animalColl.iterator();
            while(animalIterator.hasNext())
            {
                Animal animal = (Animal) animalIterator.next();
                if(status.equalsIgnoreCase(Constants.ACTIVITY_STATUS_DISABLED) && setCohort.booleanValue())
                { 
                    animal.setActivityStatus(Constants.ACTIVITY_STATUS_DISABLED);
                    animal.setCohort(null);
                }
                
               if(status.equalsIgnoreCase(Constants.ACTIVITY_STATUS_PUBLISHED))
               {              
                   Collection eventRecordsColl= animal.getEventRecordsCollection();
                   EventRecords.setEventRecordStatus(eventRecordsColl,status);
               }
            }
        }
    }
}