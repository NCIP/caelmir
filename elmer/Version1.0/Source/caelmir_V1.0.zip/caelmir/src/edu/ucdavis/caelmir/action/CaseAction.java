
package edu.ucdavis.caelmir.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.CaseForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.security.exceptions.SMException;
import edu.wustl.common.util.Utility;
import edu.wustl.common.util.dbManager.DAOException;
import gov.nih.nci.security.authorization.domainobjects.ProtectionGroup;
import gov.nih.nci.security.exceptions.CSException;
import gov.nih.nci.security.exceptions.CSTransactionException;

/**Description: This class is used as an action class for adding experimnental data for a cohort for pathology'
 * protocol.
 * <BR>The class populates all the request parameters and handles all the incoming and outgoing 
 * requests for the described scenario.
 * @see  org.apache.struts.action.Action
 * Copyright:TODO
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class CaseAction extends BaseAction
{

    /**This method is called when user clicks on the "add" link for the experimental data for pathology protocol.
     * <br>The method populates all the required lists and passes the control onto the appropriate page.
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     */

    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
    {
        CaseForm caseForm = (CaseForm) form;

        StorageManager store = new StorageManager();

        if ((store.getMap("caseForm") != null
                && caseForm.getForwardTo() != null && caseForm.getForwardTo()
                .equalsIgnoreCase(Constants.SUCCESS))
                || (caseForm.getSubmittedFor() != null && (caseForm
                        .getSubmittedFor().equalsIgnoreCase("") || caseForm
                        .getSubmittedFor().equals("Default"))))
        //&& caseForm.getActivity() != null && caseForm.getActivity().equalsIgnoreCase(Constants.EDIT))
        {
            CaseForm newCaseForm = (CaseForm) store.getMap("caseForm");
            if (caseForm.getEntityMapId() == null)
            {
                setFormValues(caseForm, newCaseForm);
                //store.remove("caseForm_"+caseForm.getAnimalId());
                store.remove("caseForm");
            }
            else
            {
                if (store.getMap("caseForm") != null)
                    //store.remove("caseForm_"+caseForm.getAnimalId());        
                    store.remove("caseForm");
            }

        }
        else
        {
            if (store.getMap("caseForm") != null)
                store.remove("caseForm");
        }

        String operation = request.getParameter(Constants.OPERATION);

        String pageOf = (String) request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        if (caseForm.getAnimalId() == null
                || caseForm.getAnimalId().toString().equals("0"))
        {
            String ID = (String) request.getParameter("animalId");//for approval 
            if (ID != null && ID.length() > 0)
                caseForm.setAnimalId(new Long(ID));
        }

        try
        {
            List tissueList = new ArrayList();

            tissueList = getSelectedTissues(caseForm);
            HttpSession session = request.getSession();

            String str = "_" + formString(caseForm);

            if (caseForm.getForwardTo() != null
                    && caseForm.getForwardTo().equals(Constants.SUCCESS))//not add new
                checkContents(tissueList, session, str);

            if (session.getAttribute(Constants.SLIDE_LIST) != null)
                session.removeAttribute(Constants.SLIDE_LIST);

            //  session.setAttribute(Constants.TISSUE_LIST, tissueList);

            session.setAttribute(Constants.TISSUE_LIST + str, tissueList);
            request.setAttribute(Constants.TISSUE_LIST, tissueList);

            String target = request.getParameter(Constants.TARGET);
            request.setAttribute(Constants.TARGET, target);
            String gross = caseForm.getGross();

            request.setAttribute(Constants.GROSS, gross);
            String pathologyNumber = caseForm.getPathologyNumber();//request.getParameter(Constants.PATHOLOGY_NUMBER);
            if (pathologyNumber != null)
            {
                String[] microDescription = new String[3];
                if (target != null && target.equals(Constants.API))
                {
                    microDescription = getImportMicroDescription(form,
                            pathologyNumber);

                    if (microDescription[0] == null)
                        microDescription[0] = "";
                    if (microDescription[1] == null)
                        microDescription[1] = "";
                    if (microDescription[2] == null)
                        microDescription[2] = "";

                    request.setAttribute(Constants.PATHOLOGY_NUMBER,
                            pathologyNumber);
                    request.setAttribute(Constants.MICROSCOPIC_DESC,
                            microDescription[0]);
                    request.setAttribute(Constants.DIAGNOSIS,
                            microDescription[1]);

                    request.setAttribute(Constants.PATHOLOGY_DATE,
                            microDescription[2]);

                }
            }
            Animal mouse = new Mouse();
            if (operation != null && operation.equalsIgnoreCase("addOrEdit")
                    || operation.equalsIgnoreCase(Constants.VIEW))
            {
                DefaultBizLogic defaultBizLogic = BizLogicFactory
                        .getDefaultBizLogic();

                if (caseForm.getAnimalId() != null
                        && !caseForm.getAnimalId().toString().equals("0"))
                {
                    List animalList = defaultBizLogic.retrieve(Mouse.class
                            .getName(), Constants.ID, caseForm.getAnimalId());

                    if (animalList != null)
                    {
                        mouse = (Animal) animalList.get(0);
                        request
                                .setAttribute("animal", mouse.getId()
                                        .toString());
                        request.setAttribute(Constants.ANIMAL_ID, mouse.getId()
                                .toString());

                        request.setAttribute("event", caseForm.getEventId());
                        request.setAttribute("Experiment", mouse.getCohort()
                                .getExperiment().getName());
                        /* Collection collection = mouse.getCohort()
                         .getExperiment()
                         .getCollectionProtocolCollection();
                         if (collection != null && !collection.isEmpty())
                         {
                         Iterator iterator = collection.iterator();
                         while (iterator.hasNext())
                         {
                         CollectionProtocol collectionProtocol = (CollectionProtocol) iterator
                         .next();
                         if (collectionProtocol.getId().equals(
                         new Long(caseForm.getProtocolId())))
                         {
                         request.setAttribute("protocol",
                         collectionProtocol.getTitle());
                         }
                         }
                         }*/
                    }

                    /* modify on Nov,27th */

                    if (operation != null
                            && (operation.equalsIgnoreCase(Constants.VIEW)))
                    {
                        Long systemIdentifier = new Long(caseForm.getId());

                        List list = defaultBizLogic.retrieve(
                                PathologyEventRecords.class.getName(), "id",
                                systemIdentifier);

                        PathologyEventRecords pathologyEventRecords = null;

                        if (list != null && !list.isEmpty())
                        {
                            pathologyEventRecords = (PathologyEventRecords) list
                                    .get(0);
                        }

                        if (pathologyEventRecords != null)
                        {

                            EntityMap entityMap = (EntityMap) pathologyEventRecords
                                    .getEntityMap();
                            if (entityMap != null)
                            {
                                if (entityMap.getCollectionProtocolEvent() != null
                                        && entityMap
                                                .getCollectionProtocolEvent()
                                                .getCollectionProtocol()
                                                .getId() != null)
                                {
                                    request
                                            .setAttribute(
                                                    "protocol",
                                                    entityMap
                                                            .getCollectionProtocolEvent()
                                                            .getCollectionProtocol()
                                                            .getTitle());
                                    request
                                            .setAttribute(
                                                    "protocolId",
                                                    entityMap
                                                            .getCollectionProtocolEvent()
                                                            .getCollectionProtocol()
                                                            .getId().toString());
                                }
                            }
                        }
                    }
                    /* end  */

                    List list = defaultBizLogic.retrieve(
                            PathologyEventRecords.class.getName(), "animal",
                            mouse);
                    if (list != null && !list.isEmpty())
                    {
                        Iterator listIterator = list.iterator();
                        while (listIterator.hasNext())
                        {
                            EventRecords eventRecord = (EventRecords) listIterator
                                    .next();
                            if (eventRecord != null
                                    && !eventRecord
                                            .getActivityStatus()
                                            .equalsIgnoreCase(
                                                    Constants.ACTIVITY_STATUS_DISABLED))
                            {
                                //if not status is not disabled 
                                EntityMap entityMap = (EntityMap) eventRecord
                                        .getEntityMap();
                                if (entityMap.getId() != null
                                        && caseForm.getEntityMapId() != null
                                        && entityMap.getId().equals(
                                                new Long(caseForm
                                                        .getEntityMapId())))
                                {
                                    caseForm.setOperation(Constants.EDIT);
                                    operation = Constants.EDIT;
                                    caseForm.setId(eventRecord.getId()
                                            .longValue());
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            if (caseForm.getAnimalId() != null
                    && !caseForm.getAnimalId().toString().equals("0"))
            {
                if (operation != null
                        && operation.equalsIgnoreCase("addOrEdit"))
                {
                    operation = Constants.ADD;
                    caseForm.setOperation(Constants.ADD);
                }

                String caseIdentifier = (String) request
                        .getAttribute(Constants.CASE_IDENTIFIER);
                String systemIdentifier = String.valueOf(caseForm.getId());
                if (caseIdentifier == null
                        && systemIdentifier != null
                        && !systemIdentifier
                                .equalsIgnoreCase(Constants.ZERO_STRING))
                {
                    caseIdentifier = systemIdentifier;
                }
                else if ((systemIdentifier == null || systemIdentifier
                        .equalsIgnoreCase(Constants.ZERO_STRING))
                        && caseIdentifier != null)
                {
                    caseForm.setId(Long.parseLong(caseIdentifier));
                }

                try
                {
                    populateCase(caseForm, request, caseIdentifier, operation);
                }
                catch (Exception daoException)
                {
                }

            }

            if (operation != null && operation.equalsIgnoreCase(Constants.EDIT))
            { //check for delete privelege
                if (isAccessPresent(request, Permissions.EXPDATA_DELETE,
                        Permissions.EXPDATA_DELETE_ACCESS_DENIED))
                {
                    request.setAttribute(Constants.DELETE_PRIVILEGE,
                            new Boolean(true));

                    //find the role of the user                    
                    boolean role = getRole(request, mouse);
                    request
                            .setAttribute(Constants.USER_ROLE,
                                    new Boolean(role));
                }
                else
                {
                    request.setAttribute(Constants.DELETE_PRIVILEGE,
                            new Boolean(false));
                }
            }
            //store.setMap("caseForm",caseForm);

        }
        catch (DAOException daoException)
        {
            return mapping.findForward(new String(Constants.FAILURE));
        }
        catch (Exception daoException)
        {
            return mapping.findForward(new String(Constants.FAILURE));
        }
        //caseForm.setForwardTo(Constants.PAGE_OF_EXPERIMENTAL_DATA);
        request.setAttribute(Constants.OPERATION, operation);

        if (pageOf != null
                && pageOf.equalsIgnoreCase(Constants.PAGE_OF_CASE_APPROVE))
        {
            request.setAttribute(Constants.ACTIVITYSTATUSLIST,
                    Constants.EXPDATA_ACTIVITY_STATUS_VALUES);
            return mapping.findForward(Constants.PAGE_OF_CASE_APPROVE);
        }

        if (caseForm.getAnimalId() != null
                && !caseForm.getAnimalId().toString().equals("0"))
        {
            if (!operation.equalsIgnoreCase(Constants.VIEW))
                return mapping.findForward(Constants.PAGE_OF_CASE);
        }
        if (caseForm.getOperation() != null
                && caseForm.getOperation().equalsIgnoreCase(Constants.VIEW))
            //return mapping.findForward(Constants.PAGE_OF_CASE_VIEW);
            return mapping.findForward(pageOf);
        else
            return mapping.findForward(Constants.FAILURE);
    }

    private String formString(CaseForm caseForm)
    {
        String str = "";
        if (caseForm.getEventId() != null && caseForm.getProtocolId() != null
                && caseForm.getAnimalId() != null)
            str = caseForm.getEventId() + "_" + caseForm.getProtocolId() + "_"
                    + caseForm.getAnimalId();
        return str;
    }

    private void checkContents(List tissueList, HttpSession session, String str)
    {
        if (session.getAttribute(Constants.TISSUE_LIST + str) != null)
        {
            List list = (List) session
                    .getAttribute(Constants.TISSUE_LIST + str);
            Iterator it = list.iterator();
            while (it.hasNext())
            {
                //Slideit.next();
                NameValueBean bean = (NameValueBean) it.next();
                Iterator tissueIt = tissueList.iterator();
                boolean flag = false;
                while (tissueIt.hasNext())
                {
                    NameValueBean bean1 = (NameValueBean) tissueIt.next();
                    if (bean1.getValue().equals(bean.getValue()))
                        flag = true;
                }
                if (!flag)
                    tissueList.add(bean);
            }
        }
    }

    private CaseForm setFormValues(CaseForm destn, CaseForm src)
    {
        destn.setActivityStatus(src.getActivityStatus());
        destn.setAnimalId(src.getAnimalId());
        destn.setCaseIdentifier(src.getCaseIdentifier());
        destn.setCohortId(src.getCohortId());
        destn.setAin(src.getAin());
        destn.setDateSubmitted(src.getDateSubmitted());
        destn.setDiagnosis(src.getDiagnosis());
        destn.setEntityMapId(src.getEntityMapId());
        destn.setMicroscopicDescription(src.getMicroscopicDescription());
        destn.setGross(src.getGross());
        destn.setId(src.getId());
        destn.setPathologyNumber(src.getPathologyNumber());

        if (destn.getPageOf() != null)
            destn.setPageOf(src.getPageOf());

        //  destn.setOperation(src.getOperation());
        destn.setExperimentIdentifier(src.getExperimentIdentifier());
        destn.setEventId(src.getEventId());
        // destn.setForwardTo(src.getForwardTo());
        //destn.setForwardTo("");
        destn.setProtocolId(src.getProtocolId());
        destn.setTarget(src.getTarget());
        destn.setTissueArr(src.getTissueArr());
        //   destn.setSubmittedFor(src.getSubmittedFor());
        //  destn.setSubmittedFor("");
        //destn.set
        return destn;

    }

    private boolean getRole(HttpServletRequest request, Animal mouse)
            throws DAOException
    {
        boolean role = false;

        SessionDataBean sessionDataBean = (SessionDataBean) request
                .getSession().getAttribute(Constants.SESSION_DATA);

        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List creatorlist = (List) bizLogic.retrieve(User.class.getName(),
                Constants.ID, sessionDataBean.getUserId());

        User user = null;
        if (creatorlist != null && !creatorlist.isEmpty())
        {
            user = (User) creatorlist.get(0);
            //          get the role of the user for that study then its default role.
            if (getStudyRole(mouse, user.getId().toString()))
            {
                role = true;
            }
            else if (user.getRoleId().toString().equalsIgnoreCase("3")) //if the loginned user is DC
                role = true;
        }

        return role;
    }

    public boolean getStudyRole(Animal mouse, String id)
    {
        boolean flag = false;
        ProtectionGroup protectionGroup = null;
        if (mouse != null)
        {
            try
            {
                String studyId = null;
                if (mouse.getCohort() != null
                        && mouse.getCohort().getExperiment() != null
                        && mouse.getCohort().getExperiment().getStudy() != null
                        && mouse.getCohort().getExperiment().getStudy().getId() != null)
                {
                    studyId = mouse.getCohort().getExperiment().getStudy()
                            .getId().toString();
                    protectionGroup = SecurityManager.getInstance(
                            this.getClass()).getProtectionGroup(
                            "STUDY_" + studyId);

                    String roles[] = null;
                    userRoleAction act = new userRoleAction();
                    if (SecurityManager.getInstance(this.getClass())
                            .getuserRoleFromPG(act.getCsmUserId(id),
                                    protectionGroup) != null)
                    {
                        roles = SecurityManager.getInstance(this.getClass())
                                .getuserRoleFromPG(act.getCsmUserId(id),
                                        protectionGroup);
                        if (roles != null && roles[0] != null
                                && roles[0].equalsIgnoreCase("3")) //if the loginned user is DC
                            return true;
                    }
                }
            }
            catch (SMException e)
            {
            }
            catch (CSTransactionException e)
            {
            }
            catch (CSException e)
            {
            }

        }
        return flag;
    }

    /**This method is used to populate the action form depending on the case object passed to the method as an argument.
     * @param caseForm Action form for case object
     * @param caseIdentifier Identifier of the object which is to be shown on the page.
     * @param request to set some request attributes.
     * @throws DAOException DAOException is thrown by the bizlogic layer.
     */
    public void populateCase(CaseForm caseForm, HttpServletRequest request,
            String caseIdentifier, String operation) throws DAOException,
            Exception
    {
        String target = request.getParameter(Constants.TARGET);
        request.setAttribute(Constants.TARGET, target);

        DefaultBizLogic bizLogic = (DefaultBizLogic) BizLogicFactory
                .getBizLogic(caseForm.getFormId());
        List caseObjectList = bizLogic.retrieve(PathologyEventRecords.class
                .getName(), Constants.ID, new Long(caseIdentifier));
        PathologyEventRecords caseObject = (PathologyEventRecords) caseObjectList
                .get(0);
        if (caseObject != null && caseObject.getAnimal() != null)
        {
            caseForm.setAnimalId(caseObject.getAnimal().getId());
        }

        if (target == null)
        {

            if (caseObject.getPathologyNumber() != null)
            {
                caseForm.setPathologyNumber(caseObject.getPathologyNumber());
            }

            if (caseObject.getSubmittedDate() != null)
            {
                caseForm
                        .setDateSubmitted(Utility.parseDateToString(caseObject
                                .getSubmittedDate(),
                                Constants.DATE_PATTERN_MM_DD_YYYY));
            }
            //caseForm.setGross(caseObject.getGross());
            if (caseObject.getMicroscopicDescription() != null)
            {
                caseForm.setMicroscopicDescription(caseObject
                        .getMicroscopicDescription());
            }
            if (caseObject.getDiagnosis() != null)
            {
                caseForm.setDiagnosis(caseObject.getDiagnosis());
            }
        }
        if (caseObject.getGross() != null)
        {
            caseForm.setGross(caseObject.getGross());
        }

        if (operation != null
                && operation.equals(Constants.EDIT)
                && (caseForm.getForwardTo().equals(Constants.SUCCESS)
                        || caseForm.getForwardTo() == null || caseForm
                        .getForwardTo().equals("")))
        {
            Collection tissueCollection = caseObject.getTissueCollection();
            List tissueList = new ArrayList();
            if (tissueCollection != null && !tissueCollection.isEmpty())
            {
                Iterator tissueIterator = tissueCollection.iterator();
                Tissue tissue;

                caseForm.setTissueArr(new String[tissueCollection.size()]);

                int i = 0;
                while (tissueIterator.hasNext())
                {
                    tissue = (Tissue) tissueIterator.next();
                    tissueList.add(new NameValueBean(tissue
                            .getTissueShortName().toString(), tissue.getId()
                            .toString()));
                    caseForm.getTissueArr()[i++] = tissue.getId().toString();
                }

                HttpSession session = request.getSession();
                String str = "_" + formString(caseForm);

                checkContents(tissueList, session, str);
                session.setAttribute(Constants.TISSUE_LIST + str, tissueList);
                request.setAttribute(Constants.TISSUE_LIST, tissueList);
            }
        }

        request.setAttribute(Constants.CASE_IDENTIFIER, caseObject.getId()
                .toString());
    }

    /**
     * To check whether particular privilege is granted for this class 
     * @param request
     * @param privilege
     * @param accessDeniedMessage
     * @return true if access is present otherwise false
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                EventRecords.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

    /**
     * 
     * @param form to get some fields
     * @return List of namevalue bean pairs of cohort object which are selected in creation of experiment. 
     * @throws Exception
     */
    private List getSelectedTissues(ActionForm form) throws Exception
    {
        List tissuelist = new ArrayList();
        CaseForm cform = (CaseForm) form;
        String[] displayNameFields = {"tissueLongName"};
        String[] whereColumnName = {"id"};
        String[] whereColumnCondition = {"="};
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (cform.getTissueArr() != null)
            for (int i = 0; i < cform.getTissueArr().length; i++)
            {
                Object[] whereColumnValue = {cform.getTissueArr()[i]};
                List list = bizLogic.getList(Tissue.class.getName(),
                        displayNameFields, "id", whereColumnName,
                        whereColumnCondition, whereColumnValue, null, null,
                        false);
                if (list.size() > 1)
                    tissuelist.add(list.get(1));
            }
        return tissuelist;
    }

    /**This method is used to get the list of NameValueBean objects for the TgMouse object.
     * Returns pathologhy number list 
     * @param form Action form for case object.
     * @return List list of "NameValueBean" objects containing pathnum as name and value.
     * @throws DAOException
     */
    public List getPathologyNumberList(ActionForm form, List tgMouseObjects)
            throws DAOException
    {
        CaseForm caseForm = (CaseForm) form;
        Iterator tgMouseIterator = tgMouseObjects.iterator();
        PathologyEventRecords tgMouse;
        List pathologyNumberList = new ArrayList();
        while (tgMouseIterator.hasNext())
        {
            tgMouse = (PathologyEventRecords) tgMouseIterator.next();
            pathologyNumberList.add(new NameValueBean(tgMouse
                    .getPathologyNumber(), tgMouse.getPathologyNumber()));
        }
        tgMouseIterator = tgMouseObjects.iterator();
        tgMouse = (PathologyEventRecords) tgMouseIterator.next();
        caseForm.setMicroscopicDescription(tgMouse.getMicroscopicDescription());
        caseForm.setDiagnosis(tgMouse.getDiagnosis());
        return pathologyNumberList;
    }

    /**
     * This method is used to get the string array of micro description for all the tgmouse objects.
     * @return String [] string array containing the micro descriptions.
     * @param pathologyNumber Pathology number for the tgMouse.
     * @param tgMouseObjects List of TgMouse objects.  
     * @return
     */
    public String[] getMicroDescription(List tgMouseObjects,
            String pathologyNumber) throws DAOException
    {
        Iterator tgMouseIterator = tgMouseObjects.iterator();
        PathologyEventRecords tgMouse;
        String[] microDescription = new String[3];
        while (tgMouseIterator.hasNext())
        {
            tgMouse = (PathologyEventRecords) tgMouseIterator.next();
            if (tgMouse.getPathologyNumber().equals(pathologyNumber))
            {
                microDescription[0] = tgMouse.getMicroscopicDescription();
                microDescription[1] = tgMouse.getDiagnosis();
                microDescription[2] = Utility.toString(tgMouse
                        .getSubmittedDate());

            }
        }

        return microDescription;

    }

    /** This method is used to get the list of all the TgMouse objects.
     * Returns tg mouse list
     * @param form Abstract action form required to get the proper biz logic factory.
     * @return List List of TgMouse objects.
     * @throws DAOException
     */
    public List getTgMouseList(ActionForm form) throws DAOException
    {
        AbstractActionForm abstractForm = (AbstractActionForm) form;
        AbstractBizLogic bizLogic = BizLogicFactory.getBizLogic(abstractForm
                .getFormId());
        String sourceObjectName = "TgMouse";
        List tgMouseObjects;
        try
        {
            tgMouseObjects = bizLogic.retrieve(sourceObjectName);
        }
        catch (DAOException daoException)
        {
            throw daoException;
        }
        return tgMouseObjects;

    }

    private String[] getImportMicroDescription(ActionForm form,
            String pathologyNumber)
    {
        String[] microDescription = new String[3];
        //   CaseForm caseForm = (CaseForm)form;

        StorageManager cache = new StorageManager();
        List list = (List) cache.getMap(Constants.PATHOLOGY_LIST);

        for (int i = 0; i < list.size(); i++)
        {
            PathologyEventRecords tgMouse = (PathologyEventRecords) list.get(i);
            if (tgMouse.getPathologyNumber().equals(pathologyNumber))
            {

                microDescription[1] = tgMouse.getDiagnosis();
                microDescription[0] = tgMouse.getMicroscopicDescription();
                microDescription[2] = Utility.toString(tgMouse
                        .getSubmittedDate());

                SimpleDateFormat sdf = new SimpleDateFormat(
                        Constants.DATE_PATTERN_MM_DD_YYYY);

                microDescription[2] = Utility.toString(sdf.format(tgMouse
                        .getSubmittedDate()));

                break;
            }
        }

        return microDescription;

    }

}