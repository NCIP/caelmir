
package edu.ucdavis.caelmir.actionForm;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;

/**
 * @author sujay_narkar
 */
public class AddDataForm extends AbstractActionForm {
    /**
     * 
     */
    String studyIdentifier;
    
    /**
     * 
     */
    String experimentIdentifier;
    /**
     * 
     */
    String protocolIdentifier;
    /***/
    String cohortIdentifier;
    
    /***/
    Boolean cohortChanged = new Boolean(false);
    
    /***/
    Boolean studyChanged = new Boolean(false);
    
    
    
    public Boolean getStudyChanged()
    {
        return studyChanged;
    }


    
    public void setStudyChanged(Boolean studyChanged)
    {
        this.studyChanged = studyChanged;
    }


    public Boolean getCohortChanged()
    {
        return cohortChanged;
    }

    
    public void setCohortChanged(Boolean cohortChanged)
    {
        this.cohortChanged = cohortChanged;
    }

    public String getCohortIdentifier() {
		return cohortIdentifier;
	}

	public void setCohortIdentifier(String cohortIdentifier) {
		this.cohortIdentifier = cohortIdentifier;
	}

	/**
     * 
     */
    public void setAllValues(AbstractDomainObject abstractDomain)   {
        
    }
    
    /**
     * 
     */
    public void reset() {
        
    }
    
    /**
     * Returns the id assigned to form bean.
     * @return the id assigned to form bean.
     */
    public int getFormId() {
        return Constants.STUDY_FORM_ID;
    }
    

	/**
	 * @return Returns the experimentIdentifier.
	 */
	public String getExperimentIdentifier() {
		return experimentIdentifier;
	}
	/**
	 * @param experimentIdentifier The experimentIdentifier to set.
	 */
	public void setExperimentIdentifier(String experimentIdentifier) {
		this.experimentIdentifier = experimentIdentifier;
	}
	/**
	 * @return Returns the studyIdentifier.
	 */
	public String getStudyIdentifier() {
		return studyIdentifier;
	}
	/**
	 * @param studyIdentifier The studyIdentifier to set.
	 */
	public void setStudyIdentifier(String studyIdentifier) {
		this.studyIdentifier = studyIdentifier;
	}
	/**
	 * @return Returns the protocolIdentifier.
	 */
	public String getProtocolIdentifier() {
		return protocolIdentifier;
	}
	/**
	 * @param protocolIdentifier The protocolIdentifier to set.
	 */
	public void setProtocolIdentifier(String protocolIdentifier) {
		this.protocolIdentifier = protocolIdentifier;
	}
	
	/**
     * Overrides the validate method of ActionForm.
     * */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
    	ActionErrors errors = new ActionErrors();
    	if(this.experimentIdentifier == null || this.experimentIdentifier.trim().length()==0) {
        	errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("app.experiment")));
        }
    	if(this.cohortIdentifier == null || this.cohortIdentifier.trim().length()==0) {
        	errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("app.cohort")));
        }
        return errors;
    }
}
