/**
 *<p>Title: ExperimentAction Class </p>
 *<p>Description: This class initializes the field and redirect to Add/Edit Experiment webpage.</p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import edu.ucdavis.caelmir.actionForm.CohortForm;
import edu.ucdavis.caelmir.actionForm.ExperimentForm;
import edu.ucdavis.caelmir.actionForm.StudyForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.util.CommonUtility;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PreferenceManager;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.UserAccessManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.security.exceptions.SMException;
import edu.wustl.common.util.dbManager.DAOException;
import gov.nih.nci.security.authorization.domainobjects.ProtectionGroup;
import gov.nih.nci.security.exceptions.CSException;

/**
 * This class initializes the fields in the Experiment Add/Edit webpage.
 * @author shital_lawhale
 */

public class ExperimentAction extends BaseAction
{

    /**
     * Overrides the execute method of Action class.
     * Sets the various fields in Experiment Add/Edit webpage.
     * */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {

        String operation = request.getParameter(Constants.OPERATION);

        boolean isAccessPresent = true;
        if (operation != null && operation.equalsIgnoreCase(Constants.ADD))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.EXPERIMENT_CREATE,
                    Permissions.EXPERIMENT_CREATE_ACCESS_DENIED);
        }
        else if (operation != null
                && operation.equalsIgnoreCase(Constants.EDIT))
        {
            Long id = getId(((ExperimentForm) form).getSystemIdentifier());
            int accessPresent = 1;

            if (id != null)
                accessPresent = CommonUtility.checkForOtherRole(id.longValue(),
                        request, Permissions.EXPERIMENT_UPDATE);

            if (accessPresent == 2) //no permission
            {
                request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                        Permissions.EXPERIMENT_UPDATE_ACCESS_DENIED);
                return mapping
                        .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
            }

            if (accessPresent == 1) //user not present so default role
            {
                isAccessPresent = isAccessPresent(request,
                        Permissions.EXPERIMENT_UPDATE,
                        Permissions.EXPERIMENT_UPDATE_ACCESS_DENIED);

                if (isAccessPresent)
                {
                    String status = ((ExperimentForm) form).getActivityStatus();
                    if (status.equals(Constants.ACTIVITY_STATUS_PUBLISHED)
                            || status.equals(Constants.ACTIVITY_STATUS_CLOSED))
                    {
                        if (status.equals(Constants.ACTIVITY_STATUS_PUBLISHED))
                            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                                    Constants.EXPERIMENT_PUBLISHED);
                        else
                            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                                    Constants.EXPERIMENT_CLOSED);
                        return mapping
                                .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
                    }
                }
            }
        }
        else if (operation != null
                && operation.equalsIgnoreCase(Constants.VIEW))
        {
            
            
            long formId = ((ExperimentForm) form).getSystemIdentifier();
            if (formId == 0) {
               String sysId = request.getParameter(Constants.SYSTEM_IDENTIFIER);
               if(sysId != null) {
                   formId = new Long(sysId.trim()).longValue();
                   ((ExperimentForm) form).setSystemIdentifier(formId);
               }
            }
            Long id = getId(formId);
            int accessPresent = 1;
            if (id != null)
                accessPresent = CommonUtility.checkForOtherRole(id.longValue(),
                        request, Permissions.EXPERIMENT_READ);

            if (accessPresent == 2) //no permission
            {
                request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                        Permissions.EXPERIMENT_READ_ACCESS_DENIED);
                return mapping
                        .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
            }

            if (accessPresent == 1) //user not present so default role
            {
            isAccessPresent = isAccessPresent(request,
                    Permissions.EXPERIMENT_READ,
                    Permissions.EXPERIMENT_READ_ACCESS_DENIED);
            }
        }
        if (!isAccessPresent)
        {
            return mapping.findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
        }
        request.setAttribute(Constants.OPERATION, operation);
        String forwardTo = ((ExperimentForm) form).getForwardTo();
        if (forwardTo == null || forwardTo.equalsIgnoreCase(Constants.SUCCESS))
        {
            ((ExperimentForm) form).setForwardTo(Constants.POST_SAVE_PROCESS);
        }
        List protocolList = new ArrayList();
        List studyList = getStudyList(request.getSession());
        String studyID = null;
        studyID = request.getParameter(Constants.STUDY_ID);
        if (studyID == null)
        {
            if (!studyList.isEmpty())
            {
                String submittedFor = ((ExperimentForm) form).getSubmittedFor();
                if (submittedFor != null && !submittedFor.equalsIgnoreCase(""))
                { //add new action
                    studyID = ((ExperimentForm) form).getStudyIdentifier();
                    PreferenceManager.setUserPreference(request,
                            Constants.LAST_USED_STUDY_PREFERENCE, studyID);
                }
                else
                {
                    studyID = PreferenceManager.getUserPreferenceValue(request,
                            Constants.LAST_USED_STUDY_PREFERENCE);
                    if (studyID == null || studyID.equalsIgnoreCase(""))
                    {
                        NameValueBean nameValue = (NameValueBean) studyList
                                .get(0);
                        studyID = nameValue.getValue();
                    }
                    ((ExperimentForm) form).setStudyIdentifier(studyID);
                }
            }
        }
        else
        {
            PreferenceManager.setUserPreference(request,
                    Constants.LAST_USED_STUDY_PREFERENCE, studyID);
        }

        List userList = new ArrayList();
        List cohortList = new ArrayList();
        List groupList = new ArrayList();

        //------------For Add New--------------
        boolean flag = checkForAddNew(form);
        if (flag || operation.equals(Constants.EDIT)
                || operation.equals(Constants.ADD))
        {

            cohortList = getSelectedCohort(form);
            userList = getSelectedUsers(form, request);
            groupList = getSelectedGroups(form);
            protocolList = getSelectedProtocol(form);

        }

        if (operation != null
                && (operation.equalsIgnoreCase(Constants.EDIT) || operation
                        .equalsIgnoreCase(Constants.ADD)))
        {
            checkCreatePermission(form, request);

            if (isAccessPresent(request, Permissions.EXPERIMENT_DELETE,
                    Permissions.EXPERIMENT_DELETE_ACCESS_DENIED))
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        true));
            }
            else
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        false));
            }
            checkClosePermission(form, request);
        }

        if (operation != null && !(operation.equalsIgnoreCase(Constants.ADD)))
        {
            ExperimentForm experimentForm = (ExperimentForm) form;
            Long systemIdentifier = new Long(experimentForm
                    .getId());
            DefaultBizLogic defaultBizLogic = BizLogicFactory
                    .getDefaultBizLogic();
            List list = defaultBizLogic.retrieve(Experiment.class.getName(),
                    "id", systemIdentifier);
            Experiment experiment = null;
            if (list != null && !list.isEmpty())
            {
                experiment = (Experiment) list.get(0);
            }
            if (experiment != null)
            {

                SessionDataBean sessionDataBean = (SessionDataBean) request
                        .getSession().getAttribute(Constants.SESSION_DATA);

                if (experiment != null
                        && operation != null
                        && operation.equalsIgnoreCase(Constants.EDIT)
                        && !UserAccessManager.isUserPresentForExperiment(
                                experiment, sessionDataBean.getUserId()))
                {
                    request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                            Constants.EXPERIMENT_NOT_EDITABLE);
                    return mapping
                            .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD);
                }

                Study study = experiment.getStudy();
                if (study != null)
                {
                    request.setAttribute(Constants.STUDY_NAME, study.getName());
                }
            }
            //check for animal having experimental data or not.
            //if no then give msg                 
            checkForExpData(form, request);

        }

        request.setAttribute(Constants.USERLIST, userList);
        request.setAttribute(Constants.COHORT, cohortList);
        request.setAttribute(Constants.PROTOCOL_LIST, protocolList);
        request.setAttribute(Constants.GROUP_LIST, groupList);
        request.setAttribute(Constants.STUDYLIST, studyList);
        String pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        if (operation != null && operation.equals(Constants.VIEW))
            populateViewParameters(request, form);

        request.setAttribute(Constants.ACTIVITY_STATUS, ((ExperimentForm) form)
                .getActivityStatus());

        return mapping.findForward(pageOf);
    }

    private Long getId(long id)
    {
        Long identifier = null;
        try
        {
            if (new Long(id) != null)
            {
                if (id != 0)// != "")
                {

                    DefaultBizLogic defaultBizLogic = BizLogicFactory
                            .getDefaultBizLogic();

                    List experimentList = defaultBizLogic.retrieve(
                            Experiment.class.getName(), "id", new Long(id));
                    if (experimentList != null && !experimentList.isEmpty())
                    {
                        Experiment experiment = (Experiment) experimentList
                                .get(0);
                        if(experiment.getStudy() !=null )
                            identifier = experiment.getStudy().getId();
                    }
                }
            }
        }
        catch (DAOException e)
        {
        }
        return identifier;

    }

    public List getObjectListForProtocol(ActionForm form, String objectName)
            throws DAOException
    {

        AbstractActionForm abstractForm = (AbstractActionForm) form;
        AbstractBizLogic bizLogic = BizLogicFactory.getBizLogic(abstractForm
                .getFormId());

        String sourceObjectName = objectName;
        String[] displayNameFields = new String[1];
        displayNameFields[0] = "title";
        String valueField = Constants.ID;
        boolean isToExcludeDisabled = false;

        List objectList = bizLogic.getList(sourceObjectName, displayNameFields,
                valueField, isToExcludeDisabled);
        if (objectList != null && objectList.size() > 0)
        {
            objectList.remove(0);
        }
        return objectList;

    }

    /**
     * check whether "close" permission is granted or not.
     * @param form
     * @param request
     * @throws DAOException
     */
    private void checkClosePermission(ActionForm form,
            HttpServletRequest request) throws DAOException
    {
        ExperimentForm experimentForm = (ExperimentForm) form;
        long id = experimentForm.getId();
        Long currentUserId = (Long) ((SessionDataBean) request.getSession()
                .getAttribute(Constants.SESSION_DATA)).getUserId();
        if (new Long(id) != null)
        {
            DefaultBizLogic defaultBizLogic = BizLogicFactory
                    .getDefaultBizLogic();
            List experimentList = defaultBizLogic.retrieve(Experiment.class
                    .getName(), "id", new Long(id));
            if (experimentList != null && !experimentList.isEmpty())
            {
                Experiment experiment = (Experiment) experimentList.get(0);
                User user = experiment.getCreator();
                if (user != null)
                {
                    long pi = user.getId().longValue();
                    if (new Long(pi).equals(currentUserId))
                    {
                        request.setAttribute(Constants.CLOSE_PRIVILEGE,
                                new Boolean(true));
                    }
                    else
                    {
                        request.setAttribute(Constants.CLOSE_PRIVILEGE,
                                new Boolean(false));
                    }
                }
            }
        }

    }

    /**
     * 
     * @param session To get session data
     * @return All studies which are active and whose creator is the login user  
     * @throws DAOException
     */
    private List getStudyList(HttpSession session) throws DAOException
    {
        List permissibleStudyList = new ArrayList();
        try
        {
            SessionDataBean sessionDataBean = (SessionDataBean) session
                    .getAttribute(Constants.SESSION_DATA);
            List studyList = BizLogicFactory.getDefaultBizLogic().retrieve(
                    Study.class.getName());

            if (studyList != null && !studyList.isEmpty())
            {
                Iterator studyListIterator = studyList.iterator();
                while (studyListIterator.hasNext())
                {
                    Study study = (Study) studyListIterator.next();
                    if (study.getActivityStatus().equalsIgnoreCase(
                            Constants.ACTIVITY_STATUS_ACTIVE))
                    {
                        ProtectionGroup protectionGroup = SecurityManager
                                .getInstance(this.getClass())
                                .getProtectionGroup(
                                        "STUDY_" + study.getSystemIdentifier());

                        if (UserAccessManager.isUserPresentForStudy(study,
                                sessionDataBean.getUserId()) && getCsmUserId(sessionDataBean.getUserId()
                                        .toString() ) != null )
                        {
                            
                            int permission= SecurityManager
                            .getInstance(this.getClass())
                            .checkPrivilegeOnUserRolesForProtectionGroup(
                                    /*sessionDataBean.getUserId()
                                            .toString()*/getCsmUserId(sessionDataBean.getUserId()
                                                    .toString()),
                                    protectionGroup,
                                    Permissions.STUDY_CREATE);
                            if (permission == 3 || permission ==1)
                            {
                                permissibleStudyList.add(study);
                            }
                        }
                    }
                }
            }
        }
        catch (CSException e)
        {
        }
        catch (SMException e)
        {
        }

        Iterator permissibleStudyListIterator = permissibleStudyList.iterator();
        List nameValuePairs = new ArrayList();
        while (permissibleStudyListIterator.hasNext())
        {
            Study permissibleStudy = (Study) permissibleStudyListIterator
                    .next();
            NameValueBean nameValueBean = new NameValueBean(permissibleStudy
                    .getName(), permissibleStudy.getId());
            nameValuePairs.add(nameValueBean);
        }

        return nameValuePairs;
    }
    
    
    public   String  getCsmUserId(String id)
    {
        String csmId= null;
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List userList=new ArrayList();
        try
        {
            userList= bizLogic.retrieve(User.class.getName(),"id",id);
            
            if(userList!=null && !userList.isEmpty())
            {
                User user= (User)userList.get(0);
                csmId = user.getCsmUserId().toString();
            }
            
        }
        catch(DAOException e){}
        return csmId;
        
    }
   

    /**
     * 
     * @param studyID Identifier of the study
     * @return the list of the protocol which are declared in given study.
     */
    private List getSelectedProtocol(ActionForm form) throws DAOException
    {

        ExperimentForm eform = (ExperimentForm) form;
        DefaultBizLogic bizLogic = new DefaultBizLogic();

        String[] displayNameFields = new String[1];
        displayNameFields[0] = "title";
        String valueField = Constants.ID;
        String[] whereColumnName = {Constants.ID};
        String[] whereColumnCondition = {"="};

        List objectList = new ArrayList();

        if (eform.getProtocol() != null)
            for (int i = 0; i < eform.getProtocol().length; i++)
            {
                Object[] whereColumnValue = {eform.getProtocol()[i]};
                List list = bizLogic.getList(
                        CollectionProtocol.class.getName(), displayNameFields,
                        valueField, whereColumnName, whereColumnCondition,
                        whereColumnValue, null, null, false);
                objectList.add(list.get(1));
            }
        return objectList;

    }

    /**
     * Sets request parameters used to display on webpage in "view" operation.
     * @param request To set attributes
     * @param form to get some fields
     * @throws DAOException 
     */
    private void populateViewParameters(HttpServletRequest request,
            ActionForm form) throws DAOException
    {
        ExperimentForm eform = (ExperimentForm) form;
        Long systemIdentifier = new Long(eform.getId());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = defaultBizLogic.retrieve(Experiment.class.getName(), "id",
                systemIdentifier);
        Experiment experiment = null;

        if (list != null && !list.isEmpty())
        {
            experiment = (Experiment) list.get(0);
        }

        if (experiment != null)
        {
            Study study = (Study) experiment.getStudy();
            request.setAttribute(Constants.STUDY_NAME, study.getName());
            request.setAttribute(Constants.STUDY_ID, study.getId().toString());

            Collection collection = experiment
                    .getCollectionProtocolCollection();
            List protocolList = new ArrayList();
            if (collection != null)
            {
                Iterator protocolIterator = collection.iterator();
                while (protocolIterator.hasNext())
                {
                    CollectionProtocol protocol = (CollectionProtocol) protocolIterator
                            .next();

                    NameValueBean bean = new NameValueBean();
                    bean.setName(protocol.getTitle());
                    bean.setValue(protocol.getId().toString());
                    protocolList.add(bean);

                }
            }
            request.setAttribute(Constants.PROTOCOL_NAME_LIST, protocolList);

            List userList = new ArrayList();
            Collection userCollection = experiment.getUserCollection();
            if (userCollection != null)
            {
                Iterator userIterator = userCollection.iterator();
                while (userIterator.hasNext())
                {
                    User user = (User) userIterator.next();
                    String userName = user.getLastName() + ","
                            + user.getFirstName();
                    userList.add(userName);
                }
            }
            request.setAttribute(Constants.USER_NAME_LIST, userList);

            List userGroupList = new ArrayList();
            Collection userGroupCollection = experiment
                    .getUserGroupCollection();
            if (userGroupCollection != null)
            {
                Iterator userGroupIterator = userGroupCollection.iterator();
                while (userGroupIterator.hasNext())
                {
                    UserGroup userGroup = (UserGroup) userGroupIterator.next();
                    userGroupList.add(userGroup.getName());
                }
            }
            request.setAttribute(Constants.USER_GROUP_NAME_LIST, userGroupList);

            List cohortList = new ArrayList();
            Collection cohortCollection = experiment.getCohortCollection();
            if (cohortCollection != null)
            {
                Iterator cohortIterator = cohortCollection.iterator();
                while (cohortIterator.hasNext())
                {
                    Cohort cohort = (Cohort) cohortIterator.next();
                    cohortList.add(cohort.getName());
                    cohortList.add(cohort.getId());
                }
            }
            request.setAttribute(Constants.COHORT_NAME_LIST, cohortList);
            boolean editPermission = PrivilegeUtil.checkPrivilege(this
                    .getClass(), Experiment.class.getName(), request
                    .getSession(), Permissions.EXPERIMENT_UPDATE);
            if (!editPermission)
            {
                request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(
                        false));
            }
            else
            {
                request.setAttribute(Constants.EDIT_PRIVILEGE,
                        new Boolean(true));
            }
        }
    }

    /**
     * 
     * @param form to get some fields
     * @return List of namevalue bean pairs of cohort object which are selected in creation of experiment. 
     * @throws Exception
     */
    private List getSelectedCohort(ActionForm form) throws Exception
    {
        List cohortList = new ArrayList();
        ExperimentForm eform = (ExperimentForm) form;
        String[] displayNameFields = {"name"};
        String[] whereColumnName = {"id"};
        String[] whereColumnCondition = {"="};
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (eform.getCohort() != null)
            for (int i = 0; i < eform.getCohort().length; i++)
            {
                Object[] whereColumnValue = {eform.getCohort()[i]};
                List list = bizLogic.getList(Cohort.class.getName(),
                        displayNameFields, "id", whereColumnName,
                        whereColumnCondition, whereColumnValue, null, null,
                        false);
                if (list.size() > 1)
                    cohortList.add(list.get(1));
            }
        return cohortList;
    }

    /**
     * 
     * @param form to get some fields
     * @return List of namevalue bean pairs of user object which are selected in creation of experiment.
     * @throws Exception
     */
    private List getSelectedUsers(ActionForm form, HttpServletRequest request)
            throws Exception
    {

        List userList = new ArrayList();
        ExperimentForm eform = (ExperimentForm) form;
        String[] displayNameFields = {"firstName"};
        String[] whereColumnName = {"id"};
        String[] whereColumnCondition = {"="};
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (eform.getUsers() != null)
            for (int i = 0; i < eform.getUsers().length; i++)
            {
                Object[] whereColumnValue = {eform.getUsers()[i]};
                List list = bizLogic.getList(User.class.getName(),
                        displayNameFields, "id", whereColumnName,
                        whereColumnCondition, whereColumnValue, null, null,
                        false);

                NameValueBean bean = (NameValueBean) list.get(1);
                Long currentUserId = (Long) ((SessionDataBean) request
                        .getSession().getAttribute(Constants.SESSION_DATA))
                        .getUserId();
                if (!bean.getValue().equals(currentUserId.toString()))
                    userList.add(list.get(1));
            }
        return userList;
    }

    /**
     * 
     * @param form to get some fields
     * @return List of namevalue bean pairs of userGroup object which are selected in creation of experiment.
     * @throws Exception
     */
    private List getSelectedGroups(ActionForm form) throws Exception
    {
        List groupList = new ArrayList();

        ExperimentForm eform = (ExperimentForm) form;
        String[] displayNameFields = {"name"};
        String[] whereColumnName = {"id"};
        String[] whereColumnCondition = {"="};
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (eform.getGroups() != null)
            for (int i = 0; i < eform.getGroups().length; i++)
            {
                Object[] whereColumnValue = {eform.getGroups()[i]};
                List list = bizLogic.getList(UserGroup.class.getName(),
                        displayNameFields, "id", whereColumnName,
                        whereColumnCondition, whereColumnValue, null, null,
                        false);
                if (list.size() > 1)
                    groupList.add(list.get(1));
            }
        return groupList;
    }

    /**
     * To check whether particular privilege is granted for this class 
     * @param request
     * @param privilege
     * @param accessDeniedMessage
     * @return true if access is present otherwise false
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                Study.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

    /**
     * 
     * @param form to get some fields
     * @return List of namevalue bean pairs of Protocol object which are selected in creation of experiment.
     * @throws Exception
     */
    private List getSelectedProtocols(ActionForm form) throws Exception
    {

        List protocolList = new ArrayList();

        ExperimentForm eform = (ExperimentForm) form;
        String[] displayNameFields = {"name"};
        String[] whereColumnName = {"id"};
        String[] whereColumnCondition = {"="};
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (eform.getProtocol() != null)
            for (int i = 0; i < eform.getProtocol().length; i++)
            {
                Object[] whereColumnValue = {eform.getProtocol()[i]};
                List list = bizLogic.getList(
                        CollectionProtocol.class.getName(), displayNameFields,
                        "id", whereColumnName, whereColumnCondition,
                        whereColumnValue, null, null, false);
                protocolList.add(list.get(1));
            }
        return protocolList;
    }

    /**
     * Checks whether "Add New" functionality is present or not.
     * @param form
     * @return true/false
     * @throws Exception
     */
    private boolean checkForAddNew(ActionForm form) throws Exception
    {
        boolean flag = false;
        ExperimentForm eform = (ExperimentForm) form;

        if (eform.getSubmittedFor() != null
                && !eform.getSubmittedFor().equals("")
                && eform.getSubmittedFor().equals("AddNew"))
        {
            flag = true;
        }
        return flag;

    }

    /**
     * checks for create permission
     * @param form
     * @param request
     */
    private void checkCreatePermission(ActionForm form,
            HttpServletRequest request)
    {
        boolean studyCreatePermission = PrivilegeUtil.checkPrivilege(this
                .getClass(), Study.class.getName(), request.getSession(),
                Permissions.STUDY_CREATE);
        //ExperimentForm experimentForm = (ExperimentForm) form;
        request.setAttribute(Constants.STUDY_CREATE_PERMISSION, new Boolean(
                studyCreatePermission));
    }

    private void checkForExpData(ActionForm form, HttpServletRequest request)
            throws DAOException
    {

        ExperimentForm eform = (ExperimentForm) form;
        Long systemIdentifier = new Long(eform.getId());
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List list = defaultBizLogic.retrieve(Experiment.class.getName(), "id",
                systemIdentifier);
        Experiment experiment = null;

        request.setAttribute(Constants.EXP_DATA_FLAG, new Boolean(false));

        if (list != null && !list.isEmpty())
        {
            experiment = (Experiment) list.get(0);
        }

        if (experiment != null)
        {
            Collection cohortColl = experiment.getCohortCollection();
            //get animal collection and check for animal ids with eexp data
            if (cohortColl != null && !cohortColl.isEmpty())
            {
                Iterator cohortIterator = cohortColl.iterator();
                while (cohortIterator.hasNext())
                {
                    Cohort cohort = (Cohort) cohortIterator.next();
                    Collection animalColl = cohort.getAnimalCollection();
                    if (animalColl != null && !animalColl.isEmpty())
                    {
                        Iterator animalIterator = animalColl.iterator();
                        while (animalIterator.hasNext())
                        {
                            Animal animal = (Animal) animalIterator.next();
                            Collection eventColl = animal
                                    .getEventRecordsCollection();
                            if (eventColl != null && !eventColl.isEmpty())
                            {
                                request.setAttribute(Constants.EXP_DATA_FLAG,
                                        new Boolean(true));
                            }
                        }
                    }
                }
            }
        }

    }

}