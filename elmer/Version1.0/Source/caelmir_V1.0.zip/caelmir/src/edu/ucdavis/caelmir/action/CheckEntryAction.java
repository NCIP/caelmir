/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */

package edu.ucdavis.caelmir.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.util.CommonUtility;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.util.dbManager.DAOException;
import edu.wustl.common.util.global.ApplicationProperties;

public class CheckEntryAction extends BaseAction
{

    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws DAOException

    {
        String textContent = (String) request.getParameter("entry");
        boolean flag =  CommonUtility.checkDuplicate(textContent);
        
        if(flag) {
            ActionErrors errors = new ActionErrors();
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError( "errors.item", ApplicationProperties
                    .getValue("duplicate.msg")));
            
            saveErrors(request, errors);
            return mapping.findForward("success1");
        }
        else
            return mapping.findForward("success2");
    }

    
}
