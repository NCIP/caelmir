/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.actionForm;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.subject.Genotype;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;
import edu.wustl.common.util.logger.Logger;



public class GenotypeForm extends AbstractActionForm
{
    /**Unique identifier of the object*/
   // private java.lang.Long id;

    /**It stores the name of the gene. This is taken from external datasource like Entrez*/
    private java.lang.String geneName;

    /**It refers to the configuration of the gene in question i.e homozygous,heterozygous,hemizygous.*/
    private java.lang.String genotype;

    /**Name of other gene which promotes the gene*/
    private java.lang.String promoter;

    /**Stores the identifier from the external datasource like Entrez*/
    private String geneIdentifier;

    
    public String getGeneIdentifier()
    {
        return geneIdentifier;
    }

    
    public void setGeneIdentifier(String geneIdentifier)
    {
        this.geneIdentifier = geneIdentifier;
    }

    
    public java.lang.String getGeneName()
    {
        return geneName;
    }

    
    public void setGeneName(java.lang.String geneName)
    {
        this.geneName = geneName;
    }

    
    public java.lang.String getGenotype()
    {
        return genotype;
    }

    
    public void setGenotype(java.lang.String genotype)
    {
        this.genotype = genotype;
    }

    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
    public java.lang.String getPromoter()
    {
        return promoter;
    }

    
    public void setPromoter(java.lang.String promoter)
    {
        this.promoter = promoter;
    }

    /**
     * Resets the values of all the fields.
     * Is called by the overridden reset method defined in ActionForm.  
     */
    protected void reset()
    {
    }

    /**
     * @return animal form Identifier
     */
    public int getFormId()
    {
        int formId = Constants.GENOTYPE_ADD_ID;
        return formId;
    }

    /**
     * Copies the data from an AbstractDomain object to a GenotypeForm object.
     * @param abstractDomain An AbstractDomain object of Genotype.  
     */
    public void setAllValues(AbstractDomainObject abstractDomain)
    {

        Genotype genotype = (Genotype) abstractDomain;

        //this.age = aform.getAge();
       
           this.geneIdentifier= genotype.getGeneIdentifier();
           this.geneName=genotype.getGeneName();
           this.genotype = genotype.getGenotype();
           this.promoter = genotype.getPromoter();
           
         // this.setSystemIdentifier(genotype.getSystemIdentifier().longValue());
          this.setId(genotype.getSystemIdentifier().longValue());
          
    }

    
    /**
    /**Overrides the validate method of ActionForm.**/
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request)
    {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();

        try
        {
         /*   if (validator.isEmpty(genus.toString()))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("animal.genus")));
            }*/
        
        	// ------ added by Ravinder------  
        	
        	if (validator.isEmpty(geneName))
             {
                 errors
                         .add(
                                 ActionErrors.GLOBAL_ERROR,
                                 new ActionError(
                                         "errors.item.required",
                                         ApplicationProperties
                                                 .getValue("animal.geneName")));
             }
        	
        	 if (validator.isEmpty(geneIdentifier))
             {
                 errors
                         .add(
                                 ActionErrors.GLOBAL_ERROR,
                                 new ActionError(
                                         "errors.item.required",
                                         ApplicationProperties
                                                 .getValue("animal.geneIdentifier")));
             }
        	
        	// ---- end ----- 
        	
        }
        catch (Exception excp)
        {
            Logger.out.error(excp.getMessage(), excp);
        }
        return errors;
    }
}
