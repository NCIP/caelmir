/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.research.Model;
import edu.ucdavis.caelmir.domain.subject.Genotype;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;


/**
 * This class initializes the fields in the cohort Add/Edit webpage.
 * @author shital_lawhale
 */
public class GenotypeAction extends BaseAction
{

    /**
     * Overrides the execute method of Action class.
     * Sets the various fields in Cohort Add/Edit webpage.
     * */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        String pageOf;
        boolean isAccessPresent = true;
        
        String operation = request.getParameter(Constants.OPERATION);
        request.setAttribute(Constants.OPERATION, operation);
        
        pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);
        
        if (operation.equalsIgnoreCase(Constants.ADD))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.GENOTYPE_CREATE,
                    Permissions.GENOTYPE_CREATE_ACCESS_DENIED);
        }
        else if (operation.equalsIgnoreCase(Constants.EDIT))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.GENOTYPE_UPDATE,
                    Permissions.GENOTYPE_UPDATE_ACCESS_DENIED);
          
        }
        else if (operation.equalsIgnoreCase(Constants.VIEW))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.GENOTYPE_READ,
                    Permissions.GENOTYPE_READ_ACCESS_DENIED);
        }
        if (!isAccessPresent)
        {
            return mapping
                    .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
        }
  	
        if(!operation.equals(Constants.VIEW))
        {
            if (isAccessPresent(request, Permissions.GENOTYPE_DELETE,
                    Permissions.GENOTYPE_DELETE_ACCESS_DENIED))
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        true));
            }
            else
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        false));
            }
        }
        
        
        return mapping.findForward(pageOf);
    }
    
    
		/**
		 * This method is used to check the given privilege on given object.
		 * @param request To get the session data bean
		 * @param privilege Name of the privilege
		 * @param accessDeniedMessage The message to be displayed if the access is not present.
		 * @return boolean true if the access is present otherwise false.
		 */
		private boolean isAccessPresent(HttpServletRequest request,
		        String privilege, String accessDeniedMessage)
		{
		    boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
		            Genotype.class.getName(), request.getSession(), privilege);
		    if (!isAccessPresent)
		    {
		        request.setAttribute(Constants.STATUS_MESSAGE_KEY,
		                accessDeniedMessage);
		    }
		    return isAccessPresent;
		}
	
}
       