/**
 * <p>Title: ActionFormFactory Class>
 * <p>Description:	ActionFormFactory is a factory that returns instances of action formbeans 
 * as per the domain objects.</p>
 * Copyright:    Copyright (c) year
 * Company: Washington University, School of Medicine, St. Louis.
 * @author Aniruddha Phadnis
 * @version 1.00
 * Created on Dec 19, 2005
 */

package edu.ucdavis.caelmir.actionForm;

import java.lang.reflect.Method;
import java.util.List;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.catissuecore.domainobject.Institution;
import edu.wustl.catissuecore.domainobject.User;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.factory.AbstractActionFormFactory;

/**
 * ActionFormFactory is a factory that returns instances of action formbeans 
 * as per the domain objects.
 * @author aniruddha_phadnis
 */
public class ActionFormFactory extends AbstractActionFormFactory
{
	/**
     * Returns the instance of formbean as per given domain object.
     * @param object The instance of domain object
     * @param operation The operation(Add/Edit) that is to be performed
     * @return the instance of formbean.
     * @see #setMessageList(List)
     */
	public AbstractActionForm getFormBean(Object object,String operation) throws Exception
	{
		if(object == null)
		{
			throw new Exception("Object should not be null while performing Add/Edit operation");
		}
		
		if(isIdNull(object))
		{
			throw new Exception("Id field of an object should not be null");
		}
		
		AbstractActionForm form = null;

		if(object instanceof User)
		{
			form = new UserForm();
		}
		else if(object instanceof Institution)
		{
			form = new InstitutionForm();
		}
		else if (object instanceof User && operation.equals(Constants.LOGIN))
		{
		    LoginForm loginForm = new LoginForm();
		    User user = (User) object;
		    loginForm.setLoginName(user.getLoginName());
		    loginForm.setPassword(user.getPassword());
		    form = loginForm;
		}
		else if (operation.equals(Constants.LOGOUT))
		{
		    form = null;
		}
		else
		{
		    throw new Exception("Invalid Object for Add/Edit Operation");
		}
		
		form.setOperation(operation);
		form.setAllVal(object);
		
		return form;
	}
	
	private static boolean isIdNull(Object domainObject) throws Exception
	{
		Method getIdMethod=domainObject.getClass().getMethod("getId",new Class[]{});
		Object object = getIdMethod.invoke(domainObject,new Object[]{});
		
		if(object == null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}