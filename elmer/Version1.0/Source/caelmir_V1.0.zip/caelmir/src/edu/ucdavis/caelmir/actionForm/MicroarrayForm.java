
package edu.ucdavis.caelmir.actionForm;

import org.apache.struts.upload.FormFile;

import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;

/**
 * @author sujay_narkar
 *
 */
public class MicroarrayForm extends AbstractActionForm {
    /**
     * 
     */
    protected String description;
    
    protected Long referenceId;
    /**
     * 
     */
    protected FormFile dataFile;
    /**
     * experiment identifier
     */
    protected String animalId;
    /***/
    private String eventId;
    /***/
    private String protocolId;
    
    private String entityMapId;
    
    
    private String fileName;
    
    /**
     * @return Returns the fileName.
     */
    public String getFileName()
    {
        return fileName;
    }
    /**
     * @param fileName The fileName to set.
     */
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }
    public String getEventId()
    {
        return eventId;
    }

    
    public void setEventId(String eventId)
    {
        this.eventId = eventId;
    }

    
    public String getProtocolId()
    {
        return protocolId;
    }

    
    public void setProtocolId(String protocolId)
    {
        this.protocolId = protocolId;
    }

    public void reset() {
        
    }
    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    /**
     * Returns the id assigned to form bean.
     * @return the id assigned to form bean.
     */
    public int getFormId() {
        return Constants.MICROARRAY_FORM_ID;
    }
    /**
     * 
     */
    public void setAllValues(AbstractDomainObject abstractDomain)   {
        MicroarrayEventRecords microarray = (MicroarrayEventRecords) abstractDomain;
        
        if (microarray.getAnimal() != null) {
        this.animalId  = String.valueOf(microarray.getAnimal().getId());
        }
        this.description = microarray.getDescription();
        this.referenceId = microarray.getReferenceId();
        this.fileName = microarray.getFileName();
        this.setId(microarray.getId().longValue());
   
    }

	/**
	 * @return Returns the description.
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description The description to set.
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return Returns the dataFile.
	 */
	public FormFile getDataFile() {
		return dataFile;
	}
	/**
	 * @param dataFile The dataFile to set.
	 */
	public void setDataFile(FormFile dataFile) {
		this.dataFile = dataFile;
	}
	/**
	 * @return Returns the experimentIdentifier.
	 */
	public String getAnimalId() {
		return animalId;
	}
	/**
	 * @param experimentIdentifier The experimentIdentifier to set.
	 */
	public void setAnimalId(String animalId) {
		this.animalId = animalId;
	}
    /**
     * @return Returns the referenceIdentifier.
     */
    public Long getReferenceId()
    {
        return referenceId;
    }
    /**
     * @param referenceIdentifier The referenceIdentifier to set.
     */
    public void setReferenceId(Long referenceId)
    {
        this.referenceId = referenceId;
    }
    
    public String getEntityMapId()
    {
        return entityMapId;
    }
    
    public void setEntityMapId(String entityMapId)
    {
        this.entityMapId = entityMapId;
    }
}
