
package edu.ucdavis.caelmir.domain.subject;

import java.io.Serializable;
import java.util.Date;

import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;

/**
 * @author sujay_narkar
 * @hibernate.class table="CAELMIR_ANIMAL_IMPORT"
 */
public class ImportAnimal extends AbstractDomainObject implements Serializable {
    
    private static final long serialVersionUID = 1234567890L;
      
    /**
     * 
     */
    protected Long animalIndex;
    
    
    /**
     * 
     */
    protected Date birthDate;
    /**
     * 
     */
    protected String earCode;
    /**
     * 
     */
    protected String sex;
    /**
     * 
     */
    protected String stain;
    /**
     * 
     */
    protected String genotype;
    /**
     * 
     *
     */
    public ImportAnimal(){
        
    }
    
    
    public ImportAnimal(AbstractActionForm form) {
        setAllValues(form);
    }
    
    /**
     * 
     */
    public void setAllValues(AbstractActionForm actionForm) {
     
    }
    
    /**
     * Returns the unique systemIdentifier assigned to institution.
     * 
     * @return A unique systemIdentifier assigned to the institution.
     * @see #setIdentifier(int)
     * */
    public Long getSystemIdentifier() {
        return null;
    }
    
    /**
     * Sets an systemIdentifier for the institution.
     * @param systemIdentifier Unique systemIdentifier to be assigned to the institution.
     * @see #getIdentifier()
     * */
    public void setSystemIdentifier(Long systemIdentifier) {
        
    }
	/**
	 * @return Returns the animalIndex.
	 * 
     * @hibernate.id name="animalIndex" column="ANIMAL_INDEX" type="long"
     *  unsaved-value="null" generator-class="assigned"
	 */
	public Long getAnimalIndex() {
		return animalIndex;
	}
	/**
	 * @param animalIndex The animalIndex to set.
	 */
	public void setAnimalIndex(Long animalIndex) {
		this.animalIndex = animalIndex;
	}
	/**
	 * @return Returns the birthDate.
	 * @hibernate.property name="birthDate" column="BIRTH_DATE" type="date" 
	 */
	public Date getBirthDate() {
		return birthDate;
	}
	/**
	 * @param birthDate The birthDate to set.
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	/**
	 * @return Returns the earCode.
     * @hibernate.property name="earCode" type="string" column="EAR_CODE" length="32"  
	 */
	public String getEarCode() {
		return earCode;
	}
	/**
	 * @param earCode The earCode to set.
	 */
	public void setEarCode(String earCode) {
		this.earCode = earCode;
	}
	/**
	 * @return Returns the genotype.
     * @hibernate.property name="genotype" type="string" column="GENOTYPE" length="16" 
	 */
	public String getGenotype() {
		return genotype;
	}
	/**
	 * @param genotype The genotype to set.
	 */
	public void setGenotype(String genotype) {
		this.genotype = genotype;
	}
	/**
	 * @return Returns the sex.
     * @hibernate.property name="sex" type="string" column="SEX" length="32" 
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex The sex to set.
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return Returns the stain.
     * @hibernate.property name="stain" type="string" column="STAIN" length="128" 
	 */
	public String getStain() {
		return stain;
	}
	/**
	 * @param stain The stain to set.
     */
	public void setStain(String stain) {
		this.stain = stain;
	}


    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#getId()
     */
    public Long getId()
    {
        // TODO Auto-generated method stub
        return null;
    }


    /* (non-Javadoc)
     * @see edu.wustl.common.domain.AbstractDomainObject#setId(java.lang.Long)
     */
    public void setId(Long arg0)
    {
        // TODO Auto-generated method stub
        
    }
}

