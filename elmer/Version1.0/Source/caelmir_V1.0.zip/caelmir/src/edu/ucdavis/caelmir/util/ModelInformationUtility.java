package edu.ucdavis.caelmir.util;

import java.io.File;
import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;


import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.cde.CDEManager;
import edu.wustl.common.util.logger.Logger;

public class ModelInformationUtility {

	private Document getDocument (String fileName) {
		//Map moduleMap  = new HashMap();
	    SAXReader saxReader = new SAXReader();
	    
	    String filePath = Variables.caElmirHome + System.getProperty("file.separator")+"caelmir-properties"+ "\\" + fileName;   
	    File file = new File(filePath);   
	    
	    Document document = null;
	//    String string = null;   
	    try
        {
            document = saxReader.read(file);    
        } catch (Exception ex) 
        {
        	Logger.out.error(ex.getMessage(), ex);        	
            
        }    
        return document;
	}
	
	private List getValuesFromFile(String fileName, String inputElementName) {
		Document document = getDocument(fileName);
		Element exampleData = document.getRootElement();
		List list = new ArrayList();
        Element inputElement = exampleData.element(inputElementName);
        if (inputElement == null) {
            return new ArrayList();
        }
        Iterator entryIterator = inputElement.elementIterator("entry");
        while (entryIterator.hasNext()) {
            Element entry =   (Element) entryIterator.next();
            Attribute name = entry.attribute("name");
            Attribute value = entry.attribute("name");
            list.add(new NameValueBean(name.getStringValue(),value.getStringValue()));
        }
        
        return list;
	}
	
	public List getModelNameValuePairs() {
		return CDEManager.getCDEManager().getPermissibleValueList(Constants.CDE_MODEL_NAME,null);
	}
	
	public List getGenotypeNameValuePairs() {
		return getValuesFromFile("modelInformation.xml","genotype");
	}
	
	public List getActualStrainNameValuePairs() {
		return getValuesFromFile("modelInformation.xml","actualStrain");
	}
	
	public List getMainStrainNameValuePairs() {
		return getValuesFromFile("modelInformation.xml","mainStrain");
	}
}
