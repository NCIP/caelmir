/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;


/**
 * @author sandeep_chinta
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class ImageTypeAction extends BaseAction
{

    /* (non-Javadoc)
     * @see edu.wustl.common.action.BaseAction#executeAction(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    protected ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	boolean isAccessPresent = true;
    	 
        String pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);
        
        String operation = request.getParameter(Constants.OPERATION);
        request.setAttribute(Constants.OPERATION, operation);
        
        if (operation.equalsIgnoreCase(Constants.ADD))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.IMAGETYPE_CREATE,
                    Permissions.IMAGETYPE_CREATE_ACCESS_DENIED);
        }
        else if (operation.equalsIgnoreCase(Constants.EDIT))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.IMAGETYPE_UPDATE,
                    Permissions.IMAGETYPE_UPDATE_ACCESS_DENIED);
          
        }
        else if (operation.equalsIgnoreCase(Constants.VIEW))
        {
            isAccessPresent = isAccessPresent(request,
                    Permissions.IMAGETYPE_READ,
                    Permissions.IMAGETYPE_READ_ACCESS_DENIED);
        }
        if (!isAccessPresent)
        {
            return mapping
                    .findForward(Permissions.PERIMISSIOIN_DENIED_FORWARD_FOR_ADMIN);
        }
        
        //check for edit privelege.
        if(operation.equals(Constants.VIEW))
         {
            boolean editPermission = PrivilegeUtil.checkPrivilege(this.getClass(),
                    ImageType.class.getName(), request.getSession(),
                    Permissions.IMAGETYPE_UPDATE);
            if (!editPermission)
            {
                request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(false));
            }
            else
            {
                request.setAttribute(Constants.EDIT_PRIVILEGE, new Boolean(true));
            }

         }
        
        
        
        return mapping.findForward(pageOf);
    }

    /**
	 * This method is used to check the given privilege on given object.
	 * @param request To get the session data bean
	 * @param privilege Name of the privilege
	 * @param accessDeniedMessage The message to be displayed if the access is not present.
	 * @return boolean true if the access is present otherwise false.
	 */
	private boolean isAccessPresent(HttpServletRequest request,
	        String privilege, String accessDeniedMessage)
	{
	    boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
	            ImageType.class.getName(), request.getSession(), privilege);
	    if (!isAccessPresent)
	    {
	        request.setAttribute(Constants.STATUS_MESSAGE_KEY,
	                accessDeniedMessage);
	    }
	    return isAccessPresent;
	}
    
    
}
