
package edu.ucdavis.caelmir.domain.eventRecords;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.struts.upload.FormFile;

import edu.ucdavis.caelmir.actionForm.TissueForm;
import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;
import edu.wustl.common.util.global.Constants;

/**
 * @author sujay_narkar
 * @hibernate.class table="CAELMIR_TISSUE"
 */
public class Tissue extends AbstractDomainObject
        implements
            java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**Unique id for the object*/
    private Long id;

    /**Long name for the tissue*/
    private String tissueLongName;

    /**Short Name for the tissue*/
    private String tissueShortName;

    /**Date of creation for the tissue*/
    private Date createdDate;

    /**Activity status for the tissue.*/
    private String activityStatus;

    /** Creator user for the tissue*/
    private edu.ucdavis.caelmir.domain.common.User creator;

    /**Collection of all the slides associated with the tissue.*/
    private Collection slideCollection = new HashSet();

    /**Collection of all the images associated with the tissue*/
    private Collection imageCollection = new HashSet();

    /**Collection of all the pathology data elements associated with the tissue,*/
    private edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords pathologyEventRecords;
    
    /**
     * 
     */
   // private Long tissue;

    
    public Tissue(AbstractActionForm form)
    {
        try
        {
            setAllValues(form);
        }
        catch (AssignDataException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public Tissue()
    {
        // TODO Auto-generated constructor stub
    }
    
    
    
    

  /*
    public Long getTissue()
    {
        return tissue;
    }

    
    public void setTissue(Long tissue)
    {
        this.tissue = tissue;
    }*/

    /**
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_TISSUE_SEQ"
     * @return Returns the systemIdentifier.
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * @return Returns the hypothesis.
     * @hibernate.property name="tissueLongName" type="string" column="TISSUE_LONG_NAME" length="100"
     */
    public String getTissueLongName()
    {
        return tissueLongName;
    }

    public void setTissueLongName(String tissueLongName)
    {
        this.tissueLongName = tissueLongName;
    }

    /**
     * @return Returns the hypothesis.
     * @hibernate.property name="tissueShortName" type="string" column="TISSUE_SHORT_NAME" length="50"
     */
    public String getTissueShortName()
    {
        return tissueShortName;
    }

    public void setTissueShortName(String tissueShortName)
    {
        this.tissueShortName = tissueShortName;
    }

    /**
     * Returns the date when the user is added to the system.
     * @hibernate.property name="createdDate" type="date" column="CREATED_DATE"
     * @return Returns the dateAdded.
     */
    public Date getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    /**
     * @return Returns the hypothesis.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="50"
     */

    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @return the user object
     * @hibernate.many-to-one column="USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.User getCreator()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.dataElements.Tissue thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Tissue();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                creator = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Tissue:getCreator throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return creator;

    }

    public void setCreator(edu.ucdavis.caelmir.domain.common.User creator)
    {
        this.creator = creator;
    }

    /**
     * @return Returns the slideCollection.
     * @hibernate.set name="slideCollection"
     *                table="CAELMIR_SLIDE" cascade="save-update"
     *                inverse="true" lazy="false"
     * @hibernate.collection-key column="TISSUE_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.eventRecords.Slide"
     */
    public Collection getSlideCollection()
    {
        //			try{
        //			   if(slideCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.dataElements.Tissue thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Tissue();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.dataElements.Slide", thisIdSet);				 
        //				 	slideCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Tissue:getSlideCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return slideCollection;
    }

    public void setSlideCollection(Collection slideCollection)
    {
        this.slideCollection = slideCollection;
    }

    /**
     * Returns the set of users in this user group.
     * @hibernate.set name="imageCollection" cascade="save-update" inverse="false" lazy="false"
     * @hibernate.collection-key column="TISSUE_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.eventRecords.Image"   
     * @return the set of users in this user group.
     */
    public Collection getImageCollection()
    {
        //			try{
        //			   if(imageCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.dataElements.Tissue thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Tissue();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.dataElements.Image", thisIdSet);				 
        //				 	imageCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Tissue:getImageCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return imageCollection;
    }

    public void setImageCollection(Collection imageCollection)
    {
        this.imageCollection = imageCollection;
    }

    /**
     * @return
     * @hibernate.many-to-one column="CASE_ID" class="edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords"
     * constrained="true"
     */
    public edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords getPathologyEventRecords()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.dataElements.Tissue thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.Tissue();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.dataElements.PathologyDataElements", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                pathologyDataElements = (edu.ucdavis.caelmir.domain.dataElements.PathologyDataElements)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Tissue:getPathologyDataElements throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return pathologyEventRecords;

    }

    public void setPathologyEventRecords(
            edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords pathologyEventRecords)
    {
        this.pathologyEventRecords = pathologyEventRecords;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Tissue)
        {
            Tissue c = (Tissue) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    protected String[] images;
    /**
     * @return Returns the images.
     */
    public String[] getImages()
    {
        return images;
    }
    
    /**
     * @param images The images to set.
     */
    public void setImages(String[] images)
    {
        this.images = images;
    }
    public void setAllValues(AbstractActionForm abstractForm)
            throws AssignDataException
    {
        // TODO Auto-generated method stub
        
        TissueForm tform = (TissueForm) abstractForm;
        this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
        
        this.setTissueLongName(tform.getTissueLongName());
        this.setTissueShortName(tform.getTissueShortName());
        
        //this.setSlideCollection()
        Set slideSet = new HashSet();
        String slideId[] = tform.getSelectedSlide();
        if (slideId != null)
        {
            for (int i = 0; i < tform.getSelectedSlide().length; i++)
            {
                String ID = slideId[i];
                Long slideID = new Long(ID);
                Slide slide = new Slide();
                slide.setId(slideID);
                slideSet.add(slide);
            }
        }
        setSlideCollection(slideSet);

        Collection imageCol = new HashSet();
        String[] imageList = tform.getImages();
        setImages(imageList);
        FormFile formFile = null;
        String imageIdentifier = null;
        int imageCounter = Integer.parseInt(tform.getImageCounter());
        for (int i =1;i<imageCounter;i++) {
            formFile = (FormFile) tform.getValue(edu.ucdavis.caelmir.util.global.Constants.SLIDE_IMAGES_UNDERSCORE + i);
            imageIdentifier = (String) tform.getValue(edu.ucdavis.caelmir.util.global.Constants.IMAGE_TYPES_UNDERSCORE + i);
               if(formFile!=null) {
		            Image image = new Image();
		            try
		            {
		                image.setImage(formFile.getFileData());
		                image.setFileName(formFile.getFileName());
		                image.setFileSize(new Long(formFile.getFileSize()));
		                image.setContentType(formFile.getContentType());
		            }
		            catch (FileNotFoundException e)
		            {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		            catch (IOException e)
		            {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		            if (imageIdentifier != null && !imageIdentifier.equals("-1")) {
		                ImageType imageType = new ImageType();
		                imageType.setId(new Long(imageIdentifier));
		                image.setImageType(imageType);
		            }
		            imageCol.add(image);
		        }
            
        }
        
        this.imageCollection = imageCol;
        
        
       

    }

    public Long getSystemIdentifier()
    {

        return id;
    }

    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;

    }

}