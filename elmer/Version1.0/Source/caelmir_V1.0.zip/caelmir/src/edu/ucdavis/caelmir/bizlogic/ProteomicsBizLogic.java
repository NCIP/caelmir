
package edu.ucdavis.caelmir.bizlogic;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.ProteomicsEventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author sujay_narkar
 *
 */
public class ProteomicsBizLogic extends DefaultBizLogic
{

    public void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {

        ProteomicsEventRecords proteomics = (ProteomicsEventRecords) obj;
        Mouse mouse = (Mouse) proteomics.getAnimal();
        if (mouse != null)
        {
            List list = (List) dao.retrieve(Mouse.class.getName(),
                    Constants.ID, mouse.getSystemIdentifier());
            if (list != null && !list.isEmpty())
            {
                Mouse mousefromTable = (Mouse) list.get(0);
                proteomics.setAnimal(mousefromTable);
            }

        }

        proteomics.setCreatedDate(new Date());
        User user = (User) ((List) dao.retrieve(User.class.getName(),
                Constants.ID, sessionDataBean.getUserId())).get(0);
        proteomics.setCreator(user);
        /* Collection collection = proteomics.getCollectionProtocolEventCollection();
         if (collection != null) {
         Iterator iterator = collection.iterator();
         Collection newCollection = new HashSet();
         while(iterator.hasNext()) {
         CollectionProtocolEvent event = (CollectionProtocolEvent) iterator.next();
         List eventList = (List) dao.retrieve(CollectionProtocolEvent.class.getName(),Constants.ID, event.getId());
         if (eventList != null && !eventList.isEmpty()) {
         CollectionProtocolEvent newEvent = (CollectionProtocolEvent) eventList.get(0);
         newEvent.getEventRecordsCollection().add(proteomics);
         newCollection.add(newEvent);
         
         }
         
         }
         proteomics.setCollectionProtocolEventCollection(newCollection);
         }*/

        if (proteomics.getEntityMap() != null)
        {
            EntityMap entityMap = (EntityMap) proteomics.getEntityMap();
            List entityMapList = (List) dao.retrieve(EntityMap.class.getName(),
                    Constants.ID, entityMap.getId());
            if (entityMapList != null && !entityMapList.isEmpty())
            {
                EntityMap entityMapFromTable = (EntityMap) entityMapList.get(0);
                
                
                proteomics.setEntityMap(entityMapFromTable);
            }

        }
        dao.insert(proteomics, null, true, false);

    }

    /**
     * Updates the experiment object in the database.
     * @param obj The experiment object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    public void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {
        ProteomicsEventRecords proteomics = (ProteomicsEventRecords) obj;

        List list = (List) dao.retrieve(ProteomicsEventRecords.class.getName(),
                Constants.ID, proteomics.getSystemIdentifier());
        if (list != null && !list.isEmpty())
        {
            ProteomicsEventRecords newProteomics = (ProteomicsEventRecords) list
                    .get(0);
            newProteomics.setActivityStatus(proteomics.getActivityStatus());

  /*          if (!proteomics.getActivityStatus().equals(
                    Constants.ACTIVITY_STATUS_DISABLED))
                newProteomics.setActivityStatus(proteomics.getActivityStatus());
            else
                newProteomics
                        .setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);*/

            newProteomics.setAnimal(proteomics.getAnimal());
            /*newProteomics.setCollectionProtocolEventCollection(null);
             Collection collection = proteomics.getCollectionProtocolEventCollection();
             if (collection != null) {
             Iterator iterator = collection.iterator();
             Collection newCollection = new HashSet();
             while(iterator.hasNext()) {
             CollectionProtocolEvent event = (CollectionProtocolEvent) iterator.next();
             List eventList = (List) dao.retrieve(CollectionProtocolEvent.class.getName(),Constants.ID, event.getId());
             if (eventList != null && !eventList.isEmpty()) {
             CollectionProtocolEvent newEvent = (CollectionProtocolEvent) eventList.get(0);
             // newEvent.getEventRecordsCollection().add(microarray);
             newCollection.add(newEvent);
             
             }
             
             }
             newProteomics.setCollectionProtocolEventCollection(newCollection);
             }
             */
            if (proteomics.getActivityStatus().equals(
                    Constants.ACTIVITY_STATUS_DISABLED))
            {
                newProteomics.setEntityMap(null);
                newProteomics.setAnimal(null);
            }
            else
            if (proteomics.getEntityMap() != null)
            {
                EntityMap entityMap = (EntityMap) proteomics.getEntityMap();
                List entityMapList = (List) dao.retrieve(EntityMap.class
                        .getName(), Constants.ID, entityMap.getId());
                if (entityMapList != null && !entityMapList.isEmpty())
                {
                    EntityMap entityMapFromTable = (EntityMap) entityMapList
                            .get(0);
                    newProteomics.setEntityMap(entityMapFromTable);
                }
            }

                newProteomics.setModifiedDate(new Date());
                newProteomics.setCreatedDate(proteomics.getCreatedDate());
                newProteomics.setDescription(proteomics.getDescription());
                newProteomics.setReferenceId(proteomics.getReferenceId());
                if (proteomics.getFileName() != null
                        && proteomics.getFileName().length() > 0)
                {
                    newProteomics.setFileName(proteomics.getFileName());
                    newProteomics.setFileSize(proteomics.getFileSize());
                    newProteomics.setContentType(proteomics.getContentType());
                    newProteomics.setDataFile(proteomics.getDataFile());
                }
            
            dao.update(newProteomics, null, true, false, false);
        }
    }

}
