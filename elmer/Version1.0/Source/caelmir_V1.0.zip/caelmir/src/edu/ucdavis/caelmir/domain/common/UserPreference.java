/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.domain.common;



/**
 * @version 1.0
 * @created 15-May-2006 12:20:30 PM
 * @hibernate.class table="CAELMIR_USERPREFERENCE"
 */
public class UserPreference
{
    
    
    Long id;
    
    String preferenceValue;

    String preferenceName;
    
    User user;
    
    
    

    /**
     * Returns the unique systemIdentifier assigned to institution.
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_USERPREFERENCE_SEQ"
     * @return A unique systemIdentifier assigned to the institution.
     * @see #setIdentifier(int)
     * */
    public Long getId()
    {
        return id;
    }

    
    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * @return Returns the description.
     * @hibernate.property name="preferenceName" type="string" column="PREFERENCE_Name" length="100"
     */
    public String getPreferenceName() {
        return this.preferenceName;
    }
    
    public void setPreferenceName(String preferenceName) {
        this.preferenceName = preferenceName;
    }

    /**
     * @return Returns the description.
     * @hibernate.property name="preferenceValue" type="string" column="PREFERENCE_VALUE" length="100"
     */
    public String getPreferenceValue()
    {
        return preferenceValue;
    }

    
    public void setPreferenceValue(String preferenceValue)
    {
        this.preferenceValue = preferenceValue;
    }

    /**
     * @return
     * @hibernate.many-to-one column="USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public User getUser()
    {
        return user;
    }
    public void setUser(User user)
    {
        this.user = user;
    }

}
