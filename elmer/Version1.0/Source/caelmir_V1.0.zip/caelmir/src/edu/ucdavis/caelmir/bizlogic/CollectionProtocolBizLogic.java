/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */

package edu.ucdavis.caelmir.bizlogic;

import java.util.Collection;
//import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
//import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

public class CollectionProtocolBizLogic extends DefaultBizLogic
{

    /**
     * Saves the user object in the database.
     * @param obj The user object to be saved.
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    protected void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {
        CollectionProtocol collectionProtocol = (CollectionProtocol) obj;
        if (sessionDataBean!=null) {
	        Long userId = sessionDataBean.getUserId();
	        User user = (User) dao.retrieve(User.class.getName(), userId);
	        collectionProtocol.setCreator(user);
        }
        Collection eventCollection = collectionProtocol
                .getCollectionProtocolEventCollection();
        Iterator eventIterator = eventCollection.iterator();

        Collection collOfProtocolEvent = new LinkedHashSet();
        while (eventIterator.hasNext())
        {
            CollectionProtocolEvent collectionProtocolEvent = (CollectionProtocolEvent) eventIterator
                    .next();
            collectionProtocolEvent.setCollectionProtocol(collectionProtocol);
            Collection entityMapCollection = collectionProtocolEvent
                    .getEntityMapCollection();
            
            Iterator entityMapIterator = entityMapCollection.iterator();
            Collection collOfEventRecord = new LinkedHashSet();
            while (entityMapIterator.hasNext())
            {
                EntityMap entityMap = (EntityMap) entityMapIterator
                        .next();
              /*  eventRecords
                        .setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);*/
                entityMap.setCollectionProtocolEvent(collectionProtocolEvent);
                collOfEventRecord.add(entityMap);
            }
            collectionProtocolEvent.setEntityMapCollection(collOfEventRecord);
                    
            collOfProtocolEvent.add(collectionProtocolEvent);
        }
        collectionProtocol
                .setCollectionProtocolEventCollection(collOfProtocolEvent);
        dao.insert(collectionProtocol, sessionDataBean, true, false);

    }
    
    public boolean checkDeleteObject(CollectionProtocolEvent collEvent,DAO dao) {
    
        Collection entityMapCol = collEvent.getEntityMapCollection();
        Iterator iterMap = entityMapCol.iterator();
        while (iterMap.hasNext()) {
            EntityMap map = (EntityMap)iterMap.next(); 
            try
            {
                List list = dao.retrieve(EventRecords.class.getName(),"entityMap", map.getId());
                if(list != null && list.size() > 0) {
                    return true;
                }
            }
            catch (DAOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return false;
    }
    
    public boolean checkDeleteObject(EntityMap map,DAO dao) {
        try
        {
            List list = dao.retrieve(EventRecords.class.getName(),"entityMap", map.getId());
            if(list != null && list.size() > 0) {
                return true;
            }
        }
        catch (DAOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }

    protected void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {

       CollectionProtocol collectionProtocol = (CollectionProtocol) obj;       
       
       CollectionProtocol newCollectionProtocol = (CollectionProtocol) dao
              .retrieve(CollectionProtocol.class.getName(),collectionProtocol.getId());
       
       newCollectionProtocol.setActivityStatus(collectionProtocol.getActivityStatus());
       newCollectionProtocol.setIrbIdentifier(collectionProtocol.getIrbIdentifier());
       newCollectionProtocol.setEndDate(collectionProtocol.getEndDate());
       newCollectionProtocol.setDescriptionURL(collectionProtocol.getDescriptionURL());
       newCollectionProtocol.setShortTitle(collectionProtocol.getShortTitle());
       newCollectionProtocol.setStartDate(collectionProtocol.getStartDate());
       newCollectionProtocol.setTitle(collectionProtocol.getTitle());       
       
        Collection eventCollection = collectionProtocol
                .getCollectionProtocolEventCollection();
        
       // collectionProtocol.setCollectionProtocolEventCollection(null);
        //dao.update(collectionProtocol, null, false, false, false);
        
        Iterator eventIterator = eventCollection.iterator();
        Set eventColl = new LinkedHashSet();
      
        Collection prevEventColl = newCollectionProtocol.getCollectionProtocolEventCollection();
        
        Iterator itr = prevEventColl.iterator();
        while (itr.hasNext()) {
            CollectionProtocolEvent newAni = (CollectionProtocolEvent) itr.next();
            if (!eventCollection.contains(newAni)) {
                if (!checkDeleteObject(newAni,dao)) {
                    newAni.setCollectionProtocol(null);
                } else {
                    newAni.setCollectionProtocol(collectionProtocol);
                }
                eventColl.add((CollectionProtocolEvent) newAni);
            }
        }
        while (eventIterator.hasNext())
        {
            CollectionProtocolEvent collectionProtocolEvent = (CollectionProtocolEvent) eventIterator
                    .next();

            CollectionProtocolEvent collectionProtocolEvent1 = collectionProtocolEvent;

            if (collectionProtocolEvent.getId() != null)
            {
                CollectionProtocolEvent collProtocolEvent 
                 = (CollectionProtocolEvent) dao
                        .retrieve(CollectionProtocolEvent.class.getName(),
                                collectionProtocolEvent.getId());

                collProtocolEvent
                        .setStudyCalendarEventPoint(collectionProtocolEvent
                                .getStudyCalendarEventPoint());             
              //  collProtocolEvent.setCollectionProtocol(collectionProtocol);
               collectionProtocolEvent1 = collProtocolEvent;
            }
            //for eventRecords
           Collection evntRecColl = collectionProtocolEvent.getEntityMapCollection();
         Collection prevEntityColl = collectionProtocolEvent1.getEntityMapCollection();
           
           Set eventRecordCollection = new LinkedHashSet();
           Iterator itre = prevEntityColl.iterator();
           while (itre.hasNext()) {
               EntityMap newMap = (EntityMap) itre.next();
               if (!evntRecColl.contains(newMap)) {
                   if(!checkDeleteObject(newMap,dao)) {
                       newMap.setCollectionProtocolEvent(null);
                   } else {
                       newMap.setCollectionProtocolEvent(collectionProtocolEvent);
                   }
                   eventRecordCollection.add((EntityMap) newMap);
               }
           }
            Iterator evntRecIterator = evntRecColl.iterator();
         
            while (evntRecIterator.hasNext())
            {
                EntityMap entityMap = (EntityMap) evntRecIterator.next();
                if (entityMap.getId() != null)
                {
                    EntityMap entityMapfromTable = (EntityMap) dao.retrieve(
                            EntityMap.class.getName(), entityMap.getId());                
                  
                    entityMapfromTable.setCollectionProtocolEvent(collectionProtocolEvent1);
                    eventRecordCollection.add(entityMapfromTable);
                }
                else
                {         
                   eventRecordCollection.add(entityMap);
                   entityMap.setCollectionProtocolEvent(collectionProtocolEvent1);
                }                
            }          
           // collectionProtocolEvent1.setEventRecordsCollection(null);
            //dao.update(collectionProtocolEvent1, null, false, false, false);
            collectionProtocolEvent1.setEntityMapCollection(eventRecordCollection);
            eventColl.add(collectionProtocolEvent1);
        }        
      // collectionProtocol.setCollectionProtocolEventCollection(null);
        newCollectionProtocol.setCollectionProtocolEventCollection(eventColl);   
        dao.update( newCollectionProtocol, null, true, false, false);

    }

}