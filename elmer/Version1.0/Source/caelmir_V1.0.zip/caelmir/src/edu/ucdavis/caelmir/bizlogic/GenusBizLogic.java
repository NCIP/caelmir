/**
 * 
 */
package edu.ucdavis.caelmir.bizlogic;

import edu.ucdavis.caelmir.domain.subject.Genus;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author ravinder_kankanala
 *
 */
public class GenusBizLogic extends DefaultBizLogic {

	 /**
     * Saves the Genus object in the database.
     * @param obj The Genus object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOEx
     */ 
	public void insert(Object obj, DAO dao, SessionDataBean sessionDataBean) throws DAOException, UserNotAuthorizedException {
		
		Genus genus= (Genus) obj;  
		dao.insert(genus,null,true,false);  
    }

	 /**
     * Updates an objects into the database.
     * @param obj The object to be updated into the database.
     * @throws DAOException
     */
    protected void update(DAO dao, Object obj, Object oldObj, SessionDataBean sessionDataBean) throws DAOException, UserNotAuthorizedException
    {
    	Genus genus= (Genus) obj;  
        dao.update(genus, null, true, false, false);
    }
}

