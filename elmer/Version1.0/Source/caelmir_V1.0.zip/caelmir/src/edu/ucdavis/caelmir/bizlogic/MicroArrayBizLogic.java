
package edu.ucdavis.caelmir.bizlogic;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * @author sujay_narkar
 *
 */
public class MicroArrayBizLogic extends DefaultBizLogic
{

    public void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {

        MicroarrayEventRecords microarray = (MicroarrayEventRecords) obj;
        Mouse mouse = (Mouse) microarray.getAnimal();
        if (mouse != null)
        {
            List list = (List) dao.retrieve(Mouse.class.getName(),
                    Constants.ID, mouse.getSystemIdentifier());
            if (list != null && !list.isEmpty())
            {
                Mouse mousefromTable = (Mouse) list.get(0);
                microarray.setAnimal(mousefromTable);
            }

        }

        microarray.setCreatedDate(new Date());
        User user = (User) ((List) dao.retrieve(User.class.getName(),
                Constants.ID, sessionDataBean.getUserId())).get(0);
        microarray.setCreator(user);
        /*  Collection collection = microarray.getCollectionProtocolEventCollection();
         if (collection != null) {
         Iterator iterator = collection.iterator();
         Collection newCollection = new HashSet();
         while(iterator.hasNext()) {
         CollectionProtocolEvent event = (CollectionProtocolEvent) iterator.next();
         List eventList = (List) dao.retrieve(CollectionProtocolEvent.class.getName(),Constants.ID, event.getId());
         if (eventList != null && !eventList.isEmpty()) {
         CollectionProtocolEvent newEvent = (CollectionProtocolEvent) eventList.get(0);
         newEvent.getEventRecordsCollection().add(microarray);
         newCollection.add(newEvent);
         
         }
         
         }
         microarray.setCollectionProtocolEventCollection(newCollection);
         }*/

        if (microarray.getEntityMap() != null)
        {
            EntityMap entityMap = (EntityMap) microarray.getEntityMap();            
            List entityMapList = (List) dao.retrieve(EntityMap.class.getName(),
                    Constants.ID, entityMap.getId());            
            
            if (entityMapList != null && !entityMapList.isEmpty())
            {
                EntityMap entityMapFromTable = (EntityMap) entityMapList.get(0);               

                              
                microarray.setEntityMap(entityMapFromTable);
            }

        }
        
        
        
        dao.insert(microarray, null, true, false);

    }

    /**
     * Updates the experiment object in the database.
     * @param obj The experiment object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    public void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {
        MicroarrayEventRecords microarray = (MicroarrayEventRecords) obj;

        List list = (List) dao.retrieve(MicroarrayEventRecords.class.getName(),
                Constants.ID, microarray.getSystemIdentifier());
        if (list != null && !list.isEmpty())
        {
            MicroarrayEventRecords newMicroaraay = (MicroarrayEventRecords) list
                    .get(0);

            newMicroaraay.setActivityStatus(microarray.getActivityStatus());
            /*
            if (!microarray.getActivityStatus().equals(
                    Constants.ACTIVITY_STATUS_DISABLED))
                newMicroaraay.setActivityStatus(microarray.getActivityStatus());
            else
                newMicroaraay
                        .setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
*/
            newMicroaraay.setAnimal(microarray.getAnimal());
            /* newMicroaraay.setCollectionProtocolEventCollection(null);
             Collection collection = microarray.getCollectionProtocolEventCollection();
             if (collection != null) {
             Iterator iterator = collection.iterator();
             Collection newCollection = new HashSet();
             while(iterator.hasNext()) {
             CollectionProtocolEvent event = (CollectionProtocolEvent) iterator.next();
             List eventList = (List) dao.retrieve(CollectionProtocolEvent.class.getName(),Constants.ID, event.getId());
             if (eventList != null && !eventList.isEmpty()) {
             CollectionProtocolEvent newEvent = (CollectionProtocolEvent) eventList.get(0);
             // newEvent.getEventRecordsCollection().add(microarray);
             newCollection.add(newEvent);
             
             }
             
             }
             newMicroaraay.setCollectionProtocolEventCollection(newCollection);
             }*/
            if (microarray.getActivityStatus().equals(
                    Constants.ACTIVITY_STATUS_DISABLED))
            {
                newMicroaraay.setEntityMap(null);
                newMicroaraay.setAnimal(null);
            }
            else
            if (microarray.getEntityMap() != null)
            {
                EntityMap entityMap = (EntityMap) microarray.getEntityMap();
                List entityMapList = (List) dao.retrieve(EntityMap.class
                        .getName(), Constants.ID, entityMap.getId());
                if (entityMapList != null && !entityMapList.isEmpty())
                {
                    EntityMap entityMapFromTable = (EntityMap) entityMapList
                            .get(0);
                    newMicroaraay.setEntityMap(entityMapFromTable);
                }

            }

          
                newMicroaraay.setName(microarray.getName());
                newMicroaraay.setCreatedDate(microarray.getCreatedDate());
                newMicroaraay.setDescription(microarray.getDescription());
                newMicroaraay.setReferenceId(microarray.getReferenceId());
                newMicroaraay.setModifiedDate(new Date());
                if (microarray.getFileName() != null
                        && microarray.getFileName().length() > 0)
                {

                    newMicroaraay.setFileName(microarray.getFileName());
                    newMicroaraay.setFileSize(microarray.getFileSize());
                    newMicroaraay.setContentType(microarray.getContentType());
                    newMicroaraay.setDataFile(microarray.getDataFile());
                }
            
            dao.update(newMicroaraay, null, true, false, false);
        }

    }

}
