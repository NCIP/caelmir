
package edu.ucdavis.caelmir.domain.subject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import edu.ucdavis.caelmir.actionForm.CohortForm;
import edu.ucdavis.caelmir.actionForm.ExperimentForm;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.Utility;

/**
 * A collection of animals within an experiemnt which share a common experiential condition
 * @author gautam_shetty
 * @hibernate.class table="CAELMIR_COHORT"
 */

public class Cohort extends AbstractDomainObject
        implements
            java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**System generated unique identifier.*/
    private Long id;

    /**name of cohort*/
    private String name;

    /**Defines the exact experimental manipulation that animal will undergo*/
    private String experimentalCondition;

    /**the date on which cohort is created*/
    private Date createdDate;

    /**Defines whether this cohort is active or in-active */
    private String activityStatus;

    /**Creator of the cohort */
    private edu.ucdavis.caelmir.domain.common.User creator;

    /**Animal collection associated with this cohort*/
    private Collection animalCollection = new HashSet();

    /**Experiment to which this cohort is associated*/
    private edu.ucdavis.caelmir.domain.research.Experiment experiment;

    /**
     * @return
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_COHORT_SEQ"
     */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * @return name of cohort
     * @hibernate.property name="name" column="NAME" type="string" length="150"
     */
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return experimentalCondition
     * @hibernate.property name="experimentalCondition" column="EXPERIMENTAL_CONDITION" type="string" length="255"
     */
    public String getExperimentalCondition()
    {
        return experimentalCondition;
    }

    public void setExperimentalCondition(String experimentalCondition)
    {
        this.experimentalCondition = experimentalCondition;
    }

    /**
     * @return Returns the startDate.
     * @hibernate.property name="createdDate" column="CREATED_DATE" type="date"
     */
    public Date getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    /**
     * Returns activityStatus of user
     * @hibernate.property name = "activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     * @return activityStatus of user
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @return
     * @hibernate.many-to-one column="USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.User getCreator()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.subject.Cohort thisIdSet = new edu.ucdavis.caelmir.domain.subject.Cohort();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                creator = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Cohort:getCreator throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return creator;

    }

    public void setCreator(edu.ucdavis.caelmir.domain.common.User creator)
    {
        this.creator = creator;
    }

    /**
     * @return
     * @hibernate.set name="animalCollection" table="CAELMIR_ANIMAL"
     * cascade="save-update" inverse="true" lazy="false"
     * @hibernate.collection-key column="COHORT_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.subject.Animal"
     */
    public Collection getAnimalCollection()
    {
        //			try{
        //			   if(animalCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.subject.Cohort thisIdSet = new edu.ucdavis.caelmir.domain.subject.Cohort();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.subject.Animal", thisIdSet);				 
        //				 	animalCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Cohort:getAnimalCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return animalCollection;
    }

    public void setAnimalCollection(Collection animalCollection)
    {
        this.animalCollection = animalCollection;
    }

    /**
     * @return
     * @hibernate.many-to-one column="EXPERIMENT_ID" class="edu.ucdavis.caelmir.domain.research.Experiment" constrained="true" cascade = "none" inverse = "false"
     */
    public edu.ucdavis.caelmir.domain.research.Experiment getExperiment()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.subject.Cohort thisIdSet = new edu.ucdavis.caelmir.domain.subject.Cohort();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.research.Experiment", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                experiment = (edu.ucdavis.caelmir.domain.research.Experiment)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Cohort:getExperiment throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return experiment;

    }

    public void setExperiment(
            edu.ucdavis.caelmir.domain.research.Experiment experiment)
    {
        this.experiment = experiment;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Cohort)
        {
            Cohort c = (Cohort) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    public Cohort(AbstractActionForm form)
    {
        setAllValues(form);
    }

    public Cohort()
    {
        // TODO Auto-generated constructor stub
    }

    /**
     * @return systemidentifier
     */
    public Long getSystemIdentifier()
    {

        return getId();
    }

    /**set systemidentifier */
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;

    }

    /**
     * This function Copies the data from an CohortForm object to a Cohort object.
     * @param abstractForm An CohortForm object containing the information about the cohort.  
     * */
    public void setAllValues(AbstractActionForm abstractForm)
    {
        CohortForm cform = (CohortForm) abstractForm;
        String operation = cform.getOperation();
        try
        {
            this.name = cform.getCohortName();
            this.experimentalCondition = cform.getExperimentalCondition();
            if (cform.getExperimentIdentifier() != null
                    && cform.getOperation() != null
                    && !cform.getExperimentIdentifier().equals("")
                    && cform.getOperation().equalsIgnoreCase(Constants.ADD))
            {
                Experiment experiment = new Experiment();
                experiment.setId(Long.valueOf(cform.getExperimentIdentifier()));
                this.setExperiment(experiment);
            }
            Date date = new Date();
            String rptDate;
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            rptDate = sdf.format(date);
            this.createdDate = Utility.parseDate(rptDate, Utility
                    .datePattern(rptDate));

            this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;

            List list = new ArrayList();
            StorageManager cache = new StorageManager();
            Map map = cform.getValuesMap();
            Set animalSet = new HashSet();
            if(map!=null && !map.isEmpty())
            {
                Set keys = map.keySet();
                Iterator it = keys.iterator(); 
                    
                while (it.hasNext())
                {
                    Mouse mouse = new Mouse();
                    String[] str1 = it.next().toString().split("_");
                    if (str1[0].equals(Constants.API_KEY))
                    {
                        list.add(str1[1]);
                    }
                    else
                    {
                        mouse.setId(new Long(str1[1]));
                        animalSet.add(mouse);
                    }
                }
            }
            setAnimalCollection(animalSet);
                cache.setMap(Constants.ANIMAL_ID_LIST, list);
            
        }
        catch (Exception e)
        {

        }
        
        if (operation != null
                && ((Constants.VIEW).equalsIgnoreCase(operation) || (Constants.EDIT)
                        .equalsIgnoreCase(operation)))
        {
            String status = cform.getActivityStatus();
            if (status != null
                    && (Constants.ACTIVITY_STATUS_DISABLED)
                            .equalsIgnoreCase(status))
            {
                //eform.setActivityStatus(null);            
                this.deleteObject(cform);
                cform.setActivityStatus(null);
            }

        }
    }
    
    /**
     * makes the activityStatus as "Disabled"
     * @param actionForm the associated formbean 
     */
    public void deleteObject(CohortForm actionForm)
    {
        this.activityStatus = Constants.ACTIVITY_STATUS_DISABLED;  
        //animalCollection = this.getAnimalCollection();
        this.setExperiment(null);
        Animal.setAnimalStatus(animalCollection,Constants.ACTIVITY_STATUS_DISABLED, new Boolean(true));
        
    }
    

    //publish
    public static void setCohortStatus(Collection cohortCollection,
            String status, Boolean cohortDeleteFlag)
    {
        if (cohortCollection != null && !cohortCollection.isEmpty())
        {
            Iterator cohortIterator = cohortCollection.iterator();
            while (cohortIterator.hasNext())
            {
                Cohort cohort = (Cohort) cohortIterator.next();
                 if (cohortDeleteFlag.booleanValue()) //if cohort delete = true 
                    cohort.setActivityStatus(status);
                else
                {
                    if (status.equals(Constants.ACTIVITY_STATUS_CLOSED)
                            || status
                                    .equalsIgnoreCase(Constants.ACTIVITY_STATUS_PUBLISHED))
                        cohort.setActivityStatus(status);
                    else
                    {
                        cohort
                                .setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
                        cohort.setExperiment(null);
                    }
                }

                if (cohortDeleteFlag.booleanValue()
                        && status
                                .equalsIgnoreCase(Constants.ACTIVITY_STATUS_DISABLED))
                {

                    Collection animalColl = cohort.getAnimalCollection();
                    Animal.setAnimalStatus(animalColl,status,new Boolean(false)); 
               
                }
                else if(status.equalsIgnoreCase(Constants.ACTIVITY_STATUS_PUBLISHED))
                {
                    Collection animalColl = cohort.getAnimalCollection();
                    Animal.setAnimalStatus(animalColl,status,new Boolean(false));
               
                }
                        
                    

            }

        }
    }

}
