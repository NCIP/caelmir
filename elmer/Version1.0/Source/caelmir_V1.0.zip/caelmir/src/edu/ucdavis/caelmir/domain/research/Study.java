
package edu.ucdavis.caelmir.domain.research;

import java.text.ParseException;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import edu.ucdavis.caelmir.actionForm.StudyForm;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;
import edu.wustl.common.util.Utility;

/**
 * @version 1.0
 * @created 15-May-2006 12:20:30 PM
 * @hibernate.class table="CAELMIR_STUDY"
 */
public class Study extends AbstractDomainObject implements java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**Unique identifier for the study*/
    private Long id;

    /**Name of the study*/
    private String name;

    /**Hypothesis of the study*/
    private String hypothesis;

    /**Brief description about the purpose of the study*/
    private String description;

    /**Date specifying when the study investigation started*/
    private Date investigationStartDate;

    /**Date specifying when the study investigation finished*/
    private Date investigationStopDate;

    /**Activity status of the study. Specifies whether this study is active closed or published or closed.*/
    private String activityStatus;

    /**Creator user of the study.*/
    private edu.ucdavis.caelmir.domain.common.User creator;

    /**Collection of all the users who are part of this study*/
    private Collection userCollection = new HashSet();

    /**Collection of all the experiments which are to be carried out in this study*/
    private Collection experimentCollection = new HashSet();

    /**Primary investigator of the study*/
    private edu.ucdavis.caelmir.domain.common.User primaryInvestigator;

    /**Collection of all the protocols associated with the study*/
    private Collection collectionProtocolCollection = new HashSet();

    /**Collection of all the user groups which are part of this study*/
    private Collection userGroupCollection = new HashSet();

    /**Date on which study was created.*/
    private Date createdDate;

    /**Model object under which this study is carried out */
    private edu.ucdavis.caelmir.domain.research.Model model;

    /**
     * @return study object this experiment is associated with.
     * @hibernate.many-to-one column="MODEL_ID" class="edu.ucdavis.caelmir.domain.research.Model" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.research.Model getModel()
    {

        return model;

    }

    public void setModel(edu.ucdavis.caelmir.domain.research.Model model)
    {
        this.model = model;
    }

    /**
     * @return Returns the startDate.
     * @hibernate.property name="createdDate" column="CREATED_DATE" type="date"
     */
    public Date getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    /**
     * Returns the unique systemIdentifier assigned to institution.
     * @hibernate.id name="id" column="IDENTIFIER" type="long"
     * length="30" unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_STUDY_SEQ"
     * @return A unique systemIdentifier assigned to the institution.
     * @see #setIdentifier(int)
     * */
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    /**
     * @return Returns the name.
     * @hibernate.property name="name" type="string" column="NAME" length="150"
     */
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * @return Returns the hypothesis.
     * @hibernate.property name="hypothesis" type="string" column="HYPOTHESIS" length="100"
     */
    public String getHypothesis()
    {
        return hypothesis;
    }

    public void setHypothesis(String hypothesis)
    {
        this.hypothesis = hypothesis;
    }

    /**
     * @return Returns the description.
     * @hibernate.property name="description" type="string" column="DESCRIPTION" length="255"
     */
    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    /**
     * @return Returns the startDate.
     * @hibernate.property name="investigationStartDate" column="INVESTIGATION_START_DATE" type="date"
     */
    public Date getInvestigationStartDate()
    {
        return investigationStartDate;
    }

    public void setInvestigationStartDate(Date investigationStartDate)
    {
        this.investigationStartDate = investigationStartDate;
    }

    /**
     * @return Returns the stopDate.
     * @hibernate.property name="investigationStopDate" column="INVESTIGATION_STOP_DATE" type="date"
     */
    public Date getInvestigationStopDate()
    {
        return investigationStopDate;
    }

    public void setInvestigationStopDate(Date investigationStopDate)
    {
        this.investigationStopDate = investigationStopDate;
    }

    /**
     * @return Returns the activityStatus.
     * @hibernate.property name="activityStatus" type="string" column="ACTIVITY_STATUS" length="10"
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    /**
     * @return
     * @hibernate.many-to-one column="USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */

    public edu.ucdavis.caelmir.domain.common.User getCreator()
    {

        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.research.Study thisIdSet = new edu.ucdavis.caelmir.domain.research.Study();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                creator = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Study:getCreator throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return creator;

    }

    public void setCreator(edu.ucdavis.caelmir.domain.common.User creator)
    {
        this.creator = creator;
    }

    /**
     * @return Returns the userGroupCollection.
     * @hibernate.set name="userCollection" table="CAELMIR_STUDY_USER" 
     * cascade="none" inverse="false" lazy="false"
     * @hibernate.collection-key column="STUDY_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.common.User" column="USER_ID"
     */

    public Collection getUserCollection()
    {
        //			try{
        //			   if(userCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.research.Study thisIdSet = new edu.ucdavis.caelmir.domain.research.Study();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //				 	userCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Study:getUserCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return userCollection;
    }

    public void setUserCollection(Collection userCollection)
    {
        this.userCollection = userCollection;
    }

    /**
     * @return Returns the experimentCollection.
     * @hibernate.set name="experimentCollection" table="CAELMIR_EXPERIMENT" cascade="save-update"
     * inverse="true" lazy="false"
     * @hibernate.collection-key column="STUDY_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.research.Experiment"
     */
    public Collection getExperimentCollection()
    {
        //			try{
        //			   if(experimentCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.research.Study thisIdSet = new edu.ucdavis.caelmir.domain.research.Study();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.research.Experiment", thisIdSet);				 
        //				 	experimentCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Study:getExperimentCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return experimentCollection;
    }

    public void setExperimentCollection(Collection experimentCollection)
    {
        this.experimentCollection = experimentCollection;
    }

    /**
     * @return
     * @hibernate.many-to-one column="PRIMARY_INVESTIGATOR_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.User getPrimaryInvestigator()
    {
        //			
        //			
        //			
        //			  ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			  edu.ucdavis.caelmir.domain.research.Study thisIdSet = new edu.ucdavis.caelmir.domain.research.Study();
        //			  thisIdSet.setId(this.getId());
        //			  
        //			  try {
        //			      List resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.User", thisIdSet);				 
        //		             if (resultList!=null && resultList.size()>0) {
        //		                primaryInvestigator = (edu.ucdavis.caelmir.domain.common.User)resultList.get(0);
        //		             }
        //		          
        //			  } catch(Exception ex) 
        //			  { 
        //			      	System.out.println("Study:getPrimaryInvestigator throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			  }
        return primaryInvestigator;

    }

    public void setPrimaryInvestigator(
            edu.ucdavis.caelmir.domain.common.User primaryInvestigator)
    {
        this.primaryInvestigator = primaryInvestigator;
    }

    /**
     * @return Returns the protocolCollection.
     * @hibernate.set name="collectionProtocolCollection" table="CAELMIR_STUDY_PROTOCOL_REL" 
     * cascade="none" inverse="false" lazy="false"
     * @hibernate.collection-key column="STUDY_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.protocol.CollectionProtocol" column="COLLECTION_PROTOCOL_ID"
     */
    public Collection getCollectionProtocolCollection()
    {
        //			try{
        //			   if(collectionProtocolCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.research.Study thisIdSet = new edu.ucdavis.caelmir.domain.research.Study();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.protocol.CollectionProtocol", thisIdSet);				 
        //				 	collectionProtocolCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Study:getCollectionProtocolCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return collectionProtocolCollection;
    }

    public void setCollectionProtocolCollection(
            Collection collectionProtocolCollection)
    {
        this.collectionProtocolCollection = collectionProtocolCollection;
    }

    /**
     * @return Returns the userGroupCollection.
     * @hibernate.set name="userGroupCollection" table="CAELMIR_STUDY_GROUP" 
     * cascade="none" inverse="false" lazy="false"
     * @hibernate.collection-key column="STUDY_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.common.UserGroup" column="USER_GROUP_ID"
     */
    public Collection getUserGroupCollection()
    {
        //			try{
        //			   if(userGroupCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.research.Study thisIdSet = new edu.ucdavis.caelmir.domain.research.Study();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.common.UserGroup", thisIdSet);				 
        //				 	userGroupCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("Study:getUserGroupCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return userGroupCollection;
    }

    public void setUserGroupCollection(Collection userGroupCollection)
    {
        this.userGroupCollection = userGroupCollection;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof Study)
        {
            Study c = (Study) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    public Long getSystemIdentifier()
    {
        return id;
    }

    /**
     * Sets an systemIdentifier for the institution.
     * @param systemIdentifier Unique systemIdentifier to be assigned to the institution.
     * @see #getIdentifier()
     * */
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;
    }

    /**
     * @throws AssignDataException 
     * 
     */
    public void setAllValues(AbstractActionForm actionForm)
            throws AssignDataException
    {

        StudyForm studyForm = (StudyForm) actionForm;
        String operation = studyForm.getOperation();
        String status = studyForm.getActivityStatus();

        if (!actionForm.getOperation().equalsIgnoreCase(Constants.EDIT))
        {
            this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
        }
        else if (status != null)
        {
            this.activityStatus = actionForm.getActivityStatus();
            actionForm.setActivityStatus(null);
        }

        if (operation != null
                && ((Constants.VIEW).equalsIgnoreCase(operation) || (Constants.EDIT)
                        .equalsIgnoreCase(operation)))
        {
            if (status != null
                    && (Constants.ACTIVITY_STATUS_CLOSED)
                            .equalsIgnoreCase(status))
            {
                this.closeAllObjects();
            }
            else if (status != null
                    && (Constants.ACTIVITY_STATUS_DISABLED)
                            .equalsIgnoreCase(status))
            {
                actionForm.setActivityStatus(null);
                this.deleteObject(studyForm);
            }
            else if (status != null
                    && (Constants.ACTIVITY_STATUS_PUBLISHED)
                            .equalsIgnoreCase(status))
            {
                this.publishObject();
            }
        } //else {
        if (status != null
                && !(Constants.ACTIVITY_STATUS_PUBLISHED)
                        .equalsIgnoreCase(status))
        {
            this.description = studyForm.getStudyDescription();
            this.hypothesis = studyForm.getStudyHypothesis();
            this.name = studyForm.getStudyName();

            if (studyForm.getModelId() != null
                    && !studyForm.getModelId().equals("")
                    && !studyForm.getModelId().equals(new String("-1")))
            {
                Model model = new Model();
                model.setSystemIdentifier(new Long(studyForm.getModelId()));
                this.model = model;
            }

            if (studyForm.getInvestigationStartDate() != null)
            {
                try
                {
                    this.investigationStartDate = Utility.parseDate(studyForm
                            .getInvestigationStartDate());
                }
                catch (ParseException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            if (studyForm.getInvestigationEndDate() != null
                    && studyForm.getInvestigationEndDate().length() > 0)
            {
                try
                {
                    this.investigationStopDate = Utility.parseDate(studyForm
                            .getInvestigationEndDate());
                    this.activityStatus = Constants.ACTIVITY_STATUS_CLOSED;
                }
                catch (ParseException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            String[] userArray = studyForm.getUsers();
            User user = null;
            Collection studyUserList = new HashSet();
            if (userArray != null)
            {

                for (int counter = 0; counter < userArray.length; counter++)
                {
                    user = new User();
                    user.setId(new Long(userArray[counter]));
                    // StudyUser studyUser = new StudyUser ();
                    //studyUser.setStudy(this);
                    // studyUser.setUser(user);
                    studyUserList.add(user);
                }
            }
            this.setUserCollection(studyUserList);

            String[] userGroupArray = studyForm.getUserGroups();
            UserGroup userGroup = null;
            Collection studyUserGroupList = new HashSet();
            if (userGroupArray != null)
            {

                for (int counter = 0; counter < userGroupArray.length; counter++)
                {
                    userGroup = new UserGroup();
                    userGroup.setId(new Long(userGroupArray[counter]));
                    studyUserGroupList.add(userGroup);
                }
            }
            this.setUserGroupCollection(studyUserGroupList);
            //this.getUserGroupCollection().clear();
            //this.getUserGroupCollection().addAll(studyUserGroupList);

            String[] protocolArray = studyForm.getProtocols();
            CollectionProtocol protocol;
            Collection studyProtocolList = new HashSet();
            if (protocolArray != null)
            {

                for (int counter = 0; counter < protocolArray.length; counter++)
                {
                    protocol = new CollectionProtocol();
                    protocol.setId(new Long(protocolArray[counter]));
                    studyProtocolList.add(protocol);
                }
            }
            this.setCollectionProtocolCollection(studyProtocolList);

            //  } 
        }
    }

    private void publishObject()
    {
        this.activityStatus = Constants.ACTIVITY_STATUS_PUBLISHED;
        //TODO Check what else needs to be done while publishing the study....
        /* 1: Get associated experiment,cohort,animal,and its exp data             
         */
        Experiment.setExperimentStatus(experimentCollection,
                this.activityStatus, new Boolean(false));

    }

    public void closeAllObjects()
    {
        this.activityStatus = Constants.ACTIVITY_STATUS_CLOSED;
        Experiment.setExperimentStatus(experimentCollection,
                Constants.ACTIVITY_STATUS_CLOSED, new Boolean(false));

    }

    public void deleteObject(StudyForm actionForm)
    {
        this.activityStatus = Constants.ACTIVITY_STATUS_DISABLED;
        Boolean deleteCohortFlag = actionForm.getDeleteCohortFlag();
        Experiment.setExperimentStatus(experimentCollection,
                Constants.ACTIVITY_STATUS_DISABLED, deleteCohortFlag);
    }

    public Study(AbstractActionForm form)
    {
        try
        {
            setAllValues(form);
        }
        catch (AssignDataException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public Study()
    {
        // TODO Auto-generated constructor stub
    }

}