
package edu.ucdavis.caelmir.bizlogic;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.CMSClient;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**Description: This class is used to insert the Case object in the database or update it. 
 * Title:TODO
 * Copyright:TODO
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class CaseBizLogic extends DefaultBizLogic
{

    /**
     * Saves the user object in the database.
     * @param obj The user object to be saved.
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    protected void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {

        PathologyEventRecords caseObject = (PathologyEventRecords) obj;
        caseObject.setModifiedDate(new Date());

        Mouse mouse = (Mouse) caseObject.getAnimal();
        Mouse mousefromTable = (Mouse) dao.retrieve(Mouse.class.getName(),
                mouse.getSystemIdentifier());
        caseObject.setAnimal(mousefromTable);

        caseObject.setCreatedDate(new Date());
        User user = (User) ((List) dao.retrieve(User.class.getName(),
                Constants.ID, sessionDataBean.getUserId())).get(0);
        caseObject.setCreator(user);

        if (caseObject.getEntityMap() != null)
        {
            EntityMap entityMap = (EntityMap) caseObject.getEntityMap();
            List entityMapList = (List) dao.retrieve(EntityMap.class.getName(),
                    Constants.ID, entityMap.getId());
            if (entityMapList != null && !entityMapList.isEmpty())
            {
                EntityMap entityMapFromTable = (EntityMap) entityMapList.get(0);       
                
                caseObject.setEntityMap(entityMapFromTable);
            }
        }

        Collection tissueColl = caseObject.getTissueCollection();
        Iterator iterate = tissueColl.iterator();
        Set tempSet = new HashSet();
        while (iterate.hasNext())
        {
            Tissue tissue = (Tissue) iterate.next();
            Tissue tissuefromTable = (Tissue) dao.retrieve(Tissue.class
                    .getName(), tissue.getId());
            tempSet.add(tissuefromTable);
            tissuefromTable.setPathologyEventRecords(caseObject);
        }
        caseObject.setTissueCollection(tempSet);

        StorageManager storage = new StorageManager();
        String pathnum = (String) caseObject.getPathologyNumber();

        List list = (List) storage.getMap(Constants.PATHOLOGY_LIST);
        String sourceLocal = (String) storage.getMap(Constants.POSITION);
        CMSClient client = new CMSClient();
        List idList = new ArrayList();

        try
        {
            if (list != null && !list.isEmpty() && !sourceLocal.equals("")
                    && sourceLocal.equalsIgnoreCase("false"))
            {
                for (int i = 0; i < list.size(); i++)
                {
                    PathologyEventRecords tgMouse = (PathologyEventRecords) list
                            .get(i);
                    if (tgMouse.getPathologyNumber().equals(pathnum))
                    {
                        /********** Mark in dataBase*************/
                        idList.add(pathnum);
                        int val = client.markTgMouseRecords(idList);

                        // if(val==1)
                        dao.insert(caseObject, sessionDataBean, true, false);

                        break;
                    }
                }
            }
            else
                dao.insert(caseObject, sessionDataBean, true, false);

        }
        catch (Exception e)
        {
            //call umnmark method
            try
            {
                client.unmarkTgMouseRecords(idList);
            }
            catch (Exception ex)
            {
            }

        }
        finally
        {
            storage.remove(Constants.PATHOLOGY_LIST);
            storage.remove(Constants.POSITION);
        }

    }

    /**
     * Updates the experiment object in the database.
     * @param obj The experiment object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    public void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {
        PathologyEventRecords caseObject = (PathologyEventRecords) obj;
        
       // PathologyEventRecords oldCaseObject = (PathologyEventRecords) oldObj;

        List list = (List) dao.retrieve(PathologyEventRecords.class.getName(),
                Constants.ID, caseObject.getId());
        if (list != null && !list.isEmpty())
        {
            PathologyEventRecords oldCaseObject = (PathologyEventRecords) list
                    .get(0);
            
            oldCaseObject.setActivityStatus(caseObject.getActivityStatus());
            /*
            if(!caseObject.getActivityStatus().equals(Constants.ACTIVITY_STATUS_DISABLED))
                newPathology.setActivityStatus(caseObject.getActivityStatus());
            else
                newPathology.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
            */
           
            
            Collection oldTissueColl = oldCaseObject.getTissueCollection();

            Collection tissueColl = caseObject.getTissueCollection();
            
            Set tempSet = new HashSet();
            Iterator itr = oldTissueColl.iterator();
            while (itr.hasNext()) {
                Tissue tissue = (Tissue) itr.next();
                
                if (!tissueColl.contains(tissue)) {
                    tissue.setPathologyEventRecords(null);
                    tissue.setActivityStatus(Constants.ACTIVITY_STATUS_DISABLED);
                    Collection slideCol = tissue.getSlideCollection();
                    Iterator iter = slideCol.iterator();
                    while (iter.hasNext()) {
                        Slide slide = (Slide) iter.next();
                        slide.setActivityStatus(Constants.ACTIVITY_STATUS_DISABLED);
                    }
                    tempSet.add((Tissue) tissue);
                }
            }

           // Collection tissueColl = caseObject.getTissueCollection();
            Iterator iterate = tissueColl.iterator();
          //  Set tempSet = new HashSet();
            while (iterate.hasNext())
            {
                Tissue tissue = (Tissue) iterate.next();
                Tissue tissuefromTable = (Tissue) dao.retrieve(Tissue.class
                        .getName(), tissue.getId());
                if(caseObject.getActivityStatus().equals(Constants.ACTIVITY_STATUS_DISABLED))
                {
                    tissuefromTable.setPathologyEventRecords(null);
                    tissuefromTable.setActivityStatus(Constants.ACTIVITY_STATUS_DISABLED);
                }
                else
                {
                    tempSet.add(tissuefromTable);
                    tissuefromTable.setPathologyEventRecords(oldCaseObject);
                }
            }
            oldCaseObject.setTissueCollection(tempSet);

            if(caseObject.getActivityStatus().equals(Constants.ACTIVITY_STATUS_DISABLED))
            {
                oldCaseObject.setEntityMap(null);
                oldCaseObject.setAnimal(null);
            }
            else    
            if (caseObject.getEntityMap() != null)
            {
                EntityMap entityMap = (EntityMap) caseObject.getEntityMap();
                List entityMapList = (List) dao.retrieve(EntityMap.class
                        .getName(), Constants.ID, entityMap.getId());
                if (entityMapList != null && !entityMapList.isEmpty())
                {
                    EntityMap entityMapFromTable = (EntityMap) entityMapList
                            .get(0);
                 //   oldCaseObject.setEntityMap(entityMapFromTable);
                }
            }

            oldCaseObject.setPathologyNumber(caseObject.getPathologyNumber());
            oldCaseObject.setCreatedDate(caseObject.getCreatedDate());
            oldCaseObject.setMicroscopicDescription(caseObject
                        .getMicroscopicDescription());
            oldCaseObject.setDiagnosis(caseObject.getDiagnosis());
            oldCaseObject.setGross(caseObject.getGross());
            oldCaseObject.setModifiedDate(new Date());
            oldCaseObject.setName(caseObject.getName());
            

            StorageManager storage = new StorageManager();
            String pathnum = (String) caseObject.getPathologyNumber();

            List pathlogyList = (List) storage.getMap(Constants.PATHOLOGY_LIST);
            String sourceLocal = (String) storage.getMap(Constants.POSITION);
            CMSClient client = new CMSClient();
            List idList = new ArrayList();

            try
            {
                if (pathlogyList != null
                        && !pathlogyList.isEmpty()
                        && sourceLocal.equalsIgnoreCase("false")
                        && !caseObject.getPathologyNumber()
                                .equals(""))
                {
                    for (int i = 0; i < pathlogyList.size(); i++)
                    {
                        PathologyEventRecords tgMouse = (PathologyEventRecords) pathlogyList
                                .get(i);
                        if (tgMouse.getPathologyNumber().equals(pathnum))
                        {
                            /********** Mark in dataBase*************/
                            idList.add(pathnum);
                            //  int val = client.markTgMouseRecords(idList);

                            //  if(val==1)
                            dao.update(oldCaseObject, null, true, false, false);
                            break;
                        }
                    }
                }
                else
                    dao.update(oldCaseObject, null, true, false, false);

            }
            catch (Exception e)
            {
                //call umnmark method
                try
                {
                    //   client.unmarkTgMouseRecords(idList);
                }
                catch (Exception ex)
                {
                }

            }
            finally
            {
                storage.remove(Constants.PATHOLOGY_LIST);
                storage.remove(Constants.POSITION);
            }

        }
    }
}
