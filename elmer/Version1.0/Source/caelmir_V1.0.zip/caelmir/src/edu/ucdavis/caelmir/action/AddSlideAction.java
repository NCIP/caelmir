/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.SlideForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.Tissue;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;



public class AddSlideAction extends BaseAction
{

    protected List getSelectedImages(ActionForm form) {
        SlideForm eform = (SlideForm) form;
        List imageList = new ArrayList();
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        if (eform.getImages() != null)
            for (int i = 0; i < eform.getImages().length; i++)
            {
                Object[] whereColumnValue = {eform.getImages()[i]};
                List list = null;
                try
                {
                    list = bizLogic.retrieve(Image.class.getName(),"id", whereColumnValue);
                }
                catch (DAOException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                if (list!=null && list.size() > 0) {
                    NameValueBean nameValue = new NameValueBean();
                    Image image = (Image) list.get(0);
                    nameValue.setValue(image.getId());
                    String type = "";
                    if (image.getImageType() != null) {
                        type = "[" + image.getImageType().getName() + "]";
                    }
                    nameValue.setName(type + "  " + image.getFileName());
                    imageList.add(nameValue);
                }
            }
        return imageList;
    }
    
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,HttpServletRequest request,
            HttpServletResponse response) 
    {
    
        String operation = request.getParameter(Constants.OPERATION);
        request.setAttribute(Constants.OPERATION, operation);
        
        String pageOf = request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);

        List imageList = new ArrayList();
      //  if (operation!=null && operation.equals("edit")) {
            imageList = getSelectedImages(form);
        //}
            SlideForm sForm = (SlideForm)form;
            DefaultBizLogic bizLogic =  (DefaultBizLogic)BizLogicFactory.getBizLogic(sForm.getFormId());
            List caseObjectList=null;
            try
            {
                if(sForm.getTissueId() != null)
                    caseObjectList = bizLogic.retrieve(Tissue.class.getName(),Constants.ID,sForm.getTissueId());
            }
            catch (DAOException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            if (caseObjectList != null && caseObjectList.size() > 0) {
                request.setAttribute(Constants.TISSUE,((Tissue) caseObjectList.get(0)).getTissueLongName());
                request.setAttribute(Constants.TISSUE_IDENTIFIER,((Tissue) caseObjectList.get(0)).getId());
            }

       // request.setAttribute(Constants.SLIDE_LIST, slideList);
        request.setAttribute(Constants.SLIDE_LIST,new ArrayList());
       request.setAttribute(Constants.IMAGE_LIST,imageList);
        request.setAttribute(Constants.IMAGE_TYPE_LIST,getImageTypeList());
        
        return mapping.findForward(pageOf);
        
    }
    
    protected List getImageTypeList() {
        List list = new ArrayList();
        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List imageTypes = null;
        try
        {
            imageTypes = bizLogic.retrieve(ImageType.class.getName());
        }
        catch (DAOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        if (imageTypes!=null) {
            Iterator iter = imageTypes.iterator();
            while (iter.hasNext()) {
                ImageType imageType = (ImageType) iter.next();
                NameValueBean nameValue = new NameValueBean();
                nameValue.setName(imageType.getName());
                nameValue.setValue(imageType.getId());
                list.add(nameValue);
            }
        }
        
        return list;
    }
    
}
