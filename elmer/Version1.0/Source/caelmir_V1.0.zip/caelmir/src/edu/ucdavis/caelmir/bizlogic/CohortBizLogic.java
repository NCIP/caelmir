/**
 *<p>Title:CohortBizLogic Class </p>
 *<p>Description: This class is used to add/update cohort information into database </p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.bizlogic;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.CMSClient;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * CohortBizLogic class is used to add/update cohort information into database.
 * @author shital_lawhale
 */
public class CohortBizLogic extends DefaultBizLogic
{

    /**
     * Saves the cohort object in the database.
     * @param obj The cohort object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    public void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {

        Cohort cohort = (Cohort) obj;

        User creator = (User) dao.retrieve(User.class.getName(),
                sessionDataBean.getUserId());
        cohort.setCreator(creator);

        if (cohort.getExperiment() != null)
        {
            Long id = cohort.getExperiment().getId();
            List experimentList = dao.retrieve(Experiment.class.getName(),
                    Constants.ID, id);
            if (experimentList != null && !experimentList.isEmpty())
            {
                Experiment experiment = (Experiment) experimentList.get(0);
                Collection cohortCollection = experiment.getCohortCollection();
                if (cohortCollection != null)
                {
                    cohortCollection.add(cohort);

                }
                else
                {
                    cohortCollection = new HashSet();
                    cohortCollection.add(cohort);

                }
                experiment.setCohortCollection(cohortCollection);
                cohort.setExperiment(experiment);
            }
        }
        Collection animalColl = cohort.getAnimalCollection();
        Iterator iterate = animalColl.iterator();

        Set tempSet = new HashSet();
        StorageManager storage = new StorageManager();

        List list = (List) storage.getMap(Constants.SELECTED_ANIMAL_LIST);
        List idList = (List) storage.getMap(Constants.ANIMAL_ID_LIST);
        
        List markList= new ArrayList();

        while (iterate.hasNext())
        {
            Mouse animal = (Mouse) iterate.next();
            Mouse anim = new Mouse();
            anim = (Mouse) dao
                    .retrieve(Mouse.class.getName(), animal.getId());
            tempSet.add(anim);
            anim.setCohort(cohort);
        }

        if (idList != null && !idList.isEmpty() )
        {
            int i = 0;
            while (i < idList.size())
            {
                Mouse anim = new Mouse();
                anim = (Mouse) list.get(Integer.parseInt((String) idList
                        .get(i)));
                i++;
                markList.add(anim.getAnimalColonyReference());
                anim.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
                anim.setId(null);
                anim.setSystemIdentifier(null);
               //******************* anim.setCreatedDate();
                tempSet.add(anim);
                anim.setCohort(cohort);
            }
        }
            /**
             * call mark method if return sucessful then 
             * only insert into local databse
             */
            CMSClient client = new CMSClient();
            try
            {
                //call mark method   
                if (markList != null && !markList.isEmpty() )
                {                   
                    int flag= client.markAnimals(markList);                   
                    if(flag==1)   //if success
                    {
                        cohort.setAnimalCollection(tempSet);
                        dao.insert(cohort, null, true, false);
                    }
                }
                else
                {
                    cohort.setAnimalCollection(tempSet);
                    dao.insert(cohort, null, true, false);
                }
            }
            catch (Exception e)
            {
                //call umnmark method
                try{
                client.unmarkAnimals(markList);}
                catch(Exception ex){}
                
            }
            finally
            {
                storage.remove(Constants.SELECTED_ANIMAL_LIST);
                storage.remove(Constants.ANIMAL_ID_LIST);
            }
       
    }
    
    public boolean checkChildObjects(Mouse animal) {
        Collection eventRecords = animal.getEventRecordsCollection();
        if (animal.getEventRecordsCollection()!= null && animal.getEventRecordsCollection().size() > 0) {
            return true;
        }
        /*Iterator iter = eventRecords.iterator();
        while (iter.hasNext()) {
            EventRecords event = (EventRecords) iter.next();
            event.getEntityMap()
        }*/
        return false;
    }

    /**
     * Updates the cohort object in the database.
     * @param obj The cohort object to be updated.
     * @param dao The hibernate data access object
     * @param session The session object.
     * @throws DAOException
     */
    public void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {
        Cohort cohort = (Cohort) obj;
        Cohort newCohort = (Cohort) oldObj;
        Collection animalColl = cohort.getAnimalCollection();
        cohort.setAnimalCollection(null);
        dao.update(cohort, null, true, false, false);
        
        Set tempSet = new HashSet();
         Collection newColl = newCohort.getAnimalCollection();
      
        Iterator itr = newColl.iterator();
        while (itr.hasNext()) {
            Mouse newAni = (Mouse) itr.next();
            
            if (!animalColl.contains(newAni)) {
                if(!checkChildObjects(newAni)) {
                    newAni.setCohort(null);
                    tempSet.add((Mouse) newAni);
                }
            }
        }
        
        if (animalColl != null)
        {
            Iterator iterate = animalColl.iterator();
            while (iterate.hasNext())
            {
                Mouse animal = (Mouse) iterate.next();
                Mouse anim = (Mouse) dao.retrieve(Mouse.class.getName(),
                        animal.getId());
                if(!cohort.getActivityStatus().equalsIgnoreCase(Constants.ACTIVITY_STATUS_DISABLED))
                {                
                    anim.setCohort(cohort);
                    tempSet.add(anim);
                }
                else
                {
                    anim.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
                    anim.setCohort(null);
                }
            }
            
            StorageManager storage = new StorageManager();

            List list = (List) storage.getMap(Constants.SELECTED_ANIMAL_LIST);
            List idList = (List) storage.getMap(Constants.ANIMAL_ID_LIST);
            List markList= new ArrayList();

            if (idList != null && !idList.isEmpty() )
            {
                int i = 0;
                while (i < idList.size())
                {
                    Mouse anim = new Mouse();
                    anim = (Mouse) list.get(Integer.parseInt((String) idList
                            .get(i)));
                    i++;
                    markList.add(anim.getAnimalColonyReference());
                    anim.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
                    anim.setId(null);
                    anim.setSystemIdentifier(null);
                   //******************* anim.setCreatedDate();
                    anim.setCohort(cohort);
                    tempSet.add(anim);
                }
            }
       /*     cohort.setAnimalCollection(tempSet);
            dao.update(cohort, null, false, false, false);*/
            
            /**
             * call mark method if return sucessful then 
             * only insert into local databse
             */
            CMSClient client = new CMSClient();
            try
            {
     //call mark method   
                if (markList != null && !markList.isEmpty() )
                {                   
                    int flag= client.markAnimals(markList);                   
                    if(flag==1)   //if success
                    {
                        cohort.setAnimalCollection(tempSet);
                        dao.update(cohort, null, true, false, false);
                    }
                }
                else
                {
                    cohort.setAnimalCollection(tempSet);
                    dao.update(cohort, null, true, false, false);
                }
            }
            catch (Exception e)
            {
                //call umnmark method
                try{
                client.unmarkAnimals(markList);}
                catch(Exception ex){}
                
            }
            finally
            {
                storage.remove(Constants.SELECTED_ANIMAL_LIST);
                storage.remove(Constants.ANIMAL_ID_LIST);
            }
            
            
            
            
        }

    }
}