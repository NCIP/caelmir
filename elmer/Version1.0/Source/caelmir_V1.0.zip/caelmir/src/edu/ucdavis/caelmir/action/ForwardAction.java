/*
 * Created on Sep 1, 2005
 * This class is used to redirect the user to the Home / SignIn Page after session is timedOut.
 */

package edu.ucdavis.caelmir.action;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.action.BaseAction;

/**
 * @author mandar_deshmukh
 *
 * This class is used to redirect the user to the Home / SignIn Page after session is timedOut.
 */
public class ForwardAction extends BaseAction
{

	public ActionForward executeAction(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	{
		/*  added by Ravinder */
        
        Properties prop = new Properties();
        try {
			prop.load(new FileInputStream(Variables.caElmirHome
				        + System.getProperty(Constants.FILE_SEPARATOR)
				        + Constants.PROPERTIES_FILE));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    String versionname = (String) prop.get(Constants.VERSION_NAME);
	   	request.setAttribute(Constants.VERSION_NAME,versionname);
    	
	   	String target= Constants.SUCCESS;
	   	
	   	HttpSession session=request.getSession();
	   	String isPublicSearch = (String) session.getAttribute("isPublicSearch");
	   	
	   	if(isPublicSearch != null 
	   			 && isPublicSearch.equalsIgnoreCase("true"))
	   	{	
	   	      target=Constants.FAILURE;
	   	      session.removeAttribute(Constants.SESSION_DATA);         
	   	}		 
	 
		return (mapping.findForward(target));
	}

}