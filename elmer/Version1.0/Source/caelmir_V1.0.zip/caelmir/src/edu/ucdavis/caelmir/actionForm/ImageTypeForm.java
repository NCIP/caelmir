/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.actionForm;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.common.ImageType;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;


/**
 * @author sandeep_chinta
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class ImageTypeForm extends AbstractActionForm
{

   // private Long id;
    
    private String name;
    
    private String description;
    
    /**
     * @return Returns the description.
     */
    public String getDescription()
    {
        return description;
    }
    /**
     * @param description The description to set.
     */
    public void setDescription(String description)
    {
        this.description = description;
    }
    /**
     * @return Returns the name.
     */
    public String getName()
    {
        return name;
    }
    /**
     * @param name The name to set.
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /* (non-Javadoc)
     * @see edu.wustl.common.actionForm.AbstractActionForm#getFormId()
     */
    public int getFormId()
    {
        return Constants.IMAGE_TYPE_FORM_ID;
    }

    /* (non-Javadoc)
     * @see edu.wustl.common.actionForm.AbstractActionForm#setAllValues(edu.wustl.common.domain.AbstractDomainObject)
     */
    public void setAllValues(AbstractDomainObject arg0)
    {
       ImageType imageType = (ImageType) arg0;
       this.name = imageType.getName();
       this.description = imageType.getDescription();
       this.id = imageType.getId().longValue();
     //  this.setSystemIdentifier(imageType.getId().longValue());

    }

    /* (non-Javadoc)
     * @see edu.wustl.common.actionForm.AbstractActionForm#reset()
     */
    protected void reset()
    {
        // TODO Auto-generated method stub

    }

    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
    /**
     * Overrides the validate method of ActionForm.
     * */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        
        if (validator.isEmpty(String.valueOf(name))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("imageType.name")));
        }
       
        return errors;
    }
    
    /**
     * @return Returns the id.
     */
   /* public Long getId()
    {
        return id;
    }*/
    /**
     * @param id The id to set.
     */
 /*   public void setId(Long id)
    {
        this.id = id;
    }*/
}
