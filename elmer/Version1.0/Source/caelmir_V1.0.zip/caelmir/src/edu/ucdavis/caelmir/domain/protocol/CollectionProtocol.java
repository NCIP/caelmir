
package edu.ucdavis.caelmir.domain.protocol;

import java.text.ParseException;
import java.util.Collection;
//import java.util.HashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import edu.ucdavis.caelmir.actionForm.CollectionProtocolForm;

import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.MicroarrayEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.PathologyEventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.ProteomicsEventRecords;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.exception.AssignDataException;
import edu.wustl.common.util.Utility;

/**
 * A set of written procedures that describe how a biospecimen is prospectively collected 
 * @author Vishvesh Mulay
 * @hibernate.joined-subclass table="CAELMIR_COLLECTION_PROTOCOL"
 * @hibernate.joined-subclass-key column="IDENTIFIER" 
 */

public class CollectionProtocol extends SpecimenProtocol
        implements
            java.io.Serializable
{

    private static final long serialVersionUID = 1234567890L;

    /**Creator user of the collection protocol*/
    private edu.ucdavis.caelmir.domain.common.User creator;

    /**Collection of all the events associated with this protocol*/
    private Collection collectionProtocolEventCollection = new LinkedHashSet();

    /**Collection of all the experiments associated with this protocol*/
    private Collection experimentCollection = new LinkedHashSet();

    /**Collection of all the studies associated with this protocol.*/
    private Collection studyCollection = new LinkedHashSet();

    /**
     * @return the user object
     * @hibernate.many-to-one column="USER_ID" class="edu.ucdavis.caelmir.domain.common.User" constrained="true"
     */
    public edu.ucdavis.caelmir.domain.common.User getCreator()
    {

        //        ApplicationService applicationService = ApplicationServiceProvider
        //                .getApplicationService();
        //        edu.ucdavis.caelmir.domain.protocol.CollectionProtocol thisIdSet = new edu.ucdavis.caelmir.domain.protocol.CollectionProtocol();
        //        thisIdSet.setId(this.getId());
        //
        //        try
        //        {
        //             List resultList = applicationService.search(
        //                    "edu.ucdavis.caelmir.domain.common.User", thisIdSet);
        //            if (resultList != null && resultList.size() > 0)
        //            {
        //                creator = (edu.ucdavis.caelmir.domain.common.User) resultList
        //                        .get(0);
        //            }
        //
        //        }
        //        catch (Exception ex)
        //        {
        //            System.out
        //                    .println("CollectionProtocol:getCreator throws exception ... ...");
        //            ex.printStackTrace();
        //        }
        return creator;

    }

    public void setCreator(edu.ucdavis.caelmir.domain.common.User creator)
    {
        this.creator = creator;
    }

    /**
     * @return Returns the collectionProtocolEventCollection.
     * @hibernate.set name="collectionProtocolEventCollection"  
     * cascade="save-update" inverse="true" lazy="false"
     * @hibernate.collection-key column="COLLECTION_PROTOCOL_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent" 
     */
    public Collection getCollectionProtocolEventCollection()
    {
        //        try
        //        {
        //            if (collectionProtocolEventCollection.size() == 0)
        //            {
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            ApplicationService applicationService = ApplicationServiceProvider
        //                    .getApplicationService();
        //            try
        //            {
        //
        //                edu.ucdavis.caelmir.domain.protocol.CollectionProtocol thisIdSet = new edu.ucdavis.caelmir.domain.protocol.CollectionProtocol();
        //                thisIdSet.setId(this.getId());
        //                 Collection resultList = applicationService
        //                        .search(
        //                                "edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent",
        //                                thisIdSet);
        //                collectionProtocolEventCollection = resultList;
        //                return resultList;
        //
        //            }
        //            catch (Exception ex)
        //            {
        //                System.out
        //                        .println("CollectionProtocol:getCollectionProtocolEventCollection throws exception ... ...");
        //                ex.printStackTrace();
        //            }
        //        }
        return collectionProtocolEventCollection;
    }

    public void setCollectionProtocolEventCollection(
            Collection collectionProtocolEventCollection)
    {
        this.collectionProtocolEventCollection = collectionProtocolEventCollection;
    }

    /**
     * @return
     * @hibernate.set name="experimentCollection" table="CAELMIR_EXPERIMENT_PROTOCOL"
     * cascade="all-delete-orphan" inverse="true" lazy="true"
     * @hibernate.collection-key column="COLLECTION_PROTOCOL_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.research.Experiment" column="EXPERIMENT_ID"
     */
    public Collection getExperimentCollection()
    {
        //        try
        //        {
        //            if (experimentCollection.size() == 0)
        //            {
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            ApplicationService applicationService = ApplicationServiceProvider
        //                    .getApplicationService();
        //            try
        //            {
        //
        //                edu.ucdavis.caelmir.domain.protocol.CollectionProtocol thisIdSet = new edu.ucdavis.caelmir.domain.protocol.CollectionProtocol();
        //                thisIdSet.setId(this.getId());
        //                 Collection resultList = applicationService.search(
        //                        "edu.ucdavis.caelmir.domain.research.Experiment",
        //                        thisIdSet);
        //                experimentCollection = resultList;
        //                return resultList;
        //
        //            }
        //            catch (Exception ex)
        //            {
        //                System.out
        //                        .println("CollectionProtocol:getExperimentCollection throws exception ... ...");
        //                ex.printStackTrace();
        //            }
        //        }
        return experimentCollection;
    }

    public void setExperimentCollection(Collection experimentCollection)
    {
        this.experimentCollection = experimentCollection;
    }

    /**
     * @return
     * @hibernate.set name="studyCollection" table="CAELMIR_STUDY_PROTOCOL_REL" 
     * cascade="all-delete-orphan" inverse="true" lazy="false"
     * @hibernate.collection-key column="COLLECTION_PROTOCOL_ID"
     * @hibernate.collection-many-to-many class="edu.ucdavis.caelmir.domain.research.Study" column="STUDY_ID"
     */
    public Collection getStudyCollection()
    {
        //        try
        //        {
        //            if (studyCollection.size() == 0)
        //            {
        //            }
        //        }
        //        catch (Exception e)
        //        {
        //            ApplicationService applicationService = ApplicationServiceProvider
        //                    .getApplicationService();
        //            try
        //            {
        //
        //                edu.ucdavis.caelmir.domain.protocol.CollectionProtocol thisIdSet = new edu.ucdavis.caelmir.domain.protocol.CollectionProtocol();
        //                thisIdSet.setId(this.getId());
        //                 Collection resultList = applicationService.search(
        //                        "edu.ucdavis.caelmir.domain.research.Study", thisIdSet);
        //                studyCollection = resultList;
        //                return resultList;
        //
        //            }
        //            catch (Exception ex)
        //            {
        //                System.out
        //                        .println("CollectionProtocol:getStudyCollection throws exception ... ...");
        //                ex.printStackTrace();
        //            }
        //        }
        return studyCollection;
    }

    public void setStudyCollection(Collection studyCollection)
    {
        this.studyCollection = studyCollection;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof CollectionProtocol)
        {
            CollectionProtocol c = (CollectionProtocol) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

    public void setAllValues(AbstractActionForm abstractForm)
            throws AssignDataException
    {

        CollectionProtocolForm collectionProtocolForm = (CollectionProtocolForm) abstractForm;
        //this.activityStatus = collectionProtocolForm.getActivityStatus();
        this.descriptionURL = collectionProtocolForm.getDescriptionURL();
        if (collectionProtocolForm.getEndDate() != null)
        {
            try
            {
                this.endDate = Utility.parseDate(collectionProtocolForm.getEndDate());
            }
            catch (ParseException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        if (collectionProtocolForm.getStartDate() != null)
        {
            try
            {
                this.startDate = Utility.parseDate(collectionProtocolForm
                        .getStartDate());
            }
            catch (ParseException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    /*    if (collectionProtocolForm.getEnrollmentNumber().length() > 0)
        {
            this.enrollment = Integer.valueOf(collectionProtocolForm
                    .getEnrollmentNumber());
        }*/
        if (collectionProtocolForm.getIrbIdentifier().length() > 0)
        {
            this.irbIdentifier = Long.valueOf(collectionProtocolForm
                    .getIrbIdentifier());
        }
        // this.systemIdentifier = collectionProtocol.getSystemIdentifier();
        this.shortTitle = collectionProtocolForm.getShortTitle();
        this.title = collectionProtocolForm.getTitle();
        if (collectionProtocolForm.getOperation() != null
                && collectionProtocolForm.getOperation().equalsIgnoreCase(
                        Constants.ADD))
        {
            this.activityStatus = Constants.ACTIVITY_STATUS_ACTIVE;
        }

        if (collectionProtocolForm.getValueMap() != null
                && !collectionProtocolForm.getValueMap().isEmpty())
        {
            Map map = collectionProtocolForm.getValueMap();
            // this.collectionProtocolEventCollection = new HashSet();

            //sort the map contents
       
            HashMap map1 = new LinkedHashMap();
            List mapKeys = new ArrayList(map.keySet());
            List mapValues = new ArrayList(map.values());
            map.clear();
            TreeSet sortedSet = new TreeSet(mapKeys);
            Object[] sortedArray = sortedSet.toArray();
            int size = sortedArray.length;
//          a) Ascending sort     
            for (int i=0; i<size; i++)
                 map1.put(sortedArray[i],mapValues.get(mapKeys.indexOf(sortedArray[i])));

            map=map1;
            
            //////
            Set keys = map.keySet();
            Iterator it = keys.iterator();
            
            
            Collection valcoll = map.values();
            Iterator valIterator = valcoll.iterator();

            Collection eventCollection = new LinkedHashSet();
          
            while (it.hasNext())
            {
                //format of  evebntPoint  map key for add : index_""
                // for edit : map key is index_identifier    
                String[] eventPointSplit = it.next().toString().split("_");

                CollectionProtocolEvent event = new CollectionProtocolEvent();
                event.setCollectionProtocol(this);
             //   if (eventPointSplit[0].equals("ep"))
            //    {
                    if (eventPointSplit.length > 1)
                        event.setId(new Long(eventPointSplit[1]));
                    else
                        event.setId(null);
                    event.setStudyCalendarEventPoint(valIterator.next()
                            .toString());
                    
           //     }
                //format of event_rec =  (rowIndex)_nameId_identifier
                if (collectionProtocolForm.getEventRecords() != null)
                {
                    Collection collection = new LinkedHashSet();
                    for(int i=0;i<collectionProtocolForm.getEventRecords().length;i++)
                    {
                        String event_rec = collectionProtocolForm
                                .getEventRecords()[i];

                        String eventRecSplit[] = event_rec.split("_");
                        try
                        {

                            boolean flag = false;
                            if (eventRecSplit[0].equals(eventPointSplit[0]))
                            {                                
                                //EventRecords newEventRecords = new EventRecords();
                                EntityMap entityMap = new EntityMap();
                                if (eventRecSplit.length > 2)
                                { //for edit operation
                                    entityMap.setId(new Long(
                                            eventRecSplit[2]));
                                }
                                else
                                //for add operation
                                {
                                    //entityMap = getNewEventRecord(eventRecSplit[1]);
                                    entityMap.setEntityReferenceId(new Long(eventRecSplit[1]));
                                    entityMap.setId(null);
                                }
                                collection.add(entityMap);                            
                       
                           }
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                 /*   if(collection !=null && !collection.isEmpty())
                        event.setEventRecordsCollection(collection);*/
                    if(collection !=null && !collection.isEmpty())
                        event.setEntityMapCollection(collection);
                }
                eventCollection.add(event);
            }
           
            this.setCollectionProtocolEventCollection(eventCollection);
        }

    }
/*
    private EntityMap getNewEventRecord(String string)
    {
        Long id = Long.valueOf(string);
        if (id != null)
        {
            if (id.equals(new Long(1)))
            {
                EventRecords newEventRecord = new MicroarrayEventRecords();
                newEventRecord.setName("MicroArray Event Record");

                return newEventRecord;
            }
            else if (id.equals(new Long(2)))
            {
                EventRecords newEventRecord = new PathologyEventRecords();
                newEventRecord.setName("Pathology Event Record");
                return newEventRecord;
            }
            else
            {
                EventRecords newEventRecord = new ProteomicsEventRecords();
                newEventRecord.setName("Proteomics Event Record");
                return newEventRecord;
            }
        }
        else
        {
            return null;
        }
    }
*/
    public CollectionProtocol(AbstractActionForm form)
            throws AssignDataException
    {
        setAllValues(form);
        // TODO Auto-generated constructor stub
    }

    public CollectionProtocol() throws AssignDataException
    {
        super();
    }
}