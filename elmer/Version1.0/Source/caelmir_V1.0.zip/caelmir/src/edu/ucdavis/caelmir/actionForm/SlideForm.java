/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.actionForm;



import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;

import edu.ucdavis.caelmir.domain.eventRecords.Image;
import edu.ucdavis.caelmir.domain.eventRecords.Slide;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;



public class SlideForm extends AbstractActionForm
{

    protected String slideNumber;
    /**
     * 
     */
    
    protected String submitType;
    
    protected String selectedImage;
    
    protected FormFile dataFile;
    
    protected String stain;
    /**
     * 
     */
    protected String tissueMicroscopicDescription;
    /**
     * 
     */
    protected String tissueDiagnosis;
  
    protected Collection imageCollection;
    
    protected String[] images;
    /**
     * @return Returns the images.
     */
    public String[] getImages()
    {
        return images;
    }
    
    protected Long tissueId;
    /**
     * @return Returns the tissueId.
     */
    public Long getTissueId()
    {
        return tissueId;
    }
    /**
     * @return Returns the slideNumber.
     */
    public String getSlideNumber()
    {
        return slideNumber;
    }
    /**
     * @param slideNumber The slideNumber to set.
     */
    public void setSlideNumber(String slideNumber) {
        this.slideNumber = slideNumber;
    }
    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    
    /**
     * @return Returns the stain.
     */
    public String getStain() {
        return stain;
    }
    /**
     * @param stain The stain to set.
     */
    public void setStain(String stain) {
        this.stain = stain;
    }
    
    
    /**
     * @return Returns the selectedImage.
     */
    public String getSelectedImage() {
        return selectedImage;
    }
    /**
     * @param selectedImage The selectedImage to set.
     */
    public void setSelectedImage(String selectedImage) {
        this.selectedImage = selectedImage;
    }
    /**
     * @return Returns the tissueDiagnosis.
     */
    public String getTissueDiagnosis() {
        return tissueDiagnosis;
    }
    /**
     * @param tissueDiagnosis The tissueDiagnosis to set.
     */
    public void setTissueDiagnosis(String tissueDiagnosis) {
        this.tissueDiagnosis = tissueDiagnosis;
    }
    /**
     * @return Returns the tissueMicroscopicDescription.
     */
    public String getTissueMicroscopicDescription() {
        return tissueMicroscopicDescription;
    }
    
    
    /**
     * @param tissueMicroscopicDescription The tissueMicroscopicDescription to set.
     */
    public void setTissueMicroscopicDescription(
            String tissueMicroscopicDescription) {
        this.tissueMicroscopicDescription = tissueMicroscopicDescription;
    }
    
    protected String imageCounter;
    /**
     * @return Returns the imageCounter.
     */
    public String getImageCounter() {
        return imageCounter;
    }
    /**
     * @param imageCounter The imageCounter to set.
     */
    public void setImageCounter(String imageCounter) {
        this.imageCounter = imageCounter;
    }
    protected Map valueMap  = new HashMap();
    
    
    public void setValue(String key, Object value) {
        valueMap.put(key, value);
    }
    /**
     * 
     * @param key
     * @return
     */
    public Object getValue(String key) {
        return valueMap.get(key);
    }
    
    
    
    
    /**
     * @return Returns the valueMap.
     */
    public Map getValueMap() {
        return valueMap;
    }
    
    /**
     * @param valueMap The valueMap to set.
     */
    public void setValueMap(Map valueMap) {
        this.valueMap = valueMap;
    }
    
    public int getFormId() {
        return Constants.SLIDE_FORM_ID;
    }
    /**
     * 
     */
    public void setAllValues(AbstractDomainObject abstractDomain)   
    {
        Slide slide=(Slide)abstractDomain;
        this.slideNumber = slide.getSlideNumber();
        this.stain = slide.getStain();
        this.id =slide.getSystemIdentifier().longValue();
        this.tissueDiagnosis = slide.getDiagnosis();
        this.tissueMicroscopicDescription = slide.getMicroscopicDescription();
        
        if(slide.getTissue() != null)
        this.tissueId = slide.getTissue().getId();
        this.imageCollection = slide.getImageCollection();
       	
		if(this.imageCollection != null && this.imageCollection.size() != 0 )
		{
	    	String [] images = new String[this.imageCollection.size()];
			Iterator iterate= this.imageCollection.iterator();			
			int i=0;				  
			while(iterate.hasNext())
			{
			    Image imageObj = (Image) iterate.next();
				images[i++]=imageObj.getId().toString();
			}
			setImages(images);
		}
        
        //set images colln
        
    }
    
    
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        
        if (validator.isEmpty(slideNumber))
        {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("slide.number")));
        }
        return errors;
        
    }
    
   public void reset() 
   {
        
    }

public String getSubmitType()
{
    return submitType;
}

public void setSubmitType(String submitType)
{
    this.submitType = submitType;
}
    
    
    /**
     * @return Returns the dataFile.
     */
    public FormFile getDataFile()
    {
        return dataFile;
    }
    /**
     * @param dataFile The dataFile to set.
     */
    public void setDataFile(FormFile dataFile)
    {
        this.dataFile = dataFile;
    }
    /**
     * @return Returns the imageCol.
     */
    public Collection getImageCollection()
    {
        return imageCollection;
    }
    /**
     * @param imageCol The imageCol to set.
     */
    public void setImageCollection(Collection imageCol)
    {
        this.imageCollection= imageCol;
    }
    /**
     * @param images The images to set.
     */
    public void setImages(String[] images)
    {
        this.images = images;
    }
}
