/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.domain.common;


import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.exception.AssignDataException;


/**
 * @author sandeep_chinta
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * @hibernate.class table="CAELMIR_ENTITY_MAP"
 */

public class EntityMap extends AbstractDomainObject implements java.io.Serializable
{
    
    /**Unique id of the object.*/
	private  Long id;
	
	private Long entityReferenceId;
	
	private edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent collectionProtocolEvent;
	
    /**
     * @hibernate.property name="entityReferenceId" column="ENTITY_REFERENCE_ID" type="long" length="30"
     * @return Returns the entityReferenceId.
     */
    public Long getEntityReferenceId()
    {
        return entityReferenceId;
    }
    /**
     * @param entityReferenceId The entityReferenceId to set.
     */
    public void setEntityReferenceId(Long entityReferenceId)
    {
        this.entityReferenceId = entityReferenceId;
    }
	
	   
    public void setAllValues(AbstractActionForm abstractForm) throws AssignDataException
    {
        // TODO Auto-generated method stub
        
    }
   
    public Long getSystemIdentifier()
    {
        // TODO Auto-generated method stub
        return id;
    }
    
    public void setSystemIdentifier(Long systemIdentifier)
    {
        this.id = systemIdentifier;
    }

    /**
     * Returns the systemIdentifier assigned to user.
     * @hibernate.id name="id" column="IDENTIFIER" type="long" length="30"
     * unsaved-value="null" generator-class="native"
     * @hibernate.generator-param name="sequence" value="CAELMIR_ENTITY_MAP_SEQ"
     * @return Returns the systemIdentifier.
     */
    public Long getId()
    {
        return id;
    }
    /**
     * @param id The id to set.
     */
    public void setId(Long id)
    {
        this.id = id;
    }
    
    /**
     * @return
     * @hibernate.many-to-one column="COLLECTION_PROTOCOL_EVENT_ID" class="edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent"
     * constrained="true"
     */
    public edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent getCollectionProtocolEvent()
    {
        return collectionProtocolEvent;
    }
    /**
     * @param collectionProtocolEvent The collectionProtocolEvent to set.
     */
    public void setCollectionProtocolEvent(
            edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent collectionProtocolEvent)
    {
        this.collectionProtocolEvent = collectionProtocolEvent;
    }
}
