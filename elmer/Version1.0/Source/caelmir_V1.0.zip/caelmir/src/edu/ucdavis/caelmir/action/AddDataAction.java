
package edu.ucdavis.caelmir.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.AddDataForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.util.CMSClient;

import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PreferenceManager;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.UserAccessManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.AbstractBizLogic;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;


/**Description: This class is used as an action class for adding experimnental data for a cohort.
 * <BR>The class populates all the request parameters and handles all the incoming and outgoing 
 * requests for the described scenario.
 * @see  org.apache.struts.action.Action
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class AddDataAction extends BaseAction
{

    /**This method is called when user clicks on the "add" link for the experimental data. The method populates all 
     * the required lists and passes the control onto the appropriate page.
     * 
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     */
    public ActionForward executeAction(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            SessionDataBean sessionDataBean = (SessionDataBean) request
                    .getSession().getAttribute(Constants.SESSION_DATA);
            List studyObjectList = getStudyList(form, sessionDataBean
                    .getUserId());
            if (studyObjectList == null || studyObjectList.size() == 0)
            {
                request.setAttribute(Constants.STUDY_NAME_VALUE_LIST,
                        new ArrayList());
                request.setAttribute(Constants.EXPERIMENT_NAME_VALUE_LIST,
                        new ArrayList());
                request.setAttribute(Constants.COHORT_NAME_VALUE_LIST,
                        new ArrayList());
                request.setAttribute("animalNameValueList",new ArrayList());
                return mapping.findForward(Constants.PAGE_OF_ADD_DATA);
            }

            List studyNameValueList = getstudyNameValueList(studyObjectList);
            request.setAttribute(Constants.STUDY_NAME_VALUE_LIST,
                    studyNameValueList);

            AddDataForm addDataForm = (AddDataForm) form;
            Study study;
            if (addDataForm.getStudyIdentifier() != null
                    && !addDataForm.getStudyIdentifier().equals(""))
            {
                PreferenceManager.setUserPreference(request,Constants.LAST_USED_STUDY_PREFERENCE,addDataForm.getStudyIdentifier());
                study = getStudyByIdentifier(studyObjectList, addDataForm
                        .getStudyIdentifier());
            }
            else
            {
                String studyId = PreferenceManager.getUserPreferenceValue(request,Constants.LAST_USED_STUDY_PREFERENCE);
                if (studyId != null && ! studyId.equalsIgnoreCase("")) {
                    study = getStudyByIdentifier(studyObjectList, studyId);
                    addDataForm.setStudyIdentifier(studyId);
                } else 
                {
                    study = (Study) studyObjectList.get(0);
                }
            }

            boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                    Cohort.class.getName(), request.getSession(), Permissions.COHORT_CREATE);
            request.setAttribute(Constants.COHORT_CREATE_FLAG,new Boolean(isAccessPresent));
            List experimentNameValueList = getExperimentsFormStudy(study);
            if (experimentNameValueList != null
                    && experimentNameValueList.size() != 0)
            {
                request.setAttribute(Constants.EXPERIMENT_NAME_VALUE_LIST,
                        getExperimentsFormStudy(study));
            }
            else
            {
                isAccessPresent = false;
                request.setAttribute(Constants.COHORT_CREATE_FLAG,new Boolean(isAccessPresent));
                request.setAttribute(Constants.EXPERIMENT_NAME_VALUE_LIST,
                        new ArrayList());
                request.setAttribute(Constants.COHORT_NAME_VALUE_LIST,
                        new ArrayList());
                return mapping.findForward(Constants.PAGE_OF_ADD_DATA);
            }

            Experiment experiment = null;
            if (addDataForm.getExperimentIdentifier() != null
                    && !addDataForm.getExperimentIdentifier().equals("")
                    && study.getExperimentCollection() != null
                    && study.getExperimentCollection().size() != 0 && !addDataForm.getStudyChanged().booleanValue())
            {
                PreferenceManager.setUserPreference(request,Constants.LAST_USED_EXPERIMENT_PREFERENCE,addDataForm.getExperimentIdentifier());
                experiment = getExperimentByIdentifier(new ArrayList(study
                        .getExperimentCollection()), addDataForm
                        .getExperimentIdentifier());
            }
            else
            {
                String experimentId = PreferenceManager.getUserPreferenceValue(request,Constants.LAST_USED_EXPERIMENT_PREFERENCE);  
                if (experimentId != null && ! experimentId.equalsIgnoreCase("")) {
                    experiment = getExperimentByIdentifier(new ArrayList(study
                            .getExperimentCollection()), experimentId);
                    addDataForm.setExperimentIdentifier(experimentId);
                }
                if (experiment == null) {
                experiment = (Experiment) new ArrayList(study
                        .getExperimentCollection()).get(0);
                }
            }
            
            request.setAttribute(Constants.PROTOCOL_NAME_VALUE_LIST,
                    getProtocolsFormExperiment(experiment));
            request.setAttribute(Constants.COHORT_NAME_VALUE_LIST,
                    getCohortFromExperiment(experiment));
            
           // if (isCohort(experiment)) {
                
                populateAnimalInformation(request,experiment,addDataForm);
                populateProtocolInformation(request,experiment,addDataForm);
                
           // }
        }
        catch (Exception Exception)
        {
            return mapping.findForward(new String(Constants.FAILURE));
        }
        return mapping.findForward(Constants.PAGE_OF_ADD_DATA);
    }

    private boolean isCohort(Experiment experiment) {
        if (experiment.getCohortCollection().size() > 0)
            return true;
        
        return false;
    }
    private void populateProtocolInformation(HttpServletRequest request, Experiment experiment, AddDataForm addDataForm)
    {
       int nodeId = 1;
       int parentNodeId = 0;
       List stringList = new ArrayList();
       Collection protocolCollection = experiment.getCollectionProtocolCollection();
       if (protocolCollection != null && !protocolCollection.isEmpty()) {
           Iterator protocolIterator = protocolCollection.iterator();
           while (protocolIterator.hasNext()) {
               CollectionProtocol protocol = (CollectionProtocol) protocolIterator.next();
               String str = String.valueOf(nodeId) + "|" + String.valueOf(0) + "|" + protocol.getTitle() + "|javascript: oc(" + String.valueOf(nodeId)+ ")";
               stringList.add(str);
               parentNodeId = nodeId;
               nodeId +=1;
              
               Collection eventCollection = protocol.getCollectionProtocolEventCollection();
               if (eventCollection != null && !eventCollection.isEmpty()) {
                   Iterator eventIterator = eventCollection.iterator();
                   int eventParentNodeId = parentNodeId;
                   while(eventIterator.hasNext()) {
                       CollectionProtocolEvent event = (CollectionProtocolEvent) eventIterator.next();
                       str = String.valueOf(nodeId) + "|" + String.valueOf(eventParentNodeId) + "|" + event.getStudyCalendarEventPoint().toString() + "|javascript: oc(" + String.valueOf(nodeId)+ ")";
                       stringList.add(str);
                       parentNodeId = nodeId;
                       nodeId += 1;
                       Collection entityMapCollection = event.getEntityMapCollection();
                       if (entityMapCollection != null && !entityMapCollection.isEmpty()) {
                           Iterator recordIterator = entityMapCollection.iterator();
                           int recordParentNodeId = parentNodeId;
                           while (recordIterator.hasNext()) {
                               EntityMap entityMap = (EntityMap) recordIterator.next();
                               if (entityMap.getEntityReferenceId() != null) {
                                   str = String.valueOf(nodeId) + "|" + String.valueOf(recordParentNodeId) + "|" + getRecordName(entityMap.getEntityReferenceId().toString()) + "|" + getURL(getRecordName(entityMap.getEntityReferenceId().toString()),entityMap,protocol,event);
                                   stringList.add(str);
                                   nodeId +=1;
                               }
                           }
                       }
                   }
               }
           }
       }
       
       request.setAttribute("protocolStringList", stringList);
        
    }
    
    /*
    private String getRecordId(String recName)
    {
        String str="";
        if(recName.equalsIgnoreCase(Constants.MICROARRAY_NAME))
          str="1";
        else if(recName.equalsIgnoreCase(Constants.PATHOLOGY_NAME))
            str="2";
        else if(recName.equalsIgnoreCase(Constants.PROTEOMICS_NAME))
            str="3";
        return str;
    }
*/
    private String getRecordName(String recId)
    {
        String str="";
        List list = new ArrayList();

        list.add(new NameValueBean(Variables.Microarray, Constants.MICROARRAY_ID));
        list.add(new NameValueBean(Variables.Pathology, Constants.PATHOLOGY_ID));
        list.add(new NameValueBean(Variables.Proteomics, Constants.PROTEOMICS_ID));
           CMSClient cms = new CMSClient();
        List dynamic = cms.getDynamicExtnEventRecords();
        list.addAll(dynamic);
        
        if(list != null && !list.isEmpty())
        {
            Iterator listIterator = list.iterator();
            while(listIterator.hasNext())
            {
                NameValueBean bean =(NameValueBean)listIterator.next();
                if(bean.getValue().equals(recId))
                {
                    str= bean.getName();
                    break;
                }
            }
            
        }
      /*  if(recId.equalsIgnoreCase("1"))
          str="MicroArray Event Record";
        else if(recId.equalsIgnoreCase("2"))
            str="Pathology Event Record";
        else if(recId.equalsIgnoreCase("3"))
            str="Proteomics Event Record";*/
        return str;
    }

    private String getURL(String eventRecord,EntityMap entityMap, CollectionProtocol protocol,CollectionProtocolEvent event)
    {
        if (eventRecord == null) {
            return "#";
        } else {
         /*   if (eventRecord.getName() == null) {
                
                if (eventRecord.getId().equals(new Long(1))) {
                    eventRecord.setName("MicroArray Event Record");
                } else if (eventRecord.getId().equals(new Long(2))) {
                    eventRecord.setName("Pathology Event Record");
                } else {
                    eventRecord.setName("Proteomics Event Record");
                }
            }*/
            if (eventRecord.equalsIgnoreCase(Variables.Microarray)) {
                return "/caelmir/MicroarrayAction.do?operation=addOrEdit&eventId="+event.getId()+"&protocolId="+protocol.getId()+"&entityMapId="+entityMap.getId()+"";
            } else if (eventRecord.equalsIgnoreCase(Variables.Pathology)) {
                return "/caelmir/CaseAction.do?operation=addOrEdit&eventId="+event.getId()+"&protocolId="+protocol.getId()+"&entityMapId="+entityMap.getId()+"";
            } else if (eventRecord.equalsIgnoreCase(Variables.Proteomics)) {
                return "/caelmir/ProteomicsAction.do?operation=addOrEdit&eventId="+event.getId()+"&protocolId="+protocol.getId()+"&entityMapId="+entityMap.getId()+"";
            } else {
               /* DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
                List list = null;
                try
                {
                   list = defaultBizLogic.retrieve(EventRecords.class.getName(),"entityMap",entityMap);
                }
                catch (DAOException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                
                String entityRecordId = "";
                if (list != null && !list.isEmpty()) {
                    EventRecords eventRecords = (EventRecords) list.get(0);
                    entityRecordId = eventRecords.getEntityRecordId().toString();
                }*/
                return "/caelmir/ContainerAction.do?operation=addOrEdit&eventId="+event.getId()+"&protocolId="+protocol.getId()+"&entityMapId="+entityMap.getId()+ "&containerIdentifier=" + entityMap.getEntityReferenceId();// +"&entityRecordId="+entityRecordId;
            }
            
        
        }
        //return null;
    }

    private void populateAnimalInformation(HttpServletRequest request, Experiment experiment, AddDataForm addDataForm) throws DAOException
    {
        String id = "";
        if (addDataForm.getCohortChanged().booleanValue()) {
            id = addDataForm.getCohortIdentifier();
        } else {
            if (experiment != null && experiment.getCohortCollection() != null && !experiment.getCohortCollection().isEmpty()) {
                Set coll = (Set) experiment.getCohortCollection();
                Object [] obj = coll.toArray();
                Cohort cohort = (Cohort) obj[0];
                id = cohort.getSystemIdentifier().toString();
             }
        }
        List animalList = new ArrayList();
        if (id != null && id.trim().length() != 0) {
        animalList = getAnimalList(id);
        }
        request.setAttribute("animalNameValueList",animalList);
    }

    private List getAnimalList(String id) throws DAOException
    {
        Long cohortId = Long.valueOf(id);
        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();
        List animalNameValueList = new ArrayList();
        List cohortList = defaultBizLogic.retrieve(Cohort.class.getName(),Constants.ID,cohortId);
        if (cohortList != null && !cohortList.isEmpty()) {
            Cohort cohort = (Cohort) cohortList.get(0);
            Collection animalCollection = cohort.getAnimalCollection();
            if (animalCollection != null && !animalCollection.isEmpty()) {
                Iterator iterator = animalCollection.iterator();
                while (iterator.hasNext()) {
                    Animal animal = (Animal) iterator.next();
                    animalNameValueList.add(new NameValueBean(animal.getAnimalNumber(),animal.getId()));
                }
            }
        }
        return animalNameValueList;
    }

    /**
     * The method gets the experiment object and obtains the collection of cohorts from it and then builds the 
     * list of NameValueBean objects which contain the name and id of the cohort as name and value.
     * @param experiment Expeirment object from which the List of cohorts is to be obtained
     * @return List List of NameValueBean objects containg the cohort name and id of the cohorts that are associated 
     * with the experiment.
     * @see edu.wustl.common.beans.NameValueBean
     * 
     */
    private List getCohortFromExperiment(Experiment experiment)
    {
        List cohortNameValueList = new ArrayList();
        if (experiment != null)
        {
            Collection cohortCollection = experiment.getCohortCollection();
            if (cohortCollection != null && !cohortCollection.isEmpty())
            {
                Iterator cohortIterator = cohortCollection.iterator();
                Cohort cohort;
                while (cohortIterator.hasNext())
                {
                    cohort = (Cohort) cohortIterator.next();
                    if (cohort.getActivityStatus().equals(Constants.ACTIVITY_STATUS_ACTIVE)) 
                    {
                        cohortNameValueList.add(new NameValueBean(cohort.getName(),
                            cohort.getId().toString()));
                    }
                }
            }
        }
        return cohortNameValueList;

    }

    /**
     * This method returns the list of study objects for which the logged in user has access.
     * @param form Action form from which form id is used to get the proper biz logic class.
     * @return List list of "Study" objects.
     * @throws DAOException
     * @see edu.ucdavis.caelmir.domain.Study
     */
    public List getStudyList(ActionForm form, Long userId) throws DAOException
    {

        AbstractActionForm abstractForm = (AbstractActionForm) form;
        AbstractBizLogic bizLogic = BizLogicFactory.getBizLogic(abstractForm
                .getFormId());
        String sourceObjectName = Constants.STUDY_ALIAS;
        List studyObjects = null;
        try
        {
            studyObjects = bizLogic.retrieve(sourceObjectName);
        }
        catch (DAOException daoException)
        {
            throw daoException;

        }
        List permissibleStudyList = new ArrayList();
        if (studyObjects != null && !studyObjects.isEmpty())
        {
            Iterator studyIterator = studyObjects.iterator();
            while (studyIterator.hasNext())
            {
                Study study = (Study) studyIterator.next();
                if (study.getActivityStatus().equals(Constants.ACTIVITY_STATUS_ACTIVE)) 
                {
                    if (UserAccessManager.isUserPresentForStudy(study, userId))
                    {
                        permissibleStudyList.add(study);
                    }
                }
            }

        }
        return permissibleStudyList;
    }

    /**
     * The method receives the list of "Study" objects and converts the list into the list of "NameValueBean" objects.
     * Study name is used as name and study id is used as value.
     * @param studyObjects List containing "Study" objects.
     * @return List list of "NameValueBean" objects.
     */
    public List getstudyNameValueList(List studyObjects)
    {
        List studyNameValueList = new ArrayList();
        Iterator studyIterator = studyObjects.iterator();
        Study study;
        NameValueBean nameValueBean;
        while (studyIterator.hasNext())
        {
            study = (Study) studyIterator.next();
            studyNameValueList.add(new NameValueBean(study.getName(), study
                    .getId().toString()));

        }
        return studyNameValueList;

    }

    /**
     * The method receives the List of "study" objects and scans it to match the given identifier and if some object
     * matches the identifier it returns that object.
     * @param identifier ID of the object which is required.
     * @return Study Study object that matches the identifier.
     */
    public Study getStudyByIdentifier(List studyObjectList, String identifier)
    {
        Iterator studyIterator = studyObjectList.iterator();
        Study study;
        while (studyIterator.hasNext())
        {
            study = (Study) studyIterator.next();
            if (study.getId().toString().equals(identifier))
            {
                return study;
            }
        }
        return null;

    }

    /**
     * The method receives the List of "Experiment" objects and scans it to match the given identifier and if some object
     * matches the identifier it returns that object.
     * @param identifier ID of the object which is required.
     * @return Experiment Experiment object that matches the identifier.
     */
    public Experiment getExperimentByIdentifier(List experimentObjectList,
            String identifier)
    {
        Iterator experimentIterator = experimentObjectList.iterator();
        Experiment experiment;
        while (experimentIterator.hasNext())
        {
            experiment = (Experiment) experimentIterator.next();
            if (experiment.getId().toString().equals(identifier))
            {
                return experiment;
            }
        }
        return null;

    }

    /**This object receives the "study" object as an argument and returns the list of experiments associated with the study.
     * @param study Study object from which the experiment collection is needed.
     * @return List list of NameValueBean objects specifying the name and id of the associated experiments.
     */
    public List getExperimentsFormStudy(Study study)
    {
        List experimentNameValueList = new ArrayList();
        Collection experimentCollection = new HashSet();
        if (study != null)
        {
            experimentCollection = study.getExperimentCollection();
            Iterator experimentIterator = experimentCollection.iterator();
            Experiment experiment;
            while (experimentIterator.hasNext())
            {
                experiment = (Experiment) experimentIterator.next();
                if (experiment.getActivityStatus().equals(Constants.ACTIVITY_STATUS_ACTIVE)) 
                {
                experimentNameValueList.add(new NameValueBean(experiment
                        .getName(), experiment.getId().toString()));
                }
            }
        }
        return experimentNameValueList;

    }

    /**This object receives the "Experiment" object as an argument and returns the list of experiments associated with the study.
     * @param Experiment Experiment object from which the experiment collection is needed.
     * @return List list of NameValueBean objects specifying the name and id of the associated protocols.
     */
    public List getProtocolsFormExperiment(Experiment experiment)
    {
        List protocolNameValueList = new ArrayList();
        if (experiment != null)
        {
            Collection protocolCollection = experiment.getCollectionProtocolCollection();
            Iterator protocolIterator = protocolCollection.iterator();
            CollectionProtocol protocol;
            while (protocolIterator.hasNext())
            {
                protocol = (CollectionProtocol) protocolIterator.next();
                protocolNameValueList.add(new NameValueBean(protocol.getTitle(),
                        protocol.getId().toString()));
            }

        }
        return protocolNameValueList;

    }

}
