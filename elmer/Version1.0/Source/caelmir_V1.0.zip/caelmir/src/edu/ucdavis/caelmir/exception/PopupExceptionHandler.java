/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.exception;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ExceptionHandler;
import org.apache.struts.config.ExceptionConfig;


import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.util.logger.Logger;



public class PopupExceptionHandler extends ExceptionHandler
{
    
        public ActionForward execute(Exception ex,
                ExceptionConfig ae,
                ActionMapping mapping,
                ActionForm formInstance,
                HttpServletRequest request,
                HttpServletResponse response)
                                    throws ServletException {
    String errorMessage = getErrorMsg(ex);
    Logger.out.error( errorMessage, ex );
   HandlePopupException h = new HandlePopupException();
    request.getSession().setAttribute( Constants.POPUP_EXCEPTION, h.str);
    return super.execute( ex, ae, mapping, formInstance, request, response );
    
    }
        
        public String getErrorMsg( Exception ex ){
            String msg = "Exception was NULL";

            if ( ex != null ){
               ByteArrayOutputStream bo = new ByteArrayOutputStream();
                PrintWriter pw = new PrintWriter(bo, true);
                ex.printStackTrace(pw);
                msg = 
                     "Message: " + ex.getMessage() +"\n" +
                     "StackTrace: " + bo.toString();
            }
           
           return msg;

       }
    
    
}
