/**
 *<p>Title:CohortForm Class </p>
 *<p>Description: This class Class is used to encapsulate all the request parameters passed </p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.actionForm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;
import edu.wustl.common.util.logger.Logger;

/**
 * CohortForm Class is used to encapsulate all the request parameters passed 
 * from cohort Add/Edit webpage.
 * @author shital_lawhale
 * */
public class CohortForm extends AbstractActionForm
{

    /**
     * Activity Status of cohort, it could be  ACTIVE, DISABLED(DELETED),CLOSED.
     */
    protected String activityStatus;

    /**
     * experimentalCondition for cohort 
     */
    private String experimentalCondition;

    /**
     * 
     * @return experimentalCondition for cohort
     * @see #setExperimentalCondition(String)
     * 
     */
    public String getExperimentalCondition()
    {
        return experimentalCondition;
    }

    /**
     * sets experimentalCondition for an Experiment
     * @param experimentalCondition for an Experiment
     * @see #getExperimentalCondition()
     * 
     */
    public void setExperimentalCondition(String experimentalCondition)
    {
        this.experimentalCondition = experimentalCondition;
    }

    /**
     * name of an Cohort
     */
    private String cohortName;

    /**
     * returns name of an Cohort
     * @return name of an Cohort
     * @see #setName(String)
     */
    public String getCohortName()
    {
        return cohortName;
    }

    /**
     * sets name for an Cohort
     * @param name name of an Cohort
     * @see #getName()
     */
    public void setCohortName(String cohortName)
    {
        this.cohortName = cohortName;
    }
      
    private Map valuesMap = new HashMap();

    /**hashMap defined for checkboxes **/
  //  private Map values = new HashMap();

    /**
     * @return hashMap 
     * @see #getValue(String)
     */
 /*   public Map getValues()
    {
        return values;
    }
*/
    /**
     * @param values 
     * @see #setValue(String, Object)
     */
/*    public void setValues(Map values)
    {
        this.values = values;
    }

    /**
     * Associates the specified object with the specified key in the map.
     * @param key the key to which the object is mapped.
     * @param value the object which is mapped.
     */
    public void setMapValue(String key, Object value)
    {
        valuesMap.put(key, value);
    }

    /**
     * Returns the object to which this map maps the specified key.
     * @param key the required key.
     * @return the object to which this map maps the specified key.
     */
    public Object getMapValue(String key)
    {
        System.out.println("get key:" + valuesMap.get(key));
        return valuesMap.get(key);

    }
    
    /**Experiment identifier to which this cohort should belong to... required in case where cohort is added from experimental data page.*/
    private String experimentIdentifier;

    /**
     * A map that handles event parameters' data
     */
    // private Map eventMap = new HashMap();
    /**
     * Associates the specified object with the specified key in the map.
     * @param key the key to which the object is mapped.
     * @param value the object which is mapped.
     */
    /*    public void setEventMap(String key, Object value) 
     {    	
     eventMap.put(key, value);
     System.out.println(" @@@@ event map value ="+value);
     }
     */
    /**
     * Returns the object to which this map maps the specified key.
     * @param key the required key.
     * @return the object to which this map maps the specified key.
     */
    /*	    public Object getEventMap(String key) 
     {
     return eventMap.get(key);
     }*/

    /**
     * @return String experiment identifier to get.
     */
    public String getExperimentIdentifier()
    {
        return experimentIdentifier;
    }

    /**
     * 
     * @param experimentIdentifier experiment identifier that is set.
     */
    public void setExperimentIdentifier(String experimentIdentifier)
    {
        this.experimentIdentifier = experimentIdentifier;
    }

    /**
     * Returns form Identifier
     */
    public int getFormId()
    {
        int formId = Constants.COHORT_CREATE_FORM_ID;
        return formId;
    }
    
    public void setAddNewObjectIdentifier(String addNewFor, Long addObjectIdentifier)
    {
            
        if(addNewFor.equals("animal"))
        {
            Long ID=new Long(addObjectIdentifier.longValue());
            String str= ID.toString();              
            List list = new ArrayList();        
           
            
            
           setMapValue("CHK_"+str,"on");            
        }
        
            
    }
    
    
    /**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
    

    /**
     * Resets the values of all the fields.
     * Is called by the overridden reset method defined in ActionForm.  
     * */
    protected void reset()
    {
        //this.experimentalCondition = null;
        // this.name = null;
    }

    /**
     * Copies the data from an AbstractDomain object to a CohortForm object.
     * @param abstractDomain AbstractDomain object of Cohort.  
     */
    public void setAllValues(AbstractDomainObject abstractDomain)
    {
        Cohort cohort = (Cohort) abstractDomain;

        this.id = cohort.getSystemIdentifier().longValue();
        this.cohortName = cohort.getName();
        this.experimentalCondition = cohort.getExperimentalCondition();
        if (cohort.getExperiment() != null) {
        this.experimentIdentifier = cohort.getExperiment().getId().toString();
        }
        Collection animColl = cohort.getAnimalCollection();
        this.valuesMap = new HashMap();
        Iterator it = animColl.iterator();
        String xx;
        while (it.hasNext())
        {
            Animal animal = (Animal) it.next();
            xx = animal.getId().toString();
            String chkName = "CHK_" + xx;
            this.setMapValue(chkName, "on");            
        }
       
        this.activityStatus = cohort.getActivityStatus();
    }

    /**
     * Overrides the validate method of ActionForm.
     * */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request)
    {

        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        try
        {
            if (validator.isEmpty(cohortName))
            {
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                        "errors.item.required", ApplicationProperties
                                .getValue("user.cohort.name")));
            }
            if (validator.isEmpty(experimentalCondition))
            {
                errors
                        .add(
                                ActionErrors.GLOBAL_ERROR,
                                new ActionError(
                                        "errors.item.required",
                                        ApplicationProperties
                                                .getValue("user.cohort.experimentalcondition")));
            }         
        }
        catch (Exception excp)
        {
            Logger.out.error(excp.getMessage(), excp);
        }
        return errors;
    }

    /**
     * @return activityStatus of cohort
     */
    public String getActivityStatus()
    {
        return activityStatus;
    }

    /**
     * @param activityStatus String representing activityStatus of cohort
     */
    public void setActivityStatus(String activityStatus)
    {
        this.activityStatus = activityStatus;
    }

    
    public Map getValuesMap()
    {
        return valuesMap;
    }

    
    public void setValuesMap(Map valuesMap)
    {
        this.valuesMap = valuesMap;
    }

    /**
     *  AnimalIDList is used to store the selected animal to forward it to jsp
     */
  /*  public List animalIDList = new ArrayList();

    public List getAnimalIDList()
    {
        return animalIDList;
    }

    public void setAnimalIDList(List animalIDList)
    {
        this.animalIDList = animalIDList;
    }
*/
}
