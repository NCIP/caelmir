package edu.ucdavis.caelmir.util.listener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import edu.ucdavis.caelmir.domain.common.Address;
import edu.ucdavis.caelmir.util.ProtectionGroups;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.bizlogic.QueryBizLogic;
import edu.wustl.common.cde.CDEManager;
import edu.wustl.common.security.SecurityManager;
import edu.wustl.common.util.Permissions;
import edu.wustl.common.util.XMLPropertyHandler;
import edu.wustl.common.util.dbManager.HibernateMetaData;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.logger.Logger;

/**
 * 
 * @author aarti_sharma
 * 
 * */
public class CatissueCoreServletContextListener implements 
						ServletContextListener, ProtectionGroups, Permissions
{
    /* (non-Javadoc)
     * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)
    {
        /**
         * Getting Application Properties file path
         */
        String applicationResourcesPath = sce.getServletContext().getRealPath("WEB-INF")
                + System.getProperty("file.separator")
                + "classes" + System.getProperty("file.separator")
                + sce.getServletContext().getInitParameter("applicationproperties");
        
        /**
         * Initializing ApplicationProperties with the class 
         * corresponding to resource bundle of the application
         */
        ApplicationProperties.initBundle(sce.getServletContext().getInitParameter("resourcebundleclass"));
        
        /**
         * Getting and storing Home path for the application
         */
        Variables.caElmirHome= sce.getServletContext().getRealPath("");

        Variables.applicationHome = sce.getServletContext().getRealPath("");
        /**
         * Creating Logs Folder inside catissue home
         */
        File logfolder=null;
        try
        {
            logfolder = new File(Variables.caElmirHome + "/Logs");
            String path = System.getProperty("app.propertiesFile");
            XMLPropertyHandler.init(path);
            logfolder = new File(Variables.caElmirHome + "/Logs");
            if (logfolder.exists() == false)
            {
                logfolder.mkdir();
            }
            
        }
        catch (Exception e)
        {
            ;
        }
        
        //List to store ROLE ID
        SecurityManager.roleList.add(Constants.ADMINISTRATOR_ROLE);
        SecurityManager.roleList.add(Constants.SUPERVISOR_ROLE);
        SecurityManager.roleList.add(Constants.TECHNICIAN_ROLE);
        SecurityManager.roleList.add(Constants.PI_ROLE);
        SecurityManager.roleList.add(Constants.PUBLIC_ROLE);
   
      
        //All users should be able to view all data by default
        Map protectionGroupsForObjectTypes = new HashMap();
        
        protectionGroupsForObjectTypes.put(Address.class.getName(),
                new String[] {PUBLIC_DATA_GROUP});

        
        Constants.STATIC_PROTECTION_GROUPS_FOR_OBJECT_TYPES.putAll(protectionGroupsForObjectTypes);
        
        /**
         * setting system property catissue.home which can be ustilized 
         * by the Logger for creating log file
         */
        System.setProperty("caelmir.home",Variables.caElmirHome + "/Logs");
        
        /**
         * Configuring the Logger class so that it can be utilized by
         * the entire application
         */
        Logger.configure(applicationResourcesPath);
        
        Logger.out.info(ApplicationProperties.getValue("caelmir.home")
                + Variables.caElmirHome);
        Logger.out.info(ApplicationProperties.getValue("logger.conf.filename")
                + applicationResourcesPath);
        
        QueryBizLogic.initializeQueryData();
        
        try
        {
            
            //TODO
            // get database name and set variables used in query
            Variables.databaseName=HibernateMetaData.getDataBaseName();
            
            System.out.println("*** databaseName : "+ HibernateMetaData.getDataBaseName());
            if(Variables.databaseName.equals(Constants.ORACLE_DATABASE)|| Variables.databaseName.equals(Constants.POSTGRESQL_DATABASE))
            {
            	//set string/function for oracle
            	
            	Variables.datePattern = "mm-dd-yyyy";
            	Variables.timePattern = "hh-mi-ss";
            	Variables.dateFormatFunction="TO_CHAR";
            	Variables.timeFormatFunction="TO_CHAR";
            	Variables.dateTostrFunction = "TO_CHAR";
            	Variables.strTodateFunction = "TO_DATE";
            }
            else
            {
            	Variables.datePattern = "%m-%d-%Y";
            	Variables.timePattern = "%H:%i:%s";
            	Variables.dateFormatFunction="DATE_FORMAT";
            	Variables.timeFormatFunction="TIME_FORMAT";
            	Variables.dateTostrFunction = "TO_CHAR";
            	Variables.strTodateFunction = "STR_TO_DATE";
            }
        }
        catch (Exception e1)
        {
            e1.printStackTrace();
        }
        
        //Initialize CDE Manager
       try
		{
        	CDEManager.init();
		}
        catch(Exception ex)
		{
        	Logger.out.error("Could not initialized application, Error in creating CDE manager.");
        	Logger.out.error(ex.getMessage(), ex);
        	
		}
        
        SecurityManager.CATISSUE_CORE_CONTEXT_NAME = "caelmir";
        
        Properties prop = new Properties();

        
        try
        {
            // load the property file
            prop.load(new FileInputStream(Variables.caElmirHome
                        + System.getProperty(Constants.FILE_SEPARATOR)
                        + Constants.PROPERTIES_FILE));


            Variables.Microarray = (String) prop.get(Constants.MICROARRAY_NAME);
            Variables.Proteomics = (String) prop.get(Constants.PROTEOMICS_NAME);
            Variables.Pathology = (String) prop.get(Constants.PATHOLOGY_NAME);
            
        }
        catch (FileNotFoundException e2)
        {
            // TODO Auto-generated catch block
            e2.printStackTrace();
        }
        catch (IOException e2)
        {
            // TODO Auto-generated catch block
            e2.printStackTrace();
        }
    }
    
    /* (non-Javadoc)
     * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)
    {

    }
}