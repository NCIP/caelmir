/**
 *<p>Title: ExperimentBizLogic Class </p>
 *<p>Description: This class is used to add/update experiment information into database.</p>
 *<p>Copyright:TODO</p>
 *@author Shital Lawhale
 *@version 1.0
 */

package edu.ucdavis.caelmir.bizlogic;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;



import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.common.UserGroup;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.research.Experiment;
import edu.ucdavis.caelmir.domain.research.Study;
import edu.ucdavis.caelmir.domain.subject.Cohort;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;

import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.dao.DAO;
import edu.wustl.common.security.exceptions.UserNotAuthorizedException;
import edu.wustl.common.util.dbManager.DAOException;

/**
 * ExperimentBizLogic class is used to add/update experiment information into database.
 * @author shital_lawhale
 */
public class ExperimentBizLogic extends DefaultBizLogic
{

    /**
     * Saves the experiment object in the database.
     * @param obj The experiment object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    public void insert(Object obj, DAO dao, SessionDataBean sessionDataBean)
            throws DAOException, UserNotAuthorizedException
    {
        Experiment experiment = (Experiment) obj;

        User creator = (User) dao.retrieve(User.class.getName(),
                sessionDataBean.getUserId());
        experiment.setCreator(creator);

        experiment.setCreatedDate(new Date());
        
        Study study = (Study) experiment.getStudy();
        Study studyfromTable = (Study) dao.retrieve(Study.class.getName(),
                study.getSystemIdentifier());
        experiment.setStudy(studyfromTable);
        studyfromTable.getExperimentCollection().add(experiment);

        Collection cohortColl = experiment.getCohortCollection();
        Iterator iterate = cohortColl.iterator();
        Set tempSet = new HashSet();
        while (iterate.hasNext())
        {
            Cohort cohort = (Cohort) iterate.next();
            Cohort cohortfromTable = (Cohort) dao.retrieve(Cohort.class
                    .getName(), cohort.getId());
            tempSet.add(cohortfromTable);
            cohortfromTable.setExperiment(experiment);
        }
        experiment.setCohortCollection(tempSet);

        Collection userColl = experiment.getUserCollection();
        Set experimentuserColl = new HashSet();
      //  boolean flag = checkForLoginUser(userColl, creator);
     //   if (!flag)
            userColl.add(creator);

        User primaryInvestigator = creator;
        while (creator.getUser() != null)
        {
            primaryInvestigator = creator.getUser();
        }
        if (primaryInvestigator != creator)
            userColl.add(primaryInvestigator);

        Iterator iterateExp = userColl.iterator();
        while (iterateExp.hasNext())
        {
            User user = (User) iterateExp.next();
            User userfromTable = (User) dao.retrieve(User.class.getName(), user
                    .getId());
            userfromTable.getExperimentCollection().add(experiment);
            experimentuserColl.add(userfromTable);
        }
        experiment.setUserCollection(experimentuserColl);

        Collection groupColl = experiment.getUserGroupCollection();
        Set groupCollection = new HashSet();
        Iterator iterateData = groupColl.iterator();
        while (iterateData.hasNext())
        {
            UserGroup userGroup = (UserGroup) iterateData.next();
            UserGroup userGroupFromTable = (UserGroup) dao.retrieve(
                    UserGroup.class.getName(), userGroup.getId());
            userGroupFromTable.getExperimentCollection().add(experiment);
            groupCollection.add(userGroupFromTable);
        }
        experiment.setUserGroupCollection(groupCollection);

        Collection protocolColl = experiment.getCollectionProtocolCollection();
        Set protocolCollection = new HashSet();
        Iterator iterateProtocol = protocolColl.iterator();
        while (iterateProtocol.hasNext())
        {
            CollectionProtocol protocol = (CollectionProtocol) iterateProtocol.next();
            CollectionProtocol protocolfromTable = (CollectionProtocol) dao.retrieve(CollectionProtocol.class
                    .getName(), protocol.getId());
            protocolfromTable.getExperimentCollection().add(experiment);
            protocolCollection.add(protocolfromTable);
        }
        experiment.setCollectionProtocolCollection(protocolCollection);
        dao.insert(experiment, null, true, false);
    }

    
    public boolean checkDeleteObjects(Cohort cohort) {
        
        Collection aCol = cohort.getAnimalCollection();
        Iterator iter = aCol.iterator();
        while (iter.hasNext()) {
            Mouse mouse = (Mouse) iter.next();
            if(mouse.getEventRecordsCollection() != null && mouse.getEventRecordsCollection().size() >0)
                return true;
        }
        
        return false;
    }
    
    
    public boolean checkDeleteObject(CollectionProtocol oldProtocol,DAO dao) {
        Collection protocolEventCol = oldProtocol.getCollectionProtocolEventCollection();
        Iterator iter = protocolEventCol.iterator();
        while (iter.hasNext()) {
            CollectionProtocolEvent pEvent = (CollectionProtocolEvent) iter.next();
            Collection entityMapCol = pEvent.getEntityMapCollection();
            Iterator iterMap = entityMapCol.iterator();
            while (iterMap.hasNext()) {
	            EntityMap map = (EntityMap)iterMap.next(); 
	            try
	            {
	                List list = dao.retrieve(EventRecords.class.getName(),"entityMap", map.getId());
	                if(list != null && list.size() > 0) {
	                    return true;
	                }
	            }
	            catch (DAOException e)
	            {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
            }
       }
        return false;
    }
    
    /**
     * Updates the experiment object in the database.
     * @param obj The experiment object to be saved.
     * @param dao The hibernate data access object
     * @param session The session in which the object is saved.
     * @throws DAOException
     */
    public void update(DAO dao, Object obj, Object oldObj,
            SessionDataBean sessionDataBean) throws DAOException,
            UserNotAuthorizedException
    {
        Experiment experiment = (Experiment) obj;  

       Experiment oldExperiment = (Experiment) oldObj;
       // Experiment newExperiment = (Experiment) dao.retrieve(Experiment.class.getName(),experiment.getId());
         Collection cohortColl = experiment.getCohortCollection();
        experiment.setCohortCollection(null);
        dao.update(experiment, null, true, false, false);

       Collection oldCohort = oldExperiment.getCohortCollection();
        Collection tempSet = new HashSet();
        Iterator itre = oldCohort.iterator();
        while (itre.hasNext()) {
            Cohort newMap = (Cohort) itre.next();
            
            if (!cohortColl.contains(newMap)) {
                if (!checkDeleteObjects(newMap)) {
                    newMap.setExperiment(null);
                    tempSet.add((Cohort) newMap);
                }
            }
        }
        Iterator iterate = cohortColl.iterator();
     
        while (iterate.hasNext())
        {
            Cohort cohort = (Cohort) iterate.next();
            Cohort cohortfromTable = (Cohort) dao.retrieve(Cohort.class
                    .getName(), cohort.getId());
            if(cohort.getActivityStatus()!=null)
            cohortfromTable.setActivityStatus(cohort.getActivityStatus());
            if (experiment.getActivityStatus().equals(Constants.ACTIVITY_STATUS_DISABLED)
                    && !cohort.getActivityStatus().equals(Constants.ACTIVITY_STATUS_DISABLED))
            {
                cohortfromTable.setExperiment(null);
            }
            else
                cohortfromTable.setExperiment(experiment);
            tempSet.add(cohortfromTable);
        }
        experiment.setCohortCollection(tempSet);
        
        Collection userColl = experiment.getUserCollection();
        experiment.setUserCollection(null);
        dao.update(experiment, null, true, false, false);

        Iterator iterateUser = userColl.iterator();
        Collection userSet = new HashSet();
        while (iterateUser.hasNext())
        {
            User user = (User) iterateUser.next();
            User userfromTable = (User) dao.retrieve(User.class
                    .getName(), user.getId());           
         //   userfromTable.getExperimentCollection().add(experiment);
            userSet.add(userfromTable);
        }
        User userfromTable = (User) dao.retrieve(User.class
                .getName(), sessionDataBean.getUserId());           
     //   userfromTable.getExperimentCollection().add(experiment);
        userSet.add(userfromTable);
        
        experiment.setUserCollection(userSet);
        
        
        Collection groupColl = experiment.getUserGroupCollection();
        experiment.setUserGroupCollection(null);
        dao.update(experiment, null, true, false, false);        
        Collection groupCollection = new HashSet();
        Iterator iterateData = groupColl.iterator();
        while (iterateData.hasNext())
        {
            UserGroup userGroup = (UserGroup) iterateData.next();
            UserGroup userGroupFromTable = (UserGroup) dao.retrieve(
                    UserGroup.class.getName(), userGroup.getId());
        //    userGroupFromTable.getExperimentCollection().add(experiment);
            groupCollection.add(userGroupFromTable);
        }
        experiment.setUserGroupCollection(groupCollection);

        Collection protocolColl = experiment.getCollectionProtocolCollection();
        experiment.setCollectionProtocolCollection(null);
        dao.update(experiment, null, true, false, false);       
        Collection protocolCollection = new HashSet();
       Iterator iterateProtocol = protocolColl.iterator();
        while (iterateProtocol.hasNext())
        {
            CollectionProtocol protocol = (CollectionProtocol) iterateProtocol.next();
            CollectionProtocol protocolfromTable = (CollectionProtocol) dao.retrieve(CollectionProtocol.class
                    .getName(), protocol.getId());
           // protocolfromTable.getExperimentCollection().add(experiment);
            protocolCollection.add(protocolfromTable);
        }
        
        Collection oldProtocolCol = oldExperiment.getCollectionProtocolCollection();
        Iterator iter = oldProtocolCol.iterator();
        while (iter.hasNext()) {
            CollectionProtocol oldProtocol = (CollectionProtocol) iter.next();
            if(!protocolCollection.contains(oldProtocol)) {
                if(checkDeleteObject(oldProtocol,dao)) {
                    protocolCollection.add(oldProtocol);
                }
            }
        }
        experiment.setCollectionProtocolCollection(protocolCollection);
        
     /*   newExperiment.setExperimentStartDate(experiment.getExperimentStartDate());
        newExperiment.setName(experiment.getName());
        newExperiment.setHypothesis(experiment.getHypothesis());
        newExperiment.setStudyRequirement(experiment.getStudyRequirement());
        newExperiment.setActivityStatus(experiment.getActivityStatus());*/
        
        dao.update(experiment, null, true, false, false);
    }

    /**
     * checks whether user is login or not.
     * @param coll Collection of user object
     * @param creator Login user
     * @return boolean value (true/false)
     */
    private boolean checkForLoginUser(Collection coll, User creator)
    {
        boolean flag = false;

        Iterator iterateData = coll.iterator();
        while (iterateData.hasNext())
        {
            User user = (User) iterateData.next();
            if (user.getId().equals(creator.getId()))
            {
                flag = true;
                break;
            }
        }
        return flag;
    }
}
