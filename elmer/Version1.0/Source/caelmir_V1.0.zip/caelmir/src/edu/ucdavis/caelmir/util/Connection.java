package edu.ucdavis.caelmir.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.util.Properties;

import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;

/*
 * Created on Apr 19, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author kapil_kaveeshwar
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Connection {

    static Authenticator authenticator = new Authenticator() {
	    protected PasswordAuthentication getPasswordAuthentication() { 
		// username, password for your proxy 
		// sets http authentication 
	        Properties prop = new Properties();
	        try
	        {
	            // load the property file
	            prop.load(new FileInputStream(Variables.caElmirHome
	                        + System.getProperty(Constants.FILE_SEPARATOR)
	                        + Constants.PROPERTIES_FILE));
	        }
	        catch (FileNotFoundException e)
	        {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        catch (IOException e)
	        {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        String username = (String) prop.get("proxy.username");
	        String password = (String) prop.get("proxy.password");
	        
		return new PasswordAuthentication(username,password.toCharArray()); 
	    } 
	};
    
    public static void proxy() {
	Authenticator.setDefault(authenticator); 
	//String securityFile = "java.policy";
	//System.setProperty("java.security.policy",securityFile);
	   Properties prop = new Properties();
       try
       {
           // load the property file
           prop.load(new FileInputStream(Variables.caElmirHome
                       + System.getProperty(Constants.FILE_SEPARATOR)
                       + Constants.PROPERTIES_FILE));
       }
       catch (FileNotFoundException e)
       {
           // TODO Auto-generated catch block
           e.printStackTrace();
       }
       catch (IOException e)
       {
           // TODO Auto-generated catch block
           e.printStackTrace();
       }
       String host = (String) prop.get("proxy.host");
       String port = (String) prop.get("proxy.port");
	System.setProperty("proxyHost",host);
	System.setProperty("proxyPort",port);
    }
}//End of class Connection.
