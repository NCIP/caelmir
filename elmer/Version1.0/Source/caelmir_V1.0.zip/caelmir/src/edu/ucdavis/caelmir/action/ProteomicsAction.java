
package edu.ucdavis.caelmir.action;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.actionForm.ProteomicsForm;
import edu.ucdavis.caelmir.bizlogic.BizLogicFactory;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.common.User;
import edu.ucdavis.caelmir.domain.eventRecords.EventRecords;
import edu.ucdavis.caelmir.domain.eventRecords.ProteomicsEventRecords;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocol;
import edu.ucdavis.caelmir.domain.protocol.CollectionProtocolEvent;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.Permissions;
import edu.ucdavis.caelmir.util.PrivilegeUtil;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.beans.SessionDataBean;
import edu.wustl.common.bizlogic.DefaultBizLogic;
import edu.wustl.common.util.dbManager.DAOException;

/**Title:TODO
 * Description: This class is used as an action class when user clicks on the "add data" or "done" link to add or 
 * modify any proteomics related data for any animal.
 * Copyright:TODO
 * @see  org.apache.struts.action.Action
 * @author Vishvesh Mulay
 * @version 1.0
 */
public class ProteomicsAction extends Action
{

    /**This method is called when user clicks on the "Add data" or "Done" link for any proteomics data.
     * <br>The method populates all the required lists and passes the control onto the appropriate page.
     * @param form Action form which is associated with the class.
     * @param mapping Action mappings specifying the mapping pages for the specified mapping attributes.
     * @param request HTTPRequest which is submitted from the page.
     * @param response HTTPRespons that is generated for the submitted request.
     * @return ActionForward Actionforward instance specifying which page the control should go to.  
     * @see org.apache.struts.action.Action
     * @see org.apache.struts.action.ActionForm
     * @see org.apache.struts.action.ActionForward
     * @see org.apache.struts.action.ActionMapping
     * @see javax.servlet.http.HttpServletRequest
     * @see javax.servlet.http.HttpServletResponse
     */
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws DAOException
    {
        ProteomicsForm actionForm = (ProteomicsForm) form;
        String operation = request.getParameter(Constants.OPERATION);

        String pageOf = (String) request.getParameter(Constants.PAGEOF);
        request.setAttribute(Constants.PAGEOF, pageOf);
        
        if (actionForm.getAnimalId() == null
                || actionForm.getAnimalId().toString().equals("0"))
        {
            String ID = (String) request.getParameter("animalId");
            if(ID!=null)
             actionForm.setAnimalId(ID);
        }

        String operations = operation;
        if (operation != null && operation.equalsIgnoreCase("addOrEdit")
                || operation.equalsIgnoreCase(Constants.VIEW))
        {
            if (actionForm.getFileName() != null)
            {
                request.setAttribute("fileName", actionForm.getFileName());
                request.setAttribute("systemIdentifier", new Long(actionForm
                        .getId()));
            }

            DefaultBizLogic defaultBizLogic = BizLogicFactory
                    .getDefaultBizLogic();
            Animal mouse = new Mouse();
            if (actionForm.getAnimalId() != null
                    && actionForm.getAnimalId().length() > 0)
            {
                List animalList = defaultBizLogic.retrieve(Mouse.class
                        .getName(), Constants.ID, Long.valueOf(actionForm
                        .getAnimalId()));

                if (animalList != null)
                {
                    mouse = (Animal) animalList.get(0);
                    request.setAttribute("animal", mouse.getId().toString());

                    request.setAttribute(Constants.ANIMAL_ID, mouse.getId()
                            .toString());

                    request.setAttribute("event", actionForm.getEventId());
                    request.setAttribute("Experiment", mouse.getCohort()
                            .getExperiment().getName());

                    request.setAttribute("experimentId", mouse.getCohort()
                            .getExperiment().getId().toString());

                    Collection collection = mouse.getCohort().getExperiment()
                            .getCollectionProtocolCollection();
                    if (collection != null && !collection.isEmpty())
                    {
                        Iterator iterator = collection.iterator();
                        while (iterator.hasNext())
                        {
                            CollectionProtocol collectionProtocol = (CollectionProtocol) iterator
                                    .next();
                            if (actionForm.getProtocolId() != null
                                    && collectionProtocol.getId()
                                            .equals(
                                                    new Long(actionForm
                                                            .getProtocolId())))
                            {
                                request.setAttribute("protocol",
                                        collectionProtocol.getTitle());

                                //  request.setAttribute("protocolId", collectionProtocol.getId().toString());
                            }

                        }
                    }
                }

                if (operation != null
                        && (operation.equalsIgnoreCase(Constants.VIEW)))
                {
                    Long systemIdentifier = new Long(actionForm
                            .getId());

                    List list = defaultBizLogic.retrieve(
                            ProteomicsEventRecords.class.getName(), "id",
                            systemIdentifier);

                    ProteomicsEventRecords proteomicsEventRecords = null;

                    if (list != null && !list.isEmpty())
                    {
                        proteomicsEventRecords = (ProteomicsEventRecords) list
                                .get(0);
                    }

                    if (proteomicsEventRecords != null)
                    {

                        EntityMap entityMap = (EntityMap) proteomicsEventRecords
                                .getEntityMap();
                        if (entityMap != null)
                        {
                            if (entityMap.getCollectionProtocolEvent() != null
                                    && entityMap.getCollectionProtocolEvent()
                                            .getCollectionProtocol().getId() != null)
                            {
                                request.setAttribute("protocol", entityMap
                                        .getCollectionProtocolEvent()
                                        .getCollectionProtocol().getTitle());
                                request.setAttribute("protocolId", entityMap
                                        .getCollectionProtocolEvent()
                                        .getCollectionProtocol().getId()
                                        .toString());
                            }
                        }
                    }
                }

                List list = defaultBizLogic
                        .retrieve(ProteomicsEventRecords.class.getName(),
                                "animal", mouse);
                if (list != null && !list.isEmpty())
                {
                    Iterator listIterator = list.iterator();
                    while (listIterator.hasNext())
                    {
                        EventRecords eventRecord = (EventRecords) listIterator
                                .next();
                        if (eventRecord != null
                                && !eventRecord
                                        .getActivityStatus()
                                        .equalsIgnoreCase(
                                                Constants.ACTIVITY_STATUS_DISABLED))
                        {
                            /* Collection eventCollection = (Collection) eventRecord.getEntityMap().getCollectionProtocolEvent();
                             if (eventCollection != null && !eventCollection.isEmpty()) {
                             Iterator eventCollectionIterator = eventCollection.iterator();
                             while (eventCollectionIterator.hasNext()) {
                             CollectionProtocolEvent event = (CollectionProtocolEvent) eventCollectionIterator.next();*/
                            EntityMap entityMap = (EntityMap) eventRecord
                                    .getEntityMap();
                            if (entityMap.getId()!=null && actionForm.getEntityMapId() != null
                                    && entityMap.getId().equals(
                                            new Long(actionForm
                                                    .getEntityMapId())))
                            {
                                actionForm.setOperation(Constants.EDIT);
                                operation = Constants.EDIT;
                                actionForm.setId(eventRecord
                                        .getId().longValue());
                                break;
                            }
                        }
                        /*if(eventRecord.getActivityStatus().equalsIgnoreCase(Constants.ACTIVITY_STATUS_DISABLED))
                        {
                            return mapping.findForward(Constants.FAILURE);
                        }*/
                        
                    }
                }
            }
        }

        if (operation != null && operation.equalsIgnoreCase(Constants.EDIT))
        { //check for delete privelege
            if (isAccessPresent(request, Permissions.EXPDATA_DELETE,
                    Permissions.EXPDATA_DELETE_ACCESS_DENIED))
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        true));

                //find the role of the user                    
                boolean role = getRole(request);
                request.setAttribute(Constants.USER_ROLE, new Boolean(role));
            }
            else
            {
                request.setAttribute(Constants.DELETE_PRIVILEGE, new Boolean(
                        false));
            }
        }

        if (actionForm.getAnimalId() != null
                && actionForm.getAnimalId().length() > 0)
        {
            if (operation != null && operation.equalsIgnoreCase("addOrEdit"))
            {
                operation = Constants.ADD;
                actionForm.setOperation(Constants.ADD);
            }
            /*   if(operations.equalsIgnoreCase(Constants.VIEW))
            operation = operations;
        */
        request.setAttribute(Constants.OPERATION,operation);
       
	    	if (operation != null) {
	    		populateProteomics(request,actionForm);
	    	}
            /* if(!operation.equalsIgnoreCase(Constants.VIEW))
                 return mapping.findForward(Constants.PAGE_OF_PROTEOMICS);
             operation = operations;
             */
            request.setAttribute(Constants.OPERATION, operation);

            if (operation != null && operation.equalsIgnoreCase(Constants.EDIT))
            {
                populateProteomics(request, actionForm);
            }

            if (pageOf != null
                    && pageOf
                            .equalsIgnoreCase(Constants.PAGE_OF_PROTEOMICS_APPROVE))
            {
                request.setAttribute(Constants.ACTIVITYSTATUSLIST,
                        Constants.EXPDATA_ACTIVITY_STATUS_VALUES);

                return mapping
                        .findForward(Constants.PAGE_OF_PROTEOMICS_APPROVE);
            }
            if (!operation.equalsIgnoreCase(Constants.VIEW))
                return mapping.findForward(Constants.PAGE_OF_PROTEOMICS);
        }

        if (operations.equalsIgnoreCase(Constants.VIEW))
            operation = operations;

        request.setAttribute(Constants.OPERATION, operation);
        if (actionForm.getOperation() != null
                && actionForm.getOperation().equalsIgnoreCase(Constants.VIEW))
            return mapping.findForward(Constants.PAGE_OF_PROTEOMICS_VIEW);
        else
            return mapping.findForward(Constants.FAILURE);

    }

    private boolean getRole(HttpServletRequest request) throws DAOException
    {
        boolean role = false;

        SessionDataBean sessionDataBean = (SessionDataBean) request
                .getSession().getAttribute(Constants.SESSION_DATA);

        DefaultBizLogic bizLogic = new DefaultBizLogic();
        List creatorlist = (List) bizLogic.retrieve(User.class.getName(),
                Constants.ID, sessionDataBean.getUserId());

        User user = null;
        if (creatorlist != null && !creatorlist.isEmpty())
        {
            user = (User) creatorlist.get(0);
            if (user.getRoleId().toString().equalsIgnoreCase("3")) //if the loginned user is DC
                role = true;
        }

        return role;
    }

    /**
     * To check whether particular privilege is granted for this class 
     * @param request
     * @param privilege
     * @param accessDeniedMessage
     * @return true if access is present otherwise false
     */
    private boolean isAccessPresent(HttpServletRequest request,
            String privilege, String accessDeniedMessage)
    {
        boolean isAccessPresent = PrivilegeUtil.checkPrivilege(this.getClass(),
                EventRecords.class.getName(), request.getSession(), privilege);
        if (!isAccessPresent)
        {
            request.setAttribute(Constants.STATUS_MESSAGE_KEY,
                    accessDeniedMessage);
        }
        return isAccessPresent;
    }

    /**
     * 
     * @param request
     * @param actionForm
     * @throws DAOException
     */
    private void populateProteomics(HttpServletRequest request,
            ProteomicsForm actionForm) throws DAOException
    {
        Long systemIdentifier = new Long(actionForm.getId());

        DefaultBizLogic defaultBizLogic = BizLogicFactory.getDefaultBizLogic();

        List list = defaultBizLogic.retrieve(ProteomicsEventRecords.class
                .getName(), Constants.ID, systemIdentifier);
        if (list != null && !list.isEmpty())
        {
            ProteomicsEventRecords proteomics = (ProteomicsEventRecords) list
                    .get(0);
            actionForm.setAllValues(proteomics);
            request.setAttribute(Constants.FILE_NAME, actionForm.getFileName());
            request.setAttribute("systemIdentifier", new Long(actionForm
                    .getId()));
        }

    }

}
