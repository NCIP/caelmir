
package edu.ucdavis.caelmir.domain.eventRecords;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import edu.ucdavis.caelmir.actionForm.CaseForm;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.StorageManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.exception.AssignDataException;
import edu.wustl.common.util.Utility;

/**
 * The diagnosis of the disease is the conclusion drawn after correlation of the animal's signs and 
 * symptoms with the pathology results 
 * @hibernate.joined-subclass table="CAELMIR_PATHOLOGY_ER"
 * @hibernate.joined-subclass-key column="IDENTIFIER"
 * 
 */

public class PathologyEventRecords extends EventRecords
        implements
            java.io.Serializable
{

    public PathologyEventRecords()
    {
        this.setName(Variables.Pathology);
        
    }

    public PathologyEventRecords(AbstractActionForm form) throws AssignDataException
    {
        setAllValues(form);
        // TODO Auto-generated constructor stub
    }

    private static final long serialVersionUID = 1234567890L;

    /**Diagnosis of the pathology*/
    private String diagnosis;

    /***/
    private String gross;

    /***/
    private String microscopicDescription;

    /***/
    private String pathologyNumber;

    /***/
    private Date submittedDate;

    /***/
    private Collection tissueCollection = new HashSet();
    
    
    /**
     * @return Returns the disgnosis.
     * @hibernate.property name="diagnosis" type="string" length="3000" column="DIAGNOSIS" 
     */
    public String getDiagnosis()
    {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis)
    {
        this.diagnosis = diagnosis;
    }

    /**
     * @return Returns the gross.
     * @hibernate.property name="gross" type="string" column="GROSS" length="300"
     */
    public String getGross()
    {
        return gross;
    }

    
    public void setGross(String gross)
    {
        this.gross = gross;
    }

    
    /**
     * @return Returns the microscopicDescription.
     * @hibernate.property name="microscopicDescription" type="string" column="MICROSCOPIC_DESCRIPTION" length="3000"
     */
    public String getMicroscopicDescription()
    {
        return microscopicDescription;
    }

    public void setMicroscopicDescription(String microscopicDescription)
    {
        this.microscopicDescription = microscopicDescription;
    }

    /**
     * @return Returns the pathologyNumber.
     * @hibernate.property name="pathologyNumber" type="string" column="pathnum" length="20"
     */
    public String getPathologyNumber()
    {
        return pathologyNumber;
    }

    public void setPathologyNumber(String pathologyNumber)
    {
        this.pathologyNumber = pathologyNumber;
    }

    /**
     * @return Returns the dateSubmitted.
     * @hibernate.property name="submittedDate" type="date" column="SUBMITTED_DATE"
     */
    public Date getSubmittedDate()
    {
        return submittedDate;
    }

    public void setSubmittedDate(Date submittedDate)
    {
        this.submittedDate = submittedDate;
    }

    /**
     * @return Returns the tissueCollection.
     * @hibernate.set name="tissueCollection"
     *                table="TISSUE" cascade="save-update"
     *                inverse="true" lazy="false"
     * @hibernate.collection-key column="CASE_ID"
     * @hibernate.collection-one-to-many class="edu.ucdavis.caelmir.domain.eventRecords.Tissue"
     */
    public Collection getTissueCollection()
    {
        //			try{
        //			   if(tissueCollection.size() == 0) {}
        //		           } catch(Exception e) {			     
        //			      ApplicationService applicationService = ApplicationServiceProvider.getApplicationService();
        //			      try {
        //			      
        //			      
        //			         
        //				 	edu.ucdavis.caelmir.domain.dataElements.PathologyDataElements thisIdSet = new edu.ucdavis.caelmir.domain.dataElements.PathologyDataElements();
        //			         	thisIdSet.setId(this.getId());
        //			         	 Collection resultList = applicationService.search("edu.ucdavis.caelmir.domain.dataElements.Tissue", thisIdSet);				 
        //				 	tissueCollection = resultList;  
        //				 	return resultList;
        //				 
        //			      
        //			      }catch(Exception ex) 
        //			      {
        //			      	System.out.println("PathologyDataElements:getTissueCollection throws exception ... ...");
        //			   		ex.printStackTrace(); 
        //			      }
        //			   }	
        return tissueCollection;
    }
    
    public void setAllValues(AbstractActionForm actionForm) 
    {
        CaseForm caseForm = (CaseForm)actionForm;
        if (caseForm.getAnimalId() != null) {
        Mouse mouse = new Mouse() ;
        mouse.setId(caseForm.getAnimalId());
        this.setAnimal(mouse);
        }
        
        this.setName(Variables.Pathology);        
        this.pathologyNumber = caseForm.getPathologyNumber();
        try {
            this.setCreatedDate(Utility.parseDate(caseForm.getDateSubmitted()));
            this.submittedDate=Utility.parseDate(caseForm.getDateSubmitted());
        }
        catch(Exception e) {
            e.printStackTrace();
           
        }
        EntityMap entityMap = new  EntityMap();
        entityMap.setId(new Long(caseForm.getEntityMapId()));      
        setEntityMap(entityMap);
        
        this.gross = caseForm.getGross();
        this.microscopicDescription = caseForm.getMicroscopicDescription();
        this.diagnosis = caseForm.getDiagnosis().trim();
        
        if(caseForm.getOperation().equalsIgnoreCase(Constants.ADD))
            this.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
        else
            this.setActivityStatus(caseForm.getActivityStatus());
        
        
        String status = caseForm.getActivityStatus();
        if (status != null
                && (Constants.ACTIVITY_STATUS_DISABLED)
                        .equalsIgnoreCase(status))
        {
            //eform.setActivityStatus(null);            
           // this.deleteObject(pform);
            caseForm.setActivityStatus(null);
        }
               
                     
        StorageManager storage = new StorageManager();
        storage.setMap(Constants.POSITION,caseForm.getSourceLocal());
        
        //add tissue coll 
        
        Set tissueSet = new HashSet();
        String tissueId[] = caseForm.getTissueArr();
        if (tissueId != null)
        {
            for (int i = 0; i < caseForm.getTissueArr().length; i++)
            {
                String ID = tissueId[i];
                Long tissueID = new Long(ID);
                Tissue tissue = new Tissue();
                tissue.setId(tissueID);
                tissueSet.add(tissue);
            }
        }
        setTissueCollection(tissueSet);
            
        
    }
    
    public void deleteObject(CaseForm actionForm)
    {
    //    this.setActivityStatus (Constants.ACTIVITY_STATUS_ACTIVE);
        this.diagnosis="";
        this.gross="";
        this.microscopicDescription="";
        this.pathologyNumber="";
        this.submittedDate=null;
   //    this.tissueCollection = new HashSet();
        
        
      //  Cohort.setCohortStatus(cohortCollection,Constants.ACTIVITY_STATUS_DISABLED, deleteCohortFlag);

    }
    
    
    public void setTissueCollection(Collection tissueCollection)
    {
        this.tissueCollection = tissueCollection;
    }

    public boolean equals(Object obj)
    {
        boolean eq = false;
        if (obj instanceof PathologyEventRecords)
        {
            PathologyEventRecords c = (PathologyEventRecords) obj;
            Long thisId = getId();

            if (thisId != null && thisId.equals(c.getId()))
            {
                eq = true;
            }

        }
        return eq;
    }

    public int hashCode()
    {
        int h = 0;

        if (getId() != null)
        {
            h += getId().hashCode();
        }

        return h;
    }

 
}