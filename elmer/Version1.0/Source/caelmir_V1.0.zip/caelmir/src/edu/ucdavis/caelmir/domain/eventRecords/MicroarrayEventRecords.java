package edu.ucdavis.caelmir.domain.eventRecords;
import java.io.FileNotFoundException;
import java.io.IOException;

import edu.ucdavis.caelmir.actionForm.MicroarrayForm;
import edu.ucdavis.caelmir.domain.common.EntityMap;
import edu.ucdavis.caelmir.domain.subject.Animal;
import edu.ucdavis.caelmir.domain.subject.Mouse;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.ucdavis.caelmir.util.global.Variables;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.exception.AssignDataException;



/**
  * A set of attributes that define microarray data
  * @hibernate.joined-subclass table="CAELMIR_MICROARRAY_ER"
  * @hibernate.joined-subclass-key column="IDENTIFIER"
  */

public  class MicroarrayEventRecords extends EventRecords implements java.io.Serializable 
{
	
    private static final long serialVersionUID = 1234567890L;

	/**Byte array representation of the daata file*/
    private byte[] dataFile;
     
    /**Reference id of the CaArray object*/
    private java.lang.Long referenceId;
    
    /**Description of the data*/
    private String description;
	   
    /**
     * 
     */
    private String contentType;
    /**
     * 
     */
    
    private String fileName;
    /**
     * 
     */
    
    private Long fileSize;
    
    public MicroarrayEventRecords()
    {
        this.setName(Variables.Microarray);
        // TODO Auto-generated constructor stub
    }
    /**
     * @hibernate.property name="dataFile" type="edu.ucdavis.caelmir.domain.common.BinaryBlobType" column="DATA_FILE"  
     * @return Returns the dataFile.
     */
	   public byte[] getDataFile(){
	      return dataFile;
	   }
	   public void setDataFile(byte[] dataFile){
	      this.dataFile = dataFile;
	   }
	
       
       
       /**
         * Returns the id of the csm user.
         * @hibernate.property name="referenceId" type="long" column="REFERENCE_ID" length="20"
         * @return Returns the password.
         */
	   public  java.lang.Long getReferenceId(){
	      return referenceId;
	   }
	   public void setReferenceId( java.lang.Long referenceId){
	      this.referenceId = referenceId;
	   }
	
      
       /**
         * Returns the loginname assigned to user.
         * @hibernate.property name="description" type="string" column="DESCRIPTION" length="2000"
         * unique="true"
         * @return Returns the description.
         */
	   public String getDescription(){
	      return description;
	   }
	   public void setDescription(String description){
	      this.description = description;
	   }
	

	

		public boolean equals(Object obj){
			boolean eq = false;
			if(obj instanceof MicroarrayEventRecords) {
				MicroarrayEventRecords c =(MicroarrayEventRecords)obj; 			 
				Long thisId = getId();		
				
					if(thisId != null && thisId.equals(c.getId())) {
					   eq = true;
				    }		
				
			}
			return eq;
		}
		
		public int hashCode(){
			int h = 0;
			
			if(getId() != null) {
				h += getId().hashCode();
			}
			
			return h;
	}
	
          
      public  MicroarrayEventRecords(AbstractActionForm form) throws AssignDataException    {
            setAllValues(form);
            // TODO Auto-generated constructor stub
        }
      
      public void setAllValues(AbstractActionForm actionForm) 
      {
          MicroarrayForm pform = (MicroarrayForm)actionForm;
          if (pform.getAnimalId() != null) {
          Long animalId = Long.valueOf(pform.getAnimalId());
          Animal animal = new Mouse();
          animal.setId(animalId);
          this.setAnimal(animal);
          }
          
          
          this.setName(Variables.Microarray);
          EntityMap entityMap = new  EntityMap();
          entityMap.setId(new Long(pform.getEntityMapId()));
        /*  Collection collection = new HashSet();
          collection.add(collectionProtocolEvent);
          
          /*if(getEntityMap() == null)
              setEntityMap().setCollectionProtocolEvent(collectionProtocolEvent);
          else
              getEntityMap().setCollectionProtocolEvent(collectionProtocolEvent);*/
          setEntityMap(entityMap);
          
          this.description = pform.getDescription();
          this.referenceId = pform.getReferenceId();
          
          if(pform.getOperation().equalsIgnoreCase(Constants.ADD))
              this.setActivityStatus(Constants.ACTIVITY_STATUS_ACTIVE);
          else
              this.setActivityStatus(pform.getActivityStatus());
          
          String status = pform.getActivityStatus();
          if (status != null
                  && (Constants.ACTIVITY_STATUS_DISABLED)
                          .equalsIgnoreCase(status))
          {
              //eform.setActivityStatus(null);            
             // this.deleteObject(pform);
              pform.setActivityStatus(null);
          }
                 
          
          try
          {
              if (pform.getDataFile() != null) {
	               this.dataFile = pform.getDataFile().getFileData();
	               this.fileName = pform.getDataFile().getFileName();
	               this.contentType = pform.getDataFile().getContentType();
	               this.fileSize = new Long(pform.getDataFile().getFileSize());
              }
              
              //this.dataFile = pform.getDataFile();
          }
          catch (FileNotFoundException e)
          {
           // TODO Auto-generated catch block
              e.printStackTrace();
          }
          catch (IOException e)
          {
           // TODO Auto-generated catch block
              e.printStackTrace();
          }
          
      }
     
      /**
       * @return Returns the contentType.
       * @hibernate.property name="contentType" type="string" length="30" column="CONTENT_TYPE"
       */
      public String getContentType()
      {
          return contentType;
      }
      /**
       * @param contentType The contentType to set.
       */
      public void setContentType(String contentType)
      {
          this.contentType = contentType;
      }
      /**
       * @return Returns the fileName.
       * @hibernate.property name="fileName" type="string" length="100" column="FILE_NAME"
       */
      public String getFileName()
      {
          return fileName;
      }
      /**
       * @param fileName The fileName to set.
       */
      public void setFileName(String fileName)
      {
          this.fileName = fileName;
      }
      /**
       * @return Returns the fileSize.
       * @hibernate.property name="fileSize" type="long" length="30" column="FILE_SIZE"
       */
      public Long getFileSize()
      {
          return fileSize;
      }
      /**
       * @param fileSize The fileSize to set.
       */
      public void setFileSize(Long fileSize)
      {
          this.fileSize = fileSize;
      }
      
}