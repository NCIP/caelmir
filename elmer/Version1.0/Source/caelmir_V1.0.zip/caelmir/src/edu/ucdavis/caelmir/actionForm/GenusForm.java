/**
 * 
 */
package edu.ucdavis.caelmir.actionForm;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import edu.ucdavis.caelmir.domain.subject.Genus;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.actionForm.AbstractActionForm;
import edu.wustl.common.domain.AbstractDomainObject;
import edu.wustl.common.util.global.ApplicationProperties;
import edu.wustl.common.util.global.Validator;

/**
 * @author ravinder_kankanala
 *
 */
public class GenusForm extends AbstractActionForm {

	
	/**
     * Genus Name
     */
    private String genusName;
  
	
	
	public String getGenusName() {
		return genusName;
	}

	public void setGenusName(String genusName) {
		this.genusName = genusName;
	}


	/**
     * Returns the id assigned to form bean.
     * @return the id assigned to form bean.
     */
	public int getFormId() {
		 return Constants.GENUS_FORM_ID;
	}

	
	/** 
	 * 
	 */
	public void setAllValues(AbstractDomainObject abstractDomain) {
		
		Genus genus = (Genus) abstractDomain;
		
		this.activityStatus = genus.getActivityStatus();
		this.genusName = genus.getGenusName().toString();
		this.id = genus.getSystemIdentifier().longValue();
	}


	/**
     * @return Returns the systemIdentifier.
     */
    public long getSystemIdentifier()
    {
        return id;
    }
    /**
     * @param systemIdentifier The systemIdentifier to set.
     */
    public void setSystemIdentifier(long systemIdentifier)
    {
        this.id = systemIdentifier;
    }
	
	
	
	/**
     * Overrides the validate method of ActionForm.
     * */
    public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
        Validator validator = new Validator();
        
        if (validator.isEmpty(String.valueOf(genusName))) {
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError(
                    "errors.item.required", ApplicationProperties
                            .getValue("genus.name")));
        }
        
       
        return errors;
    }
	
	
	
	protected void reset() {
		
	}

}
