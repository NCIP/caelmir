/**
 *<p>Title: </p>
 *<p>Description:  </p>
 *<p>Copyright:TODO</p>
 *@author 
 *@version 1.0
 */ 
package edu.ucdavis.caelmir.action;

import java.util.Collection;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import edu.common.dynamicextensions.domain.FileAttributeTypeInformation;
import edu.common.dynamicextensions.domaininterface.AttributeInterface;
import edu.common.dynamicextensions.domaininterface.EntityInterface;
import edu.common.dynamicextensions.domaininterface.userinterface.ContainerInterface;
import edu.common.dynamicextensions.entitymanager.EntityManager;
import edu.common.dynamicextensions.entitymanager.EntityManagerInterface;
import edu.common.dynamicextensions.ui.webui.util.WebUIManagerConstants;

import edu.ucdavis.caelmir.util.QueryInterfaceManager;
import edu.ucdavis.caelmir.util.global.Constants;
import edu.wustl.common.action.BaseAction;
import edu.wustl.common.bizlogic.QueryBizLogic;


/**
 * @author sandeep_chinta
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class EventRecordsAddAction extends BaseAction
{

    /* (non-Javadoc)
     * @see edu.wustl.common.action.BaseAction#executeAction(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    protected ActionForward executeAction(ActionMapping mapping, ActionForm arg1,
            HttpServletRequest req, HttpServletResponse res) throws Exception
    {
        String status = req.getParameter(WebUIManagerConstants.OPERATION_STATUS_PARAMETER_NAME);
        String containerId = null;
        containerId = req.getParameter(WebUIManagerConstants.CONTAINER_IDENTIFIER);
        if (containerId != null) {
            EntityManagerInterface entityManagerInterface = EntityManager.getInstance();
           
            ContainerInterface container= entityManagerInterface.getContainerByIdentifier(containerId);
            EntityInterface entity = container.getEntity();
            QueryInterfaceManager.insertMetdataOnCreateEntity(entity,container);
            Collection attributeCollection = entity.getAttributeCollection();
            if(attributeCollection  != null){
                Iterator attributeCollectionIterator = attributeCollection.iterator();
                while(attributeCollectionIterator.hasNext()){
                    AttributeInterface attribute = (AttributeInterface) attributeCollectionIterator.next();
                    //Adding the attribute columns to the table.
                    if ( !(attribute.getAttributeTypeInformation() instanceof FileAttributeTypeInformation) && !(attribute.getIsCollection().booleanValue())) 
                        QueryInterfaceManager.insertMetadataOnAddAttribute(attribute);
                }
            }
            QueryBizLogic.initializeQueryData();
        }
        if(!status.equals(WebUIManagerConstants.SUCCESS)) {
            req.setAttribute("message","Unable To Create Entity");
           // return mapping.findForward(Constants.FAILURE);
        } else {
            req.setAttribute("message","Entity Created Successfully");
        }
        return mapping.findForward(Constants.SUCCESS);
    }

}
