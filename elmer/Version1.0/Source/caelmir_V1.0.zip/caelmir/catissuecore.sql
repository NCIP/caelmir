alter table CAELMIR_TISSUE drop constraint FK2FC4DE534BDEEC8A
alter table CAELMIR_PROTEOMICS drop constraint FKCABEA34BCE37489D
alter table CAELMIR_USER_GROUP_REL drop constraint FKAACACA932206F20F
alter table CAELMIR_USER_GROUP_REL drop constraint FKAACACA93637E40EF
alter table CAELMIR_STUDY_PROTOCOL drop constraint FK1DC0B3DC9E810B71
alter table CAELMIR_STUDY_PROTOCOL drop constraint FK1DC0B3DC67DD4822
alter table CAELMIR_STUDY drop constraint FKD837167B2206F20F
alter table CAELMIR_STUDY drop constraint FKD837167BA45AA914
alter table CAELMIR_PROTOCOL drop constraint FK87D1F4866F21562E
alter table CAELMIR_EXPERIMENT_PROTOCOL drop constraint FK1721BDECCE37489D
alter table CAELMIR_EXPERIMENT_PROTOCOL drop constraint FK1721BDEC67DD4822
alter table CAELMIR_ANIMAL drop constraint FKF9A9B6A48A08DA5
alter table CAELMIR_COHORT drop constraint FK1311F9632206F20F
alter table CAELMIR_COHORT drop constraint FK1311F963CE37489D
alter table CAELMIR_EXPERIMENT drop constraint FK296F7A6B9E810B71
alter table CAELMIR_EXPERIMENT drop constraint FK296F7A6B8519D8DC
alter table CAELMIR_SLIDE drop constraint FKD8334663FEC042B5
alter table CAELMIR_MICROARRAY drop constraint FK7F6D6C83CE37489D
alter table CAELMIR_USER drop constraint FK935D80B96CD94566
alter table CAELMIR_USER drop constraint FK935D80B9808A4B7A
alter table CAELMIR_USER drop constraint FK935D80B91792AD22
alter table CAELMIR_STUDY_GROUP drop constraint FK6CD86F9B9E810B71
alter table CAELMIR_STUDY_GROUP drop constraint FK6CD86F9B637E40EF
alter table CAELMIR_PATHOLOGY_IMAGE drop constraint FK1FB0CCCDE2CBF289
alter table CAELMIR_PATHOLOGY_IMAGE drop constraint FK1FB0CCCDC8AE1BBE
alter table CAELMIR_EXPERIMENT_GROUP drop constraint FK94D21F8B637E40EF
alter table CAELMIR_EXPERIMENT_GROUP drop constraint FK94D21F8BCE37489D
alter table CAELMIR_EXPERIMENT_USER drop constraint FK4F25ED1FCE37489D
alter table CAELMIR_EXPERIMENT_USER drop constraint FK4F25ED1F2206F20F
drop table CAELMIR_ADDRESS cascade constraints
drop table CAELMIR_TISSUE cascade constraints
drop table CAELMIR_PROTEOMICS cascade constraints
drop table CAELMIR_USER_GROUP_REL cascade constraints
drop table CAELMIR_ANIMAL_IMPORT cascade constraints
drop table CAELMIR_STUDY_PROTOCOL cascade constraints
drop table CAELMIR_IMAGE_TYPE cascade constraints
drop table CAELMIR_CASE cascade constraints
drop table CAELMIR_STUDY cascade constraints
drop table CAELMIR_PROTOCOL cascade constraints
drop table CAELMIR_STUDY_USER cascade constraints
drop table CAELMIR_TGMOUSE cascade constraints
drop table CAELMIR_EXPERIMENT_PROTOCOL cascade constraints
drop table CAELMIR_ANIMAL cascade constraints
drop table CAELMIR_COHORT cascade constraints
drop table CAELMIR_EXPERIMENT cascade constraints
drop table CAELMIR_SLIDE cascade constraints
drop table CAELMIR_USER_GROUP cascade constraints
drop table CAELMIR_MICROARRAY cascade constraints
drop table CAELMIR_USER cascade constraints
drop table CAELMIR_STUDY_GROUP cascade constraints
drop table CAELMIR_REPORTED_PROBLEM cascade constraints
drop table CAELMIR_PATHOLOGY_IMAGE cascade constraints
drop table CAELMIR_EXPERIMENT_GROUP cascade constraints
drop table CAELMIR_INSTITUTION cascade constraints
drop table CAELMIR_EXPERIMENT_USER cascade constraints
drop sequence CAELMIR_CASE_SEQ
drop sequence CAELMIR_ADDRESS_SEQ
drop sequence CAELMIR_USER_SEQ
drop sequence CAELMIR_COHORT_SEQ
drop sequence CAELMIR_EXPERIMENT_SEQ
drop sequence CAELMIR_ANIMAL_SEQ
drop sequence CAELMIR_USER_GROUP_SEQ
drop sequence CAELMIR_INSTITUTION_SEQ
drop sequence CAELMIR_REPORTED_PROBLEM_SEQ
drop sequence CAELMIR_TISSUE_SEQ
drop sequence CAELMIR_STUDY_USER_SEQ
drop sequence CAELMIR_SLIDE_SEQ
drop sequence CAELMIR_PROTOCOL_SEQ
drop sequence CAELMIR_PATHOLOGY_IMAGE_SEQ
drop sequence CAELMIR_MICROARRAY_SEQ
drop sequence CAELMIR_PROTEOMICS_SEQ
drop sequence CAELMIR_IMAGE_TYPE_SEQ
drop sequence CAELMIR_STUDY_SEQ
create table CAELMIR_ADDRESS (
   IDENTIFIER number(19,0) not null,
   STREET varchar2(50),
   CITY varchar2(50),
   STATE varchar2(50),
   COUNTRY varchar2(50),
   ZIPCODE varchar2(30),
   primary key (IDENTIFIER)
)
create table CAELMIR_TISSUE (
   IDENTIFIER number(19,0) not null,
   ACTIVITY_STATUS varchar2(50),
   CASE_ID number(19,0),
   TISSUE_LONG_NAME varchar2(100),
   TISSUE_SHORT_NAME varchar2(50),
   primary key (IDENTIFIER)
)
create table CAELMIR_PROTEOMICS (
   ID number(19,0) not null,
   DESCRIPTION varchar2(200),
   DATA_FILE blob,
   CONTENTS_TYPE varchar2(200),
   FILE_NAME varchar2(200),
   FILE_SIZE number(19,0),
   EXPERIMENT_ID number(19,0),
   primary key (ID)
)
create table CAELMIR_USER_GROUP_REL (
   USER_ID number(19,0) not null,
   USER_GROUP_ID number(19,0) not null,
   primary key (USER_GROUP_ID, USER_ID)
)
create table CAELMIR_ANIMAL_IMPORT (
   ANIMAL_INDEX number(19,0) not null,
   BIRTH_DATE date,
   EAR_CODE varchar2(32),
   GENOTYPE varchar2(16),
   SEX varchar2(32),
   STAIN varchar2(128),
   primary key (ANIMAL_INDEX)
)
create table CAELMIR_STUDY_PROTOCOL (
   PROTOCOL_ID number(19,0) not null,
   STUDY_ID number(19,0) not null,
   primary key (STUDY_ID, PROTOCOL_ID)
)
create table CAELMIR_IMAGE_TYPE (
   IDENTIFIER number(19,0) not null,
   IMAGE_TYPE varchar2(50),
   primary key (IDENTIFIER)
)
create table CAELMIR_CASE (
   IDENTIFIER number(19,0) not null,
   SUBMITTED_DATE date,
   DIAGNOSIS varchar2(254),
   GROSS varchar2(300),
   LAST_EDITED_DATE date,
   MICROSCOPIC_DESCRIPTION varchar2(300),
   pathnum varchar2(20),
   ANIMAL_IDENTIFICATION_NUMBER varchar2(50),
   primary key (IDENTIFIER)
)
create table CAELMIR_STUDY (
   IDENTIFIER number(19,0) not null,
   MODEL_ID number(19,0),
   GENOTYPE varchar2(100),
   ACTUAL_STRAIN varchar2(100),
   MAIN_STRAIN varchar2(100),
   DESCRIPTION varchar2(255),
   HYPOTHESIS varchar2(100),
   NAME varchar2(150),
   INVESTIGATION_START_DATE date,
   INVESTIGATION_STOP_DATE date,
   PRIMARY_INVESTIGATOR_ID number(19,0),
   USER_ID number(19,0),
   ACTIVITY_STATUS varchar2(10),
   primary key (IDENTIFIER)
)
create table CAELMIR_PROTOCOL (
   IDENTIFIER number(19,0) not null,
   DESCRIPTION varchar2(100),
   NAME varchar2(100),
   TYPE varchar2(100),
   CREATOR_ID number(19,0),
   primary key (IDENTIFIER)
)
create table CAELMIR_STUDY_USER (
   IDENTIFIER number(19,0) not null,
   ACTIVITY_STATUS varchar2(10),
   ROLE_ID number(19,0),
   STUDY_ID number(19,0),
   USER_ID number(19,0),
   primary key (IDENTIFIER)
)
create table CAELMIR_TGMOUSE (
   pathnum varchar2(20) not null,
   diagnosis varchar2(254),
   micro varchar2(300),
   primary key (pathnum)
)
create table CAELMIR_EXPERIMENT_PROTOCOL (
   EXPERIMENT_ID number(19,0) not null,
   PROTOCOL_ID number(19,0) not null,
   primary key (PROTOCOL_ID, EXPERIMENT_ID)
)
create table CAELMIR_ANIMAL (
   IDENTIFIER number(19,0) not null,
   LOCAL_ANIMAL_NUMBER number(10,0),
   ANIMAL_COLONY_REFERENCE varchar2(100),
   BASE_STRAIN varchar2(100),
   STRAIN varchar2(100),
   BIRTH_DATE date,
   GENE_OF_INTEREST varchar2(100),
   GENOTYPE varchar2(100),
   SEX char(1),
   LENGTH double precision,
   WEIGHT double precision,
   ACTIVITY_STATUS varchar2(10),
   COHORT_ID number(19,0),
   primary key (IDENTIFIER)
)
create table CAELMIR_COHORT (
   IDENTIFIER number(19,0) not null,
   EXPERIMENT_ID number(19,0),
   USER_ID number(19,0),
   ACTIVITY_STATUS varchar2(10),
   CREATED_DATE date,
   EXPERIMENTAL_CONDITION varchar2(255),
   NAME varchar2(150),
   primary key (IDENTIFIER)
)
create table CAELMIR_EXPERIMENT (
   IDENTIFIER number(19,0) not null,
   HYPOTHESIS varchar2(255),
   NAME varchar2(150),
   EXPERIMENT_START_DATE date,
   EXPERIMENT_STOP_DATE date,
   STUDY_REQUIREMENTS varchar2(255),
   STUDY_ID number(19,0),
   CREATOR_USER_ID number(19,0),
   ACTIVITY_STATUS varchar2(10),
   primary key (IDENTIFIER)
)
create table CAELMIR_SLIDE (
   IDENTIFIER number(19,0) not null,
   ACTIVITY_STATUS varchar2(10),
   DIAGNOSIS varchar2(100),
   MICROSCOPIC_DESCRIPTION varchar2(500),
   SLIDE_NUMBER varchar2(5),
   STAIN varchar2(50),
   TISSUE_ID number(19,0),
   primary key (IDENTIFIER)
)
create table CAELMIR_USER_GROUP (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(150),
   DESCRIPTION varchar2(255),
   ACTIVITY_STATUS varchar2(50),
   primary key (IDENTIFIER)
)
create table CAELMIR_MICROARRAY (
   ID number(19,0) not null,
   DESCRIPTION varchar2(200),
   DATA_FILE blob,
   CONTENTS_TYPE varchar2(200),
   FILE_NAME varchar2(200),
   FILE_SIZE number(19,0),
   EXPERIMENT_ID number(19,0),
   primary key (ID)
)
create table CAELMIR_USER (
   IDENTIFIER number(19,0) not null,
   FAX_NUMBER varchar2(50),
   EMAIL_ADDRESS varchar2(50),
   PASSWORD varchar2(50),
   FIRST_NAME varchar2(50),
   LAST_NAME varchar2(50),
   LOGIN_NAME varchar2(50) not null unique,
   CREATED_DATE date,
   ACTIVITY_STATUS varchar2(10),
   INSTITUTION_ID number(19,0),
   ADDRESS_ID number(19,0),
   CSM_USER_ID number(19,0),
   COMMENTS varchar2(2000),
   PARENT_USER_ID number(19,0),
   PHONE_NUMBER varchar2(50),
   PHONE_POST_HOUR varchar2(50),
   primary key (IDENTIFIER)
)
create table CAELMIR_STUDY_GROUP (
   STUDY_ID number(19,0) not null,
   USER_GROUP_ID number(19,0) not null,
   primary key (USER_GROUP_ID, STUDY_ID)
)
create table CAELMIR_REPORTED_PROBLEM (
   IDENTIFIER number(19,0) not null,
   AFFILIATION varchar2(200) not null,
   NAME_OF_REPORTER varchar2(200) not null,
   REPORTERS_EMAIL_ID varchar2(50) not null,
   MESSAGE_BODY varchar2(200) not null,
   SUBJECT varchar2(100),
   REPORTED_DATE date,
   ACTIVITY_STATUS varchar2(100),
   COMMENTS varchar2(2000),
   primary key (IDENTIFIER)
)
create table CAELMIR_PATHOLOGY_IMAGE (
   IDENTIFIER number(19,0) not null,
   ACTIVITY_STATUS varchar2(10),
   IMAGE blob,
   SLIDE_ID number(19,0),
   CONTENT_TYPE varchar2(50),
   FILE_NAME varchar2(255),
   FILE_SIZE number(19,0),
   IMAGE_TYPE number(19,0),
   primary key (IDENTIFIER)
)
create table CAELMIR_EXPERIMENT_GROUP (
   EXPERIMENT_ID number(19,0) not null,
   USER_GROUP_ID number(19,0) not null,
   primary key (USER_GROUP_ID, EXPERIMENT_ID)
)
create table CAELMIR_INSTITUTION (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(150) not null unique,
   ACTIVITY_STATUS varchar2(10),
   CONTACT_INFORMATION varchar2(255),
   INSTITUTION_CODE varchar2(50),
   WEBSITE_URL varchar2(50),
   primary key (IDENTIFIER)
)
create table CAELMIR_EXPERIMENT_USER (
   EXPERIMENT_ID number(19,0) not null,
   USER_ID number(19,0) not null,
   primary key (USER_ID, EXPERIMENT_ID)
)
alter table CAELMIR_TISSUE add constraint FK2FC4DE534BDEEC8A foreign key (CASE_ID) references CAELMIR_CASE
alter table CAELMIR_PROTEOMICS add constraint FKCABEA34BCE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT
alter table CAELMIR_USER_GROUP_REL add constraint FKAACACA932206F20F foreign key (USER_ID) references CAELMIR_USER
alter table CAELMIR_USER_GROUP_REL add constraint FKAACACA93637E40EF foreign key (USER_GROUP_ID) references CAELMIR_USER_GROUP
alter table CAELMIR_STUDY_PROTOCOL add constraint FK1DC0B3DC9E810B71 foreign key (STUDY_ID) references CAELMIR_STUDY
alter table CAELMIR_STUDY_PROTOCOL add constraint FK1DC0B3DC67DD4822 foreign key (PROTOCOL_ID) references CAELMIR_PROTOCOL
alter table CAELMIR_STUDY add constraint FKD837167B2206F20F foreign key (USER_ID) references CAELMIR_USER
alter table CAELMIR_STUDY add constraint FKD837167BA45AA914 foreign key (PRIMARY_INVESTIGATOR_ID) references CAELMIR_USER
alter table CAELMIR_PROTOCOL add constraint FK87D1F4866F21562E foreign key (CREATOR_ID) references CAELMIR_USER
alter table CAELMIR_EXPERIMENT_PROTOCOL add constraint FK1721BDECCE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT
alter table CAELMIR_EXPERIMENT_PROTOCOL add constraint FK1721BDEC67DD4822 foreign key (PROTOCOL_ID) references CAELMIR_PROTOCOL
alter table CAELMIR_ANIMAL add constraint FKF9A9B6A48A08DA5 foreign key (COHORT_ID) references CAELMIR_COHORT
alter table CAELMIR_COHORT add constraint FK1311F9632206F20F foreign key (USER_ID) references CAELMIR_USER
alter table CAELMIR_COHORT add constraint FK1311F963CE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT
alter table CAELMIR_EXPERIMENT add constraint FK296F7A6B9E810B71 foreign key (STUDY_ID) references CAELMIR_STUDY
alter table CAELMIR_EXPERIMENT add constraint FK296F7A6B8519D8DC foreign key (CREATOR_USER_ID) references CAELMIR_USER
alter table CAELMIR_SLIDE add constraint FKD8334663FEC042B5 foreign key (TISSUE_ID) references CAELMIR_TISSUE
alter table CAELMIR_MICROARRAY add constraint FK7F6D6C83CE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT
alter table CAELMIR_USER add constraint FK935D80B96CD94566 foreign key (ADDRESS_ID) references CAELMIR_ADDRESS
alter table CAELMIR_USER add constraint FK935D80B9808A4B7A foreign key (PARENT_USER_ID) references CAELMIR_USER
alter table CAELMIR_USER add constraint FK935D80B91792AD22 foreign key (INSTITUTION_ID) references CAELMIR_INSTITUTION
alter table CAELMIR_STUDY_GROUP add constraint FK6CD86F9B9E810B71 foreign key (STUDY_ID) references CAELMIR_STUDY
alter table CAELMIR_STUDY_GROUP add constraint FK6CD86F9B637E40EF foreign key (USER_GROUP_ID) references CAELMIR_USER_GROUP
alter table CAELMIR_PATHOLOGY_IMAGE add constraint FK1FB0CCCDE2CBF289 foreign key (SLIDE_ID) references CAELMIR_SLIDE
alter table CAELMIR_PATHOLOGY_IMAGE add constraint FK1FB0CCCDC8AE1BBE foreign key (IMAGE_TYPE) references CAELMIR_IMAGE_TYPE
alter table CAELMIR_EXPERIMENT_GROUP add constraint FK94D21F8B637E40EF foreign key (USER_GROUP_ID) references CAELMIR_USER_GROUP
alter table CAELMIR_EXPERIMENT_GROUP add constraint FK94D21F8BCE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT
alter table CAELMIR_EXPERIMENT_USER add constraint FK4F25ED1FCE37489D foreign key (EXPERIMENT_ID) references CAELMIR_EXPERIMENT
alter table CAELMIR_EXPERIMENT_USER add constraint FK4F25ED1F2206F20F foreign key (USER_ID) references CAELMIR_USER
create sequence CAELMIR_CASE_SEQ
create sequence CAELMIR_ADDRESS_SEQ
create sequence CAELMIR_USER_SEQ
create sequence CAELMIR_COHORT_SEQ
create sequence CAELMIR_EXPERIMENT_SEQ
create sequence CAELMIR_ANIMAL_SEQ
create sequence CAELMIR_USER_GROUP_SEQ
create sequence CAELMIR_INSTITUTION_SEQ
create sequence CAELMIR_REPORTED_PROBLEM_SEQ
create sequence CAELMIR_TISSUE_SEQ
create sequence CAELMIR_STUDY_USER_SEQ
create sequence CAELMIR_SLIDE_SEQ
create sequence CAELMIR_PROTOCOL_SEQ
create sequence CAELMIR_PATHOLOGY_IMAGE_SEQ
create sequence CAELMIR_MICROARRAY_SEQ
create sequence CAELMIR_PROTEOMICS_SEQ
create sequence CAELMIR_IMAGE_TYPE_SEQ
create sequence CAELMIR_STUDY_SEQ
