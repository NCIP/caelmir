alter table CAELMIR_USER drop constraint FK935D80B9F30C2528
alter table CAELMIR_USER drop constraint FK935D80B96CD94566
alter table CAELMIR_USER drop constraint FK935D80B9FFA96920
alter table CAELMIR_USER drop constraint FK935D80B91792AD22
alter table CAELMIR_PROTOCOL drop constraint FK87D1F4866F21562E
alter table CAELMIR_ANIMAL drop constraint FKF9A9B6A48A08DA5
drop table CAELMIR_ADDRESS cascade constraints
drop table CAELMIR_COHORT cascade constraints
drop table CAELMIR_EXPERIMENT cascade constraints
drop table CAELMIR_PROTOCOL_STUDY cascade constraints
drop table CAELMIR_USER cascade constraints
drop table CAELMIR_STUDY cascade constraints
drop table CAELMIR_PROTOCOL cascade constraints
drop table CAELMIR_REPORTED_PROBLEM cascade constraints
drop table CAELMIR_DEPARTMENT cascade constraints
drop table CAELMIR_EXPERIMENT_PROTOCOL cascade constraints
drop table CAELMIR_ANIMAL cascade constraints
drop table CAELMIR_CANCER_RESEARCH_GROUP cascade constraints
drop table CAELMIR_INSTITUTION cascade constraints
drop sequence CATISSUE_CANCER_RES_GRP_SEQ
drop sequence CATISSUE_DEPARTMENT_SEQ
drop sequence CATISSUE_ADDRESS_SEQ
drop sequence CATISSUE_USER_SEQ
drop sequence CAELMIR_PROTOCOL_SEQ
drop sequence CATISSUE_REPORTED_PROBLEM_SEQ
drop sequence CATISSUE_STUDY_SEQ
drop sequence CAELMIR_COHORT_SEQ
drop sequence CAELMIR_EXPERIMENT_SEQ
drop sequence CATISSUE_INSTITUTION_SEQ
drop sequence CAELMIR_ANIMAL_SEQ
create table CAELMIR_ADDRESS (
   IDENTIFIER number(19,0) not null,
   STREET varchar2(50),
   CITY varchar2(50),
   STATE varchar2(50),
   COUNTRY varchar2(50),
   ZIPCODE varchar2(30),
   PHONE_NUMBER varchar2(50),
   FAX_NUMBER varchar2(50),
   primary key (IDENTIFIER)
)
create table CAELMIR_COHORT (
   IDENTIFIER number(19,0) not null,
   EXPERIMENT_CONDITION varchar2(100),
   NAME varchar2(100),
   primary key (IDENTIFIER)
)
create table CAELMIR_EXPERIMENT (
   IDENTIFIER number(19,0) not null,
   HYPOTHESIS varchar2(100),
   NAME varchar2(100),
   START_DATE date,
   STOP_DATE date,
   STUDY_REQUIREMENTS varchar2(100),
   primary key (IDENTIFIER)
)
create table CAELMIR_PROTOCOL_STUDY (
   PROTOCOL_ID number(19,0) not null,
   STUDY_ID number(19,0) not null
)
create table CAELMIR_USER (
   IDENTIFIER number(19,0) not null,
   EMAIL_ADDRESS varchar2(100),
   PASSWORD varchar2(50),
   FIRST_NAME varchar2(50),
   LAST_NAME varchar2(50),
   LOGIN_NAME varchar2(50) not null unique,
   START_DATE date,
   ACTIVITY_STATUS varchar2(50),
   DEPARTMENT_ID number(19,0),
   CANCER_RESEARCH_GROUP_ID number(19,0),
   INSTITUTION_ID number(19,0),
   ADDRESS_ID number(19,0),
   CSM_USER_ID number(19,0),
   STATUS_COMMENT varchar2(2000),
   primary key (IDENTIFIER)
)
create table CAELMIR_STUDY (
   IDENTIFIER number(19,0) not null,
   DESCRIPTION varchar2(100),
   HYPOTHESIS varchar2(100),
   NAME varchar2(100),
   START_DATE date,
   STOP_DATE date,
   primary key (IDENTIFIER)
)
create table CAELMIR_PROTOCOL (
   IDENTIFIER number(19,0) not null,
   DESCRIPTION varchar2(100),
   NAME varchar2(100),
   TYPE varchar2(100),
   CREATOR_ID number(19,0),
   primary key (IDENTIFIER)
)
create table CAELMIR_REPORTED_PROBLEM (
   IDENTIFIER number(19,0) not null,
   AFFILIATION varchar2(200) not null,
   NAME_OF_REPORTER varchar2(200) not null,
   REPORTERS_EMAIL_ID varchar2(50) not null,
   MESSAGE_BODY varchar2(200) not null,
   SUBJECT varchar2(100),
   REPORTED_DATE date,
   ACTIVITY_STATUS varchar2(100),
   COMMENTS varchar2(2000),
   primary key (IDENTIFIER)
)
create table CAELMIR_DEPARTMENT (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(50) not null unique,
   primary key (IDENTIFIER)
)
create table CAELMIR_EXPERIMENT_PROTOCOL (
   PROTOCOL_ID number(19,0) not null,
   EXPERIMENT_ID number(19,0) not null
)
create table CAELMIR_ANIMAL (
   IDENTIFIER number(19,0) not null,
   AGE number(10,0),
   BRAIN_STRAIN varchar2(100),
   GENE_OF_INTEREST number(10,0),
   LOCAL_ANIMAL_NUMBER number(10,0),
   MOUSE_COLONY_IDENTIFIER number(10,0),
   STRAIN varchar2(100),
   COHORT_ID number(19,0),
   primary key (IDENTIFIER)
)
create table CAELMIR_CANCER_RESEARCH_GROUP (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(50) not null unique,
   primary key (IDENTIFIER)
)
create table CAELMIR_INSTITUTION (
   IDENTIFIER number(19,0) not null,
   NAME varchar2(50) not null unique,
   primary key (IDENTIFIER)
)
alter table CAELMIR_USER add constraint FK935D80B9F30C2528 foreign key (DEPARTMENT_ID) references CAELMIR_DEPARTMENT
alter table CAELMIR_USER add constraint FK935D80B96CD94566 foreign key (ADDRESS_ID) references CAELMIR_ADDRESS
alter table CAELMIR_USER add constraint FK935D80B9FFA96920 foreign key (CANCER_RESEARCH_GROUP_ID) references CAELMIR_CANCER_RESEARCH_GROUP
alter table CAELMIR_USER add constraint FK935D80B91792AD22 foreign key (INSTITUTION_ID) references CAELMIR_INSTITUTION
alter table CAELMIR_PROTOCOL add constraint FK87D1F4866F21562E foreign key (CREATOR_ID) references CAELMIR_USER
alter table CAELMIR_ANIMAL add constraint FKF9A9B6A48A08DA5 foreign key (COHORT_ID) references CAELMIR_COHORT
create sequence CATISSUE_CANCER_RES_GRP_SEQ
create sequence CATISSUE_DEPARTMENT_SEQ
create sequence CATISSUE_ADDRESS_SEQ
create sequence CATISSUE_USER_SEQ
create sequence CAELMIR_PROTOCOL_SEQ
create sequence CATISSUE_REPORTED_PROBLEM_SEQ
create sequence CATISSUE_STUDY_SEQ
create sequence CAELMIR_COHORT_SEQ
create sequence CAELMIR_EXPERIMENT_SEQ
create sequence CATISSUE_INSTITUTION_SEQ
create sequence CAELMIR_ANIMAL_SEQ
